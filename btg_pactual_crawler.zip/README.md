# BTG Pactual DTVM PDF Crawler

This Python script crawls the BTG Pactual investor relations website to gather PDF files about debenture emissions, events, and related documents from their fiduciary agent services.

## Overview

BTG Pactual is one of Brazil's largest investment banks and acts as a fiduciary agent (agente fiduciário) for various debenture emissions and financial instruments. This crawler helps gather relevant PDF documents from their investor relations portal.

## Features

- **Automated PDF Discovery**: Automatically finds and downloads PDF documents from the BTG Pactual CVM documents section
- **Keyword Filtering**: Filters documents based on debenture-related keywords (debenture, emission, notes, etc.)
- **Respectful Crawling**: Includes delays between requests to be respectful to the server
- **Error Handling**: Robust error handling for network issues and file operations
- **Logging**: Comprehensive logging for monitoring the crawling process

## Requirements

- Python 3.6+
- Required packages:
  - `requests`
  - `beautifulsoup4`

## Installation

1. Install the required packages:
```bash
pip install requests beautifulsoup4
```

2. Download the crawler script:
```bash
wget https://path/to/btg_pactual_crawler.py
```

## Usage

### Basic Usage

Run the crawler for the current year (2024):
```bash
python3 btg_pactual_crawler.py
```

### Customization

You can modify the script to:

1. **Change target years**: Edit the `years_to_crawl` list in the `main()` function
2. **Add more keywords**: Extend the `debenture_keywords` list in the `filter_debenture_related()` method
3. **Change output directory**: Modify the `output_dir` variable in the `crawl_year()` method

### Example Customization

```python
# In the main() function, change:
years_to_crawl = [2024]
# To:
years_to_crawl = [2022, 2023, 2024]

# In the filter_debenture_related() method, add more keywords:
debenture_keywords = [
    'debenture', 'debênture', 'emissão', 'emission', 'evento', 'event',
    'nota', 'note', 'subordinada', 'subordinated', 'senior', 'fiduciário',
    'fiduciary', 'agente', 'agent', 'comunicado', 'fato relevante',
    'escritura', 'oferta', 'prospecto', 'distribuição', 'securitização',
    'your_custom_keyword'  # Add your own keywords here
]
```

## Output

The crawler creates a directory named `btg_pactual_pdfs_YYYY` (where YYYY is the year) and downloads all relevant PDF files into this directory. Files are named with a sequential number and timestamp for easy identification.

## Website Structure

The crawler targets the BTG Pactual CVM documents page:
- **Base URL**: https://ri.btgpactual.com/documentos-cvm/
- **Document Categories**:
  - Assembleias (Shareholder Meetings)
  - Aviso aos Acionistas (Shareholder Notices)
  - Comunicado ao Mercado (Market Communications)
  - Dados Econômico-Financeiros (Economic-Financial Data)
  - Fato Relevante (Material Facts)
  - Formulário de Referência (Reference Forms)
  - And others...

## Technical Details

### PDF Link Detection

The crawler uses two main strategies to find PDF links:

1. **MZ File Manager Links**: Looks for links containing 'mzfilemanager' (the document management system used by BTG Pactual)
2. **Direct PDF Links**: Searches for links ending with '.pdf'

### Keyword Filtering

Documents are filtered based on context around the links, including:
- Link text
- Parent element text (table rows, list items, etc.)
- Surrounding content

### Rate Limiting

The crawler includes a 1-second delay between downloads to be respectful to the server and avoid overwhelming it with requests.

## Limitations

1. **Year Selection**: The current implementation doesn't automatically select different years from the dropdown. It crawls whatever documents are currently visible on the page.

2. **Dynamic Content**: If the website uses heavy JavaScript for content loading, some documents might not be detected.

3. **Authentication**: The crawler doesn't handle any authentication requirements.

## Troubleshooting

### Common Issues

1. **No documents found**: 
   - Check if the website structure has changed
   - Verify the base URL is still correct
   - Check if there are any access restrictions

2. **Download failures**:
   - Check your internet connection
   - Verify the PDF links are still valid
   - Check if there are any rate limiting restrictions

3. **Permission errors**:
   - Ensure you have write permissions in the current directory
   - Check if antivirus software is blocking file downloads

### Debugging

Enable debug logging by changing the logging level:
```python
logging.basicConfig(level=logging.DEBUG, format="%(asctime)s - %(levelname)s - %(message)s")
```

## Legal Considerations

- This crawler is designed for educational and research purposes
- Ensure compliance with BTG Pactual's terms of service and robots.txt
- Respect rate limits and don't overwhelm the server
- Only download publicly available documents
- Use the downloaded documents in accordance with applicable laws and regulations

## Contributing

Feel free to submit issues and enhancement requests. When contributing:

1. Follow Python PEP 8 style guidelines
2. Add appropriate error handling
3. Include logging for important operations
4. Test with different scenarios

## License

This script is provided as-is for educational purposes. Please ensure compliance with all applicable laws and website terms of service when using this crawler.

