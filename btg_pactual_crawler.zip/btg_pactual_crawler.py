#!/usr/bin/env python3
"""
BTG Pactual DTVM PDF Crawler

This script crawls the BTG Pactual investor relations website to gather PDF files
about debenture emissions, events, and related documents from their fiduciary agent services.

Author: Manus AI
Date: 2025-08-08
"""

import requests
from bs4 import BeautifulSoup
import os
import re
import time
from urllib.parse import urljoin, urlparse
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

class BTGPactualCrawler:
    def __init__(self, base_url="https://ri.btgpactual.com/documentos-cvm/"):
        self.base_url = base_url
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        })
        
    def download_pdf(self, url, folder_path, filename=None):
        """Download a PDF file from the given URL."""
        try:
            response = self.session.get(url, stream=True, timeout=30)
            response.raise_for_status()
            
            if filename is None:
                # Extract filename from URL or generate one
                parsed_url = urlparse(url)
                filename = parsed_url.path.split('/')[-1]
                if not filename or not filename.endswith('.pdf'):
                    filename = f"document_{int(time.time())}.pdf"
            
            if not filename.endswith('.pdf'):
                filename += '.pdf'
                
            file_path = os.path.join(folder_path, filename)
            
            with open(file_path, 'wb') as pdf_file:
                for chunk in response.iter_content(chunk_size=8192):
                    if chunk:
                        pdf_file.write(chunk)
            
            logger.info(f"Downloaded: {filename}")
            return True
            
        except requests.exceptions.RequestException as e:
            logger.error(f"Failed to download {url}: {e}")
            return False
        except Exception as e:
            logger.error(f"Error downloading {url}: {e}")
            return False
    
    def extract_pdf_links(self, html_content):
        """Extract PDF links from HTML content."""
        soup = BeautifulSoup(html_content, 'html.parser')
        pdf_links = []
        
        # Look for links containing 'mzfilemanager' (based on observed pattern)
        for a_tag in soup.find_all('a', href=True):
            href = a_tag['href']
            if 'mzfilemanager' in href:
                # Make sure it's a full URL
                if href.startswith('http'):
                    pdf_links.append(href)
                else:
                    pdf_links.append(urljoin(self.base_url, href))
        
        # Also look for direct PDF links
        for a_tag in soup.find_all('a', href=True):
            href = a_tag['href']
            if href.endswith('.pdf'):
                if href.startswith('http'):
                    pdf_links.append(href)
                else:
                    pdf_links.append(urljoin(self.base_url, href))
        
        return list(set(pdf_links))  # Remove duplicates
    
    def filter_debenture_related(self, links, html_content):
        """Filter links that are related to debentures, emissions, or events."""
        soup = BeautifulSoup(html_content, 'html.parser')
        debenture_keywords = [
            'debenture', 'debênture', 'emissão', 'emission', 'evento', 'event',
            'nota', 'note', 'subordinada', 'subordinated', 'senior', 'fiduciário',
            'fiduciary', 'agente', 'agent', 'comunicado', 'fato relevante',
            'escritura', 'oferta', 'prospecto', 'distribuição', 'securitização'
        ]
        
        filtered_links = []
        
        for link in links:
            # Find the context around the link
            link_element = soup.find('a', href=link)
            if link_element:
                # Get text content around the link
                context_text = ""
                
                # Get the link text itself
                context_text += link_element.get_text(strip=True).lower()
                
                # Get parent element text (e.g., table row, list item)
                parent = link_element.find_parent()
                if parent:
                    context_text += " " + parent.get_text(strip=True).lower()
                
                # Check if any debenture-related keywords are in the context
                if any(keyword.lower() in context_text for keyword in debenture_keywords):
                    filtered_links.append(link)
                    logger.info(f"Found debenture-related document: {link}")
        
        # If no specific matches found, return all links (better to have more than miss important docs)
        if not filtered_links:
            logger.warning("No specific debenture-related documents found based on keywords. Returning all PDF links.")
            return links
        
        return filtered_links
    
    def crawl_year(self, year):
        """Crawl documents for a specific year."""
        logger.info(f"Starting crawl for year {year}")
        
        try:
            # Fetch the main page
            response = self.session.get(self.base_url, timeout=30)
            response.raise_for_status()
            html_content = response.text
            
            # Extract all PDF links
            all_links = self.extract_pdf_links(html_content)
            logger.info(f"Found {len(all_links)} total PDF links")
            
            # Filter for debenture-related documents
            filtered_links = self.filter_debenture_related(all_links, html_content)
            logger.info(f"Found {len(filtered_links)} debenture-related PDF links")
            
            # Create output directory
            output_dir = f"btg_pactual_pdfs_{year}"
            if not os.path.exists(output_dir):
                os.makedirs(output_dir)
            
            # Download PDFs
            successful_downloads = 0
            for i, link in enumerate(filtered_links, 1):
                logger.info(f"Downloading {i}/{len(filtered_links)}: {link}")
                
                # Generate a meaningful filename
                filename = f"btg_document_{i:03d}_{int(time.time())}.pdf"
                
                if self.download_pdf(link, output_dir, filename):
                    successful_downloads += 1
                
                # Be respectful to the server
                time.sleep(1) # Add a small delay between requests
            
            logger.info(f"Crawl completed. Downloaded {successful_downloads}/{len(filtered_links)} documents to {output_dir}")
            return successful_downloads
            
        except requests.exceptions.RequestException as e:
            logger.error(f"Error fetching main page: {e}")
            return 0
        except Exception as e:
            logger.error(f"Unexpected error during crawl: {e}")
            return 0
    
    def crawl_multiple_years(self, years):
        """Crawl documents for multiple years."""
        total_downloads = 0
        for year in years:
            downloads = self.crawl_year(year)
            total_downloads += downloads
        
        logger.info(f"Total downloads across all years: {total_downloads}")
        return total_downloads

def main():
    """Main function to run the crawler."""
    crawler = BTGPactualCrawler()
    
    # Crawl for 2024 (can be extended to multiple years)
    years_to_crawl = [2024]
    
    logger.info("Starting BTG Pactual DTVM PDF Crawler")
    logger.info(f"Target years: {years_to_crawl}")
    
    total_downloads = crawler.crawl_multiple_years(years_to_crawl)
    
    logger.info(f"Crawler finished. Total documents downloaded: {total_downloads}")

if __name__ == "__main__":
    main()


