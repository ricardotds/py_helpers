import requests
from bs4 import BeautifulSoup
import os
from urllib.parse import urljoin

# URL of the Vórtx DTVM debentures page
BASE_URL = "https://www.vortx.com.br/investidor/debenture"

# Directory to save downloaded PDFs
PDF_DIR = "downloaded_pdfs"

# Create the PDF directory if it doesn't exist
os.makedirs(PDF_DIR, exist_ok=True)

def download_pdf(url, filename):
    try:
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; IPABot/1.0)"
        }
        response = requests.get(url, headers=headers, stream=True)
        response.raise_for_status()
        with open(os.path.join(PDF_DIR, filename), 'wb') as pdf_file:
            for chunk in response.iter_content(chunk_size=8192):
                pdf_file.write(chunk)
        print(f"Downloaded {filename}")
    except requests.exceptions.RequestException as e:
        print(f"Error downloading {url}: {e}")

def main():
    print(f"Accessing {BASE_URL} to find PDF links...")
    try:
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36"
        }
        response = requests.get(BASE_URL, headers=headers)
        response.raise_for_status()
        soup = BeautifulSoup(response.content, 'html.parser')

        # Find all links that point to PDF files
        pdf_links = []
        for link in soup.find_all('a', href=True):
            href = link['href']
            if href.endswith('.pdf'):
                # Construct absolute URL if it's relative
                if not href.startswith('http'):
                    href = urljoin(BASE_URL, href)
                pdf_links.append(href)
        
        if not pdf_links:
            print("No PDF links found on the page.")
            return

        print(f"Found {len(pdf_links)} PDF links. Downloading...")
        for i, pdf_url in enumerate(pdf_links):
            filename = f"debenture_{i+1}.pdf"
            download_pdf(pdf_url, filename)

        print("PDF download complete.")

    except requests.exceptions.RequestException as e:
        print(f"Error accessing {BASE_URL}: {e}")

if __name__ == "__main__":
    main()


