#!/usr/bin/env python3
"""
Vórtx DTVM debenture-related PDF crawler

Features
- Starts from Vórtx investor/debenture seeds (configurable)
- Crawls pages within allowed domains (configurable), BFS with depth/size limits
- Respects robots.txt when available
- Detects PDFs via extension and Content-Type (HEAD + small GET fallback)
- Optional keyword filtering for debenture-related terms (enabled by default)
- Optional downloading of external-domain PDFs
- Saves files with deduped names; prints a line per PDF downloaded

Usage examples
  python3 vortx_debenture_pdf_crawler.py \
    --out ./vortx_pdfs --max-pages 500 --max-depth 3 --delay 1.0 \
    --allow-external-pdf --domains vortx.com.br,mziq.com,rad.cvm.gov.br

  python3 vortx_debenture_pdf_crawler.py --no-keyword-filter

Requirements: requests, beautifulsoup4
"""

import argparse
import hashlib
import os
import queue
import re
import sys
import time
from dataclasses import dataclass
from typing import Iterable, Set, Tuple
from urllib.parse import urljoin, urlparse, urldefrag
import urllib.robotparser as robotparser

import requests
from bs4 import BeautifulSoup

# Default seeds (can be extended via --seed)
DEFAULT_SEEDS = [
    "https://www.vortx.com.br/investidor/debenture",
    "https://www.vortx.com.br/investidor",
    "https://www.vortx.com.br/",
    "https://www.vortx.com.br/servicos/corporate-trust",
    "https://www.vortx.com.br/blog",
]

# Portuguese and English keywords commonly found in relevant debenture docs
PDF_KEYWORDS = [
    # Portuguese
    "debenture", "debênture", "debentures", "debêntures",
    "escritura", "escrituras", "emissão", "emissoes", "emissões",
    "anuncio", "anúncio", "inicio", "início",
    "comunicado", "ata", "assembleia", "assembleia geral",
    "evento", "eventos", "evento relevante", "fato relevante",
    "termo", "securitização", "securitizacao",
    "relatório", "relatorio", "acompanhamento",
    "prospecto", "oferta", "distribuição", "distribuicao",
    # English fallbacks
    "indenture", "issuance", "issuances",
    "notice", "announcement", "meeting", "minutes",
    "report", "prospectus", "offering", "distribution",
]

USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/121.0.0.0 Safari/537.36"
)
HEADERS = {
    "User-Agent": USER_AGENT,
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
}

@dataclass
class CrawlConfig:
    out_dir: str
    seeds: Iterable[str]
    allowed_domains: Set[str]
    max_pages: int
    max_depth: int
    request_delay: float
    timeout: float
    follow_external_pdf: bool
    keyword_filter: bool

@dataclass
class CrawlState:
    visited_pages: Set[str]
    downloaded_urls: Set[str]
    enqueued: Set[str]


def norm_url(u: str) -> str:
    u, _ = urldefrag(u)
    return u


def url_domain(u: str) -> str:
    return urlparse(u).netloc.lower()


def same_domain(u: str, allowed: Set[str]) -> bool:
    host = url_domain(u)
    return any(host == d or host.endswith("." + d) for d in allowed)


def is_probably_pdf_url(u: str) -> bool:
    return urlparse(u).path.lower().endswith(".pdf")


def filename_from_url(u: str) -> str:
    path = urlparse(u).path
    name = os.path.basename(path)
    if not name:
        name = hashlib.sha256(u.encode("utf-8")).hexdigest()[:16] + ".pdf"
    return name


def sanitize_filename(name: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]", "_", name)[:200]


def text_contains_keywords(text: str, keywords: Iterable[str]) -> bool:
    t = (text or "").lower()
    return any(k.lower() in t for k in keywords)


def ensure_dir(path: str) -> None:
    os.makedirs(path, exist_ok=True)


def load_robots_txt(base: str, headers: dict, timeout: float) -> robotparser.RobotFileParser | None:
    try:
        p = urlparse(base)
        robots_url = f"{p.scheme}://{p.netloc}/robots.txt"
        rp = robotparser.RobotFileParser()
        rp.set_url(robots_url)
        resp = requests.get(robots_url, headers=headers, timeout=timeout)
        if resp.status_code >= 400:
            return None
        rp.parse(resp.text.splitlines())
        return rp
    except Exception:
        return None


def robots_allowed(rp: robotparser.RobotFileParser | None, url: str) -> bool:
    if rp is None:
        return True
    try:
        return rp.can_fetch(USER_AGENT, url)
    except Exception:
        return True


def head_is_pdf(url: str, headers: dict, timeout: float) -> Tuple[bool, int]:
    """Try HEAD; if inconclusive, do a tiny GET with Range. Returns (is_pdf, status)."""
    try:
        rh = requests.head(url, headers=headers, allow_redirects=True, timeout=timeout)
        ct = rh.headers.get("Content-Type", "").lower()
        if "application/pdf" in ct:
            return True, rh.status_code
        # Fallback small GET
        rg_headers = headers.copy()
        rg_headers["Range"] = "bytes=0-1023"
        rg = requests.get(url, headers=rg_headers, stream=True, timeout=timeout)
        ctg = rg.headers.get("Content-Type", "").lower()
        if "application/pdf" in ctg:
            return True, rg.status_code
        if is_probably_pdf_url(url):
            return True, rg.status_code
        return False, rg.status_code
    except requests.RequestException:
        return False, 0


def download_pdf(url: str, out_dir: str, headers: dict, timeout: float) -> str | None:
    try:
        resp = requests.get(url, headers=headers, stream=True, timeout=timeout)
        resp.raise_for_status()
        fname = sanitize_filename(filename_from_url(url))
        fpath = os.path.join(out_dir, fname)
        if os.path.exists(fpath):
            stem, ext = os.path.splitext(fname)
            alt = f"{stem}_{hashlib.sha256(url.encode('utf-8')).hexdigest()[:8]}{ext or '.pdf'}"
            fpath = os.path.join(out_dir, alt)
        with open(fpath, "wb") as f:
            for chunk in resp.iter_content(chunk_size=8192):
                if chunk:
                    f.write(chunk)
        return fpath
    except requests.RequestException:
        return None


def crawl(config: CrawlConfig) -> None:
    ensure_dir(config.out_dir)

    robots_cache: dict[str, robotparser.RobotFileParser | None] = {}
    for d in config.allowed_domains:
        robots_cache[d] = load_robots_txt(f"https://{d}/", HEADERS, config.timeout)

    q: queue.Queue[Tuple[str, int]] = queue.Queue()
    state = CrawlState(visited_pages=set(), downloaded_urls=set(), enqueued=set())

    for s in config.seeds:
        s = norm_url(s)
        q.put((s, 0))
        state.enqueued.add(s)

    pages_processed = 0

    while not q.empty() and pages_processed < config.max_pages:
        url, depth = q.get()
        if url in state.visited_pages:
            continue
        state.visited_pages.add(url)

        # Direct PDF URL case (e.g., from external links provided as seeds)
        if is_probably_pdf_url(url):
            if config.follow_external_pdf or same_domain(url, config.allowed_domains):
                if (not config.keyword_filter) or text_contains_keywords(url, PDF_KEYWORDS):
                    if url not in state.downloaded_urls:
                        saved = download_pdf(url, config.out_dir, HEADERS, config.timeout)
                        if saved:
                            state.downloaded_urls.add(url)
                            print(f"[PDF] {url} -> {saved}")
            continue

        if not same_domain(url, config.allowed_domains):
            continue

        host = url_domain(url)
        if not robots_allowed(robots_cache.get(host) or None, url):
            continue

        try:
            time.sleep(config.request_delay)
            resp = requests.get(url, headers=HEADERS, timeout=config.timeout)
        except requests.RequestException:
            continue

        pages_processed += 1
        if resp.status_code >= 400:
            continue

        soup = BeautifulSoup(resp.text, "html.parser")

        # Collect hrefs from any element and from <a> specifically
        hrefs: Set[str] = set()
        for tag in soup.find_all(href=True):
            hrefs.add(tag.get("href"))
        for a in soup.find_all("a", href=True):
            hrefs.add(a["href"])  # de-duplicated by set

        for href in list(hrefs):
            if not href:
                continue
            target = norm_url(urljoin(url, href))

            if is_probably_pdf_url(target):
                if config.follow_external_pdf or same_domain(target, config.allowed_domains):
                    if (not config.keyword_filter) or text_contains_keywords(target, PDF_KEYWORDS) or text_contains_keywords(href, PDF_KEYWORDS):
                        is_pdf, _ = head_is_pdf(target, HEADERS, config.timeout)
                        if is_pdf and target not in state.downloaded_urls:
                            saved = download_pdf(target, config.out_dir, HEADERS, config.timeout)
                            if saved:
                                state.downloaded_urls.add(target)
                                print(f"[PDF] {target} -> {saved}")
                continue

            if depth + 1 <= config.max_depth and same_domain(target, config.allowed_domains):
                if target not in state.visited_pages and target not in state.enqueued:
                    thost = url_domain(target)
                    if robots_allowed(robots_cache.get(thost) or None, target):
                        q.put((target, depth + 1))
                        state.enqueued.add(target)

    print(f"Done. Pages processed: {pages_processed}. PDFs found: {len(state.downloaded_urls)}")


def parse_args(argv: Iterable[str]) -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Crawl Vórtx DTVM sites for debenture-related PDF documents.")
    p.add_argument("--out", dest="out_dir", default="./vortx_pdfs", help="Output directory for downloaded PDFs")
    p.add_argument("--seed", dest="seeds", action="append", default=[], help="Additional seed URL (can repeat)")
    p.add_argument("--max-pages", dest="max_pages", type=int, default=500, help="Max pages to fetch")
    p.add_argument("--max-depth", dest="max_depth", type=int, default=3, help="Max crawl depth from each seed")
    p.add_argument("--delay", dest="delay", type=float, default=1.0, help="Delay between requests (seconds)")
    p.add_argument("--timeout", dest="timeout", type=float, default=20.0, help="Request timeout (seconds)")
    p.add_argument("--allow-external-pdf", dest="allow_external_pdf", action="store_true", help="Also download PDF links that point to external domains")
    p.add_argument("--no-keyword-filter", dest="no_keyword_filter", action="store_true", help="Disable keyword filtering; download all PDFs found")
    p.add_argument(
        "--domains",
        dest="domains",
        default=(
            "vortx.com.br,mziq.com,rad.cvm.gov.br,glbimg.com,"
            "bamboodcm.com,leveragesec.com.br,akrualstorage.blob.core.windows.net,nambbu.net"
        ),
        help="Comma-separated list of allowed domains (default: Vórtx and known external hosts)",
    )
    return p.parse_args(list(argv))


def main(argv: Iterable[str] | None = None) -> None:
    args = parse_args(argv or sys.argv[1:])

    seeds = list(DEFAULT_SEEDS)
    if args.seeds:
        seeds.extend(args.seeds)

    allowed_domains = {d.strip().lower() for d in args.domains.split(",") if d.strip()}

    config = CrawlConfig(
        out_dir=args.out_dir,
        seeds=seeds,
        allowed_domains=allowed_domains,
        max_pages=args.max_pages,
        max_depth=args.max_depth,
        request_delay=args.delay,
        timeout=args.timeout,
        follow_external_pdf=bool(args.allow_external_pdf),
        keyword_filter=not bool(args.no_keyword_filter),
    )

    print("Seeds:")
    for s in seeds:
        print(" -", s)
    print("Allowed domains:")
    for d in sorted(allowed_domains):
        print(" -", d)

    crawl(config)


if __name__ == "__main__":
    main()


