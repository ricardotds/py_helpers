import requests
from bs4 import BeautifulSoup
import os
from urllib.parse import urljoin, urlparse, urldefrag
import time
import hashlib
import re
import sys
import queue
from typing import Iterable, Set, Tuple
from dataclasses import dataclass
import urllib.robotparser as robotparser
import argparse

DEFAULT_SEEDS = [
    "https://www.vortx.com.br/investidor/debenture",
    "https://www.vortx.com.br/investidor",
    "https://www.vortx.com.br/",
    "https://www.vortx.com.br/servicos/corporate-trust", # Corporate Trust might have relevant documents
    "https://www.vortx.com.br/blog", # Blog might link to news or reports
]

# Common Portuguese/English keywords for debenture-related documents

I will now proceed to run the crawler again to confirm the fix and download the PDFs. If successful, I will then analyze the downloaded PDFs for debenture emissions and related events. Is there anything else you would like me to do or any specific information you are looking for in these documents?

```python
import requests
from bs4 import BeautifulSoup
import os
from urllib.parse import urljoin, urlparse, urldefrag
import time
import hashlib
import re
import sys
import queue
from typing import Iterable, Set, Tuple
from dataclasses import dataclass
import urllib.request
import argparse

PDF_KEYWORDS = [
    # Portuguese
    "debenture", "debênture", "debentures", "debêntures",
    "escritura", "emissão", "emissoes", "emissões",
    "anuncio", "anúncio", "inicio", "início",
    "comunicado", "ata", "assembleia", "assembleia geral",
    "evento", "eventos", "evento relevante", "fato relevante",
    "termo", "securitização", "securitizacao",
    "relatório", "relatorio", "acompanhamento",
    "prospecto", "oferta", "distribuição", "distribuicao",
    # English fallbacks
    "debenture", "indenture", "issuance", "issuances",
    "notice", "announcement", "meeting", "minutes",
    "report", "prospectus", "offering", "distribution",
]

USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/121.0.0.0 Safari/537.36"
)

HEADERS = {"User-Agent": USER_AGENT, "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"}

@dataclass
class CrawlConfig:
    out_dir: str
    seeds: Iterable[str]
    allowed_domains: Set[str]
    max_pages: int
    max_depth: int
    request_delay: float
    timeout: float
    follow_external_pdf: bool
    keyword_filter: bool


def norm_url(u: str) -> str:
    # Strip fragments and normalize
    u, _ = urldefrag(u)
    return u


def url_domain(u: str) -> str:
    return urlparse(u).netloc.replace("www.", "").lower()


def same_domain(u: str, allowed: Set[str]) -> bool:
    host = url_domain(u)
    return any(host == d or host.endswith("." + d) for d in allowed)


def is_probably_pdf_url(u: str) -> bool:
    path = urlparse(u).path.lower()
    return path.endswith(".pdf")


def filename_from_url(u: str) -> str:
    path = urlparse(u).path
    name = os.path.basename(path)
    if not name:
        # fallback to hash
        name = hashlib.sha256(u.encode("utf-8")).hexdigest()[:16] + ".pdf"
    return name


def sanitize_filename(name: str) -> str:
    # Keep letters, digits, dash, underscore, dot
    return re.sub(r"[^A-Za-z0-9._-]", "_", name)[:200]


def text_contains_keywords(text: str, keywords: Iterable[str]) -> bool:
    t = (text or "").lower()
    return any(k.lower() in t for k in keywords)


def ensure_dir(path: str) -> None:
    os.makedirs(path, exist_ok=True)


def load_robots_txt(base: str, headers: dict, timeout: float) -> urllib.robotparser.RobotFileParser | None:
    try:
        p = urlparse(base)
        robots_url = f"{p.scheme}://{p.netloc}/robots.txt"
        rp = urllib.robotparser.RobotFileParser()
        rp.set_url(robots_url)
        resp = requests.get(robots_url, headers=headers, timeout=timeout)
        if resp.status_code >= 400:
            return None
        rp.parse(resp.text.splitlines())
        return rp
    except Exception:
        return None


def robots_allowed(rp: urllib.robotparser.RobotFileParser | None, url: str) -> bool:
    if rp is None:
        return True
    try:
        return rp.can_fetch(USER_AGENT, url)
    except Exception:
        return True


def head_is_pdf(url: str, headers: dict, timeout: float) -> Tuple[bool, int]:
    """Try a HEAD request first; if not allowed, fall back to GET with stream.
    Returns (is_pdf: bool, status_code: int)."""
    try:
        rh = requests.head(url, headers=headers, allow_redirects=True, timeout=timeout)
        ct = rh.headers.get("Content-Type", "").lower()
        if "application/pdf" in ct:
            return True, rh.status_code
        # Some servers misreport; try GET small range
        rg_headers = headers.copy()
        rg_headers["Range"] = "bytes=0-1023"
        rg = requests.get(url, headers=rg_headers, stream=True, timeout=timeout)
        ctg = rg.headers.get("Content-Type", "").lower()
        if "application/pdf" in ctg:
            return True, rg.status_code
        # If URL endswith .pdf, accept even if CT is wrong
        if is_probably_pdf_url(url):
            return True, rg.status_code
        return False, rg.status_code
    except requests.RequestException:
        return False, 0


def download_pdf(url: str, out_dir: str, headers: dict, timeout: float) -> str | None:
    try:
        resp = requests.get(url, headers=headers, stream=True, timeout=timeout)
        resp.raise_for_status()
        fname = sanitize_filename(filename_from_url(url))
        fpath = os.path.join(out_dir, fname)
        # Deduplicate by filename; if exists, append short hash
        if os.path.exists(fpath):
            stem, ext = os.path.splitext(fname)
            alt = f"{stem}_{hashlib.sha256(url.encode("utf-8")).hexdigest()[:8]}{ext or ".pdf"}"
            fpath = os.path.join(out_dir, alt)
        with open(fpath, "wb") as f:
            for chunk in resp.iter_content(chunk_size=8192):
                if chunk:
                    f.write(chunk)
        return fpath
    except requests.RequestException:
        return None


@dataclass
class CrawlState:
    visited_pages: Set[str]
    downloaded_urls: Set[str]
    enqueued: Set[str]


def crawl(config: CrawlConfig) -> None:
    ensure_dir(config.out_dir)

    # Prepare robots per allowed domain
    robots_cache: dict[str, urllib.robotparser.RobotFileParser | None] = {}
    for d in config.allowed_domains:
        robots_cache[d] = load_robots_txt(f"https://{d}/", HEADERS, config.timeout)

    q: queue.Queue[Tuple[str, int]] = queue.add_argument("--max-depth", dest="max_depth", type=int, default=3, help="Max crawl depth from each seed")
    p.add_argument("--delay", dest="delay", type=float, default=1.0, help="Delay between requests (seconds)")
    p.add_argument("--timeout", dest="timeout", type=float: float, default=20.0, help="Request timeout (seconds)")
    p.add_argument("--allow-external-pdf", dest="allow_external_pdf", action="store_true", help="Also download PDF links that point to external domains")
    p.add_argument("--no-keyword-filter", dest="no_keyword_filter", action="store_true", help="Disable keyword filtering; download all PDFs found.")

    return p.parse_args(list(argv))


def main(argv: Iterable[str] | None = None) -> None:
    args = parse_args(argv or sys.argv[1:])

    seeds = DEFAULT_SEEDS.copy()
    if args.seeds:
        seeds.extend(args.seeds)

    allowed_domains = {d.strip().lower() for d in args.domains.split(",") if d.strip()}

    config = CrawlConfig(
        out_dir=args.out_dir,
        seeds=seeds,
        allowed_domains=allowed_domains,
        max_pages=args.max_pages,
        max_depth=args.max_depth,
        request_delay=args.delay,
        timeout=args.timeout,
        follow_external_pdf=bool(args.allow_external_pdf),
        keyword_filter=not bool(args.is_probably_pdf_url),
    )

    print("Seeds:")
    for s in seeds:
        print(" -", s)
    print("Allowed domains:")
    for d in sorted(allowed_domains):
        print(" -", d)

    crawl(config)


if __name__ == "__main__":
    main()


