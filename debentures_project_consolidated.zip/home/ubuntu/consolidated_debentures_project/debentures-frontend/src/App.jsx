import React, { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Loader2, ExternalLink, Search, Play, CheckCircle, XCircle, Clock } from 'lucide-react'
import './App.css'

const API_BASE_URL = 'https://lnh8imcjo7el.manus.space/api'

function App() {
  const [activeTab, setActiveTab] = useState('dashboard')
  const [loading, setLoading] = useState(false)
  const [data, setData] = useState({
    emissoes: [],
    assembleias: [],
    taxas: [],
    eventos: [],
    pdfLinks: []
  })
  const [filters, setFilters] = useState({
    dataInicio: '',
    dataFim: '',
    filtroEmisor: '',
    filtroAgente: ''
  })
  const [crawlerStatus, setCrawlerStatus] = useState([])

  const loadAllData = async () => {
    setLoading(true)
    try {
      const params = new URLSearchParams()
      if (filters.dataInicio) params.append('dataInicio', filters.dataInicio)
      if (filters.dataFim) params.append('dataFim', filters.dataFim)
      if (filters.filtroEmisor) params.append('filtroEmisor', filters.filtroEmisor)

      const [emissoes, assembleias, taxas, eventos, pdfLinks] = await Promise.all([
        fetch(`${API_BASE_URL}/emissoes?${params}`).then(res => res.json()),
        fetch(`${API_BASE_URL}/assembleias`).then(res => res.json()),
        fetch(`${API_BASE_URL}/taxas`).then(res => res.json()),
        fetch(`${API_BASE_URL}/eventos`).then(res => res.json()),
        fetch(`${API_BASE_URL}/pdf-links?${new URLSearchParams({
          filtroEmisor: filters.filtroEmisor,
          filtroAgente: filters.filtroAgente
        })}`).then(res => res.json())
      ])

      setData({ emissoes, assembleias, taxas, eventos, pdfLinks })
    } catch (error) {
      console.error('Erro ao carregar dados:', error)
    } finally {
      setLoading(false)
    }
  }

  const loadCrawlerStatus = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/crawler-status`)
      const status = await response.json()
      setCrawlerStatus(status)
    } catch (error) {
      console.error('Erro ao carregar status dos crawlers:', error)
    }
  }

  const runCrawler = async (agente) => {
    try {
      const response = await fetch(`${API_BASE_URL}/crawler/${agente}`, {
        method: 'POST'
      })
      
      if (response.ok) {
        // Atualizar status imediatamente
        loadCrawlerStatus()
        // Recarregar dados após um tempo
        setTimeout(() => {
          loadAllData()
          loadCrawlerStatus()
        }, 2000)
      }
    } catch (error) {
      console.error('Erro ao executar crawler:', error)
    }
  }

  useEffect(() => {
    loadAllData()
    loadCrawlerStatus()
  }, [filters.dataInicio, filters.dataFim, filters.filtroEmisor, filters.filtroAgente])

  useEffect(() => {
    // Polling para atualizar status dos crawlers
    const interval = setInterval(() => {
      loadCrawlerStatus()
    }, 3000)

    return () => clearInterval(interval)
  }, [])

  const getStatusIcon = (status) => {
    switch (status) {
      case 'processando':
        return <Loader2 className="h-4 w-4 animate-spin text-blue-500" />
      case 'concluido':
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case 'erro':
        return <XCircle className="h-4 w-4 text-red-500" />
      default:
        return <Clock className="h-4 w-4 text-gray-500" />
    }
  }

  const getStatusBadge = (status) => {
    const variants = {
      'inativo': 'secondary',
      'processando': 'default',
      'concluido': 'default',
      'erro': 'destructive'
    }
    
    const colors = {
      'inativo': 'bg-gray-100 text-gray-800',
      'processando': 'bg-blue-100 text-blue-800',
      'concluido': 'bg-green-100 text-green-800',
      'erro': 'bg-red-100 text-red-800'
    }

    return (
      <Badge variant={variants[status]} className={colors[status]}>
        {status === 'inativo' && 'Inativo'}
        {status === 'processando' && 'Processando'}
        {status === 'concluido' && 'Concluído'}
        {status === 'erro' && 'Erro'}
      </Badge>
    )
  }

  const crawlerAgents = [
    { key: 'pentagono', name: 'Pentágono S.A. DTVM' },
    { key: 'vortx', name: 'Vórtx DTVM' },
    { key: 'oliveira_trust', name: 'Oliveira Trust DTVM' },
    { key: 'planner_trustee', name: 'Planner Trustee DTVM Ltda' },
    { key: 'btg_pactual', name: 'BTG Pactual Serviços Financeiros S.A. DTVM' },
    { key: 'brl_trust', name: 'BRL Trust DTVM S.A.' },
    { key: 'xp_investimentos', name: 'XP Investimentos CCTVM S.A.' },
    { key: 'banco_brasil', name: 'Banco do Brasil S.A.' },
    { key: 'itau_dtvm', name: 'Itaú DTVM S.A.' }
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto p-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Sistema de Monitoramento de Debêntures
          </h1>
          <p className="text-gray-600">
            Acompanhamento diário de emissões, assembleias, taxas e eventos de debêntures brasileiras
          </p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-7 h-auto">
            <TabsTrigger value="dashboard" className="text-xs px-2 py-2">Dashboard</TabsTrigger>
            <TabsTrigger value="emissoes" className="text-xs px-2 py-2">Emissões</TabsTrigger>
            <TabsTrigger value="assembleias" className="text-xs px-2 py-2">Assembleias</TabsTrigger>
            <TabsTrigger value="taxas" className="text-xs px-2 py-2">Taxas</TabsTrigger>
            <TabsTrigger value="eventos" className="text-xs px-2 py-2">Eventos</TabsTrigger>
            <TabsTrigger value="pdf-links" className="text-xs px-2 py-2">Links PDF</TabsTrigger>
            <TabsTrigger value="crawlers" className="text-xs px-2 py-2">Controle de Crawlers</TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Emissões</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{data.emissoes.length}</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Assembleias</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{data.assembleias.length}</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Taxas</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{data.taxas.length}</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Eventos</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{data.eventos.length}</div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Filtros</CardTitle>
                <CardDescription>
                  Filtre os dados por período e emissor
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="text-sm font-medium mb-2 block">Data Início</label>
                    <Input
                      type="date"
                      value={filters.dataInicio}
                      onChange={(e) => setFilters(prev => ({ ...prev, dataInicio: e.target.value }))}
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-2 block">Data Fim</label>
                    <Input
                      type="date"
                      value={filters.dataFim}
                      onChange={(e) => setFilters(prev => ({ ...prev, dataFim: e.target.value }))}
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-2 block">Emissor</label>
                    <Input
                      placeholder="Nome do emissor"
                      value={filters.filtroEmisor}
                      onChange={(e) => setFilters(prev => ({ ...prev, filtroEmisor: e.target.value }))}
                    />
                  </div>
                </div>
                <div className="flex justify-between items-center">
                  <Button onClick={loadAllData} disabled={loading}>
                    {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Search className="mr-2 h-4 w-4" />}
                    Buscar
                  </Button>
                  {loading && <span className="text-sm text-gray-500">Carregando dados...</span>}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="emissoes">
            <Card>
              <CardHeader>
                <CardTitle>Emissões de Debêntures</CardTitle>
                <CardDescription>
                  Lista completa das emissões cadastradas ({data.emissoes.length} registros)
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse border border-gray-300">
                    <thead>
                      <tr className="bg-gray-50">
                        <th className="border border-gray-300 px-4 py-2 text-left">Código</th>
                        <th className="border border-gray-300 px-4 py-2 text-left">Emissor</th>
                        <th className="border border-gray-300 px-4 py-2 text-left">Agente Fiduciário</th>
                        <th className="border border-gray-300 px-4 py-2 text-left">Data Emissão</th>
                        <th className="border border-gray-300 px-4 py-2 text-left">Vencimento</th>
                        <th className="border border-gray-300 px-4 py-2 text-left">Taxa</th>
                        <th className="border border-gray-300 px-4 py-2 text-left">Rating</th>
                      </tr>
                    </thead>
                    <tbody>
                      {data.emissoes.map((emissao, index) => (
                        <tr key={index} className="hover:bg-gray-50">
                          <td className="border border-gray-300 px-4 py-2 font-mono">{emissao.codigo}</td>
                          <td className="border border-gray-300 px-4 py-2">{emissao.emissor}</td>
                          <td className="border border-gray-300 px-4 py-2">{emissao.agente_fiduciario}</td>
                          <td className="border border-gray-300 px-4 py-2">{emissao.data_emissao}</td>
                          <td className="border border-gray-300 px-4 py-2">{emissao.data_vencimento}</td>
                          <td className="border border-gray-300 px-4 py-2">{emissao.taxa}</td>
                          <td className="border border-gray-300 px-4 py-2">
                            {emissao.rating && <Badge variant="outline">{emissao.rating}</Badge>}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="assembleias">
            <Card>
              <CardHeader>
                <CardTitle>Assembleias de Debenturistas</CardTitle>
                <CardDescription>
                  Assembleias programadas e realizadas ({data.assembleias.length} registros)
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse border border-gray-300">
                    <thead>
                      <tr className="bg-gray-50">
                        <th className="border border-gray-300 px-4 py-2 text-left">Código</th>
                        <th className="border border-gray-300 px-4 py-2 text-left">Emissor</th>
                        <th className="border border-gray-300 px-4 py-2 text-left">Data</th>
                        <th className="border border-gray-300 px-4 py-2 text-left">Tipo</th>
                        <th className="border border-gray-300 px-4 py-2 text-left">Pauta</th>
                      </tr>
                    </thead>
                    <tbody>
                      {data.assembleias.map((assembleia, index) => (
                        <tr key={index} className="hover:bg-gray-50">
                          <td className="border border-gray-300 px-4 py-2 font-mono">{assembleia.codigo}</td>
                          <td className="border border-gray-300 px-4 py-2">{assembleia.emissor}</td>
                          <td className="border border-gray-300 px-4 py-2">{assembleia.data_assembleia}</td>
                          <td className="border border-gray-300 px-4 py-2">{assembleia.tipo}</td>
                          <td className="border border-gray-300 px-4 py-2">{assembleia.pauta}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="taxas">
            <Card>
              <CardHeader>
                <CardTitle>Taxas e Preços</CardTitle>
                <CardDescription>
                  Taxas indicativas e preços unitários ({data.taxas.length} registros)
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse border border-gray-300">
                    <thead>
                      <tr className="bg-gray-50">
                        <th className="border border-gray-300 px-4 py-2 text-left">Código</th>
                        <th className="border border-gray-300 px-4 py-2 text-left">Emissor</th>
                        <th className="border border-gray-300 px-4 py-2 text-left">Data Referência</th>
                        <th className="border border-gray-300 px-4 py-2 text-left">Preço Unitário</th>
                        <th className="border border-gray-300 px-4 py-2 text-left">Taxa Indicativa</th>
                      </tr>
                    </thead>
                    <tbody>
                      {data.taxas.map((taxa, index) => (
                        <tr key={index} className="hover:bg-gray-50">
                          <td className="border border-gray-300 px-4 py-2 font-mono">{taxa.codigo}</td>
                          <td className="border border-gray-300 px-4 py-2">{taxa.emissor}</td>
                          <td className="border border-gray-300 px-4 py-2">{taxa.data_referencia}</td>
                          <td className="border border-gray-300 px-4 py-2">
                            {taxa.preco_unitario && `R$ ${taxa.preco_unitario.toFixed(2)}`}
                          </td>
                          <td className="border border-gray-300 px-4 py-2">
                            {taxa.taxa_indicativa && `${taxa.taxa_indicativa.toFixed(2)}%`}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="eventos">
            <Card>
              <CardHeader>
                <CardTitle>Eventos Corporativos</CardTitle>
                <CardDescription>
                  Eventos relacionados às debêntures ({data.eventos.length} registros)
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse border border-gray-300">
                    <thead>
                      <tr className="bg-gray-50">
                        <th className="border border-gray-300 px-4 py-2 text-left">Código</th>
                        <th className="border border-gray-300 px-4 py-2 text-left">Emissor</th>
                        <th className="border border-gray-300 px-4 py-2 text-left">Data</th>
                        <th className="border border-gray-300 px-4 py-2 text-left">Tipo</th>
                        <th className="border border-gray-300 px-4 py-2 text-left">Descrição</th>
                      </tr>
                    </thead>
                    <tbody>
                      {data.eventos.map((evento, index) => (
                        <tr key={index} className="hover:bg-gray-50">
                          <td className="border border-gray-300 px-4 py-2 font-mono">{evento.codigo}</td>
                          <td className="border border-gray-300 px-4 py-2">{evento.emissor}</td>
                          <td className="border border-gray-300 px-4 py-2">{evento.data_evento}</td>
                          <td className="border border-gray-300 px-4 py-2">{evento.tipo_evento}</td>
                          <td className="border border-gray-300 px-4 py-2">{evento.descricao}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="pdf-links">
            <Card>
              <CardHeader>
                <CardTitle>Links de Documentos PDF</CardTitle>
                <CardDescription>
                  Documentos PDF encontrados pelos crawlers ({data.pdfLinks.length} registros)
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium mb-2 block">Filtrar por Emissor</label>
                    <Input
                      placeholder="Nome do emissor"
                      value={filters.filtroEmisor}
                      onChange={(e) => setFilters(prev => ({ ...prev, filtroEmisor: e.target.value }))}
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-2 block">Filtrar por Agente</label>
                    <Input
                      placeholder="Nome do agente fiduciário"
                      value={filters.filtroAgente}
                      onChange={(e) => setFilters(prev => ({ ...prev, filtroAgente: e.target.value }))}
                    />
                  </div>
                </div>
                
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse border border-gray-300">
                    <thead>
                      <tr className="bg-gray-50">
                        <th className="border border-gray-300 px-4 py-2 text-left">Código</th>
                        <th className="border border-gray-300 px-4 py-2 text-left">Emissor</th>
                        <th className="border border-gray-300 px-4 py-2 text-left">Documento</th>
                        <th className="border border-gray-300 px-4 py-2 text-left">Agente Fonte</th>
                        <th className="border border-gray-300 px-4 py-2 text-left">Data Coleta</th>
                        <th className="border border-gray-300 px-4 py-2 text-left">Link</th>
                      </tr>
                    </thead>
                    <tbody>
                      {data.pdfLinks.map((pdf, index) => (
                        <tr key={index} className="hover:bg-gray-50">
                          <td className="border border-gray-300 px-4 py-2 font-mono">{pdf.codigo}</td>
                          <td className="border border-gray-300 px-4 py-2">{pdf.emissor}</td>
                          <td className="border border-gray-300 px-4 py-2">{pdf.titulo_documento}</td>
                          <td className="border border-gray-300 px-4 py-2">{pdf.agente_fiduciario}</td>
                          <td className="border border-gray-300 px-4 py-2">
                            {pdf.data_coleta && new Date(pdf.data_coleta).toLocaleDateString('pt-BR')}
                          </td>
                          <td className="border border-gray-300 px-4 py-2">
                            <a
                              href={pdf.url_pdf}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="inline-flex items-center text-blue-600 hover:text-blue-800"
                            >
                              <ExternalLink className="h-4 w-4 mr-1" />
                              Abrir PDF
                            </a>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                
                {data.pdfLinks.length === 0 && (
                  <div className="text-center py-8 text-gray-500">
                    Nenhum documento PDF encontrado. Execute os crawlers para coletar documentos.
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="crawlers">
            <Card>
              <CardHeader>
                <CardTitle>Controle de Crawlers</CardTitle>
                <CardDescription>
                  Execute os crawlers para coletar dados dos agentes fiduciários
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {crawlerAgents.map((agent) => {
                    const status = crawlerStatus.find(s => s.agente_fiduciario === agent.name) || { status: 'inativo' }
                    const isProcessing = status.status === 'processando'
                    
                    return (
                      <Card key={agent.key} className="relative">
                        <CardHeader className="pb-3">
                          <div className="flex items-center justify-between">
                            <CardTitle className="text-sm font-medium">{agent.name}</CardTitle>
                            {getStatusIcon(status.status)}
                          </div>
                          <div className="flex items-center space-x-2">
                            {getStatusBadge(status.status)}
                          </div>
                        </CardHeader>
                        <CardContent className="space-y-3">
                          {status.mensagem && (
                            <p className="text-xs text-gray-600">{status.mensagem}</p>
                          )}
                          
                          {status.inicio_processamento && (
                            <div className="text-xs text-gray-500">
                              <div>Início: {new Date(status.inicio_processamento).toLocaleString('pt-BR')}</div>
                              {status.fim_processamento && (
                                <div>Fim: {new Date(status.fim_processamento).toLocaleString('pt-BR')}</div>
                              )}
                            </div>
                          )}
                          
                          <Button
                            onClick={() => runCrawler(agent.key)}
                            disabled={isProcessing}
                            className="w-full"
                            size="sm"
                          >
                            {isProcessing ? (
                              <>
                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                Processando...
                              </>
                            ) : (
                              <>
                                <Play className="mr-2 h-4 w-4" />
                                Executar Crawler
                              </>
                            )}
                          </Button>
                        </CardContent>
                      </Card>
                    )
                  })}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

export default App

