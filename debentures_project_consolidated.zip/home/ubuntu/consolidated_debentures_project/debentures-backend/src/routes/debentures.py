from flask import Blueprint, jsonify, request
from src.models.debenture import db, Emissao, Assembleia, Taxa, Evento, PDFLink, CrawlerStatus
from datetime import datetime
import time
import threading
import requests
from bs4 import BeautifulSoup
import random
import sqlite3
from sqlalchemy.exc import OperationalError

debentures_bp = Blueprint('debentures', __name__)

def retry_db_operation(func, max_retries=3, delay=0.1):
    """Retry database operations with exponential backoff"""
    for attempt in range(max_retries):
        try:
            return func()
        except (OperationalError, sqlite3.OperationalError) as e:
            if "database is locked" in str(e).lower() and attempt < max_retries - 1:
                time.sleep(delay * (2 ** attempt))
                continue
            raise e
    return None

# Dados mock para simular crawlers
MOCK_DATA = {
    'pentagono': {
        'emissoes': [
            {
                'codigo': 'PTGN11',
                'emissor': 'Pentágono S.A.',
                'agente_fiduciario': 'Pentágono S.A. DTVM',
                'data_emissao': '2024-01-15',
                'data_vencimento': '2027-01-15',
                'valor_nominal': 1000.0,
                'taxa': 'CDI + 2.5%',
                'indexador': 'CDI',
                'rating': 'AA-',
                'garantia': 'Quirografária',
                'conversibilidade': 'Não conversível'
            }
        ],
        'pdfs': [
            {
                'codigo': 'PTGN11',
                'emissor': 'Pentágono S.A.',
                'titulo_documento': 'Escritura de Emissão PTGN11',
                'url_pdf': 'https://www.pentagono.com.br/docs/ptgn11_escritura.pdf'
            }
        ]
    },
    'vortx': {
        'emissoes': [
            {
                'codigo': 'VRTX21',
                'emissor': 'Vórtx DTVM',
                'agente_fiduciario': 'Vórtx DTVM',
                'data_emissao': '2024-02-10',
                'data_vencimento': '2026-02-10',
                'valor_nominal': 1000.0,
                'taxa': 'IPCA + 7.2%',
                'indexador': 'IPCA',
                'rating': 'A+',
                'garantia': 'Fidejussória',
                'conversibilidade': 'Não conversível'
            }
        ],
        'pdfs': [
            {
                'codigo': 'VRTX21',
                'emissor': 'Vórtx DTVM',
                'titulo_documento': 'Relatório Trimestral VRTX21',
                'url_pdf': 'https://www.vortx.com.br/docs/vrtx21_relatorio.pdf'
            }
        ]
    },
    'oliveira_trust': {
        'emissoes': [
            {
                'codigo': 'OLTV31',
                'emissor': 'Oliveira Trust DTVM',
                'agente_fiduciario': 'Oliveira Trust DTVM',
                'data_emissao': '2024-03-05',
                'data_vencimento': '2028-03-05',
                'valor_nominal': 1000.0,
                'taxa': 'CDI + 3.8%',
                'indexador': 'CDI',
                'rating': 'AA',
                'garantia': 'Real',
                'conversibilidade': 'Não conversível'
            }
        ],
        'pdfs': [
            {
                'codigo': 'OLTV31',
                'emissor': 'Oliveira Trust DTVM',
                'titulo_documento': 'Demonstrações Financeiras OLTV31',
                'url_pdf': 'https://www.oliveiratrust.com.br/docs/oltv31_demonstracoes.pdf'
            }
        ]
    },
    'planner_trustee': {
        'emissoes': [
            {
                'codigo': 'PLAN41',
                'emissor': 'Planner Trustee DTVM',
                'agente_fiduciario': 'Planner Trustee DTVM Ltda',
                'data_emissao': '2024-04-12',
                'data_vencimento': '2029-04-12',
                'valor_nominal': 1000.0,
                'taxa': 'CDI + 4.1%',
                'indexador': 'CDI',
                'rating': 'A',
                'garantia': 'Quirografária',
                'conversibilidade': 'Não conversível'
            }
        ],
        'pdfs': [
            {
                'codigo': 'PLAN41',
                'emissor': 'Planner Trustee DTVM',
                'titulo_documento': 'Prospecto de Emissão PLAN41',
                'url_pdf': 'https://www.plannertrust.com.br/docs/plan41_prospecto.pdf'
            }
        ]
    },
    'btg_pactual': {
        'emissoes': [
            {
                'codigo': 'BTGP51',
                'emissor': 'BTG Pactual',
                'agente_fiduciario': 'BTG Pactual Serviços Financeiros S.A. DTVM',
                'data_emissao': '2024-05-20',
                'data_vencimento': '2027-05-20',
                'valor_nominal': 1000.0,
                'taxa': 'IPCA + 6.8%',
                'indexador': 'IPCA',
                'rating': 'AAA',
                'garantia': 'Fidejussória',
                'conversibilidade': 'Não conversível'
            }
        ],
        'pdfs': [
            {
                'codigo': 'BTGP51',
                'emissor': 'BTG Pactual',
                'titulo_documento': 'Relatório de Administração BTGP51',
                'url_pdf': 'https://www.btgpactual.com/docs/btgp51_relatorio.pdf'
            }
        ]
    },
    'brl_trust': {
        'emissoes': [
            {
                'codigo': 'BRLT61',
                'emissor': 'BRL Trust',
                'agente_fiduciario': 'BRL Trust DTVM S.A.',
                'data_emissao': '2024-06-15',
                'data_vencimento': '2026-06-15',
                'valor_nominal': 1000.0,
                'taxa': 'CDI + 2.9%',
                'indexador': 'CDI',
                'rating': 'A+',
                'garantia': 'Real',
                'conversibilidade': 'Não conversível'
            }
        ],
        'pdfs': [
            {
                'codigo': 'BRLT61',
                'emissor': 'BRL Trust',
                'titulo_documento': 'Balanço Patrimonial BRLT61',
                'url_pdf': 'https://www.brltrust.com.br/docs/brlt61_balanco.pdf'
            }
        ]
    },
    'xp_investimentos': {
        'emissoes': [
            {
                'codigo': 'XPIN71',
                'emissor': 'XP Investimentos',
                'agente_fiduciario': 'XP Investimentos CCTVM S.A.',
                'data_emissao': '2024-07-08',
                'data_vencimento': '2028-07-08',
                'valor_nominal': 1000.0,
                'taxa': 'IPCA + 8.1%',
                'indexador': 'IPCA',
                'rating': 'AA+',
                'garantia': 'Quirografária',
                'conversibilidade': 'Não conversível'
            }
        ],
        'pdfs': [
            {
                'codigo': 'XPIN71',
                'emissor': 'XP Investimentos',
                'titulo_documento': 'Ata de Assembleia XPIN71',
                'url_pdf': 'https://www.xpi.com.br/docs/xpin71_ata.pdf'
            }
        ]
    },
    'banco_brasil': {
        'emissoes': [
            {
                'codigo': 'BBAS81',
                'emissor': 'Banco do Brasil',
                'agente_fiduciario': 'Banco do Brasil S.A.',
                'data_emissao': '2024-08-25',
                'data_vencimento': '2029-08-25',
                'valor_nominal': 1000.0,
                'taxa': 'CDI + 3.2%',
                'indexador': 'CDI',
                'rating': 'AAA',
                'garantia': 'Fidejussória',
                'conversibilidade': 'Não conversível'
            }
        ],
        'pdfs': [
            {
                'codigo': 'BBAS81',
                'emissor': 'Banco do Brasil',
                'titulo_documento': 'Fato Relevante BBAS81',
                'url_pdf': 'https://www.bb.com.br/docs/bbas81_fato_relevante.pdf'
            }
        ]
    },
    'itau_dtvm': {
        'emissoes': [
            {
                'codigo': 'ITAU91',
                'emissor': 'Itaú DTVM',
                'agente_fiduciario': 'Itaú DTVM S.A.',
                'data_emissao': '2024-09-10',
                'data_vencimento': '2027-09-10',
                'valor_nominal': 1000.0,
                'taxa': 'IPCA + 7.5%',
                'indexador': 'IPCA',
                'rating': 'AAA',
                'garantia': 'Real',
                'conversibilidade': 'Não conversível'
            }
        ],
        'pdfs': [
            {
                'codigo': 'ITAU91',
                'emissor': 'Itaú DTVM',
                'titulo_documento': 'Comunicado ao Mercado ITAU91',
                'url_pdf': 'https://www.itau.com.br/docs/itau91_comunicado.pdf'
            }
        ]
    }
}

def simulate_crawler(agente_key, agente_nome):
    """Simula o processo de crawler para um agente fiduciário"""
    try:
        def update_status_processing():
            status = CrawlerStatus.query.filter_by(agente_fiduciario=agente_nome).first()
            if not status:
                status = CrawlerStatus(agente_fiduciario=agente_nome)
                db.session.add(status)
            
            status.status = 'processando'
            status.inicio_processamento = datetime.utcnow()
            status.mensagem = 'Iniciando coleta de dados...'
            status.pdfs_encontrados = 0
            db.session.commit()
        
        retry_db_operation(update_status_processing)
        
        # Simular tempo de processamento
        time.sleep(random.uniform(2, 5))
        
        # Obter dados mock
        mock_data = MOCK_DATA.get(agente_key, {})
        emissoes = mock_data.get('emissoes', [])
        pdfs = mock_data.get('pdfs', [])
        
        def insert_data():
            # Inserir emissões
            for emissao_data in emissoes:
                existing = Emissao.query.filter_by(codigo=emissao_data['codigo']).first()
                if not existing:
                    emissao = Emissao(**emissao_data)
                    db.session.add(emissao)
            
            # Inserir PDFs
            for pdf_data in pdfs:
                pdf_data["agente_fiduciario"] = agente_nome
                existing = PDFLink.query.filter_by(
                    codigo=pdf_data['codigo'], 
                    url_pdf=pdf_data['url_pdf']
                ).first()
                if not existing:
                    pdf_link = PDFLink(**pdf_data)
                    db.session.add(pdf_link)
            
            db.session.commit()
        
        retry_db_operation(insert_data)
        
        def update_status_completed():
            status = CrawlerStatus.query.filter_by(agente_fiduciario=agente_nome).first()
            if status:
                status.status = 'concluido'
                status.fim_processamento = datetime.utcnow()
                status.mensagem = f'Dados coletados com sucesso. {len(pdfs)} PDFs encontrados.'
                status.pdfs_encontrados = len(pdfs)
                db.session.commit()
        
        retry_db_operation(update_status_completed)
        
    except Exception as e:
        def update_status_error():
            status = CrawlerStatus.query.filter_by(agente_fiduciario=agente_nome).first()
            if status:
                status.status = 'erro'
                status.fim_processamento = datetime.utcnow()
                status.mensagem = f'Erro durante a coleta: {str(e)}'
                db.session.commit()
        
        retry_db_operation(update_status_error)

@debentures_bp.route('/emissoes', methods=['GET'])
def get_emissoes():
    try:
        def query_emissoes():
            data_inicio = request.args.get("dataInicio")
            data_fim = request.args.get("dataFim")
            filtro_emissor = request.args.get("filtroEmisor", "").strip()
            
            query = Emissao.query
            
            if filtro_emissor:
                query = query.filter(Emissao.emissor.ilike(f"%{filtro_emissor}%"))
            
            if data_inicio:
                query = query.filter(Emissao.data_emissao >= data_inicio)
            
            if data_fim:
                query = query.filter(Emissao.data_emissao <= data_fim)
            
            emissoes = query.all()
            
            result = []
            for emissao in emissoes:
                result.append({
                    "id": emissao.id,
                    "codigo": emissao.codigo,
                    "emissor": emissao.emissor,
                    "agente_fiduciario": emissao.agente_fiduciario,
                    "data_emissao": emissao.data_emissao,
                    "data_vencimento": emissao.data_vencimento,
                    "valor_nominal": emissao.valor_nominal,
                    "taxa": emissao.taxa,
                    "indexador": emissao.indexador,
                    "rating": emissao.rating,
                    "garantia": emissao.garantia,
                    "conversibilidade": emissao.conversibilidade
                })
            
            return result
        
        result = retry_db_operation(query_emissoes)
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@debentures_bp.route('/assembleias', methods=['GET'])
def get_assembleias():
    try:
        def query_assembleias():
            assembleias = Assembleia.query.all()
            result = []
            for assembleia in assembleias:
                result.append({
                    'id': assembleia.id,
                    'codigo': assembleia.codigo,
                    'emissor': assembleia.emissor,
                    'data_assembleia': assembleia.data_assembleia,
                    'tipo': assembleia.tipo,
                    'pauta': assembleia.pauta,
                    'agente_fiduciario': assembleia.agente_fiduciario
                })
            return result
        
        result = retry_db_operation(query_assembleias)
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@debentures_bp.route('/taxas', methods=['GET'])
def get_taxas():
    try:
        def query_taxas():
            taxas = Taxa.query.all()
            result = []
            for taxa in taxas:
                result.append({
                    'id': taxa.id,
                    'codigo': taxa.codigo,
                    'emissor': taxa.emissor,
                    'data_referencia': taxa.data_referencia,
                    'preco_unitario': taxa.preco_unitario,
                    'taxa_indicativa': taxa.taxa_indicativa,
                    'agente_fiduciario': taxa.agente_fiduciario
                })
            return result
        
        result = retry_db_operation(query_taxas)
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@debentures_bp.route('/eventos', methods=['GET'])
def get_eventos():
    try:
        def query_eventos():
            eventos = Evento.query.all()
            result = []
            for evento in eventos:
                result.append({
                    'id': evento.id,
                    'codigo': evento.codigo,
                    'emissor': evento.emissor,
                    'data_evento': evento.data_evento,
                    'tipo_evento': evento.tipo_evento,
                    'descricao': evento.descricao,
                    'agente_fiduciario': evento.agente_fiduciario
                })
            return result
        
        result = retry_db_operation(query_eventos)
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@debentures_bp.route('/pdf-links', methods=['GET'])
def get_pdf_links():
    try:
        def query_pdf_links():
            filtro_emissor = request.args.get("filtroEmisor", "").strip()
            filtro_agente = request.args.get("filtroAgente", "").strip()
            
            query = PDFLink.query
            
            if filtro_emissor:
                query = query.filter(PDFLink.emissor.ilike(f"%{filtro_emissor}%"))
            
            if filtro_agente:
                query = query.filter(PDFLink.agente_fiduciario.ilike(f"%{filtro_agente}%"))
            
            pdf_links = query.order_by(PDFLink.data_coleta.desc()).all()
            
            result = []
            for pdf_link in pdf_links:
                result.append({
                    "id": pdf_link.id,
                    "codigo": pdf_link.codigo,
                    "emissor": pdf_link.emissor,
                    "titulo_documento": pdf_link.titulo_documento,
                    "url_pdf": pdf_link.url_pdf,
                    "agente_fiduciario": pdf_link.agente_fiduciario,
                    "data_coleta": pdf_link.data_coleta.isoformat() if pdf_link.data_coleta else None
                })
            
            return result
        
        result = retry_db_operation(query_pdf_links)
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@debentures_bp.route('/crawler-status', methods=['GET'])
def get_crawler_status():
    try:
        def query_crawler_status():
            agentes = [
                'Pentágono S.A. DTVM',
                'Vórtx DTVM',
                'Oliveira Trust DTVM',
                'Planner Trustee DTVM Ltda',
                'BTG Pactual Serviços Financeiros S.A. DTVM',
                'BRL Trust DTVM S.A.',
                'XP Investimentos CCTVM S.A.',
                'Banco do Brasil S.A.',
                'Itaú DTVM S.A.'
            ]
            
            result = []
            for agente in agentes:
                status = CrawlerStatus.query.filter_by(agente_fiduciario=agente).first()
                if not status:
                    status = CrawlerStatus(agente_fiduciario=agente)
                    db.session.add(status)
                    db.session.commit()
                
                result.append({
                    'agente_fiduciario': status.agente_fiduciario,
                    'status': status.status,
                    'inicio_processamento': status.inicio_processamento.isoformat() if status.inicio_processamento else None,
                    'fim_processamento': status.fim_processamento.isoformat() if status.fim_processamento else None,
                    'mensagem': status.mensagem,
                    'pdfs_encontrados': status.pdfs_encontrados
                })
            
            return result
        
        result = retry_db_operation(query_crawler_status)
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@debentures_bp.route('/crawler/<agente>', methods=['POST'])
def run_crawler(agente):
    try:
        agente_mapping = {
            'pentagono': 'Pentágono S.A. DTVM',
            'vortx': 'Vórtx DTVM',
            'oliveira_trust': 'Oliveira Trust DTVM',
            'planner_trustee': 'Planner Trustee DTVM Ltda',
            'btg_pactual': 'BTG Pactual Serviços Financeiros S.A. DTVM',
            'brl_trust': 'BRL Trust DTVM S.A.',
            'xp_investimentos': 'XP Investimentos CCTVM S.A.',
            'banco_brasil': 'Banco do Brasil S.A.',
            'itau_dtvm': 'Itaú DTVM S.A.'
        }
        
        if agente not in agente_mapping:
            return jsonify({'error': 'Agente fiduciário não encontrado'}), 404
        
        agente_nome = agente_mapping[agente]
        
        def check_status():
            status = CrawlerStatus.query.filter_by(agente_fiduciario=agente_nome).first()
            return status and status.status == 'processando'
        
        # Verificar se já está processando
        if retry_db_operation(check_status):
            return jsonify({'error': 'Crawler já está em execução para este agente'}), 400
        
        # Executar crawler de forma síncrona
        simulate_crawler(agente, agente_nome)
        
        return jsonify({'message': f'Crawler {agente_nome} executado com sucesso'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

