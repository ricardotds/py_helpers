# AI Agents Management Platform

A comprehensive, enterprise-ready platform for managing and orchestrating AI workflows. Built with modern cloud-native technologies, it provides a complete pipeline management system similar to n8n and Langflow, with advanced features for AI tool integration, secure execution, and scalable deployment on Azure.

## 🌟 Key Features

- **🔧 Visual Pipeline Builder**: Create complex AI workflows with JSON-based pipeline definitions
- **🤖 AI Tool Integration**: Support for Azure OpenAI, AWS Bedrock, Azure AI Search, and custom Python code
- **🔐 Enterprise Authentication**: Microsoft Entra ID (Azure AD) OAuth2 integration
- **⚡ Real-time Monitoring**: WebSocket-based execution monitoring and notifications
- **🛡️ Secure Execution**: Isolated Python code execution in virtual environments
- **📊 RESTful API**: Comprehensive REST API with OpenAPI documentation
- **💻 Modern UI**: React/TypeScript frontend with responsive design
- **🚀 Cloud Native**: Production-ready deployment on Azure Kubernetes Service
- **📅 Airflow Integration**: Deploy pipelines to Apache Airflow for scheduling
- **🔍 RAG Support**: Retrieval Augmented Generation with Azure AI Search

## 🏗️ Architecture

### Technology Stack
- **Backend**: FastAPI (Python 3.11)
- **Frontend**: React 18 with TypeScript
- **Database**: Azure CosmosDB with MongoDB API
- **Authentication**: Microsoft Entra ID OAuth2
- **Container Platform**: Azure Kubernetes Service (AKS)
- **Pipeline Execution**: Apache Airflow
- **AI Services**: Azure OpenAI, AWS Bedrock, Azure AI Search

### System Overview
```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   React Frontend│    │  FastAPI Backend│    │   CosmosDB      │
│   (Port 3000)   │◄──►│   (Port 8000)   │◄──►│   (MongoDB API) │
└─────────────────┘    └─────────────────┘    └─────────────────┘
         │                       │                       │
         │                       │                       │
         ▼                       ▼                       ▼
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│  Azure AD Auth  │    │  AI Services    │    │  Airflow        │
│  (OAuth2)       │    │  (OpenAI/Bedrock)│    │  (Scheduling)   │
└─────────────────┘    └─────────────────┘    └─────────────────┘
```

## 🚀 Quick Start

### Prerequisites
- Azure subscription with appropriate permissions
- Docker and Kubernetes tools installed
- Node.js 18+ and Python 3.11+

### Local Development

1. **Clone the repository**:
   ```bash
   git clone <repository-url>
   cd ai-agents-platform
   ```

2. **Backend setup**:
   ```bash
   cd backend
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   pip install -r requirements.txt
   cp .env.template .env
   # Edit .env with your configuration
   uvicorn app.main:app --reload
   ```

3. **Frontend setup**:
   ```bash
   cd frontend
   npm install
   cp .env.example .env
   # Edit .env with your configuration
   npm run dev
   ```

4. **Access the application**:
   - Frontend: http://localhost:3000
   - Backend API: http://localhost:8000
   - API Documentation: http://localhost:8000/docs

### Docker Deployment

```bash
# Build and run with Docker Compose
docker-compose up -d

# Access the application
# Frontend: http://localhost:3000
# Backend: http://localhost:8000
```

## 📁 Project Structure

```
ai-agents-platform/
├── backend/                    # FastAPI backend application
│   ├── app/
│   │   ├── api/v1/            # REST API endpoints
│   │   ├── auth/              # Authentication and authorization
│   │   ├── core/              # Core configuration and utilities
│   │   ├── database/          # Database connection and repository
│   │   ├── models/            # Pydantic data models
│   │   ├── services/          # Business logic services
│   │   └── tools/             # AI tool executors
│   ├── tests/                 # Test suite
│   └── requirements.txt       # Python dependencies
├── frontend/                  # React/TypeScript frontend
│   ├── src/
│   │   ├── components/        # Reusable UI components
│   │   ├── contexts/          # React contexts
│   │   ├── lib/               # Utility libraries
│   │   └── pages/             # Application pages
│   └── package.json           # Node.js dependencies
├── k8s/                       # Kubernetes deployment configurations
│   ├── base/                  # Base Kubernetes manifests
│   ├── components/            # Component-specific configurations
│   └── overlays/              # Environment-specific overlays
├── docker/                    # Docker configurations
│   └── generic-executor/      # Pipeline step executor container
├── docs/                      # Comprehensive documentation
│   ├── API_DOCUMENTATION.md   # Complete API reference
│   ├── USER_GUIDE.md          # User manual and tutorials
│   └── DEPLOYMENT_GUIDE.md    # Deployment instructions
└── README.md                  # This file
```

## 📚 Documentation

### Complete Documentation Suite
- **[📖 Final Delivery Summary](FINAL_DELIVERY.md)**: Complete project overview and delivery details
- **[🔌 API Documentation](docs/API_DOCUMENTATION.md)**: Complete REST API reference with examples
- **[👤 User Guide](docs/USER_GUIDE.md)**: Comprehensive user manual with tutorials
- **[🚀 Deployment Guide](docs/DEPLOYMENT_GUIDE.md)**: Production deployment instructions
- **[☸️ Kubernetes Documentation](k8s/README.md)**: Kubernetes-specific deployment details

## 🔧 Core Components

### Pipeline Management
- **Pipeline Builder**: Create and manage AI workflows
- **Step Configuration**: Configure individual pipeline steps
- **Dependency Management**: Define step execution order
- **Validation**: Ensure pipeline integrity and correctness

### AI Tool Integration
- **LLM Tools**: Azure OpenAI and AWS Bedrock integration
- **API Tools**: Generic HTTP API integration
- **RAG Tools**: Azure AI Search for knowledge retrieval
- **Python Tools**: Custom code execution in secure environments

### Resource Management
- **Prompts**: Reusable text templates with variables
- **Schemas**: JSON Schema definitions for data validation
- **Tools**: AI service configurations and settings
- **RAG Indexes**: Document knowledge bases for retrieval

### Execution Engine
- **Real-time Execution**: Live pipeline execution with monitoring
- **WebSocket Updates**: Real-time progress notifications
- **Error Handling**: Comprehensive error reporting and recovery
- **Result Management**: Store and retrieve execution results

## 🔐 Security Features

### Authentication & Authorization
- Microsoft Entra ID OAuth2 integration
- JWT token-based authentication
- Role-based access control (RBAC)
- User group-based permissions

### Infrastructure Security
- Kubernetes network policies
- Pod security standards
- Secret management with Azure Key Vault
- SSL/TLS encryption
- Container image scanning

## 📊 Monitoring & Observability

### Real-time Monitoring
- WebSocket-based live updates
- Pipeline execution progress tracking
- System health monitoring
- Performance metrics collection

### Logging & Metrics
- Structured logging with correlation IDs
- Application performance monitoring
- Resource utilization tracking
- Custom business metrics

## 🚀 Deployment Options

### Local Development
- Docker Compose for local services
- Hot reload for development
- Local database setup
- Development authentication

### Production Deployment
- Azure Kubernetes Service (AKS)
- High availability configuration
- Auto-scaling capabilities
- Production monitoring and alerting

## 🧪 Testing

The project includes a comprehensive test framework:

```bash
# Run backend tests
cd backend
python -m pytest tests/ -v

# Run frontend tests
cd frontend
npm test
```

## 🔄 API Endpoints

### Core Resources
- **Pipelines**: `/api/v1/pipelines` - Pipeline CRUD operations
- **Tools**: `/api/v1/tools` - AI tool management
- **Prompts**: `/api/v1/prompts` - Text template management
- **Schemas**: `/api/v1/schemas` - Data schema definitions
- **RAG Indexes**: `/api/v1/rag-indexes` - Knowledge base management

### Execution & Monitoring
- **Execution**: `/api/v1/execution` - Pipeline execution
- **WebSocket**: `/api/v1/ws` - Real-time updates
- **Airflow**: `/api/v1/airflow` - Pipeline deployment

### Authentication
- **Auth**: `/api/v1/auth` - Microsoft Entra ID integration

## 🌐 Frontend Features

### User Interface
- **Dashboard**: Overview of pipelines and executions
- **Pipeline Builder**: Visual pipeline creation interface
- **Resource Management**: CRUD interfaces for all resources
- **Execution Monitor**: Real-time execution tracking
- **User Profile**: Account and preference management

### Technology Features
- **React 18**: Modern React with hooks and context
- **TypeScript**: Type-safe development
- **Responsive Design**: Mobile and desktop support
- **Real-time Updates**: WebSocket integration
- **Authentication**: Microsoft OAuth2 flow

## 🔧 Configuration

### Environment Variables

#### Backend Configuration
```bash
# Application
APP_NAME=AI Agents Management Platform
DEBUG=false
API_V1_STR=/api/v1

# Database
MONGODB_URL=mongodb://your-cosmosdb.mongo.cosmos.azure.com:10255
DATABASE_NAME=ai_agents_platform

# Authentication
AZURE_CLIENT_ID=your-client-id
AZURE_CLIENT_SECRET=your-client-secret
AZURE_TENANT_ID=your-tenant-id

# AI Services
AZURE_OPENAI_ENDPOINT=https://your-openai.openai.azure.com
AZURE_OPENAI_API_KEY=your-openai-key
AWS_ACCESS_KEY_ID=your-aws-key
AWS_SECRET_ACCESS_KEY=your-aws-secret
AZURE_SEARCH_ENDPOINT=https://your-search.search.windows.net
AZURE_SEARCH_API_KEY=your-search-key
```

#### Frontend Configuration
```bash
REACT_APP_API_URL=http://localhost:8000
REACT_APP_WS_URL=ws://localhost:8000
REACT_APP_AZURE_CLIENT_ID=your-client-id
REACT_APP_AZURE_TENANT_ID=your-tenant-id
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🆘 Support

### Getting Help
- **Documentation**: Check the comprehensive guides in the `docs/` directory
- **API Reference**: Visit `/docs` endpoint for interactive API documentation
- **Issues**: Report bugs and request features via GitHub issues
- **Discussions**: Join community discussions for questions and ideas

### Troubleshooting
- **Common Issues**: Check the troubleshooting section in the user guide
- **Logs**: Review application logs for error details
- **Health Checks**: Use the `/health` endpoint to verify system status

## 🎯 Use Cases

### AI Workflow Automation
- **Content Generation**: Automated content creation pipelines
- **Data Processing**: AI-powered data analysis workflows
- **Document Analysis**: Intelligent document processing
- **Customer Support**: Automated response generation

### Enterprise Integration
- **API Orchestration**: Combine multiple AI services
- **Scheduled Processing**: Automated batch processing
- **Real-time Analytics**: Live data processing pipelines
- **Knowledge Management**: RAG-based information retrieval

## 🔮 Roadmap

### Planned Features
- **Visual Pipeline Editor**: Drag-and-drop pipeline builder
- **Advanced Analytics**: Pipeline performance analytics
- **Multi-cloud Support**: AWS and GCP integration
- **Marketplace**: Community tool and template sharing
- **Advanced Scheduling**: Complex scheduling patterns

### Integration Opportunities
- **GitHub Actions**: CI/CD pipeline integration
- **Slack/Teams**: Notification integrations
- **Data Warehouses**: Direct data source connections
- **MLOps Platforms**: Model deployment integration

---

## 🎉 Ready to Get Started?

1. **📖 Read the Documentation**: Start with the [User Guide](docs/USER_GUIDE.md)
2. **🚀 Deploy Locally**: Follow the Quick Start guide above
3. **☁️ Deploy to Production**: Use the [Deployment Guide](docs/DEPLOYMENT_GUIDE.md)
4. **🔌 Explore the API**: Check out the [API Documentation](docs/API_DOCUMENTATION.md)
5. **💡 Build Your First Pipeline**: Create your first AI workflow!

**Welcome to the future of AI workflow management!** 🚀

