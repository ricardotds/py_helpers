#!/usr/bin/env python3
"""
Generic step executor for AI Agents Platform pipeline steps
Runs in Kubernetes pods to execute individual pipeline steps
"""

import os
import sys
import json
import asyncio
import logging
from typing import Dict, Any, Optional
from datetime import datetime

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class StepExecutor:
    """Generic step executor for all step types"""
    
    def __init__(self):
        self.step_config = self._load_step_config()
        self.step_type = os.getenv("STEP_TYPE")
        self.step_id = os.getenv("STEP_ID")
        self.pipeline_id = os.getenv("PIPELINE_ID")
        self.user_id = os.getenv("USER_ID")
        
        logger.info(f"Initializing step executor: {self.step_type} - {self.step_id}")
    
    def _load_step_config(self) -> Dict[str, Any]:
        """Load step configuration from environment"""
        config_str = os.getenv("STEP_CONFIG")
        if not config_str:
            raise ValueError("STEP_CONFIG environment variable not found")
        
        try:
            return json.loads(config_str)
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON in STEP_CONFIG: {e}")
    
    async def execute(self) -> Dict[str, Any]:
        """Execute the step based on its type"""
        try:
            logger.info(f"Executing step {self.step_id} of type {self.step_type}")
            
            if self.step_type == "llm":
                return await self._execute_llm_step()
            elif self.step_type == "api":
                return await self._execute_api_step()
            elif self.step_type == "rag":
                return await self._execute_rag_step()
            elif self.step_type == "python":
                return await self._execute_python_step()
            else:
                raise ValueError(f"Unknown step type: {self.step_type}")
                
        except Exception as e:
            logger.error(f"Error executing step: {e}")
            raise
    
    async def _execute_llm_step(self) -> Dict[str, Any]:
        """Execute LLM step"""
        from llm_executor import LLMExecutor
        
        executor = LLMExecutor()
        inputs = self._get_step_inputs()
        
        result = await executor.execute(self.step_config, inputs)
        
        return {
            "type": "llm",
            "result": result,
            "timestamp": datetime.utcnow().isoformat()
        }
    
    async def _execute_api_step(self) -> Dict[str, Any]:
        """Execute API step"""
        from api_executor import APIExecutor
        
        executor = APIExecutor()
        inputs = self._get_step_inputs()
        
        result = await executor.execute(self.step_config, inputs)
        
        return {
            "type": "api",
            "result": result,
            "timestamp": datetime.utcnow().isoformat()
        }
    
    async def _execute_rag_step(self) -> Dict[str, Any]:
        """Execute RAG step"""
        from rag_executor import RAGExecutor
        
        executor = RAGExecutor()
        inputs = self._get_step_inputs()
        
        result = await executor.execute(self.step_config, inputs)
        
        return {
            "type": "rag",
            "result": result,
            "timestamp": datetime.utcnow().isoformat()
        }
    
    async def _execute_python_step(self) -> Dict[str, Any]:
        """Execute Python step"""
        from python_executor import PythonExecutor
        
        executor = PythonExecutor()
        inputs = self._get_step_inputs()
        
        result = await executor.execute(self.step_config, inputs)
        
        return {
            "type": "python",
            "result": result,
            "timestamp": datetime.utcnow().isoformat()
        }
    
    def _get_step_inputs(self) -> Dict[str, Any]:
        """Get step inputs from environment or mounted volumes"""
        # In a real implementation, this would read inputs from:
        # - ConfigMaps
        # - Secrets
        # - Previous step outputs stored in shared storage
        # - Environment variables
        
        inputs = {}
        
        # Try to load inputs from environment
        inputs_str = os.getenv("STEP_INPUTS")
        if inputs_str:
            try:
                inputs = json.loads(inputs_str)
            except json.JSONDecodeError:
                logger.warning("Invalid JSON in STEP_INPUTS, using empty inputs")
        
        # Try to load inputs from mounted file
        inputs_file = "/app/inputs/step_inputs.json"
        if os.path.exists(inputs_file):
            try:
                with open(inputs_file, 'r') as f:
                    file_inputs = json.load(f)
                    inputs.update(file_inputs)
            except Exception as e:
                logger.warning(f"Could not load inputs from file: {e}")
        
        return inputs
    
    def _save_outputs(self, outputs: Dict[str, Any]):
        """Save step outputs for next steps"""
        # Save outputs to mounted volume for next steps
        outputs_dir = "/app/outputs"
        os.makedirs(outputs_dir, exist_ok=True)
        
        outputs_file = os.path.join(outputs_dir, f"{self.step_id}_outputs.json")
        try:
            with open(outputs_file, 'w') as f:
                json.dump(outputs, f, indent=2)
            logger.info(f"Outputs saved to {outputs_file}")
        except Exception as e:
            logger.error(f"Could not save outputs: {e}")


async def main():
    """Main execution function"""
    try:
        executor = StepExecutor()
        
        # Execute the step
        result = await executor.execute()
        
        # Save outputs
        executor._save_outputs(result)
        
        # Print result for logging
        print(json.dumps(result, indent=2))
        
        logger.info("Step execution completed successfully")
        sys.exit(0)
        
    except Exception as e:
        logger.error(f"Step execution failed: {e}")
        
        # Print error for logging
        error_result = {
            "error": str(e),
            "timestamp": datetime.utcnow().isoformat(),
            "step_id": os.getenv("STEP_ID"),
            "step_type": os.getenv("STEP_TYPE")
        }
        print(json.dumps(error_result, indent=2))
        
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())

