#!/bin/bash

# Build script for AI Agents Platform Docker images

set -e

echo "Building AI Agents Platform Docker images..."

# Build generic executor image
echo "Building generic-executor image..."
cd generic-executor
docker build -t ai-agents-platform/generic-executor:latest .
cd ..

# Tag images for different step types (they all use the same image)
docker tag ai-agents-platform/generic-executor:latest ai-agents-platform/llm-executor:latest
docker tag ai-agents-platform/generic-executor:latest ai-agents-platform/api-executor:latest
docker tag ai-agents-platform/generic-executor:latest ai-agents-platform/rag-executor:latest
docker tag ai-agents-platform/generic-executor:latest ai-agents-platform/python-executor:latest

echo "Docker images built successfully!"
echo "Available images:"
docker images | grep ai-agents-platform

