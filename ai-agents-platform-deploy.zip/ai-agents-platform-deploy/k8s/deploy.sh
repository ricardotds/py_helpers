#!/bin/bash

# AI Agents Platform Kubernetes Deployment Script

set -e

# Configuration
ENVIRONMENT=${1:-production}
NAMESPACE="ai-agents-platform"
EXECUTION_NAMESPACE="pipeline-execution"

echo "🚀 Deploying AI Agents Platform to Kubernetes"
echo "Environment: $ENVIRONMENT"
echo "Namespace: $NAMESPACE"

# Check if kubectl is available
if ! command -v kubectl &> /dev/null; then
    echo "❌ kubectl is not installed or not in PATH"
    exit 1
fi

# Check if kustomize is available
if ! command -v kustomize &> /dev/null; then
    echo "❌ kustomize is not installed or not in PATH"
    exit 1
fi

# Check if we're connected to a cluster
if ! kubectl cluster-info &> /dev/null; then
    echo "❌ Not connected to a Kubernetes cluster"
    exit 1
fi

echo "✅ Prerequisites check passed"

# Create namespaces first
echo "📦 Creating namespaces..."
kubectl apply -f base/namespaces.yaml

# Wait for namespaces to be ready
kubectl wait --for=condition=Ready namespace/$NAMESPACE --timeout=60s
kubectl wait --for=condition=Ready namespace/$EXECUTION_NAMESPACE --timeout=60s

echo "✅ Namespaces created successfully"

# Apply the configuration using kustomize
echo "🔧 Applying Kubernetes manifests..."
kustomize build overlays/$ENVIRONMENT | kubectl apply -f -

echo "⏳ Waiting for deployments to be ready..."

# Wait for backend deployment
kubectl rollout status deployment/ai-agents-backend -n $NAMESPACE --timeout=300s

# Wait for frontend deployment
kubectl rollout status deployment/ai-agents-frontend -n $NAMESPACE --timeout=300s

echo "✅ Deployments are ready"

# Check pod status
echo "📊 Checking pod status..."
kubectl get pods -n $NAMESPACE
kubectl get pods -n $EXECUTION_NAMESPACE

# Check services
echo "🌐 Checking services..."
kubectl get services -n $NAMESPACE

# Check ingress
echo "🔗 Checking ingress..."
kubectl get ingress -n $NAMESPACE

# Get external IP
echo "🌍 Getting external IP..."
EXTERNAL_IP=$(kubectl get service nginx-ingress-controller -n ingress-nginx -o jsonpath='{.status.loadBalancer.ingress[0].ip}' 2>/dev/null || echo "Not available")
echo "External IP: $EXTERNAL_IP"

echo ""
echo "🎉 AI Agents Platform deployed successfully!"
echo ""
echo "📋 Deployment Summary:"
echo "  Environment: $ENVIRONMENT"
echo "  Namespace: $NAMESPACE"
echo "  Execution Namespace: $EXECUTION_NAMESPACE"
echo "  External IP: $EXTERNAL_IP"
echo ""
echo "🔧 Next steps:"
echo "  1. Configure DNS to point to the external IP"
echo "  2. Update secrets with actual values"
echo "  3. Configure SSL certificates"
echo "  4. Set up monitoring and alerting"
echo ""
echo "📖 Useful commands:"
echo "  kubectl get pods -n $NAMESPACE"
echo "  kubectl logs -f deployment/ai-agents-backend -n $NAMESPACE"
echo "  kubectl logs -f deployment/ai-agents-frontend -n $NAMESPACE"
echo "  kubectl describe ingress ai-agents-platform-ingress -n $NAMESPACE"

