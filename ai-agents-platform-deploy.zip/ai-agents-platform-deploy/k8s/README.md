# AI Agents Platform - Kubernetes Deployment

This directory contains all the Kubernetes manifests and deployment configurations for the AI Agents Platform.

## Architecture Overview

The AI Agents Platform is deployed across multiple namespaces in Azure Kubernetes Service (AKS):

- **ai-agents-platform**: Main application namespace containing backend and frontend services
- **pipeline-execution**: Dedicated namespace for pipeline execution workloads
- **ai-agents-monitoring**: Monitoring and observability components

## Prerequisites

### Required Tools

- `kubectl` - Kubernetes command-line tool
- `kustomize` - Kubernetes configuration management tool
- `helm` (optional) - For installing additional components
- Azure CLI (for AKS management)

### Azure Resources

1. **Azure Kubernetes Service (AKS) Cluster**
   - Minimum 2 node pools: system and execution
   - RBAC enabled
   - Network policy enabled (optional)

2. **Azure Container Registry (ACR)**
   - For storing Docker images
   - Integrated with AKS

3. **Azure Cosmos DB**
   - MongoDB API enabled
   - Connection string configured

4. **Azure AI Search**
   - Search service provisioned
   - API keys configured

5. **Azure Active Directory**
   - App registration for authentication
   - Client ID and secret configured

## Directory Structure

```
k8s/
├── base/                           # Base Kubernetes manifests
│   ├── namespaces.yaml            # Namespace definitions
│   ├── nodepool-execution.yaml    # Node pool configuration
│   └── kustomization.yaml         # Base kustomization
├── components/                     # Component-specific manifests
│   ├── backend/                   # Backend service manifests
│   ├── frontend/                  # Frontend service manifests
│   ├── ingress/                   # Ingress configuration
│   └── monitoring/                # Monitoring setup
├── overlays/                      # Environment-specific overlays
│   ├── development/               # Development environment
│   ├── staging/                   # Staging environment
│   └── production/                # Production environment
├── deploy.sh                      # Deployment script
└── README.md                      # This file
```

## Deployment Guide

### 1. Prepare the Environment

#### Create AKS Cluster with Node Pools

```bash
# Create resource group
az group create --name ai-agents-rg --location eastus

# Create AKS cluster
az aks create \
  --resource-group ai-agents-rg \
  --name ai-agents-aks \
  --node-count 2 \
  --node-vm-size Standard_D4s_v3 \
  --enable-addons monitoring \
  --enable-rbac \
  --generate-ssh-keys

# Add execution node pool
az aks nodepool add \
  --resource-group ai-agents-rg \
  --cluster-name ai-agents-aks \
  --name execution \
  --node-count 1 \
  --min-count 1 \
  --max-count 10 \
  --enable-cluster-autoscaler \
  --node-vm-size Standard_D4s_v3 \
  --node-taints workload=pipeline-execution:NoSchedule \
  --labels workload=pipeline-execution \
  --max-pods 30
```

#### Connect to AKS Cluster

```bash
az aks get-credentials --resource-group ai-agents-rg --name ai-agents-aks
```

### 2. Install Required Components

#### Install NGINX Ingress Controller

```bash
helm repo add ingress-nginx https://kubernetes.github.io/ingress-nginx
helm repo update

helm install ingress-nginx ingress-nginx/ingress-nginx \
  --namespace ingress-nginx \
  --create-namespace \
  --set controller.service.type=LoadBalancer
```

#### Install Cert-Manager (for SSL certificates)

```bash
helm repo add jetstack https://charts.jetstack.io
helm repo update

helm install cert-manager jetstack/cert-manager \
  --namespace cert-manager \
  --create-namespace \
  --set installCRDs=true
```

### 3. Configure Secrets

Before deploying, update the secrets in the overlay files with actual values:

#### Production Secrets (`overlays/production/kustomization.yaml`)

```yaml
secretGenerator:
  - name: ai-agents-backend-secrets
    behavior: replace
    literals:
      - DATABASE_URL=mongodb://your-actual-cosmosdb-connection-string
      - JWT_SECRET_KEY=your-actual-jwt-secret-key
      - AZURE_CLIENT_SECRET=your-actual-azure-client-secret
      - OPENAI_API_KEY=your-actual-openai-api-key
      - OPENAI_API_BASE=https://your-actual-azure-openai-endpoint.openai.azure.com/
      - AWS_ACCESS_KEY_ID=your-actual-aws-access-key
      - AWS_SECRET_ACCESS_KEY=your-actual-aws-secret-key
      - AWS_REGION=us-east-1
      - AZURE_SEARCH_SERVICE_NAME=your-actual-search-service
      - AZURE_SEARCH_API_KEY=your-actual-search-api-key
```

### 4. Build and Push Docker Images

```bash
# Build backend image
docker build -t your-acr.azurecr.io/ai-agents-platform/backend:v1.0.0 ./backend

# Build frontend image
docker build -t your-acr.azurecr.io/ai-agents-platform/frontend:v1.0.0 ./frontend

# Build executor image
docker build -t your-acr.azurecr.io/ai-agents-platform/generic-executor:latest ./docker/generic-executor

# Push images to ACR
az acr login --name your-acr
docker push your-acr.azurecr.io/ai-agents-platform/backend:v1.0.0
docker push your-acr.azurecr.io/ai-agents-platform/frontend:v1.0.0
docker push your-acr.azurecr.io/ai-agents-platform/generic-executor:latest
```

### 5. Deploy the Application

```bash
# Deploy to production
./deploy.sh production

# Or deploy to staging
./deploy.sh staging

# Or deploy to development
./deploy.sh development
```

### 6. Configure DNS

After deployment, configure your DNS to point to the external IP:

```bash
# Get external IP
kubectl get service nginx-ingress-controller -n ingress-nginx

# Configure DNS records:
# A record: ai-agents-platform.com -> EXTERNAL_IP
# A record: api.ai-agents-platform.com -> EXTERNAL_IP
```

## Configuration

### Environment Variables

#### Backend Configuration

| Variable | Description | Required |
|----------|-------------|----------|
| `DATABASE_URL` | CosmosDB connection string | Yes |
| `JWT_SECRET_KEY` | JWT signing secret | Yes |
| `AZURE_CLIENT_SECRET` | Azure AD client secret | Yes |
| `OPENAI_API_KEY` | OpenAI API key | Yes |
| `AWS_ACCESS_KEY_ID` | AWS access key | Yes |
| `AZURE_SEARCH_API_KEY` | Azure Search API key | Yes |

#### Frontend Configuration

| Variable | Description | Required |
|----------|-------------|----------|
| `VITE_API_BASE_URL` | Backend API URL | Yes |
| `VITE_WS_BASE_URL` | WebSocket URL | Yes |
| `VITE_AZURE_CLIENT_ID` | Azure AD client ID | Yes |
| `VITE_AZURE_TENANT_ID` | Azure AD tenant ID | Yes |

### Resource Requirements

#### Backend

- **Requests**: 500m CPU, 1Gi memory
- **Limits**: 1000m CPU, 2Gi memory
- **Replicas**: 3 (production)

#### Frontend

- **Requests**: 200m CPU, 512Mi memory
- **Limits**: 400m CPU, 1Gi memory
- **Replicas**: 2 (production)

#### Pipeline Execution

- **Per Pod Requests**: 100m CPU, 256Mi memory
- **Per Pod Limits**: 1 CPU, 2Gi memory
- **Max Pods**: 100 (per namespace quota)

## Monitoring and Observability

### Health Checks

- Backend health endpoint: `/health`
- Frontend health endpoint: `/`
- Liveness and readiness probes configured

### Metrics

- Prometheus metrics exposed on `/metrics`
- Grafana dashboard included
- Custom alerts for critical issues

### Logging

- Structured logging with JSON format
- Log aggregation via Azure Monitor (if enabled)
- Log retention policies configured

## Troubleshooting

### Common Issues

#### Pods Not Starting

```bash
# Check pod status
kubectl get pods -n ai-agents-platform

# Check pod logs
kubectl logs -f deployment/ai-agents-backend -n ai-agents-platform

# Describe pod for events
kubectl describe pod <pod-name> -n ai-agents-platform
```

#### Ingress Not Working

```bash
# Check ingress status
kubectl get ingress -n ai-agents-platform

# Check ingress controller logs
kubectl logs -f deployment/ingress-nginx-controller -n ingress-nginx

# Check external IP
kubectl get service nginx-ingress-controller -n ingress-nginx
```

#### Database Connection Issues

```bash
# Check secrets
kubectl get secrets -n ai-agents-platform

# Check configmaps
kubectl get configmaps -n ai-agents-platform

# Test database connectivity from pod
kubectl exec -it deployment/ai-agents-backend -n ai-agents-platform -- /bin/bash
```

### Useful Commands

```bash
# View all resources
kubectl get all -n ai-agents-platform

# Check resource usage
kubectl top pods -n ai-agents-platform
kubectl top nodes

# Scale deployments
kubectl scale deployment ai-agents-backend --replicas=5 -n ai-agents-platform

# Update deployment
kubectl rollout restart deployment/ai-agents-backend -n ai-agents-platform

# Check rollout status
kubectl rollout status deployment/ai-agents-backend -n ai-agents-platform
```

## Security Considerations

### Network Policies

- Implement network policies to restrict pod-to-pod communication
- Isolate pipeline execution namespace from main application

### RBAC

- Service accounts with minimal required permissions
- Separate roles for different components
- Regular audit of permissions

### Secrets Management

- Use Azure Key Vault for sensitive data (recommended)
- Rotate secrets regularly
- Never commit secrets to version control

### Image Security

- Scan images for vulnerabilities
- Use minimal base images
- Keep images updated

## Scaling

### Horizontal Pod Autoscaler (HPA)

```yaml
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: ai-agents-backend-hpa
  namespace: ai-agents-platform
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: ai-agents-backend
  minReplicas: 3
  maxReplicas: 10
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
```

### Cluster Autoscaler

- Configured on execution node pool
- Automatically scales nodes based on demand
- Cost-effective for variable workloads

## Backup and Disaster Recovery

### Database Backup

- CosmosDB automatic backups enabled
- Point-in-time recovery available
- Cross-region replication (optional)

### Configuration Backup

- Store Kubernetes manifests in version control
- Regular backup of secrets and configmaps
- Document recovery procedures

## Support

For deployment issues or questions:

1. Check the troubleshooting section above
2. Review pod logs and events
3. Consult the main project documentation
4. Contact the development team

