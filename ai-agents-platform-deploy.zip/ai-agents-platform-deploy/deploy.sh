#!/bin/bash

# AI Agents Management Platform - Deployment Script
# This script helps deploy the platform in different environments

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Print colored output
print_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Display usage
usage() {
    echo "AI Agents Management Platform - Deployment Script"
    echo ""
    echo "Usage: $0 [OPTION]"
    echo ""
    echo "Options:"
    echo "  local       Deploy locally with Docker Compose"
    echo "  k8s         Deploy to Kubernetes cluster"
    echo "  build       Build Docker images"
    echo "  setup       Setup development environment"
    echo "  help        Show this help message"
    echo ""
    echo "Examples:"
    echo "  $0 setup       # Setup development environment"
    echo "  $0 local       # Deploy locally with Docker"
    echo "  $0 build       # Build Docker images"
    echo "  $0 k8s         # Deploy to Kubernetes"
}

# Setup development environment
setup_dev() {
    print_info "Setting up development environment..."
    
    # Check prerequisites
    if ! command_exists python3; then
        print_error "Python 3 is required but not installed."
        exit 1
    fi
    
    if ! command_exists node; then
        print_error "Node.js is required but not installed."
        exit 1
    fi
    
    if ! command_exists npm; then
        print_error "npm is required but not installed."
        exit 1
    fi
    
    # Setup backend
    print_info "Setting up backend..."
    cd backend
    
    if [ ! -d "venv" ]; then
        python3 -m venv venv
        print_success "Created Python virtual environment"
    fi
    
    source venv/bin/activate
    pip install -r requirements.txt
    print_success "Installed Python dependencies"
    
    if [ ! -f ".env" ]; then
        cp .env.template .env
        print_warning "Created .env file from template. Please configure it with your settings."
    fi
    
    cd ..
    
    # Setup frontend
    print_info "Setting up frontend..."
    cd frontend
    
    npm install
    print_success "Installed Node.js dependencies"
    
    if [ ! -f ".env" ]; then
        echo "REACT_APP_API_URL=http://localhost:8000" > .env
        print_warning "Created frontend .env file. Please configure it with your settings."
    fi
    
    cd ..
    
    print_success "Development environment setup complete!"
    print_info "Next steps:"
    echo "  1. Configure backend/.env with your Azure and database settings"
    echo "  2. Configure frontend/.env with your API URL"
    echo "  3. Run 'cd backend && source venv/bin/activate && uvicorn app.main:app --reload'"
    echo "  4. Run 'cd frontend && npm start' in another terminal"
}

# Build Docker images
build_images() {
    print_info "Building Docker images..."
    
    if ! command_exists docker; then
        print_error "Docker is required but not installed."
        exit 1
    fi
    
    # Build backend image
    print_info "Building backend image..."
    docker build -t ai-agents-backend:latest ./backend
    print_success "Built backend image"
    
    # Build frontend image
    print_info "Building frontend image..."
    docker build -t ai-agents-frontend:latest ./frontend
    print_success "Built frontend image"
    
    # Build executor image
    print_info "Building executor image..."
    docker build -t ai-agents-executor:latest ./docker/generic-executor
    print_success "Built executor image"
    
    print_success "All Docker images built successfully!"
}

# Deploy locally with Docker Compose
deploy_local() {
    print_info "Deploying locally with Docker Compose..."
    
    if ! command_exists docker-compose && ! command_exists docker; then
        print_error "Docker and Docker Compose are required but not installed."
        exit 1
    fi
    
    # Check if docker-compose.yml exists
    if [ ! -f "docker-compose.yml" ]; then
        print_info "Creating docker-compose.yml..."
        cat > docker-compose.yml << 'EOF'
version: '3.8'

services:
  mongodb:
    image: mongo:6.0
    ports:
      - "27017:27017"
    environment:
      MONGO_INITDB_ROOT_USERNAME: admin
      MONGO_INITDB_ROOT_PASSWORD: password
    volumes:
      - mongodb_data:/data/db

  backend:
    build: ./backend
    ports:
      - "8000:8000"
    environment:
      - MONGODB_URL=mongodb://admin:password@mongodb:27017
      - DATABASE_NAME=ai_agents_platform
    depends_on:
      - mongodb
    volumes:
      - ./backend:/app

  frontend:
    build: ./frontend
    ports:
      - "3000:3000"
    environment:
      - REACT_APP_API_URL=http://localhost:8000
    depends_on:
      - backend

volumes:
  mongodb_data:
EOF
        print_success "Created docker-compose.yml"
    fi
    
    # Start services
    if command_exists docker-compose; then
        docker-compose up -d
    else
        docker compose up -d
    fi
    
    print_success "Local deployment started!"
    print_info "Access the application:"
    echo "  - Frontend: http://localhost:3000"
    echo "  - Backend API: http://localhost:8000"
    echo "  - API Documentation: http://localhost:8000/docs"
}

# Deploy to Kubernetes
deploy_k8s() {
    print_info "Deploying to Kubernetes..."
    
    if ! command_exists kubectl; then
        print_error "kubectl is required but not installed."
        exit 1
    fi
    
    # Check if connected to cluster
    if ! kubectl cluster-info >/dev/null 2>&1; then
        print_error "Not connected to a Kubernetes cluster. Please configure kubectl."
        exit 1
    fi
    
    # Deploy to Kubernetes
    cd k8s
    
    print_info "Creating namespaces..."
    kubectl apply -f base/namespaces.yaml
    
    print_info "Deploying base components..."
    kubectl apply -k base/
    
    print_info "Deploying production overlay..."
    kubectl apply -k overlays/production/
    
    cd ..
    
    print_success "Kubernetes deployment complete!"
    print_info "Check deployment status:"
    echo "  kubectl get pods -n ai-agents-platform"
    echo "  kubectl get services -n ai-agents-platform"
    echo "  kubectl get ingress -n ai-agents-platform"
}

# Main script logic
case "${1:-help}" in
    setup)
        setup_dev
        ;;
    build)
        build_images
        ;;
    local)
        build_images
        deploy_local
        ;;
    k8s)
        deploy_k8s
        ;;
    help|--help|-h)
        usage
        ;;
    *)
        print_error "Unknown option: $1"
        echo ""
        usage
        exit 1
        ;;
esac

