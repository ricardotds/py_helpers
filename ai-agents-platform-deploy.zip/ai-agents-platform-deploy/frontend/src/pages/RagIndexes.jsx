/**
 * RAG Indexes management page
 */

import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  Plus, 
  Search, 
  Filter, 
  MoreHorizontal, 
  Edit, 
  Trash2, 
  Copy,
  Database,
  Tag,
  Calendar,
  User,
  CheckCircle,
  XCircle,
  AlertCircle,
  FileText,
  Globe,
  Zap,
  BarChart3
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { apiClient } from '../lib/api';

export default function RagIndexes() {
  const [indexes, setIndexes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('');
  const [statuses, setStatuses] = useState([]);

  useEffect(() => {
    loadIndexes();
  }, [searchTerm, selectedStatus]);

  const loadIndexes = async () => {
    try {
      setLoading(true);
      setError(null);
      
      // Mock data for development
      const mockIndexes = [
        {
          id: '1',
          name: 'Company Knowledge Base',
          description: 'Internal company documentation and policies',
          service_name: 'company-search-service',
          index_name: 'knowledge-base',
          endpoint: 'https://company-search.search.windows.net',
          api_version: '2023-11-01',
          tags: ['internal', 'documentation', 'policies'],
          document_count: 1247,
          storage_size: '2.3 GB',
          last_updated: '2024-01-25T14:30:00Z',
          status: 'active',
          health: 'healthy',
          created_at: '2024-01-15T10:00:00Z',
          updated_at: '2024-01-25T14:30:00Z',
          owner_id: 'dev-user'
        },
        {
          id: '2',
          name: 'Product Catalog Search',
          description: 'Searchable product information and specifications',
          service_name: 'product-search-service',
          index_name: 'product-catalog',
          endpoint: 'https://product-search.search.windows.net',
          api_version: '2023-11-01',
          tags: ['products', 'catalog', 'specifications'],
          document_count: 5432,
          storage_size: '1.8 GB',
          last_updated: '2024-01-24T09:15:00Z',
          status: 'active',
          health: 'healthy',
          created_at: '2024-01-12T09:00:00Z',
          updated_at: '2024-01-24T09:15:00Z',
          owner_id: 'dev-user'
        },
        {
          id: '3',
          name: 'Customer Support FAQ',
          description: 'Frequently asked questions and support articles',
          service_name: 'support-search-service',
          index_name: 'faq-articles',
          endpoint: 'https://support-search.search.windows.net',
          api_version: '2023-11-01',
          tags: ['support', 'faq', 'help'],
          document_count: 892,
          storage_size: '456 MB',
          last_updated: '2024-01-23T16:45:00Z',
          status: 'active',
          health: 'warning',
          created_at: '2024-01-10T14:00:00Z',
          updated_at: '2024-01-23T16:45:00Z',
          owner_id: 'dev-user'
        },
        {
          id: '4',
          name: 'Legal Documents Index',
          description: 'Legal contracts, terms, and compliance documents',
          service_name: 'legal-search-service',
          index_name: 'legal-docs',
          endpoint: 'https://legal-search.search.windows.net',
          api_version: '2023-11-01',
          tags: ['legal', 'contracts', 'compliance'],
          document_count: 234,
          storage_size: '1.2 GB',
          last_updated: '2024-01-20T11:20:00Z',
          status: 'inactive',
          health: 'error',
          created_at: '2024-01-08T11:00:00Z',
          updated_at: '2024-01-20T11:20:00Z',
          owner_id: 'dev-user'
        },
        {
          id: '5',
          name: 'Research Papers',
          description: 'Academic and industry research papers collection',
          service_name: 'research-search-service',
          index_name: 'research-papers',
          endpoint: 'https://research-search.search.windows.net',
          api_version: '2023-11-01',
          tags: ['research', 'academic', 'papers'],
          document_count: 3156,
          storage_size: '4.7 GB',
          last_updated: '2024-01-26T08:00:00Z',
          status: 'active',
          health: 'healthy',
          created_at: '2024-01-05T16:00:00Z',
          updated_at: '2024-01-26T08:00:00Z',
          owner_id: 'dev-user'
        }
      ];

      setIndexes(mockIndexes);
      
      // Extract unique statuses
      const uniqueStatuses = [...new Set(mockIndexes.map(index => index.status))];
      setStatuses(uniqueStatuses);
      
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteIndex = async (indexId) => {
    if (!confirm('Are you sure you want to delete this RAG index?')) return;
    
    try {
      // In real app: await apiClient.deleteRagIndex(indexId);
      setIndexes(indexes.filter(index => index.id !== indexId));
    } catch (err) {
      setError(err.message);
    }
  };

  const handleDuplicateIndex = async (index) => {
    try {
      const duplicatedIndex = {
        ...index,
        id: Date.now().toString(),
        name: `${index.name} (Copy)`,
        index_name: `${index.index_name}-copy`,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };
      
      setIndexes([...indexes, duplicatedIndex]);
    } catch (err) {
      setError(err.message);
    }
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString();
  };

  const formatFileSize = (sizeString) => {
    return sizeString;
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'active':
        return 'bg-green-100 text-green-800';
      case 'inactive':
        return 'bg-gray-100 text-gray-800';
      case 'indexing':
        return 'bg-blue-100 text-blue-800';
      case 'error':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getHealthIcon = (health) => {
    switch (health) {
      case 'healthy':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'warning':
        return <AlertCircle className="h-4 w-4 text-yellow-500" />;
      case 'error':
        return <XCircle className="h-4 w-4 text-red-500" />;
      default:
        return <AlertCircle className="h-4 w-4 text-gray-500" />;
    }
  };

  const getHealthText = (health) => {
    switch (health) {
      case 'healthy':
        return 'Healthy';
      case 'warning':
        return 'Warning';
      case 'error':
        return 'Error';
      default:
        return 'Unknown';
    }
  };

  const filteredIndexes = indexes.filter(index => {
    const matchesSearch = index.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         index.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = !selectedStatus || index.status === selectedStatus;
    return matchesSearch && matchesStatus;
  });

  const totalDocuments = filteredIndexes.reduce((sum, index) => sum + index.document_count, 0);
  const totalStorageGB = filteredIndexes.reduce((sum, index) => {
    const size = parseFloat(index.storage_size.replace(/[^\d.]/g, ''));
    const unit = index.storage_size.includes('GB') ? 1 : 0.001;
    return sum + (size * unit);
  }, 0);

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-bold">RAG Indexes</h1>
        </div>
        <div className="flex items-center justify-center py-12">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">RAG Indexes</h1>
          <p className="text-muted-foreground">
            Manage your Azure AI Search indexes for retrieval-augmented generation
          </p>
        </div>
        <Button asChild>
          <Link to="/rag-indexes/new">
            <Plus className="mr-2 h-4 w-4" />
            New Index
          </Link>
        </Button>
      </div>

      {/* Error Alert */}
      {error && (
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Search & Filter</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search indexes..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <div className="sm:w-48">
              <select
                value={selectedStatus}
                onChange={(e) => setSelectedStatus(e.target.value)}
                className="w-full px-3 py-2 border border-input bg-background rounded-md text-sm"
              >
                <option value="">All Statuses</option>
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
                <option value="indexing">Indexing</option>
                <option value="error">Error</option>
              </select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Indexes List */}
      {filteredIndexes.length === 0 ? (
        <Card>
          <CardContent className="text-center py-12">
            <Database className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">No indexes found</h3>
            <p className="text-muted-foreground mb-4">
              {searchTerm || selectedStatus 
                ? 'No indexes match your current filters.' 
                : 'Get started by creating your first RAG index.'
              }
            </p>
            <Button asChild>
              <Link to="/rag-indexes/new">
                <Plus className="mr-2 h-4 w-4" />
                Create Index
              </Link>
            </Button>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Service</TableHead>
                <TableHead>Documents</TableHead>
                <TableHead>Storage</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Health</TableHead>
                <TableHead>Tags</TableHead>
                <TableHead>Updated</TableHead>
                <TableHead className="w-[50px]"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredIndexes.map((index) => (
                <TableRow key={index.id}>
                  <TableCell>
                    <div className="flex items-center space-x-3">
                      <div className="p-2 rounded-lg bg-purple-500">
                        <Database className="h-4 w-4 text-white" />
                      </div>
                      <div>
                        <div className="font-medium">{index.name}</div>
                        {index.description && (
                          <div className="text-sm text-muted-foreground truncate max-w-xs">
                            {index.description}
                          </div>
                        )}
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="text-sm">
                      <div className="font-medium">{index.service_name}</div>
                      <div className="text-muted-foreground">{index.index_name}</div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-1">
                      <FileText className="h-4 w-4 text-muted-foreground" />
                      <span className="font-medium">{index.document_count.toLocaleString()}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="text-sm font-medium">{formatFileSize(index.storage_size)}</div>
                  </TableCell>
                  <TableCell>
                    <Badge className={getStatusColor(index.status)}>
                      {index.status}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-1">
                      {getHealthIcon(index.health)}
                      <span className="text-sm">{getHealthText(index.health)}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex flex-wrap gap-1">
                      {index.tags.slice(0, 2).map(tag => (
                        <Badge key={tag} variant="secondary" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                      {index.tags.length > 2 && (
                        <Badge variant="secondary" className="text-xs">
                          +{index.tags.length - 2}
                        </Badge>
                      )}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-1 text-sm text-muted-foreground">
                      <Calendar className="h-3 w-3" />
                      <span>{formatDate(index.updated_at)}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem asChild>
                          <Link to={`/rag-indexes/${index.id}`}>
                            <Edit className="mr-2 h-4 w-4" />
                            Edit
                          </Link>
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleDuplicateIndex(index)}>
                          <Copy className="mr-2 h-4 w-4" />
                          Duplicate
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem 
                          onClick={() => handleDeleteIndex(index.id)}
                          className="text-destructive"
                        >
                          <Trash2 className="mr-2 h-4 w-4" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Card>
      )}

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Indexes</CardTitle>
            <Database className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{filteredIndexes.length}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Documents</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalDocuments.toLocaleString()}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Storage</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalStorageGB.toFixed(1)} GB</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Healthy Indexes</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {filteredIndexes.filter(i => i.health === 'healthy').length}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

