/**
 * Tools management page
 */

import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  Plus, 
  Search, 
  Filter, 
  MoreHorizontal, 
  Edit, 
  Trash2, 
  Copy,
  Settings,
  Tag,
  Calendar,
  User,
  Bot,
  Globe,
  Database,
  Code,
  Zap
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { apiClient } from '../lib/api';

export default function Tools() {
  const [tools, setTools] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedType, setSelectedType] = useState('');
  const [toolTypes, setToolTypes] = useState([]);

  useEffect(() => {
    loadTools();
  }, [searchTerm, selectedType]);

  const loadTools = async () => {
    try {
      setLoading(true);
      setError(null);
      
      // Mock data for development
      const mockTools = [
        {
          id: '1',
          name: 'Azure OpenAI GPT-4',
          description: 'GPT-4 model for advanced text generation and analysis',
          type: 'llm',
          category: 'AI Models',
          tags: ['gpt-4', 'azure', 'openai'],
          configuration: {
            provider: 'azure_openai',
            model: 'gpt-4',
            endpoint: 'https://your-resource.openai.azure.com/',
            api_version: '2024-02-15-preview'
          },
          created_at: '2024-01-15T10:00:00Z',
          updated_at: '2024-01-20T15:30:00Z',
          owner_id: 'dev-user',
          status: 'active'
        },
        {
          id: '2',
          name: 'AWS Bedrock Claude',
          description: 'Anthropic Claude model via AWS Bedrock',
          type: 'llm',
          category: 'AI Models',
          tags: ['claude', 'aws', 'bedrock'],
          configuration: {
            provider: 'aws_bedrock',
            model: 'anthropic.claude-3-sonnet-20240229-v1:0',
            region: 'us-east-1'
          },
          created_at: '2024-01-12T09:00:00Z',
          updated_at: '2024-01-18T11:45:00Z',
          owner_id: 'dev-user',
          status: 'active'
        },
        {
          id: '3',
          name: 'Customer API',
          description: 'REST API for customer data retrieval',
          type: 'api',
          category: 'Data Sources',
          tags: ['rest', 'customer', 'data'],
          configuration: {
            base_url: 'https://api.customer-system.com',
            auth_type: 'bearer',
            headers: {
              'Content-Type': 'application/json'
            }
          },
          created_at: '2024-01-10T14:00:00Z',
          updated_at: '2024-01-22T16:20:00Z',
          owner_id: 'dev-user',
          status: 'active'
        },
        {
          id: '4',
          name: 'Knowledge Base Search',
          description: 'Azure AI Search index for company knowledge',
          type: 'rag',
          category: 'Knowledge',
          tags: ['azure', 'search', 'knowledge'],
          configuration: {
            service_name: 'company-search',
            index_name: 'knowledge-base',
            api_version: '2023-11-01'
          },
          created_at: '2024-01-08T11:00:00Z',
          updated_at: '2024-01-25T09:15:00Z',
          owner_id: 'dev-user',
          status: 'active'
        },
        {
          id: '5',
          name: 'Data Processor',
          description: 'Python script for data transformation',
          type: 'python',
          category: 'Processing',
          tags: ['python', 'data', 'transform'],
          configuration: {
            requirements: ['pandas', 'numpy', 'requests'],
            timeout: 300
          },
          created_at: '2024-01-05T16:00:00Z',
          updated_at: '2024-01-20T13:30:00Z',
          owner_id: 'dev-user',
          status: 'active'
        }
      ];

      setTools(mockTools);
      
      // Extract unique types
      const uniqueTypes = [...new Set(mockTools.map(tool => tool.type))];
      setToolTypes(uniqueTypes);
      
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteTool = async (toolId) => {
    if (!confirm('Are you sure you want to delete this tool?')) return;
    
    try {
      // In real app: await apiClient.deleteTool(toolId);
      setTools(tools.filter(tool => tool.id !== toolId));
    } catch (err) {
      setError(err.message);
    }
  };

  const handleDuplicateTool = async (tool) => {
    try {
      const duplicatedTool = {
        ...tool,
        id: Date.now().toString(),
        name: `${tool.name} (Copy)`,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };
      
      setTools([...tools, duplicatedTool]);
    } catch (err) {
      setError(err.message);
    }
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString();
  };

  const getToolIcon = (type) => {
    switch (type) {
      case 'llm':
        return <Bot className="h-4 w-4" />;
      case 'api':
        return <Globe className="h-4 w-4" />;
      case 'rag':
        return <Database className="h-4 w-4" />;
      case 'python':
        return <Code className="h-4 w-4" />;
      default:
        return <Settings className="h-4 w-4" />;
    }
  };

  const getToolTypeColor = (type) => {
    switch (type) {
      case 'llm':
        return 'bg-blue-500';
      case 'api':
        return 'bg-green-500';
      case 'rag':
        return 'bg-purple-500';
      case 'python':
        return 'bg-orange-500';
      default:
        return 'bg-gray-500';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'active':
        return 'bg-green-100 text-green-800';
      case 'inactive':
        return 'bg-gray-100 text-gray-800';
      case 'error':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const filteredTools = tools.filter(tool => {
    const matchesSearch = tool.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         tool.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = !selectedType || tool.type === selectedType;
    return matchesSearch && matchesType;
  });

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-bold">Tools</h1>
        </div>
        <div className="flex items-center justify-center py-12">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Tools</h1>
          <p className="text-muted-foreground">
            Manage your AI tools and integrations
          </p>
        </div>
        <Button asChild>
          <Link to="/tools/new">
            <Plus className="mr-2 h-4 w-4" />
            New Tool
          </Link>
        </Button>
      </div>

      {/* Error Alert */}
      {error && (
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Search & Filter</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search tools..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <div className="sm:w-48">
              <select
                value={selectedType}
                onChange={(e) => setSelectedType(e.target.value)}
                className="w-full px-3 py-2 border border-input bg-background rounded-md text-sm"
              >
                <option value="">All Types</option>
                <option value="llm">LLM</option>
                <option value="api">API</option>
                <option value="rag">RAG</option>
                <option value="python">Python</option>
              </select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Tools List */}
      {filteredTools.length === 0 ? (
        <Card>
          <CardContent className="text-center py-12">
            <Settings className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">No tools found</h3>
            <p className="text-muted-foreground mb-4">
              {searchTerm || selectedType 
                ? 'No tools match your current filters.' 
                : 'Get started by configuring your first tool.'
              }
            </p>
            <Button asChild>
              <Link to="/tools/new">
                <Plus className="mr-2 h-4 w-4" />
                Add Tool
              </Link>
            </Button>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Category</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Tags</TableHead>
                <TableHead>Updated</TableHead>
                <TableHead className="w-[50px]"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredTools.map((tool) => (
                <TableRow key={tool.id}>
                  <TableCell>
                    <div className="flex items-center space-x-3">
                      <div className={`p-2 rounded-lg ${getToolTypeColor(tool.type)}`}>
                        {getToolIcon(tool.type)}
                      </div>
                      <div>
                        <div className="font-medium">{tool.name}</div>
                        {tool.description && (
                          <div className="text-sm text-muted-foreground truncate max-w-xs">
                            {tool.description}
                          </div>
                        )}
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline" className="uppercase">
                      {tool.type}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <span className="text-sm">{tool.category}</span>
                  </TableCell>
                  <TableCell>
                    <Badge className={getStatusColor(tool.status)}>
                      {tool.status}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex flex-wrap gap-1">
                      {tool.tags.slice(0, 2).map(tag => (
                        <Badge key={tag} variant="secondary" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                      {tool.tags.length > 2 && (
                        <Badge variant="secondary" className="text-xs">
                          +{tool.tags.length - 2}
                        </Badge>
                      )}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-1 text-sm text-muted-foreground">
                      <Calendar className="h-3 w-3" />
                      <span>{formatDate(tool.updated_at)}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem asChild>
                          <Link to={`/tools/${tool.id}`}>
                            <Edit className="mr-2 h-4 w-4" />
                            Edit
                          </Link>
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleDuplicateTool(tool)}>
                          <Copy className="mr-2 h-4 w-4" />
                          Duplicate
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem 
                          onClick={() => handleDeleteTool(tool.id)}
                          className="text-destructive"
                        >
                          <Trash2 className="mr-2 h-4 w-4" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Card>
      )}

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Tools</CardTitle>
            <Settings className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{filteredTools.length}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">LLM Tools</CardTitle>
            <Bot className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {filteredTools.filter(t => t.type === 'llm').length}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">API Tools</CardTitle>
            <Globe className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {filteredTools.filter(t => t.type === 'api').length}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Tools</CardTitle>
            <Zap className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {filteredTools.filter(t => t.status === 'active').length}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

