/**
 * Login page component
 */

import { useState, useEffect } from 'react';
import { Navigate } from 'react-router-dom';
import { Bot, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useAuth } from '../contexts/AuthContext';

export default function Login() {
  const { login, loading, error, isAuthenticated } = useAuth();
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  // Redirect if already authenticated
  if (isAuthenticated) {
    return <Navigate to="/" replace />;
  }

  // Handle OAuth callback
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const code = urlParams.get('code');
    const state = urlParams.get('state');
    
    if (code) {
      handleOAuthCallback(code, state);
    }
  }, []);

  const handleOAuthCallback = async (code, state) => {
    setIsLoggingIn(true);
    try {
      const result = await login({ code, state });
      if (result.success && !result.redirect) {
        // Login successful, user will be redirected by the auth context
      }
    } catch (error) {
      console.error('OAuth callback failed:', error);
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleLogin = async () => {
    setIsLoggingIn(true);
    try {
      const result = await login({});
      if (result.success && result.redirect) {
        // Will redirect to OAuth provider
      }
    } catch (error) {
      console.error('Login failed:', error);
    } finally {
      setIsLoggingIn(false);
    }
  };

  if (loading || isLoggingIn) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="flex flex-col items-center space-y-4">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <p className="text-sm text-muted-foreground">
            {isLoggingIn ? 'Signing you in...' : 'Loading...'}
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-background px-4">
      <div className="w-full max-w-md space-y-8">
        <div className="flex flex-col items-center space-y-6">
          {/* Logo and title */}
          <div className="flex items-center space-x-2">
            <Bot className="h-12 w-12 text-primary" />
            <div className="text-center">
              <h1 className="text-2xl font-bold">AI Agents Platform</h1>
              <p className="text-sm text-muted-foreground">
                Manage and execute AI pipelines
              </p>
            </div>
          </div>

          {/* Login card */}
          <Card className="w-full">
            <CardHeader className="space-y-1">
              <CardTitle className="text-2xl text-center">Welcome back</CardTitle>
              <CardDescription className="text-center">
                Sign in to your account to continue
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {error && (
                <Alert variant="destructive">
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              <Button 
                onClick={handleLogin} 
                className="w-full" 
                size="lg"
                disabled={isLoggingIn}
              >
                {isLoggingIn ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Signing in...
                  </>
                ) : (
                  'Sign in with Microsoft'
                )}
              </Button>

              <div className="text-center text-sm text-muted-foreground">
                <p>
                  By signing in, you agree to our terms of service and privacy policy.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Features */}
          <div className="w-full space-y-4">
            <h3 className="text-lg font-semibold text-center">Platform Features</h3>
            <div className="grid grid-cols-1 gap-4 text-sm">
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-primary rounded-full" />
                <span>Visual pipeline editor similar to n8n</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-primary rounded-full" />
                <span>LLM integration (Azure OpenAI, AWS Bedrock)</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-primary rounded-full" />
                <span>RAG with Azure AI Search</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-primary rounded-full" />
                <span>Custom Python code execution</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-primary rounded-full" />
                <span>Real-time execution monitoring</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

