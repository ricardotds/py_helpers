/**
 * Dashboard page component
 */

import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  Bot, 
  Workflow, 
  Play, 
  Settings, 
  FileText, 
  Database,
  Plus,
  TrendingUp,
  Clock,
  CheckCircle,
  XCircle,
  Code
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { useAuth } from '../contexts/AuthContext';
import { apiClient } from '../lib/api';

export default function Dashboard() {
  const { user } = useAuth();
  const [stats, setStats] = useState({
    pipelines: 0,
    tools: 0,
    prompts: 0,
    schemas: 0,
    ragIndexes: 0,
    executions: 0
  });
  const [recentExecutions, setRecentExecutions] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      setLoading(true);
      
      // Load stats in parallel
      const [
        pipelinesRes,
        toolsRes,
        promptsRes,
        schemasRes,
        ragIndexesRes,
        executionsRes
      ] = await Promise.all([
        apiClient.getPipelines({ limit: 1 }),
        apiClient.getTools({ limit: 1 }),
        apiClient.getPrompts({ limit: 1 }),
        apiClient.getSchemas({ limit: 1 }),
        apiClient.getRagIndexes({ limit: 1 }),
        apiClient.getExecutions()
      ]);

      setStats({
        pipelines: pipelinesRes.total || 0,
        tools: toolsRes.total || 0,
        prompts: promptsRes.total || 0,
        schemas: schemasRes.total || 0,
        ragIndexes: ragIndexesRes.total || 0,
        executions: executionsRes.length || 0
      });

      // Get recent executions (last 5)
      setRecentExecutions(executionsRes.slice(0, 5) || []);
      
    } catch (error) {
      console.error('Failed to load dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const getExecutionStatusColor = (status) => {
    switch (status) {
      case 'completed':
        return 'bg-green-500';
      case 'failed':
        return 'bg-red-500';
      case 'running':
        return 'bg-blue-500';
      case 'pending':
        return 'bg-yellow-500';
      case 'cancelled':
        return 'bg-gray-500';
      default:
        return 'bg-gray-500';
    }
  };

  const getExecutionIcon = (status) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'failed':
        return <XCircle className="h-4 w-4 text-red-500" />;
      case 'running':
        return <Play className="h-4 w-4 text-blue-500" />;
      default:
        return <Clock className="h-4 w-4 text-gray-500" />;
    }
  };

  const quickActions = [
    {
      title: 'Create Pipeline',
      description: 'Build a new AI pipeline',
      icon: Workflow,
      href: '/pipelines/new',
      color: 'bg-blue-500'
    },
    {
      title: 'Add Tool',
      description: 'Configure a new tool',
      icon: Settings,
      href: '/tools/new',
      color: 'bg-green-500'
    },
    {
      title: 'Create Prompt',
      description: 'Write a new prompt template',
      icon: FileText,
      href: '/prompts/new',
      color: 'bg-purple-500'
    },
    {
      title: 'Add RAG Index',
      description: 'Set up a new knowledge base',
      icon: Database,
      href: '/rag-indexes/new',
      color: 'bg-orange-500'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Dashboard</h1>
          <p className="text-muted-foreground">
            Welcome back, {user?.name || 'User'}! Here's what's happening with your AI agents.
          </p>
        </div>
        <Button asChild>
          <Link to="/pipelines/new">
            <Plus className="mr-2 h-4 w-4" />
            New Pipeline
          </Link>
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pipelines</CardTitle>
            <Workflow className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.pipelines}</div>
            <p className="text-xs text-muted-foreground">
              Active workflows
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Tools</CardTitle>
            <Settings className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.tools}</div>
            <p className="text-xs text-muted-foreground">
              Configured tools
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Prompts</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.prompts}</div>
            <p className="text-xs text-muted-foreground">
              Prompt templates
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Schemas</CardTitle>
            <Code className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.schemas}</div>
            <p className="text-xs text-muted-foreground">
              Data schemas
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">RAG Indexes</CardTitle>
            <Database className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.ragIndexes}</div>
            <p className="text-xs text-muted-foreground">
              Knowledge bases
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Executions</CardTitle>
            <Play className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.executions}</div>
            <p className="text-xs text-muted-foreground">
              Total runs
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
            <CardDescription>
              Get started with common tasks
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {quickActions.map((action) => {
              const Icon = action.icon;
              return (
                <Link
                  key={action.title}
                  to={action.href}
                  className="flex items-center space-x-4 p-3 rounded-lg border hover:bg-accent transition-colors"
                >
                  <div className={`p-2 rounded-lg ${action.color}`}>
                    <Icon className="h-4 w-4 text-white" />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-medium">{action.title}</h4>
                    <p className="text-sm text-muted-foreground">
                      {action.description}
                    </p>
                  </div>
                </Link>
              );
            })}
          </CardContent>
        </Card>

        {/* Recent Executions */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Executions</CardTitle>
            <CardDescription>
              Latest pipeline runs
            </CardDescription>
          </CardHeader>
          <CardContent>
            {recentExecutions.length === 0 ? (
              <div className="text-center py-6">
                <Play className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">No executions yet</p>
                <p className="text-sm text-muted-foreground">
                  Run your first pipeline to see results here
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {recentExecutions.map((execution) => (
                  <div
                    key={execution.execution_id}
                    className="flex items-center space-x-4 p-3 rounded-lg border"
                  >
                    {getExecutionIcon(execution.status)}
                    <div className="flex-1 min-w-0">
                      <p className="font-medium truncate">
                        Pipeline {execution.pipeline_id}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {execution.start_time && 
                          new Date(execution.start_time).toLocaleString()
                        }
                      </p>
                    </div>
                    <Badge variant="outline" className="capitalize">
                      {execution.status}
                    </Badge>
                  </div>
                ))}
                <div className="text-center">
                  <Button variant="outline" asChild>
                    <Link to="/executions">View All Executions</Link>
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Getting Started */}
      {stats.pipelines === 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Bot className="h-5 w-5" />
              <span>Getting Started</span>
            </CardTitle>
            <CardDescription>
              Welcome to AI Agents Platform! Follow these steps to create your first pipeline.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <div className="w-6 h-6 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-sm font-bold">
                    1
                  </div>
                  <h4 className="font-medium">Configure Tools</h4>
                </div>
                <p className="text-sm text-muted-foreground">
                  Set up LLM providers, APIs, and other tools you'll use in your pipelines.
                </p>
                <Button variant="outline" size="sm" asChild>
                  <Link to="/tools">Manage Tools</Link>
                </Button>
              </div>

              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <div className="w-6 h-6 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-sm font-bold">
                    2
                  </div>
                  <h4 className="font-medium">Create Resources</h4>
                </div>
                <p className="text-sm text-muted-foreground">
                  Build prompts, schemas, and RAG indexes to use in your workflows.
                </p>
                <Button variant="outline" size="sm" asChild>
                  <Link to="/prompts">Create Prompts</Link>
                </Button>
              </div>

              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <div className="w-6 h-6 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-sm font-bold">
                    3
                  </div>
                  <h4 className="font-medium">Build Pipeline</h4>
                </div>
                <p className="text-sm text-muted-foreground">
                  Use the visual editor to create your first AI pipeline.
                </p>
                <Button size="sm" asChild>
                  <Link to="/pipelines/new">Create Pipeline</Link>
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

