/**
 * Schemas management page
 */

import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  Plus, 
  Search, 
  Filter, 
  MoreHorizontal, 
  Edit, 
  Trash2, 
  Copy,
  FileText,
  Tag,
  Calendar,
  User,
  CheckCircle,
  XCircle,
  Code,
  Database
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { apiClient } from '../lib/api';

export default function Schemas() {
  const [schemas, setSchemas] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [categories, setCategories] = useState([]);

  useEffect(() => {
    loadSchemas();
  }, [searchTerm, selectedCategory]);

  const loadSchemas = async () => {
    try {
      setLoading(true);
      setError(null);
      
      // Mock data for development
      const mockSchemas = [
        {
          id: '1',
          name: 'Customer Profile',
          description: 'Schema for customer profile data structure',
          category: 'Customer Data',
          tags: ['customer', 'profile', 'personal'],
          schema: {
            type: 'object',
            properties: {
              id: { type: 'string', description: 'Unique customer identifier' },
              name: { type: 'string', description: 'Full customer name' },
              email: { type: 'string', format: 'email', description: 'Customer email address' },
              phone: { type: 'string', description: 'Phone number' },
              address: {
                type: 'object',
                properties: {
                  street: { type: 'string' },
                  city: { type: 'string' },
                  country: { type: 'string' },
                  zipCode: { type: 'string' }
                },
                required: ['street', 'city', 'country']
              },
              preferences: {
                type: 'object',
                properties: {
                  newsletter: { type: 'boolean' },
                  notifications: { type: 'boolean' }
                }
              }
            },
            required: ['id', 'name', 'email']
          },
          version: '1.2.0',
          is_valid: true,
          created_at: '2024-01-15T10:00:00Z',
          updated_at: '2024-01-20T15:30:00Z',
          owner_id: 'dev-user'
        },
        {
          id: '2',
          name: 'Product Catalog',
          description: 'Schema for product information in catalog',
          category: 'Product Data',
          tags: ['product', 'catalog', 'inventory'],
          schema: {
            type: 'object',
            properties: {
              id: { type: 'string', description: 'Product SKU' },
              name: { type: 'string', description: 'Product name' },
              description: { type: 'string', description: 'Product description' },
              price: { type: 'number', minimum: 0, description: 'Product price' },
              currency: { type: 'string', enum: ['USD', 'EUR', 'GBP'], description: 'Price currency' },
              category: { type: 'string', description: 'Product category' },
              tags: { type: 'array', items: { type: 'string' }, description: 'Product tags' },
              inStock: { type: 'boolean', description: 'Availability status' },
              images: { 
                type: 'array', 
                items: { type: 'string', format: 'uri' },
                description: 'Product image URLs'
              }
            },
            required: ['id', 'name', 'price', 'currency', 'category']
          },
          version: '2.1.0',
          is_valid: true,
          created_at: '2024-01-12T09:00:00Z',
          updated_at: '2024-01-18T11:45:00Z',
          owner_id: 'dev-user'
        },
        {
          id: '3',
          name: 'API Response',
          description: 'Standard API response format schema',
          category: 'API Schemas',
          tags: ['api', 'response', 'standard'],
          schema: {
            type: 'object',
            properties: {
              success: { type: 'boolean', description: 'Request success status' },
              data: { type: 'object', description: 'Response data payload' },
              message: { type: 'string', description: 'Human-readable message' },
              errors: { 
                type: 'array', 
                items: {
                  type: 'object',
                  properties: {
                    field: { type: 'string' },
                    message: { type: 'string' },
                    code: { type: 'string' }
                  }
                },
                description: 'Validation errors'
              },
              meta: {
                type: 'object',
                properties: {
                  timestamp: { type: 'string', format: 'date-time' },
                  version: { type: 'string' },
                  requestId: { type: 'string' }
                }
              }
            },
            required: ['success', 'data', 'message']
          },
          version: '1.0.0',
          is_valid: true,
          created_at: '2024-01-10T14:00:00Z',
          updated_at: '2024-01-22T16:20:00Z',
          owner_id: 'dev-user'
        },
        {
          id: '4',
          name: 'Analytics Event',
          description: 'Schema for tracking analytics events',
          category: 'Analytics',
          tags: ['analytics', 'tracking', 'events'],
          schema: {
            type: 'object',
            properties: {
              eventType: { type: 'string', enum: ['page_view', 'click', 'conversion', 'error'] },
              userId: { type: 'string', description: 'User identifier' },
              sessionId: { type: 'string', description: 'Session identifier' },
              timestamp: { type: 'string', format: 'date-time' },
              properties: { type: 'object', description: 'Event-specific properties' },
              context: {
                type: 'object',
                properties: {
                  page: { type: 'string' },
                  referrer: { type: 'string' },
                  userAgent: { type: 'string' }
                }
              }
            },
            required: ['eventType', 'timestamp']
          },
          version: '1.1.0',
          is_valid: false,
          created_at: '2024-01-08T11:00:00Z',
          updated_at: '2024-01-25T09:15:00Z',
          owner_id: 'dev-user'
        }
      ];

      setSchemas(mockSchemas);
      
      // Extract unique categories
      const uniqueCategories = [...new Set(mockSchemas.map(schema => schema.category))];
      setCategories(uniqueCategories);
      
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteSchema = async (schemaId) => {
    if (!confirm('Are you sure you want to delete this schema?')) return;
    
    try {
      // In real app: await apiClient.deleteSchema(schemaId);
      setSchemas(schemas.filter(schema => schema.id !== schemaId));
    } catch (err) {
      setError(err.message);
    }
  };

  const handleDuplicateSchema = async (schema) => {
    try {
      const duplicatedSchema = {
        ...schema,
        id: Date.now().toString(),
        name: `${schema.name} (Copy)`,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };
      
      setSchemas([...schemas, duplicatedSchema]);
    } catch (err) {
      setError(err.message);
    }
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString();
  };

  const getPropertyCount = (schema) => {
    if (!schema.schema || !schema.schema.properties) return 0;
    return Object.keys(schema.schema.properties).length;
  };

  const getRequiredCount = (schema) => {
    if (!schema.schema || !schema.schema.required) return 0;
    return schema.schema.required.length;
  };

  const filteredSchemas = schemas.filter(schema => {
    const matchesSearch = schema.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         schema.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = !selectedCategory || schema.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-bold">Schemas</h1>
        </div>
        <div className="flex items-center justify-center py-12">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Schemas</h1>
          <p className="text-muted-foreground">
            Manage your JSON schemas for structured data validation
          </p>
        </div>
        <Button asChild>
          <Link to="/schemas/new">
            <Plus className="mr-2 h-4 w-4" />
            New Schema
          </Link>
        </Button>
      </div>

      {/* Error Alert */}
      {error && (
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Search & Filter</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search schemas..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <div className="sm:w-48">
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="w-full px-3 py-2 border border-input bg-background rounded-md text-sm"
              >
                <option value="">All Categories</option>
                {categories.map(category => (
                  <option key={category} value={category}>{category}</option>
                ))}
              </select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Schemas List */}
      {filteredSchemas.length === 0 ? (
        <Card>
          <CardContent className="text-center py-12">
            <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">No schemas found</h3>
            <p className="text-muted-foreground mb-4">
              {searchTerm || selectedCategory 
                ? 'No schemas match your current filters.' 
                : 'Get started by creating your first schema.'
              }
            </p>
            <Button asChild>
              <Link to="/schemas/new">
                <Plus className="mr-2 h-4 w-4" />
                Create Schema
              </Link>
            </Button>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Category</TableHead>
                <TableHead>Version</TableHead>
                <TableHead>Properties</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Tags</TableHead>
                <TableHead>Updated</TableHead>
                <TableHead className="w-[50px]"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredSchemas.map((schema) => (
                <TableRow key={schema.id}>
                  <TableCell>
                    <div className="flex items-center space-x-3">
                      <div className="p-2 rounded-lg bg-indigo-500">
                        <FileText className="h-4 w-4 text-white" />
                      </div>
                      <div>
                        <div className="font-medium">{schema.name}</div>
                        {schema.description && (
                          <div className="text-sm text-muted-foreground truncate max-w-xs">
                            {schema.description}
                          </div>
                        )}
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <span className="text-sm">{schema.category}</span>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline">
                      v{schema.version}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="text-sm">
                      <span className="font-medium">{getPropertyCount(schema)}</span> total
                      <span className="text-muted-foreground"> / </span>
                      <span className="font-medium">{getRequiredCount(schema)}</span> required
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-1">
                      {schema.is_valid ? (
                        <>
                          <CheckCircle className="h-4 w-4 text-green-500" />
                          <span className="text-sm text-green-700">Valid</span>
                        </>
                      ) : (
                        <>
                          <XCircle className="h-4 w-4 text-red-500" />
                          <span className="text-sm text-red-700">Invalid</span>
                        </>
                      )}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex flex-wrap gap-1">
                      {schema.tags.slice(0, 2).map(tag => (
                        <Badge key={tag} variant="secondary" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                      {schema.tags.length > 2 && (
                        <Badge variant="secondary" className="text-xs">
                          +{schema.tags.length - 2}
                        </Badge>
                      )}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-1 text-sm text-muted-foreground">
                      <Calendar className="h-3 w-3" />
                      <span>{formatDate(schema.updated_at)}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem asChild>
                          <Link to={`/schemas/${schema.id}`}>
                            <Edit className="mr-2 h-4 w-4" />
                            Edit
                          </Link>
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleDuplicateSchema(schema)}>
                          <Copy className="mr-2 h-4 w-4" />
                          Duplicate
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem 
                          onClick={() => handleDeleteSchema(schema.id)}
                          className="text-destructive"
                        >
                          <Trash2 className="mr-2 h-4 w-4" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Card>
      )}

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Schemas</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{filteredSchemas.length}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Valid Schemas</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {filteredSchemas.filter(s => s.is_valid).length}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Categories</CardTitle>
            <Database className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{categories.length}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg Properties</CardTitle>
            <Code className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {filteredSchemas.length > 0 
                ? Math.round(filteredSchemas.reduce((sum, s) => sum + getPropertyCount(s), 0) / filteredSchemas.length)
                : 0
              }
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

