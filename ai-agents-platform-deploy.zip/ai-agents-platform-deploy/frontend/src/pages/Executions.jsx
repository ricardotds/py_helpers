/**
 * Executions monitoring page with real-time updates
 */

import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  Search, 
  Filter, 
  MoreHorizontal, 
  Play,
  Pause,
  Square,
  RefreshCw,
  Clock,
  CheckCircle,
  XCircle,
  AlertCircle,
  Eye,
  Calendar,
  Timer,
  Activity,
  TrendingUp,
  Zap
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Progress } from '@/components/ui/progress';
import { apiClient } from '../lib/api';

export default function Executions() {
  const [executions, setExecutions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('');
  const [statuses, setStatuses] = useState([]);
  const [isConnected, setIsConnected] = useState(false);

  useEffect(() => {
    loadExecutions();
    // Simulate WebSocket connection for real-time updates
    simulateRealTimeUpdates();
  }, [searchTerm, selectedStatus]);

  const loadExecutions = async () => {
    try {
      setLoading(true);
      setError(null);
      
      // Mock data for development
      const mockExecutions = [
        {
          id: 'exec_001',
          pipeline_id: '1',
          pipeline_name: 'Customer Support Automation',
          status: 'running',
          progress: 60,
          current_step: 'Search Knowledge Base',
          step_index: 2,
          total_steps: 5,
          started_at: '2024-01-26T10:45:00Z',
          estimated_completion: '2024-01-26T10:46:30Z',
          duration: 45,
          input_data: { inquiry: 'How do I reset my password?' },
          output_data: null,
          error_message: null,
          user_id: 'dev-user'
        },
        {
          id: 'exec_002',
          pipeline_id: '2',
          pipeline_name: 'Document Analysis Pipeline',
          status: 'completed',
          progress: 100,
          current_step: 'Save Results',
          step_index: 5,
          total_steps: 5,
          started_at: '2024-01-26T10:30:00Z',
          completed_at: '2024-01-26T10:32:15Z',
          duration: 135,
          input_data: { document_url: 'https://example.com/doc.pdf' },
          output_data: { 
            summary: 'Document contains quarterly financial results...',
            insights: ['Revenue increased by 15%', 'New market expansion']
          },
          error_message: null,
          user_id: 'dev-user'
        },
        {
          id: 'exec_003',
          pipeline_id: '4',
          pipeline_name: 'Content Moderation System',
          status: 'failed',
          progress: 40,
          current_step: 'Safety Check',
          step_index: 2,
          total_steps: 6,
          started_at: '2024-01-26T10:20:00Z',
          failed_at: '2024-01-26T10:20:45Z',
          duration: 45,
          input_data: { content: 'User generated content to moderate' },
          output_data: null,
          error_message: 'API rate limit exceeded for safety check service',
          user_id: 'dev-user'
        },
        {
          id: 'exec_004',
          pipeline_id: '1',
          pipeline_name: 'Customer Support Automation',
          status: 'completed',
          progress: 100,
          current_step: 'Send Response',
          step_index: 5,
          total_steps: 5,
          started_at: '2024-01-26T10:15:00Z',
          completed_at: '2024-01-26T10:15:42Z',
          duration: 42,
          input_data: { inquiry: 'What are your business hours?' },
          output_data: { 
            response: 'Our business hours are Monday-Friday 9AM-6PM EST...',
            confidence: 0.95
          },
          error_message: null,
          user_id: 'dev-user'
        },
        {
          id: 'exec_005',
          pipeline_id: '2',
          pipeline_name: 'Document Analysis Pipeline',
          status: 'queued',
          progress: 0,
          current_step: 'Document Upload',
          step_index: 0,
          total_steps: 5,
          started_at: null,
          estimated_start: '2024-01-26T10:47:00Z',
          duration: 0,
          input_data: { document_url: 'https://example.com/report.pdf' },
          output_data: null,
          error_message: null,
          user_id: 'dev-user'
        }
      ];

      setExecutions(mockExecutions);
      
      // Extract unique statuses
      const uniqueStatuses = [...new Set(mockExecutions.map(exec => exec.status))];
      setStatuses(uniqueStatuses);
      
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const simulateRealTimeUpdates = () => {
    // Simulate WebSocket connection
    setIsConnected(true);
    
    // Simulate real-time updates every 2 seconds
    const interval = setInterval(() => {
      setExecutions(prevExecutions => 
        prevExecutions.map(exec => {
          if (exec.status === 'running' && exec.progress < 100) {
            const newProgress = Math.min(exec.progress + Math.random() * 20, 100);
            const newStatus = newProgress >= 100 ? 'completed' : 'running';
            const newStepIndex = Math.floor((newProgress / 100) * exec.total_steps);
            
            return {
              ...exec,
              progress: newProgress,
              status: newStatus,
              step_index: newStepIndex,
              duration: exec.duration + 2,
              completed_at: newStatus === 'completed' ? new Date().toISOString() : null
            };
          }
          return exec;
        })
      );
    }, 2000);

    // Cleanup interval on component unmount
    return () => {
      clearInterval(interval);
      setIsConnected(false);
    };
  };

  const handleCancelExecution = async (executionId) => {
    try {
      // In real app: await apiClient.cancelExecution(executionId);
      setExecutions(executions.map(exec => 
        exec.id === executionId 
          ? { ...exec, status: 'cancelled' }
          : exec
      ));
    } catch (err) {
      setError(err.message);
    }
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'Not started';
    return new Date(dateString).toLocaleString();
  };

  const formatDuration = (seconds) => {
    if (seconds < 60) return `${seconds}s`;
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}m ${remainingSeconds}s`;
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'running':
        return 'bg-blue-100 text-blue-800';
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'failed':
        return 'bg-red-100 text-red-800';
      case 'cancelled':
        return 'bg-gray-100 text-gray-800';
      case 'queued':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'running':
        return <RefreshCw className="h-4 w-4 text-blue-500 animate-spin" />;
      case 'completed':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'failed':
        return <XCircle className="h-4 w-4 text-red-500" />;
      case 'cancelled':
        return <Square className="h-4 w-4 text-gray-500" />;
      case 'queued':
        return <Clock className="h-4 w-4 text-yellow-500" />;
      default:
        return <AlertCircle className="h-4 w-4 text-gray-500" />;
    }
  };

  const filteredExecutions = executions.filter(execution => {
    const matchesSearch = execution.pipeline_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         execution.id.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = !selectedStatus || execution.status === selectedStatus;
    return matchesSearch && matchesStatus;
  });

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-bold">Executions</h1>
        </div>
        <div className="flex items-center justify-center py-12">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Executions</h1>
          <p className="text-muted-foreground">
            Monitor your pipeline executions in real-time
          </p>
        </div>
        <div className="flex items-center space-x-2">
          <div className="flex items-center space-x-1 text-sm">
            <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-green-500' : 'bg-red-500'}`}></div>
            <span className="text-muted-foreground">
              {isConnected ? 'Connected' : 'Disconnected'}
            </span>
          </div>
          <Button variant="outline" onClick={loadExecutions}>
            <RefreshCw className="mr-2 h-4 w-4" />
            Refresh
          </Button>
        </div>
      </div>

      {/* Error Alert */}
      {error && (
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Search & Filter</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search executions..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <div className="sm:w-48">
              <select
                value={selectedStatus}
                onChange={(e) => setSelectedStatus(e.target.value)}
                className="w-full px-3 py-2 border border-input bg-background rounded-md text-sm"
              >
                <option value="">All Statuses</option>
                <option value="running">Running</option>
                <option value="completed">Completed</option>
                <option value="failed">Failed</option>
                <option value="cancelled">Cancelled</option>
                <option value="queued">Queued</option>
              </select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Executions List */}
      {filteredExecutions.length === 0 ? (
        <Card>
          <CardContent className="text-center py-12">
            <Activity className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">No executions found</h3>
            <p className="text-muted-foreground mb-4">
              {searchTerm || selectedStatus 
                ? 'No executions match your current filters.' 
                : 'Pipeline executions will appear here when they start running.'
              }
            </p>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Execution</TableHead>
                <TableHead>Pipeline</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Progress</TableHead>
                <TableHead>Duration</TableHead>
                <TableHead>Started</TableHead>
                <TableHead className="w-[100px]">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredExecutions.map((execution) => (
                <TableRow key={execution.id}>
                  <TableCell>
                    <div className="flex items-center space-x-3">
                      <div className="p-2 rounded-lg bg-orange-500">
                        <Activity className="h-4 w-4 text-white" />
                      </div>
                      <div>
                        <div className="font-medium">{execution.id}</div>
                        <div className="text-sm text-muted-foreground">
                          Step {execution.step_index + 1} of {execution.total_steps}
                        </div>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div>
                      <div className="font-medium">{execution.pipeline_name}</div>
                      <div className="text-sm text-muted-foreground">
                        {execution.current_step}
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-2">
                      {getStatusIcon(execution.status)}
                      <Badge className={getStatusColor(execution.status)}>
                        {execution.status}
                      </Badge>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="space-y-1">
                      <div className="flex items-center justify-between text-sm">
                        <span>{Math.round(execution.progress)}%</span>
                        <span className="text-muted-foreground">
                          {execution.step_index + 1}/{execution.total_steps}
                        </span>
                      </div>
                      <Progress value={execution.progress} className="h-2" />
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-1">
                      <Timer className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm">{formatDuration(execution.duration)}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-1 text-sm text-muted-foreground">
                      <Calendar className="h-3 w-3" />
                      <span>{formatDate(execution.started_at)}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-1">
                      {execution.status === 'running' && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleCancelExecution(execution.id)}
                        >
                          <Square className="h-4 w-4" />
                        </Button>
                      )}
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem asChild>
                            <Link to={`/executions/${execution.id}`}>
                              <Eye className="mr-2 h-4 w-4" />
                              View Details
                            </Link>
                          </DropdownMenuItem>
                          <DropdownMenuItem asChild>
                            <Link to={`/pipelines/${execution.pipeline_id}`}>
                              <Eye className="mr-2 h-4 w-4" />
                              View Pipeline
                            </Link>
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Card>
      )}

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Executions</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{filteredExecutions.length}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Running</CardTitle>
            <RefreshCw className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {filteredExecutions.filter(e => e.status === 'running').length}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Completed</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {filteredExecutions.filter(e => e.status === 'completed').length}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Success Rate</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {filteredExecutions.length > 0 
                ? Math.round((filteredExecutions.filter(e => e.status === 'completed').length / filteredExecutions.length) * 100)
                : 0
              }%
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

