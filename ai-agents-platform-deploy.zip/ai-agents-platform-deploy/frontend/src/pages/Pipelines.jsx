/**
 * Pipelines management page with basic visual editor
 */

import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  Plus, 
  Search, 
  Filter, 
  MoreHorizontal, 
  Edit, 
  Trash2, 
  Copy,
  Play,
  Pause,
  Square,
  GitBranch,
  Tag,
  Calendar,
  User,
  CheckCircle,
  XCircle,
  AlertCircle,
  Clock,
  Zap,
  Settings,
  Eye
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { apiClient } from '../lib/api';

export default function Pipelines() {
  const [pipelines, setPipelines] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('');
  const [statuses, setStatuses] = useState([]);

  useEffect(() => {
    loadPipelines();
  }, [searchTerm, selectedStatus]);

  const loadPipelines = async () => {
    try {
      setLoading(true);
      setError(null);
      
      // Mock data for development
      const mockPipelines = [
        {
          id: '1',
          name: 'Customer Support Automation',
          description: 'Automated customer inquiry processing and response generation',
          tags: ['customer-service', 'automation', 'llm'],
          status: 'active',
          last_run: '2024-01-26T10:30:00Z',
          last_run_status: 'success',
          total_runs: 156,
          success_rate: 94.2,
          avg_duration: 45,
          steps: [
            { id: 'input', type: 'input', name: 'Customer Inquiry' },
            { id: 'classify', type: 'llm', name: 'Classify Intent' },
            { id: 'search', type: 'rag', name: 'Search Knowledge Base' },
            { id: 'generate', type: 'llm', name: 'Generate Response' },
            { id: 'output', type: 'output', name: 'Send Response' }
          ],
          created_at: '2024-01-15T10:00:00Z',
          updated_at: '2024-01-25T14:30:00Z',
          owner_id: 'dev-user'
        },
        {
          id: '2',
          name: 'Document Analysis Pipeline',
          description: 'Extract insights and summaries from uploaded documents',
          tags: ['document-processing', 'analysis', 'extraction'],
          status: 'active',
          last_run: '2024-01-26T09:15:00Z',
          last_run_status: 'success',
          total_runs: 89,
          success_rate: 97.8,
          avg_duration: 120,
          steps: [
            { id: 'upload', type: 'input', name: 'Document Upload' },
            { id: 'extract', type: 'python', name: 'Extract Text' },
            { id: 'analyze', type: 'llm', name: 'Analyze Content' },
            { id: 'summarize', type: 'llm', name: 'Generate Summary' },
            { id: 'save', type: 'api', name: 'Save Results' }
          ],
          created_at: '2024-01-12T09:00:00Z',
          updated_at: '2024-01-24T11:20:00Z',
          owner_id: 'dev-user'
        },
        {
          id: '3',
          name: 'Product Recommendation Engine',
          description: 'Generate personalized product recommendations based on user behavior',
          tags: ['recommendations', 'personalization', 'ml'],
          status: 'draft',
          last_run: null,
          last_run_status: null,
          total_runs: 0,
          success_rate: 0,
          avg_duration: 0,
          steps: [
            { id: 'user_data', type: 'input', name: 'User Data' },
            { id: 'fetch_history', type: 'api', name: 'Fetch Purchase History' },
            { id: 'analyze_behavior', type: 'python', name: 'Analyze Behavior' },
            { id: 'generate_recs', type: 'llm', name: 'Generate Recommendations' },
            { id: 'rank_products', type: 'python', name: 'Rank Products' },
            { id: 'return_results', type: 'output', name: 'Return Results' }
          ],
          created_at: '2024-01-20T14:00:00Z',
          updated_at: '2024-01-25T16:45:00Z',
          owner_id: 'dev-user'
        },
        {
          id: '4',
          name: 'Content Moderation System',
          description: 'Automated content review and moderation for user-generated content',
          tags: ['moderation', 'safety', 'classification'],
          status: 'paused',
          last_run: '2024-01-24T15:20:00Z',
          last_run_status: 'failed',
          total_runs: 234,
          success_rate: 89.7,
          avg_duration: 30,
          steps: [
            { id: 'content_input', type: 'input', name: 'Content Input' },
            { id: 'detect_language', type: 'llm', name: 'Detect Language' },
            { id: 'check_safety', type: 'llm', name: 'Safety Check' },
            { id: 'classify_content', type: 'llm', name: 'Classify Content' },
            { id: 'make_decision', type: 'python', name: 'Moderation Decision' },
            { id: 'notify_result', type: 'api', name: 'Notify Result' }
          ],
          created_at: '2024-01-08T11:00:00Z',
          updated_at: '2024-01-24T15:20:00Z',
          owner_id: 'dev-user'
        }
      ];

      setPipelines(mockPipelines);
      
      // Extract unique statuses
      const uniqueStatuses = [...new Set(mockPipelines.map(pipeline => pipeline.status))];
      setStatuses(uniqueStatuses);
      
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleDeletePipeline = async (pipelineId) => {
    if (!confirm('Are you sure you want to delete this pipeline?')) return;
    
    try {
      // In real app: await apiClient.deletePipeline(pipelineId);
      setPipelines(pipelines.filter(pipeline => pipeline.id !== pipelineId));
    } catch (err) {
      setError(err.message);
    }
  };

  const handleDuplicatePipeline = async (pipeline) => {
    try {
      const duplicatedPipeline = {
        ...pipeline,
        id: Date.now().toString(),
        name: `${pipeline.name} (Copy)`,
        status: 'draft',
        total_runs: 0,
        last_run: null,
        last_run_status: null,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };
      
      setPipelines([...pipelines, duplicatedPipeline]);
    } catch (err) {
      setError(err.message);
    }
  };

  const handleRunPipeline = async (pipelineId) => {
    try {
      // In real app: await apiClient.runPipeline(pipelineId);
      console.log('Running pipeline:', pipelineId);
      // Update pipeline status to show it's running
      setPipelines(pipelines.map(p => 
        p.id === pipelineId 
          ? { ...p, status: 'running', last_run: new Date().toISOString() }
          : p
      ));
    } catch (err) {
      setError(err.message);
    }
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'Never';
    return new Date(dateString).toLocaleDateString();
  };

  const formatDuration = (seconds) => {
    if (seconds < 60) return `${seconds}s`;
    return `${Math.floor(seconds / 60)}m ${seconds % 60}s`;
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'active':
        return 'bg-green-100 text-green-800';
      case 'draft':
        return 'bg-gray-100 text-gray-800';
      case 'paused':
        return 'bg-yellow-100 text-yellow-800';
      case 'running':
        return 'bg-blue-100 text-blue-800';
      case 'error':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getRunStatusIcon = (status) => {
    switch (status) {
      case 'success':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'failed':
        return <XCircle className="h-4 w-4 text-red-500" />;
      case 'running':
        return <Clock className="h-4 w-4 text-blue-500" />;
      default:
        return <AlertCircle className="h-4 w-4 text-gray-500" />;
    }
  };

  const getStepTypeIcon = (type) => {
    switch (type) {
      case 'input':
        return '📥';
      case 'output':
        return '📤';
      case 'llm':
        return '🤖';
      case 'api':
        return '🌐';
      case 'rag':
        return '🗄️';
      case 'python':
        return '🐍';
      default:
        return '⚙️';
    }
  };

  const filteredPipelines = pipelines.filter(pipeline => {
    const matchesSearch = pipeline.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         pipeline.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = !selectedStatus || pipeline.status === selectedStatus;
    return matchesSearch && matchesStatus;
  });

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-bold">Pipelines</h1>
        </div>
        <div className="flex items-center justify-center py-12">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Pipelines</h1>
          <p className="text-muted-foreground">
            Build and manage your AI workflow pipelines
          </p>
        </div>
        <Button asChild>
          <Link to="/pipelines/new">
            <Plus className="mr-2 h-4 w-4" />
            New Pipeline
          </Link>
        </Button>
      </div>

      {/* Error Alert */}
      {error && (
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Search & Filter</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search pipelines..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <div className="sm:w-48">
              <select
                value={selectedStatus}
                onChange={(e) => setSelectedStatus(e.target.value)}
                className="w-full px-3 py-2 border border-input bg-background rounded-md text-sm"
              >
                <option value="">All Statuses</option>
                <option value="active">Active</option>
                <option value="draft">Draft</option>
                <option value="paused">Paused</option>
                <option value="running">Running</option>
                <option value="error">Error</option>
              </select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Pipelines List */}
      {filteredPipelines.length === 0 ? (
        <Card>
          <CardContent className="text-center py-12">
            <GitBranch className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">No pipelines found</h3>
            <p className="text-muted-foreground mb-4">
              {searchTerm || selectedStatus 
                ? 'No pipelines match your current filters.' 
                : 'Get started by creating your first pipeline.'
              }
            </p>
            <Button asChild>
              <Link to="/pipelines/new">
                <Plus className="mr-2 h-4 w-4" />
                Create Pipeline
              </Link>
            </Button>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Steps</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Last Run</TableHead>
                <TableHead>Success Rate</TableHead>
                <TableHead>Avg Duration</TableHead>
                <TableHead>Tags</TableHead>
                <TableHead className="w-[100px]">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredPipelines.map((pipeline) => (
                <TableRow key={pipeline.id}>
                  <TableCell>
                    <div className="flex items-center space-x-3">
                      <div className="p-2 rounded-lg bg-blue-500">
                        <GitBranch className="h-4 w-4 text-white" />
                      </div>
                      <div>
                        <div className="font-medium">{pipeline.name}</div>
                        {pipeline.description && (
                          <div className="text-sm text-muted-foreground truncate max-w-xs">
                            {pipeline.description}
                          </div>
                        )}
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-1">
                      {pipeline.steps.slice(0, 4).map((step, index) => (
                        <span key={step.id} className="text-lg" title={step.name}>
                          {getStepTypeIcon(step.type)}
                        </span>
                      ))}
                      {pipeline.steps.length > 4 && (
                        <span className="text-xs text-muted-foreground">
                          +{pipeline.steps.length - 4}
                        </span>
                      )}
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge className={getStatusColor(pipeline.status)}>
                      {pipeline.status}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-1">
                      {getRunStatusIcon(pipeline.last_run_status)}
                      <span className="text-sm">{formatDate(pipeline.last_run)}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="text-sm">
                      {pipeline.total_runs > 0 ? (
                        <>
                          <span className="font-medium">{pipeline.success_rate}%</span>
                          <span className="text-muted-foreground"> ({pipeline.total_runs} runs)</span>
                        </>
                      ) : (
                        <span className="text-muted-foreground">No runs</span>
                      )}
                    </div>
                  </TableCell>
                  <TableCell>
                    <span className="text-sm">
                      {pipeline.avg_duration > 0 ? formatDuration(pipeline.avg_duration) : '-'}
                    </span>
                  </TableCell>
                  <TableCell>
                    <div className="flex flex-wrap gap-1">
                      {pipeline.tags.slice(0, 2).map(tag => (
                        <Badge key={tag} variant="secondary" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                      {pipeline.tags.length > 2 && (
                        <Badge variant="secondary" className="text-xs">
                          +{pipeline.tags.length - 2}
                        </Badge>
                      )}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-1">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleRunPipeline(pipeline.id)}
                        disabled={pipeline.status === 'running'}
                      >
                        <Play className="h-4 w-4" />
                      </Button>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem asChild>
                            <Link to={`/pipelines/${pipeline.id}`}>
                              <Eye className="mr-2 h-4 w-4" />
                              View
                            </Link>
                          </DropdownMenuItem>
                          <DropdownMenuItem asChild>
                            <Link to={`/pipelines/${pipeline.id}/edit`}>
                              <Edit className="mr-2 h-4 w-4" />
                              Edit
                            </Link>
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleDuplicatePipeline(pipeline)}>
                            <Copy className="mr-2 h-4 w-4" />
                            Duplicate
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem 
                            onClick={() => handleDeletePipeline(pipeline.id)}
                            className="text-destructive"
                          >
                            <Trash2 className="mr-2 h-4 w-4" />
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Card>
      )}

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Pipelines</CardTitle>
            <GitBranch className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{filteredPipelines.length}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Pipelines</CardTitle>
            <Zap className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {filteredPipelines.filter(p => p.status === 'active').length}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Runs</CardTitle>
            <Play className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {filteredPipelines.reduce((sum, p) => sum + p.total_runs, 0)}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg Success Rate</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {filteredPipelines.length > 0 
                ? Math.round(filteredPipelines.reduce((sum, p) => sum + p.success_rate, 0) / filteredPipelines.length)
                : 0
              }%
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

