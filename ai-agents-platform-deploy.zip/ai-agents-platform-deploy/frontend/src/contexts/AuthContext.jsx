/**
 * Authentication context for managing user state
 */

import { createContext, useContext, useState, useEffect } from 'react';
import { apiClient } from '../lib/api';

const AuthContext = createContext();

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    checkAuthStatus();
  }, []);

  const checkAuthStatus = async () => {
    try {
      // Development mode bypass for testing
      if (import.meta.env.DEV && !localStorage.getItem('access_token')) {
        // Set a mock user for development
        setUser({
          id: 'dev-user',
          name: 'Development User',
          email: 'dev@example.com',
          groups: ['developers']
        });
        setLoading(false);
        return;
      }

      const token = localStorage.getItem('access_token');
      if (!token) {
        setLoading(false);
        return;
      }

      apiClient.setToken(token);
      const userData = await apiClient.getCurrentUser();
      setUser(userData);
    } catch (error) {
      console.error('Auth check failed:', error);
      localStorage.removeItem('access_token');
      apiClient.setToken(null);
    } finally {
      setLoading(false);
    }
  };

  const login = async (credentials) => {
    try {
      setError(null);
      setLoading(true);
      
      const response = await apiClient.login(credentials);
      
      if (response.access_token) {
        apiClient.setToken(response.access_token);
        const userData = await apiClient.getCurrentUser();
        setUser(userData);
        return { success: true };
      } else {
        // Handle OAuth redirect
        if (response.auth_url) {
          window.location.href = response.auth_url;
          return { success: true, redirect: true };
        }
      }
    } catch (error) {
      setError(error.message);
      return { success: false, error: error.message };
    } finally {
      setLoading(false);
    }
  };

  const logout = () => {
    localStorage.removeItem('access_token');
    apiClient.setToken(null);
    setUser(null);
    window.location.href = '/login';
  };

  const refreshToken = async () => {
    try {
      const response = await apiClient.refreshToken();
      if (response.access_token) {
        apiClient.setToken(response.access_token);
        return true;
      }
    } catch (error) {
      console.error('Token refresh failed:', error);
      logout();
    }
    return false;
  };

  const value = {
    user,
    loading,
    error,
    login,
    logout,
    refreshToken,
    isAuthenticated: !!user,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

