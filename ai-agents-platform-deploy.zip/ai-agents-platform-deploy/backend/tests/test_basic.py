"""
Basic tests to verify the testing framework works
"""

import pytest
import os

# Set test environment
os.environ["PYTEST_CURRENT_TEST"] = "true"

from tests.test_config import setup_test_environment
setup_test_environment()


def test_environment_setup():
    """Test that the test environment is properly set up"""
    assert os.getenv("PYTEST_CURRENT_TEST") is not None  # pytest sets this automatically
    assert os.getenv("AZURE_CLIENT_ID") == "test-client-id"
    assert os.getenv("SECRET_KEY") == "test-secret-key-for-testing-only"


def test_basic_math():
    """Basic test to verify pytest is working"""
    assert 1 + 1 == 2
    assert 2 * 3 == 6


def test_string_operations():
    """Test string operations"""
    test_string = "AI Agents Platform"
    assert "AI" in test_string
    assert test_string.lower() == "ai agents platform"


@pytest.mark.asyncio
async def test_async_function():
    """Test async functionality"""
    async def async_add(a, b):
        return a + b
    
    result = await async_add(5, 3)
    assert result == 8


class TestBasicClass:
    """Test class-based tests"""
    
    def test_class_method(self):
        """Test method in class"""
        assert True
    
    def test_list_operations(self):
        """Test list operations"""
        test_list = [1, 2, 3, 4, 5]
        assert len(test_list) == 5
        assert 3 in test_list
        assert test_list[0] == 1

