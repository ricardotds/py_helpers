"""
Tests for pipeline API endpoints
"""

import pytest
from httpx import AsyncClient
from unittest.mock import AsyncMock

from app.models.pipeline import Pipeline


@pytest.mark.asyncio
async def test_create_pipeline(test_client: AsyncClient, mock_db, mock_user):
    """Test creating a new pipeline"""
    pipeline_data = {
        "name": "Test Pipeline",
        "description": "A test pipeline",
        "steps": [
            {
                "id": "step1",
                "name": "Step 1",
                "type": "llm",
                "config": {"model": "gpt-4"},
                "depends_on": []
            }
        ]
    }
    
    # Mock the database insert operation
    mock_db.pipelines.insert_one.return_value = AsyncMock(inserted_id="655c8a3b8e8a8a8a8a8a8a8c")
    
    response = await test_client.post("/api/v1/pipelines", json=pipeline_data)
    
    assert response.status_code == 201
    response_data = response.json()
    assert response_data["name"] == "Test Pipeline"
    assert response_data["owner_id"] == str(mock_user.id)


@pytest.mark.asyncio
async def test_get_pipeline(test_client: AsyncClient, mock_db, mock_user):
    """Test getting a pipeline by ID"""
    pipeline = Pipeline(
        id="655c8a3b8e8a8a8a8a8a8a8c",
        name="Test Pipeline",
        description="A test pipeline",
        owner_id=str(mock_user.id),
        steps=[],
        outputs=[]
    )
    
    # Mock the database find operation
    mock_db.pipelines.find_one.return_value = pipeline.model_dump()
    
    response = await test_client.get(f"/api/v1/pipelines/{pipeline.id}")
    
    assert response.status_code == 200
    assert response.json()["name"] == "Test Pipeline"


@pytest.mark.asyncio
async def test_get_pipelines(test_client: AsyncClient, mock_db, mock_user):
    """Test getting all pipelines for a user"""
    pipelines = [
        Pipeline(
            id="1", 
            name="Pipeline 1", 
            description="First pipeline",
            owner_id=str(mock_user.id),
            steps=[],
            outputs=[]
        ).model_dump(),
        Pipeline(
            id="2", 
            name="Pipeline 2", 
            description="Second pipeline",
            owner_id=str(mock_user.id),
            steps=[],
            outputs=[]
        ).model_dump()
    ]
    
    # Mock the database find operation
    mock_db.pipelines.find.return_value = AsyncMock(to_list=AsyncMock(return_value=pipelines))
    mock_db.pipelines.count_documents.return_value = len(pipelines)
    
    response = await test_client.get("/api/v1/pipelines")
    
    assert response.status_code == 200
    response_data = response.json()
    assert len(response_data["data"]) == 2
    assert response_data["total"] == 2


@pytest.mark.asyncio
async def test_update_pipeline(test_client: AsyncClient, mock_db, mock_user):
    """Test updating a pipeline"""
    pipeline = Pipeline(
        id="655c8a3b8e8a8a8a8a8a8a8c",
        name="Test Pipeline",
        description="A test pipeline",
        owner_id=str(mock_user.id),
        steps=[],
        outputs=[]
    )
    
    # Mock the database operations
    mock_db.pipelines.find_one.return_value = pipeline.model_dump()
    mock_db.pipelines.update_one.return_value = AsyncMock(modified_count=1)
    
    # Create updated pipeline for the second find_one call
    updated_pipeline = pipeline.model_copy()
    updated_pipeline.name = "Updated Pipeline"
    
    # Configure mock to return updated pipeline on second call
    mock_db.pipelines.find_one.side_effect = [
        pipeline.model_dump(),  # First call for permission check
        updated_pipeline.model_dump()  # Second call for returning updated data
    ]
    
    update_data = {"name": "Updated Pipeline"}
    
    response = await test_client.put(f"/api/v1/pipelines/{pipeline.id}", json=update_data)
    
    assert response.status_code == 200
    assert response.json()["name"] == "Updated Pipeline"


@pytest.mark.asyncio
async def test_delete_pipeline(test_client: AsyncClient, mock_db, mock_user):
    """Test deleting a pipeline"""
    pipeline = Pipeline(
        id="655c8a3b8e8a8a8a8a8a8a8c",
        name="Test Pipeline",
        description="A test pipeline",
        owner_id=str(mock_user.id),
        steps=[],
        outputs=[]
    )
    
    # Mock the database operations
    mock_db.pipelines.find_one.return_value = pipeline.model_dump()
    mock_db.pipelines.delete_one.return_value = AsyncMock(deleted_count=1)
    
    response = await test_client.delete(f"/api/v1/pipelines/{pipeline.id}")
    
    assert response.status_code == 204


@pytest.mark.asyncio
async def test_get_pipeline_not_found(test_client: AsyncClient, mock_db, mock_user):
    """Test getting a non-existent pipeline"""
    # Mock the database to return None (not found)
    mock_db.pipelines.find_one.return_value = None
    
    response = await test_client.get("/api/v1/pipelines/nonexistent")
    
    assert response.status_code == 404


@pytest.mark.asyncio
async def test_update_pipeline_not_found(test_client: AsyncClient, mock_db, mock_user):
    """Test updating a non-existent pipeline"""
    # Mock the database to return None (not found)
    mock_db.pipelines.find_one.return_value = None
    
    update_data = {"name": "Updated Pipeline"}
    
    response = await test_client.put("/api/v1/pipelines/nonexistent", json=update_data)
    
    assert response.status_code == 404


@pytest.mark.asyncio
async def test_delete_pipeline_not_found(test_client: AsyncClient, mock_db, mock_user):
    """Test deleting a non-existent pipeline"""
    # Mock the database to return None (not found)
    mock_db.pipelines.find_one.return_value = None
    
    response = await test_client.delete("/api/v1/pipelines/nonexistent")
    
    assert response.status_code == 404


