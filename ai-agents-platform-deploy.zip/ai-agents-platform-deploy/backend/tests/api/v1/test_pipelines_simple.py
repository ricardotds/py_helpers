"""
Simple tests for pipeline API endpoints
"""

import pytest
from httpx import AsyncClient
from unittest.mock import AsyncMock, MagicMock, patch

# Set test environment before imports
import os
os.environ["PYTEST_CURRENT_TEST"] = "true"

from tests.test_config import setup_test_environment
setup_test_environment()

from app.main import app
from app.database.connection import get_database


@pytest.fixture(scope="function")
def mock_db():
    """Mock the database connection."""
    mock_database = MagicMock()
    
    # Mock collections
    mock_database.pipelines = MagicMock()
    mock_database.pipelines.find_one = AsyncMock(return_value=None)
    mock_database.pipelines.find = MagicMock(return_value=AsyncMock(to_list=AsyncMock(return_value=[])))
    mock_database.pipelines.insert_one = AsyncMock(return_value=MagicMock(inserted_id="test_id"))
    mock_database.pipelines.update_one = AsyncMock(return_value=MagicMock(modified_count=1))
    mock_database.pipelines.delete_one = AsyncMock(return_value=MagicMock(deleted_count=1))
    mock_database.pipelines.count_documents = AsyncMock(return_value=0)
    
    # Override the database dependency
    async def get_mock_database():
        return mock_database
    
    app.dependency_overrides[get_database] = get_mock_database
    return mock_database


@pytest.fixture(scope="function")
def mock_auth():
    """Mock the authentication."""
    from app.auth.dependencies import get_current_active_user
    
    # Create a simple user dict instead of User object
    mock_user_data = {
        "id": "test_user_id",
        "email": "test@example.com",
        "name": "Test User",
        "azure_object_id": "test-azure-id",
        "groups": ["test-group"],
        "is_active": True,
        "is_admin": False
    }
    
    async def mock_get_current_active_user():
        # Return a simple object with the required attributes
        class MockUser:
            def __init__(self, data):
                for key, value in data.items():
                    setattr(self, key, value)
        
        return MockUser(mock_user_data)
    
    app.dependency_overrides[get_current_active_user] = mock_get_current_active_user
    return mock_user_data


@pytest.fixture(scope="function")
async def test_client(mock_db, mock_auth) -> AsyncClient:
    """Create a test client for the FastAPI application."""
    async with AsyncClient(app=app, base_url="http://test") as client:
        yield client


@pytest.mark.asyncio
async def test_create_pipeline_simple(test_client: AsyncClient, mock_db):
    """Test creating a new pipeline"""
    pipeline_data = {
        "name": "Test Pipeline",
        "description": "A test pipeline",
        "steps": [
            {
                "id": "step1",
                "name": "Step 1",
                "type": "llm",
                "config": {"model": "gpt-4"},
                "depends_on": []
            }
        ]
    }
    
    # Mock the database insert operation
    mock_db.pipelines.insert_one.return_value = AsyncMock(inserted_id="655c8a3b8e8a8a8a8a8a8a8c")
    
    response = await test_client.post("/api/v1/pipelines", json=pipeline_data)
    
    assert response.status_code == 201
    response_data = response.json()
    assert response_data["name"] == "Test Pipeline"


@pytest.mark.asyncio
async def test_get_pipelines_simple(test_client: AsyncClient, mock_db):
    """Test getting all pipelines for a user"""
    pipelines = [
        {
            "id": "1", 
            "name": "Pipeline 1", 
            "description": "First pipeline",
            "owner_id": "test_user_id",
            "steps": [],
            "outputs": [],
            "created_at": "2023-01-01T00:00:00Z",
            "updated_at": "2023-01-01T00:00:00Z"
        }
    ]
    
    # Mock the database find operation
    mock_db.pipelines.find.return_value = AsyncMock(to_list=AsyncMock(return_value=pipelines))
    mock_db.pipelines.count_documents.return_value = len(pipelines)
    
    response = await test_client.get("/api/v1/pipelines")
    
    assert response.status_code == 200
    response_data = response.json()
    assert len(response_data["data"]) == 1
    assert response_data["total"] == 1


@pytest.fixture(autouse=True)
def cleanup_overrides():
    """Clean up dependency overrides after each test."""
    yield
    app.dependency_overrides.clear()

