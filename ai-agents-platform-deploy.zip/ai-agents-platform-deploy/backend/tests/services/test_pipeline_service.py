"""
Tests for pipeline service
"""

import pytest
from unittest.mock import AsyncMock, MagicMock

from app.services.pipeline_service import PipelineService
from app.models.pipeline import Pipeline, PipelineCreate
from app.models.user import User


@pytest.mark.asyncio
async def test_create_pipeline_service(mock_db):
    """Test creating a pipeline with the service"""
    pipeline_service = PipelineService()
    user = User(id="user1", email="test@example.com", name="Test User")
    pipeline_data = PipelineCreate(
        name="Service Test Pipeline",
        description="A test pipeline",
        steps=[],
        outputs=[]
    )
    
    # Mock the database insert operation
    mock_db.pipelines.insert_one.return_value = AsyncMock(inserted_id="pipeline1")
    
    pipeline = await pipeline_service.create_pipeline(pipeline_data, user)
    
    assert pipeline.id == "pipeline1"
    assert pipeline.name == "Service Test Pipeline"
    assert pipeline.owner_id == "user1"


@pytest.mark.asyncio
async def test_get_pipeline_service(mock_db):
    """Test getting a pipeline with the service"""
    pipeline_service = PipelineService()
    user = User(id="user1", email="test@example.com", name="Test User")
    
    pipeline_data = {
        "id": "pipeline1",
        "name": "Test Pipeline",
        "description": "A test pipeline",
        "owner_id": "user1",
        "steps": [],
        "outputs": [],
        "created_at": "2023-01-01T00:00:00Z",
        "updated_at": "2023-01-01T00:00:00Z"
    }
    
    # Mock the database find operation
    mock_db.pipelines.find_one.return_value = pipeline_data
    
    pipeline = await pipeline_service.get_pipeline("pipeline1", user)
    
    assert pipeline is not None
    assert pipeline.id == "pipeline1"
    assert pipeline.name == "Test Pipeline"


@pytest.mark.asyncio
async def test_get_pipeline_not_found(mock_db):
    """Test getting a non-existent pipeline"""
    pipeline_service = PipelineService()
    user = User(id="user1", email="test@example.com", name="Test User")
    
    # Mock the database to return None
    mock_db.pipelines.find_one.return_value = None
    
    pipeline = await pipeline_service.get_pipeline("nonexistent", user)
    
    assert pipeline is None


@pytest.mark.asyncio
async def test_list_pipelines_service(mock_db):
    """Test listing pipelines with the service"""
    pipeline_service = PipelineService()
    user = User(id="user1", email="test@example.com", name="Test User")
    
    pipelines_data = [
        {
            "id": "pipeline1",
            "name": "Pipeline 1",
            "description": "First pipeline",
            "owner_id": "user1",
            "steps": [],
            "outputs": [],
            "created_at": "2023-01-01T00:00:00Z",
            "updated_at": "2023-01-01T00:00:00Z"
        },
        {
            "id": "pipeline2",
            "name": "Pipeline 2",
            "description": "Second pipeline",
            "owner_id": "user1",
            "steps": [],
            "outputs": [],
            "created_at": "2023-01-01T00:00:00Z",
            "updated_at": "2023-01-01T00:00:00Z"
        }
    ]
    
    # Mock the database operations
    mock_db.pipelines.find.return_value = AsyncMock(to_list=AsyncMock(return_value=pipelines_data))
    mock_db.pipelines.count_documents.return_value = len(pipelines_data)
    
    result = await pipeline_service.list_pipelines(user, skip=0, limit=10)
    
    assert result["total"] == 2
    assert len(result["data"]) == 2
    assert result["data"][0].name == "Pipeline 1"


@pytest.mark.asyncio
async def test_validate_pipeline_service():
    """Test pipeline validation logic"""
    pipeline_service = PipelineService()
    
    # Test valid pipeline
    valid_pipeline_data = PipelineCreate(
        name="Valid Pipeline",
        description="A valid pipeline",
        steps=[
            {
                "id": "s1", 
                "name": "Step 1", 
                "type": "llm", 
                "depends_on": [], 
                "outputs": ["output1"],
                "config": {"model": "gpt-4"}
            },
            {
                "id": "s2", 
                "name": "Step 2", 
                "type": "api", 
                "depends_on": ["s1"],
                "config": {"url": "https://api.example.com"}
            }
        ],
        outputs=[
            {"name": "final_output", "source_step": "s2", "source_output": "response"}
        ]
    )
    
    errors = await pipeline_service._validate_pipeline_structure(valid_pipeline_data)
    assert not errors
    
    # Test invalid pipeline (circular dependency)
    invalid_pipeline_data = PipelineCreate(
        name="Invalid Pipeline",
        description="An invalid pipeline",
        steps=[
            {
                "id": "s1", 
                "name": "Step 1", 
                "type": "llm", 
                "depends_on": ["s2"],
                "config": {"model": "gpt-4"}
            },
            {
                "id": "s2", 
                "name": "Step 2", 
                "type": "api", 
                "depends_on": ["s1"],
                "config": {"url": "https://api.example.com"}
            }
        ],
        outputs=[]
    )
    
    errors = await pipeline_service._validate_pipeline_structure(invalid_pipeline_data)
    assert any("circular dependency" in e.lower() for e in errors)

    # Test invalid pipeline (missing dependency)
    invalid_pipeline_2_data = PipelineCreate(
        name="Invalid Pipeline 2",
        description="Another invalid pipeline",
        steps=[
            {
                "id": "s1", 
                "name": "Step 1", 
                "type": "llm", 
                "depends_on": ["s3"],
                "config": {"model": "gpt-4"}
            }
        ],
        outputs=[]
    )
    
    errors = await pipeline_service._validate_pipeline_structure(invalid_pipeline_2_data)
    assert any("non-existent step 's3'" in e for e in errors)


@pytest.mark.asyncio
async def test_update_pipeline_service(mock_db):
    """Test updating a pipeline with the service"""
    pipeline_service = PipelineService()
    user = User(id="user1", email="test@example.com", name="Test User")
    
    existing_pipeline_data = {
        "id": "pipeline1",
        "name": "Original Pipeline",
        "description": "Original description",
        "owner_id": "user1",
        "steps": [],
        "outputs": [],
        "created_at": "2023-01-01T00:00:00Z",
        "updated_at": "2023-01-01T00:00:00Z"
    }
    
    update_data = PipelineCreate(
        name="Updated Pipeline",
        description="Updated description",
        steps=[],
        outputs=[]
    )
    
    # Mock the database operations
    mock_db.pipelines.find_one.return_value = existing_pipeline_data
    mock_db.pipelines.update_one.return_value = AsyncMock(modified_count=1)
    
    # Mock the second find_one call to return updated data
    updated_pipeline_data = existing_pipeline_data.copy()
    updated_pipeline_data["name"] = "Updated Pipeline"
    updated_pipeline_data["description"] = "Updated description"
    
    mock_db.pipelines.find_one.side_effect = [
        existing_pipeline_data,  # First call for permission check
        updated_pipeline_data    # Second call for returning updated data
    ]
    
    pipeline = await pipeline_service.update_pipeline("pipeline1", update_data, user)
    
    assert pipeline is not None
    assert pipeline.name == "Updated Pipeline"
    assert pipeline.description == "Updated description"


@pytest.mark.asyncio
async def test_delete_pipeline_service(mock_db):
    """Test deleting a pipeline with the service"""
    pipeline_service = PipelineService()
    user = User(id="user1", email="test@example.com", name="Test User")
    
    existing_pipeline_data = {
        "id": "pipeline1",
        "name": "Pipeline to Delete",
        "description": "This will be deleted",
        "owner_id": "user1",
        "steps": [],
        "outputs": [],
        "created_at": "2023-01-01T00:00:00Z",
        "updated_at": "2023-01-01T00:00:00Z"
    }
    
    # Mock the database operations
    mock_db.pipelines.find_one.return_value = existing_pipeline_data
    mock_db.pipelines.delete_one.return_value = AsyncMock(deleted_count=1)
    
    result = await pipeline_service.delete_pipeline("pipeline1", user)
    
    assert result is True



