"""
Pytest configuration and fixtures
"""

import os
import pytest
import asyncio
from httpx import AsyncClient
from unittest.mock import MagicMock, AsyncMock, patch
from typing import Any

# Set PYTEST_CURRENT_TEST environment variable before any imports
os.environ["PYTEST_CURRENT_TEST"] = "true"

# Set up test environment before importing the app
from tests.test_config import setup_test_environment
setup_test_environment()

from app.main import app
from app.database.connection import get_database, close_database_connection
from app.auth.dependencies import get_current_active_user
from app.models.user import User


@pytest.fixture(scope="session")
def event_loop():
    """Create an instance of the default event loop for each test session."""
    loop = asyncio.get_event_loop_policy().new_event_loop()
    yield loop
    loop.close()


@pytest.fixture(scope="function")
def mock_db():
    """Mock the database connection."""
    # Create a mock database object that behaves like MongoDB
    mock_database = MagicMock()
    
    # Mock collections
    mock_database.users = MagicMock()
    mock_database.pipelines = MagicMock()
    mock_database.tools = MagicMock()
    mock_database.prompts = MagicMock()
    mock_database.schemas = MagicMock()
    mock_database.rag_indexes = MagicMock()
    mock_database.executions = MagicMock()
    
    # Configure default return values for common operations
    for collection in [mock_database.users, mock_database.pipelines, mock_database.tools,
                      mock_database.prompts, mock_database.schemas, mock_database.rag_indexes,
                      mock_database.executions]:
        collection.find_one = AsyncMock(return_value=None)
        collection.find = MagicMock(return_value=AsyncMock(to_list=AsyncMock(return_value=[])))
        collection.insert_one = AsyncMock(return_value=MagicMock(inserted_id="test_id"))
        collection.update_one = AsyncMock(return_value=MagicMock(modified_count=1))
        collection.delete_one = AsyncMock(return_value=MagicMock(deleted_count=1))
        collection.count_documents = AsyncMock(return_value=0)
    
    # Override the database dependency
    async def get_mock_database():
        return mock_database
    
    app.dependency_overrides[get_database] = get_mock_database
    return mock_database


@pytest.fixture(scope="function")
async def test_client(mock_db) -> AsyncClient:
    """Create a test client for the FastAPI application."""
    async with AsyncClient(app=app, base_url="http://test") as client:
        yield client


@pytest.fixture(scope="function")
def mock_user(mock_db) -> User:
    """Create a mock user for testing."""
    # Create user data as dict first to avoid Pydantic validation issues
    user_data = {
        "id": "655c8a3b8e8a8a8a8a8a8a8a",
        "email": "test@example.com",
        "name": "Test User",
        "azure_object_id": "test-azure-id",
        "groups": ["test-group"],
        "is_active": True,
        "is_admin": False,
        "preferences": {},
        "created_at": "2023-01-01T00:00:00Z",
        "updated_at": "2023-01-01T00:00:00Z"
    }
    
    user = User(**user_data)
    
    async def mock_get_current_active_user():
        return user
    
    app.dependency_overrides[get_current_active_user] = mock_get_current_active_user
    mock_db.users.find_one.return_value = user_data
    return user


@pytest.fixture(scope="function")
def mock_admin_user(mock_db) -> User:
    """Create a mock admin user for testing."""
    # Create user data as dict first to avoid Pydantic validation issues
    user_data = {
        "id": "655c8a3b8e8a8a8a8a8a8a8b",
        "email": "admin@example.com",
        "name": "Admin User",
        "azure_object_id": "admin-azure-id",
        "groups": ["admin-group"],
        "is_active": True,
        "is_admin": True,
        "preferences": {},
        "created_at": "2023-01-01T00:00:00Z",
        "updated_at": "2023-01-01T00:00:00Z"
    }
    
    user = User(**user_data)
    
    async def mock_get_current_active_user():
        return user
    
    app.dependency_overrides[get_current_active_user] = mock_get_current_active_user
    mock_db.users.find_one.return_value = user_data
    return user


@pytest.fixture(autouse=True)
async def cleanup_overrides():
    """Clean up dependency overrides after each test."""
    yield
    app.dependency_overrides.clear()


@pytest.fixture(autouse=True)
async def cleanup_database():
    """Clean up database connection after tests."""
    yield
    try:
        await close_database_connection()
    except Exception:
        pass  # Ignore cleanup errors in tests


