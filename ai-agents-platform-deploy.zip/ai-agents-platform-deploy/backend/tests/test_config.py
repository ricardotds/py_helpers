"""
Test configuration for the AI Agents Management Platform
"""

import os
from app.core.config import Settings


class TestSettings(Settings):
    """Test-specific settings that override the main settings"""
    
    # Application
    DEBUG: bool = True
    
    # Database - Use test database
    MONGODB_URL: str = "mongodb://localhost:27017"
    DATABASE_NAME: str = "ai_agents_platform_test"
    
    # Authentication - Use dummy values for testing
    AZURE_CLIENT_ID: str = "test-client-id"
    AZURE_CLIENT_SECRET: str = "test-client-secret"
    AZURE_TENANT_ID: str = "test-tenant-id"
    AZURE_AUTHORITY: str = "https://login.microsoftonline.com"
    
    # JWT - Use test secret
    SECRET_KEY: str = "test-secret-key-for-testing-only"
    
    # AI Services - Use dummy values for testing
    AZURE_OPENAI_ENDPOINT: str = "https://test.openai.azure.com"
    AZURE_OPENAI_API_KEY: str = "test-openai-key"
    
    AWS_ACCESS_KEY_ID: str = "test-aws-key"
    AWS_SECRET_ACCESS_KEY: str = "test-aws-secret"
    
    AZURE_SEARCH_ENDPOINT: str = "https://test.search.windows.net"
    AZURE_SEARCH_API_KEY: str = "test-search-key"
    
    # Airflow
    AIRFLOW_WEBSERVER_URL: str = "http://localhost:8080"
    AIRFLOW_USERNAME: str = "test"
    AIRFLOW_PASSWORD: str = "test"


# Set environment variables for testing
def setup_test_environment():
    """Set up environment variables for testing"""
    test_settings = TestSettings()
    
    # Set environment variables
    os.environ["AZURE_CLIENT_ID"] = test_settings.AZURE_CLIENT_ID
    os.environ["AZURE_CLIENT_SECRET"] = test_settings.AZURE_CLIENT_SECRET
    os.environ["AZURE_TENANT_ID"] = test_settings.AZURE_TENANT_ID
    os.environ["SECRET_KEY"] = test_settings.SECRET_KEY
    os.environ["MONGODB_URL"] = test_settings.MONGODB_URL
    os.environ["DATABASE_NAME"] = test_settings.DATABASE_NAME
    
    return test_settings

