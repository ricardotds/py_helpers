"""
OAuth2 authentication with Microsoft Entra ID
"""

import os
import msal
import httpx
from typing import Optional, Dict, Any, List
from unittest.mock import MagicMock
from fastapi import HTTPException, status
from jose import JWTError, jwt
from datetime import datetime, timedelta

from app.core.config import settings
from app.core.logging import LoggerMixin
from app.models.user import User, UserCreate


class MicrosoftEntraAuth(LoggerMixin):
    """Microsoft Entra ID authentication handler"""
    
    def __init__(self):
        if os.getenv("PYTEST_CURRENT_TEST"):
            self.client_app = MagicMock()
        else:
            self.client_app = msal.ConfidentialClientApplication(
                client_id=settings.AZURE_CLIENT_ID,
                client_credential=settings.AZURE_CLIENT_SECRET,
                authority=f"{settings.AZURE_AUTHORITY}/{settings.AZURE_TENANT_ID or 'dummy-tenant'}"
            )

    
    def get_authorization_url(self, redirect_uri: str, state: str = None) -> str:
        """Get authorization URL for OAuth2 flow"""
        try:
            auth_url = self.client_app.get_authorization_request_url(
                scopes=settings.AZURE_SCOPE,
                redirect_uri=redirect_uri,
                state=state
            )
            return auth_url
        except Exception as e:
            self.logger.error(f"Error getting authorization URL: {e}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to generate authorization URL"
            )
    
    async def exchange_code_for_token(self, code: str, redirect_uri: str) -> Dict[str, Any]:
        """Exchange authorization code for access token"""
        try:
            result = self.client_app.acquire_token_by_authorization_code(
                code=code,
                scopes=settings.AZURE_SCOPE,
                redirect_uri=redirect_uri
            )
            
            if "error" in result:
                self.logger.error(f"Token exchange error: {result.get('error_description')}")
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Token exchange failed: {result.get('error_description')}"
                )
            
            return result
        except HTTPException:
            raise
        except Exception as e:
            self.logger.error(f"Error exchanging code for token: {e}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to exchange authorization code"
            )
    
    async def get_user_info(self, access_token: str) -> Dict[str, Any]:
        """Get user information from Microsoft Graph API"""
        try:
            headers = {
                "Authorization": f"Bearer {access_token}",
                "Content-Type": "application/json"
            }
            
            async with httpx.AsyncClient() as client:
                # Get user profile
                user_response = await client.get(
                    "https://graph.microsoft.com/v1.0/me",
                    headers=headers
                )
                user_response.raise_for_status()
                user_data = user_response.json()
                
                # Get user groups
                groups_response = await client.get(
                    "https://graph.microsoft.com/v1.0/me/memberOf",
                    headers=headers
                )
                groups_response.raise_for_status()
                groups_data = groups_response.json()
                
                # Extract group names
                groups = [
                    group.get("displayName", "")
                    for group in groups_data.get("value", [])
                    if group.get("@odata.type") == "#microsoft.graph.group"
                ]
                
                return {
                    "id": user_data.get("id"),
                    "email": user_data.get("mail") or user_data.get("userPrincipalName"),
                    "name": user_data.get("displayName"),
                    "groups": groups
                }
                
        except httpx.HTTPStatusError as e:
            self.logger.error(f"HTTP error getting user info: {e}")
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Failed to get user information"
            )
        except Exception as e:
            self.logger.error(f"Error getting user info: {e}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to retrieve user information"
            )
    
    def create_access_token(self, data: Dict[str, Any], expires_delta: Optional[timedelta] = None) -> str:
        """Create JWT access token"""
        try:
            to_encode = data.copy()
            if expires_delta:
                expire = datetime.utcnow() + expires_delta
            else:
                expire = datetime.utcnow() + timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
            
            to_encode.update({"exp": expire})
            encoded_jwt = jwt.encode(to_encode, settings.SECRET_KEY, algorithm=settings.ALGORITHM)
            return encoded_jwt
        except Exception as e:
            self.logger.error(f"Error creating access token: {e}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to create access token"
            )
    
    def verify_token(self, token: str) -> Dict[str, Any]:
        """Verify and decode JWT token"""
        try:
            payload = jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])
            return payload
        except JWTError as e:
            self.logger.error(f"JWT verification error: {e}")
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid token",
                headers={"WWW-Authenticate": "Bearer"},
            )
    
    async def refresh_token(self, refresh_token: str) -> Dict[str, Any]:
        """Refresh access token using refresh token"""
        try:
            result = self.client_app.acquire_token_by_refresh_token(
                refresh_token=refresh_token,
                scopes=settings.AZURE_SCOPE
            )
            
            if "error" in result:
                self.logger.error(f"Token refresh error: {result.get('error_description')}")
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Failed to refresh token"
                )
            
            return result
        except HTTPException:
            raise
        except Exception as e:
            self.logger.error(f"Error refreshing token: {e}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to refresh token"
            )


class AuthorizationManager(LoggerMixin):
    """Authorization and RBAC manager"""
    
    def __init__(self):
        pass
    
    def check_user_permission(
        self,
        user: User,
        resource_owner_id: str,
        shared_with_users: List[str] = None,
        shared_with_groups: List[str] = None,
        is_public: bool = False,
        required_permission: str = "read"
    ) -> bool:
        """Check if user has permission to access a resource"""
        try:
            # Admin users have access to everything
            if user.is_admin:
                return True
            
            # Owner has full access
            if user.id == resource_owner_id:
                return True
            
            # Public resources are accessible to all authenticated users
            if is_public:
                return True
            
            # Check if user is explicitly shared with
            if shared_with_users and str(user.id) in shared_with_users:
                return True
            
            # Check if any of user's groups are shared with
            if shared_with_groups and user.groups:
                user_groups_set = set(user.groups)
                shared_groups_set = set(shared_with_groups)
                if user_groups_set.intersection(shared_groups_set):
                    return True
            
            return False
            
        except Exception as e:
            self.logger.error(f"Error checking user permission: {e}")
            return False
    
    def check_group_membership(self, user: User, required_groups: List[str]) -> bool:
        """Check if user belongs to any of the required groups"""
        try:
            if not required_groups:
                return True
            
            if user.is_admin:
                return True
            
            user_groups_set = set(user.groups or [])
            required_groups_set = set(required_groups)
            
            return bool(user_groups_set.intersection(required_groups_set))
            
        except Exception as e:
            self.logger.error(f"Error checking group membership: {e}")
            return False
    
    def filter_accessible_resources(
        self,
        user: User,
        resources: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """Filter resources based on user permissions"""
        try:
            accessible_resources = []
            
            for resource in resources:
                if self.check_user_permission(
                    user=user,
                    resource_owner_id=resource.get("owner_id"),
                    shared_with_users=resource.get("share_settings", {}).get("shared_with_users", []),
                    shared_with_groups=resource.get("share_settings", {}).get("shared_with_groups", []),
                    is_public=resource.get("share_settings", {}).get("is_public", False)
                ):
                    accessible_resources.append(resource)
            
            return accessible_resources
            
        except Exception as e:
            self.logger.error(f"Error filtering accessible resources: {e}")
            return []


# Global instances
entra_auth = MicrosoftEntraAuth()
auth_manager = AuthorizationManager()

