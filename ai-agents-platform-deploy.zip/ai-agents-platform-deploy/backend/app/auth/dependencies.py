"""
Authentication dependencies for FastAPI
"""

from fastapi import Depends, HTTPException, status, Query, WebSocket, WebSocketException
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from typing import Optional, List

from app.auth.oauth import entra_auth, auth_manager
from app.models.user import User
from app.services.user_service import UserService
from app.core.logging import get_logger

logger = get_logger(__name__)

# Security scheme
security = HTTPBearer()


async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security)
) -> User:
    """Get current authenticated user"""
    try:
        # Verify JWT token
        payload = entra_auth.verify_token(credentials.credentials)
        user_id = payload.get("sub")
        
        if user_id is None:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid token payload",
                headers={"WWW-Authenticate": "Bearer"},
            )
        
        # Get user from database
        user_service = UserService()
        user = await user_service.get_by_azure_object_id(user_id)
        
        if user is None:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="User not found",
                headers={"WWW-Authenticate": "Bearer"},
            )
        
        if not user.is_active:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="User account is disabled",
                headers={"WWW-Authenticate": "Bearer"},
            )
        
        return user
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting current user: {e}")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Could not validate credentials",
            headers={"WWW-Authenticate": "Bearer"},
        )


async def get_current_user_websocket(
    websocket: WebSocket,
    token: Optional[str] = Query(None)
) -> str:
    """
    Get current authenticated user for WebSocket connections
    Token can be passed as query parameter: /ws?token=<jwt_token>
    """
    try:
        if not token:
            # Try to get token from headers (if supported by client)
            auth_header = websocket.headers.get("authorization")
            if auth_header and auth_header.startswith("Bearer "):
                token = auth_header[7:]
        
        if not token:
            raise WebSocketException(code=status.WS_1008_POLICY_VIOLATION, reason="Missing authentication token")
        
        # Verify JWT token
        payload = entra_auth.verify_token(token)
        user_id = payload.get("sub")
        
        if user_id is None:
            raise WebSocketException(code=status.WS_1008_POLICY_VIOLATION, reason="Invalid token")
        
        # For WebSocket, we'll return just the user_id for simplicity
        # In production, you might want to validate the user exists in the database
        return user_id
        
    except WebSocketException:
        raise
    except Exception as e:
        logger.error(f"WebSocket authentication error: {e}")
        raise WebSocketException(code=status.WS_1008_POLICY_VIOLATION, reason="Authentication failed")


async def get_current_active_user(
    current_user: User = Depends(get_current_user)
) -> User:
    """Get current active user"""
    if not current_user.is_active:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Inactive user"
        )
    return current_user


async def get_current_admin_user(
    current_user: User = Depends(get_current_active_user)
) -> User:
    """Get current admin user"""
    if not current_user.is_admin:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not enough permissions"
        )
    return current_user


def require_groups(required_groups: List[str]):
    """Dependency factory for group-based authorization"""
    
    async def check_groups(
        current_user: User = Depends(get_current_active_user)
    ) -> User:
        if not auth_manager.check_group_membership(current_user, required_groups):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"User must belong to one of these groups: {', '.join(required_groups)}"
            )
        return current_user
    
    return check_groups


def require_resource_access(
    resource_owner_id: str,
    shared_with_users: Optional[List[str]] = None,
    shared_with_groups: Optional[List[str]] = None,
    is_public: bool = False,
    required_permission: str = "read"
):
    """Dependency factory for resource-based authorization"""
    
    async def check_access(
        current_user: User = Depends(get_current_active_user)
    ) -> User:
        if not auth_manager.check_user_permission(
            user=current_user,
            resource_owner_id=resource_owner_id,
            shared_with_users=shared_with_users or [],
            shared_with_groups=shared_with_groups or [],
            is_public=is_public,
            required_permission=required_permission
        ):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Not enough permissions to access this resource"
            )
        return current_user
    
    return check_access


class PermissionChecker:
    """Helper class for checking permissions in route handlers"""
    
    @staticmethod
    def check_resource_permission(
        user: User,
        resource_owner_id: str,
        shared_with_users: Optional[List[str]] = None,
        shared_with_groups: Optional[List[str]] = None,
        is_public: bool = False,
        required_permission: str = "read"
    ) -> bool:
        """Check if user has permission to access a resource"""
        return auth_manager.check_user_permission(
            user=user,
            resource_owner_id=resource_owner_id,
            shared_with_users=shared_with_users or [],
            shared_with_groups=shared_with_groups or [],
            is_public=is_public,
            required_permission=required_permission
        )
    
    @staticmethod
    def check_group_membership(user: User, required_groups: List[str]) -> bool:
        """Check if user belongs to required groups"""
        return auth_manager.check_group_membership(user, required_groups)
    
    @staticmethod
    def ensure_resource_access(
        user: User,
        resource_owner_id: str,
        shared_with_users: Optional[List[str]] = None,
        shared_with_groups: Optional[List[str]] = None,
        is_public: bool = False,
        required_permission: str = "read"
    ):
        """Ensure user has access to resource, raise exception if not"""
        if not PermissionChecker.check_resource_permission(
            user=user,
            resource_owner_id=resource_owner_id,
            shared_with_users=shared_with_users,
            shared_with_groups=shared_with_groups,
            is_public=is_public,
            required_permission=required_permission
        ):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Not enough permissions to access this resource"
            )
    
    @staticmethod
    def ensure_group_membership(user: User, required_groups: List[str]):
        """Ensure user belongs to required groups, raise exception if not"""
        if not PermissionChecker.check_group_membership(user, required_groups):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"User must belong to one of these groups: {', '.join(required_groups)}"
            )

