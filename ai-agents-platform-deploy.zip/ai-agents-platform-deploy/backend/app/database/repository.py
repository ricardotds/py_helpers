"""
Base repository classes for database operations
"""

from typing import Optional, List, Dict, Any, Type, TypeVar, Generic
from bson import ObjectId
from pymongo.errors import DuplicateKeyError
from motor.motor_asyncio import AsyncIOMotorCollection
from datetime import datetime
import json

from app.database.connection import get_collection
from app.models.base import BaseDocument
from app.core.logging import LoggerMixin

T = TypeVar('T', bound=BaseDocument)


class BaseRepository(Generic[T], LoggerMixin):
    """Base repository class for CRUD operations"""
    
    def __init__(self, collection_name: str, model_class: Type[T]):
        self.collection_name = collection_name
        self.model_class = model_class
    
    @property
    def collection(self) -> AsyncIOMotorCollection:
        """Get the MongoDB collection"""
        return get_collection(self.collection_name)
    
    async def create(self, data: Dict[str, Any]) -> T:
        """Create a new document"""
        try:
            # Add timestamps
            now = datetime.utcnow()
            data["created_at"] = now
            data["updated_at"] = now
            
            # Insert document
            result = await self.collection.insert_one(data)
            
            # Retrieve and return the created document
            created_doc = await self.collection.find_one({"_id": result.inserted_id})
            return self.model_class(**created_doc)
            
        except DuplicateKeyError as e:
            self.logger.error(f"Duplicate key error creating {self.collection_name}: {e}")
            raise ValueError(f"Document with this key already exists")
        except Exception as e:
            self.logger.error(f"Error creating {self.collection_name}: {e}")
            raise
    
    async def get_by_id(self, document_id: str) -> Optional[T]:
        """Get document by ID"""
        try:
            if not ObjectId.is_valid(document_id):
                return None
            
            doc = await self.collection.find_one({"_id": ObjectId(document_id)})
            return self.model_class(**doc) if doc else None
            
        except Exception as e:
            self.logger.error(f"Error getting {self.collection_name} by ID {document_id}: {e}")
            return None
    
    async def get_by_field(self, field: str, value: Any) -> Optional[T]:
        """Get document by a specific field"""
        try:
            doc = await self.collection.find_one({field: value})
            return self.model_class(**doc) if doc else None
            
        except Exception as e:
            self.logger.error(f"Error getting {self.collection_name} by {field}={value}: {e}")
            return None
    
    async def list(
        self,
        filter_dict: Optional[Dict[str, Any]] = None,
        skip: int = 0,
        limit: int = 100,
        sort_by: Optional[str] = None,
        sort_order: int = -1
    ) -> List[T]:
        """List documents with optional filtering, pagination, and sorting"""
        try:
            query = filter_dict or {}
            
            cursor = self.collection.find(query)
            
            if sort_by:
                cursor = cursor.sort(sort_by, sort_order)
            
            cursor = cursor.skip(skip).limit(limit)
            
            docs = await cursor.to_list(length=limit)
            return [self.model_class(**doc) for doc in docs]
            
        except Exception as e:
            self.logger.error(f"Error listing {self.collection_name}: {e}")
            return []
    
    async def count(self, filter_dict: Optional[Dict[str, Any]] = None) -> int:
        """Count documents matching filter"""
        try:
            query = filter_dict or {}
            return await self.collection.count_documents(query)
            
        except Exception as e:
            self.logger.error(f"Error counting {self.collection_name}: {e}")
            return 0
    
    async def update(self, document_id: str, update_data: Dict[str, Any]) -> Optional[T]:
        """Update document by ID"""
        try:
            if not ObjectId.is_valid(document_id):
                return None
            
            # Add updated timestamp
            update_data["updated_at"] = datetime.utcnow()
            
            result = await self.collection.update_one(
                {"_id": ObjectId(document_id)},
                {"$set": update_data}
            )
            
            if result.modified_count == 0:
                return None
            
            # Return updated document
            updated_doc = await self.collection.find_one({"_id": ObjectId(document_id)})
            return self.model_class(**updated_doc) if updated_doc else None
            
        except Exception as e:
            self.logger.error(f"Error updating {self.collection_name} {document_id}: {e}")
            return None
    
    async def delete(self, document_id: str) -> bool:
        """Delete document by ID"""
        try:
            if not ObjectId.is_valid(document_id):
                return False
            
            result = await self.collection.delete_one({"_id": ObjectId(document_id)})
            return result.deleted_count > 0
            
        except Exception as e:
            self.logger.error(f"Error deleting {self.collection_name} {document_id}: {e}")
            return False
    
    async def exists(self, document_id: str) -> bool:
        """Check if document exists"""
        try:
            if not ObjectId.is_valid(document_id):
                return False
            
            count = await self.collection.count_documents({"_id": ObjectId(document_id)})
            return count > 0
            
        except Exception as e:
            self.logger.error(f"Error checking existence of {self.collection_name} {document_id}: {e}")
            return False
    
    async def search(
        self,
        search_term: str,
        search_fields: List[str],
        filter_dict: Optional[Dict[str, Any]] = None,
        skip: int = 0,
        limit: int = 100
    ) -> List[T]:
        """Search documents using text search"""
        try:
            # Build text search query
            query = filter_dict or {}
            
            if search_term:
                # Use MongoDB text search if available, otherwise use regex
                text_query = {
                    "$or": [
                        {field: {"$regex": search_term, "$options": "i"}}
                        for field in search_fields
                    ]
                }
                query.update(text_query)
            
            cursor = self.collection.find(query).skip(skip).limit(limit)
            docs = await cursor.to_list(length=limit)
            
            return [self.model_class(**doc) for doc in docs]
            
        except Exception as e:
            self.logger.error(f"Error searching {self.collection_name}: {e}")
            return []
    
    async def bulk_create(self, documents: List[Dict[str, Any]]) -> List[T]:
        """Create multiple documents in bulk"""
        try:
            if not documents:
                return []
            
            # Add timestamps to all documents
            now = datetime.utcnow()
            for doc in documents:
                doc["created_at"] = now
                doc["updated_at"] = now
            
            result = await self.collection.insert_many(documents)
            
            # Retrieve created documents
            created_docs = await self.collection.find(
                {"_id": {"$in": result.inserted_ids}}
            ).to_list(length=len(result.inserted_ids))
            
            return [self.model_class(**doc) for doc in created_docs]
            
        except Exception as e:
            self.logger.error(f"Error bulk creating {self.collection_name}: {e}")
            return []
    
    async def bulk_update(self, updates: List[Dict[str, Any]]) -> int:
        """Update multiple documents in bulk"""
        try:
            if not updates:
                return 0
            
            operations = []
            now = datetime.utcnow()
            
            for update in updates:
                if "_id" not in update or "data" not in update:
                    continue
                
                update["data"]["updated_at"] = now
                operations.append({
                    "update_one": {
                        "filter": {"_id": ObjectId(update["_id"])},
                        "update": {"$set": update["data"]}
                    }
                })
            
            if operations:
                result = await self.collection.bulk_write(operations)
                return result.modified_count
            
            return 0
            
        except Exception as e:
            self.logger.error(f"Error bulk updating {self.collection_name}: {e}")
            return 0
    
    async def aggregate(self, pipeline: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Execute aggregation pipeline"""
        try:
            cursor = self.collection.aggregate(pipeline)
            return await cursor.to_list(length=None)
            
        except Exception as e:
            self.logger.error(f"Error executing aggregation on {self.collection_name}: {e}")
            return []

