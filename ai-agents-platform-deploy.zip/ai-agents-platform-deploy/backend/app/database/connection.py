"""
Database connection utilities for CosmosDB MongoDB API
"""

from motor.motor_asyncio import AsyncIOMotorClient
from pymongo.errors import ConnectionFailure
import asyncio
from typing import Optional
from app.core.config import settings
from app.core.logging import get_logger

logger = get_logger(__name__)

class Database:
    """Database connection manager"""
    
    def __init__(self):
        self.client: Optional[AsyncIOMotorClient] = None
        self.database = None
    
    async def connect(self):
        """Connect to MongoDB"""
        try:
            self.client = AsyncIOMotorClient(
                settings.MONGODB_URL,
                serverSelectionTimeoutMS=5000,
                connectTimeoutMS=10000,
                socketTimeoutMS=10000
            )
            
            # Test the connection
            await self.client.admin.command('ping')
            
            self.database = self.client[settings.DATABASE_NAME]
            logger.info(f"Connected to MongoDB database: {settings.DATABASE_NAME}")
            
            # Create indexes
            await self._create_indexes()
            
        except ConnectionFailure as e:
            logger.error(f"Failed to connect to MongoDB: {e}")
            raise
        except Exception as e:
            logger.error(f"Unexpected error connecting to MongoDB: {e}")
            raise
    
    async def disconnect(self):
        """Disconnect from MongoDB"""
        if self.client:
            self.client.close()
            logger.info("Disconnected from MongoDB")
    
    async def _create_indexes(self):
        """Create database indexes for optimal performance"""
        try:
            # Users collection indexes
            await self.database.users.create_index("email", unique=True)
            await self.database.users.create_index("azure_object_id", unique=True)
            
            # Pipelines collection indexes
            await self.database.pipelines.create_index("name")
            await self.database.pipelines.create_index("owner_id")
            await self.database.pipelines.create_index("shared_with")
            await self.database.pipelines.create_index("created_at")
            await self.database.pipelines.create_index("updated_at")
            
            # Tools collection indexes
            await self.database.tools.create_index("name")
            await self.database.tools.create_index("tool_type")
            await self.database.tools.create_index("owner_id")
            
            # Prompts collection indexes
            await self.database.prompts.create_index("name")
            await self.database.prompts.create_index("owner_id")
            
            # Schemas collection indexes
            await self.database.schemas.create_index("name")
            await self.database.schemas.create_index("owner_id")
            
            # RAG indexes collection indexes
            await self.database.rag_indexes.create_index("name")
            await self.database.rag_indexes.create_index("owner_id")
            
            # Pipeline executions collection indexes
            await self.database.pipeline_executions.create_index("pipeline_id")
            await self.database.pipeline_executions.create_index("status")
            await self.database.pipeline_executions.create_index("started_at")
            await self.database.pipeline_executions.create_index("completed_at")
            
            logger.info("Database indexes created successfully")
            
        except Exception as e:
            logger.error(f"Error creating database indexes: {e}")
    
    def get_collection(self, collection_name: str):
        """Get a collection from the database"""
        if not self.database:
            raise RuntimeError("Database not connected")
        return self.database[collection_name]


# Global database instance
db = Database()


async def connect_to_mongo():
    """Connect to MongoDB"""
    await db.connect()


async def close_mongo_connection():
    """Close MongoDB connection"""
    await db.disconnect()


def get_database():
    """Get database instance"""
    return db.database


def get_collection(collection_name: str):
    """Get a specific collection"""
    return db.get_collection(collection_name)




async def close_database_connection():
    """Close the database connection"""
    await db.disconnect()

