"""
Pipeline data models
"""

from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any, Union
from app.models.base import BaseDocument, ShareSettings, ExecutionStatus, StepStatus, ToolType


class PipelineStep(BaseModel):
    """Individual step in a pipeline"""
    
    id: str = Field(..., description="Unique step identifier")
    name: str = Field(..., description="Human-readable step name")
    tool_type: ToolType = Field(..., description="Type of tool to execute")
    tool_config: Dict[str, Any] = Field(..., description="Tool-specific configuration")
    inputs: Dict[str, Any] = Field(default_factory=dict, description="Step input mappings")
    outputs: Dict[str, str] = Field(default_factory=dict, description="Step output mappings")
    depends_on: List[str] = Field(default_factory=list, description="Step dependencies")
    position: Dict[str, float] = Field(default_factory=dict, description="UI position (x, y)")
    enabled: bool = True
    
    class Config:
        schema_extra = {
            "example": {
                "id": "step_1",
                "name": "Generate Summary",
                "tool_type": "llm_call",
                "tool_config": {
                    "model": "gpt-4",
                    "prompt_template": "Summarize the following text: {input_text}",
                    "max_tokens": 150
                },
                "inputs": {
                    "input_text": "{{pipeline.input.text}}"
                },
                "outputs": {
                    "summary": "summary"
                },
                "depends_on": [],
                "position": {"x": 100, "y": 100},
                "enabled": True
            }
        }


class PipelineInput(BaseModel):
    """Pipeline input definition"""
    
    name: str = Field(..., description="Input parameter name")
    type: str = Field(..., description="Input data type")
    description: Optional[str] = None
    required: bool = True
    default_value: Optional[Any] = None
    
    class Config:
        schema_extra = {
            "example": {
                "name": "input_text",
                "type": "string",
                "description": "Text to be processed",
                "required": True,
                "default_value": None
            }
        }


class PipelineOutput(BaseModel):
    """Pipeline output definition"""
    
    name: str = Field(..., description="Output parameter name")
    type: str = Field(..., description="Output data type")
    description: Optional[str] = None
    source_step: str = Field(..., description="Step that produces this output")
    source_output: str = Field(..., description="Output key from the source step")
    
    class Config:
        schema_extra = {
            "example": {
                "name": "final_summary",
                "type": "string",
                "description": "Generated summary",
                "source_step": "step_1",
                "source_output": "summary"
            }
        }


class Pipeline(BaseDocument):
    """Pipeline model"""
    
    name: str = Field(..., description="Pipeline name")
    description: Optional[str] = None
    version: str = Field(default="1.0.0", description="Pipeline version")
    owner_id: str = Field(..., description="Owner user ID")
    
    # Pipeline definition
    inputs: List[PipelineInput] = Field(default_factory=list)
    outputs: List[PipelineOutput] = Field(default_factory=list)
    steps: List[PipelineStep] = Field(default_factory=list)
    
    # Metadata
    tags: List[str] = Field(default_factory=list)
    category: Optional[str] = None
    
    # Sharing and permissions
    share_settings: ShareSettings = Field(default_factory=ShareSettings)
    
    # Deployment
    is_deployed: bool = False
    deployment_config: Optional[Dict[str, Any]] = None
    airflow_dag_id: Optional[str] = None
    
    # Validation
    is_validated: bool = False
    validation_errors: List[str] = Field(default_factory=list)
    
    class Config:
        schema_extra = {
            "example": {
                "name": "Text Summarization Pipeline",
                "description": "A pipeline that summarizes input text using AI",
                "version": "1.0.0",
                "owner_id": "user123",
                "inputs": [
                    {
                        "name": "input_text",
                        "type": "string",
                        "description": "Text to summarize",
                        "required": True
                    }
                ],
                "outputs": [
                    {
                        "name": "summary",
                        "type": "string",
                        "description": "Generated summary",
                        "source_step": "summarize_step",
                        "source_output": "result"
                    }
                ],
                "steps": [
                    {
                        "id": "summarize_step",
                        "name": "Summarize Text",
                        "tool_type": "llm_call",
                        "tool_config": {
                            "model": "gpt-4",
                            "prompt_template": "Summarize: {text}"
                        },
                        "inputs": {
                            "text": "{{pipeline.input.input_text}}"
                        },
                        "outputs": {
                            "result": "summary"
                        }
                    }
                ],
                "tags": ["nlp", "summarization"],
                "category": "text-processing"
            }
        }


class PipelineCreate(BaseModel):
    """Pipeline creation model"""
    
    name: str
    description: Optional[str] = None
    version: str = "1.0.0"
    inputs: List[PipelineInput] = Field(default_factory=list)
    outputs: List[PipelineOutput] = Field(default_factory=list)
    steps: List[PipelineStep] = Field(default_factory=list)
    tags: List[str] = Field(default_factory=list)
    category: Optional[str] = None


class PipelineUpdate(BaseModel):
    """Pipeline update model"""
    
    name: Optional[str] = None
    description: Optional[str] = None
    version: Optional[str] = None
    inputs: Optional[List[PipelineInput]] = None
    outputs: Optional[List[PipelineOutput]] = None
    steps: Optional[List[PipelineStep]] = None
    tags: Optional[List[str]] = None
    category: Optional[str] = None
    share_settings: Optional[ShareSettings] = None


class PipelineExecution(BaseDocument):
    """Pipeline execution model"""
    
    pipeline_id: str = Field(..., description="Pipeline ID")
    pipeline_version: str = Field(..., description="Pipeline version at execution time")
    executor_id: str = Field(..., description="User who executed the pipeline")
    
    # Execution data
    input_data: Dict[str, Any] = Field(..., description="Input data provided")
    output_data: Optional[Dict[str, Any]] = None
    
    # Status and timing
    status: ExecutionStatus = ExecutionStatus.PENDING
    started_at: Optional[str] = None
    completed_at: Optional[str] = None
    duration_seconds: Optional[float] = None
    
    # Step execution details
    step_executions: List[Dict[str, Any]] = Field(default_factory=list)
    
    # Error handling
    error_message: Optional[str] = None
    error_details: Optional[Dict[str, Any]] = None
    
    # Execution environment
    execution_environment: Optional[str] = None  # local, airflow, k8s
    
    class Config:
        schema_extra = {
            "example": {
                "pipeline_id": "pipeline123",
                "pipeline_version": "1.0.0",
                "executor_id": "user123",
                "input_data": {
                    "input_text": "This is a sample text to summarize."
                },
                "status": "completed",
                "started_at": "2023-12-01T10:00:00Z",
                "completed_at": "2023-12-01T10:01:30Z",
                "duration_seconds": 90.5,
                "step_executions": [
                    {
                        "step_id": "summarize_step",
                        "status": "completed",
                        "started_at": "2023-12-01T10:00:05Z",
                        "completed_at": "2023-12-01T10:01:25Z",
                        "output": {
                            "summary": "This is a summary of the input text."
                        }
                    }
                ]
            }
        }


class PipelineExecutionCreate(BaseModel):
    """Pipeline execution creation model"""
    
    pipeline_id: str
    input_data: Dict[str, Any]
    execution_environment: Optional[str] = "local"


class StepExecution(BaseModel):
    """Individual step execution details"""
    
    step_id: str
    status: StepStatus = StepStatus.PENDING
    started_at: Optional[str] = None
    completed_at: Optional[str] = None
    duration_seconds: Optional[float] = None
    input_data: Optional[Dict[str, Any]] = None
    output_data: Optional[Dict[str, Any]] = None
    error_message: Optional[str] = None
    error_details: Optional[Dict[str, Any]] = None
    logs: List[str] = Field(default_factory=list)

