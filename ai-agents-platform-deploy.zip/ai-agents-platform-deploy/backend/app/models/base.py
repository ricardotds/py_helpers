"""
Base data models for AI Agents Management Platform
"""

from pydantic import BaseModel, Field
from typing import Optional, Dict, Any, List
from datetime import datetime
from bson import ObjectId
from enum import Enum


class PyObjectId(ObjectId):
    """Custom ObjectId type for Pydantic"""
    
    @classmethod
    def __get_validators__(cls):
        yield cls.validate
    
    @classmethod
    def validate(cls, v):
        if not ObjectId.is_valid(v):
            raise ValueError("Invalid ObjectId")
        return ObjectId(v)
    
    @classmethod
    def __get_pydantic_json_schema__(
        cls,
        core_schema: "CoreSchema",
        handler: "GetJsonSchemaHandler"
    ) -> "JsonSchemaValue":
        # Use the same JSON schema for all ObjectId instances
        return {"type": "string"}


class BaseDocument(BaseModel):
    """Base document model with common fields"""
    
    id: Optional[PyObjectId] = Field(default_factory=PyObjectId, alias="_id")
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    
    class Config:
        allow_population_by_field_name = True
        arbitrary_types_allowed = True
        json_encoders = {ObjectId: str}


class SharePermission(str, Enum):
    """Share permission levels"""
    READ = "read"
    WRITE = "write"
    EXECUTE = "execute"
    ADMIN = "admin"


class ShareSettings(BaseModel):
    """Share settings for resources"""
    is_public: bool = False
    shared_with_users: List[str] = Field(default_factory=list)  # User IDs
    shared_with_groups: List[str] = Field(default_factory=list)  # Group names
    permissions: Dict[str, SharePermission] = Field(default_factory=dict)  # user_id/group -> permission


class ToolType(str, Enum):
    """Types of tools available in the platform"""
    LLM_CALL = "llm_call"
    API_CALL = "api_call"
    RAG_INTERACTION = "rag_interaction"
    PYTHON_CODE = "python_code"
    CUSTOM = "custom"


class ExecutionStatus(str, Enum):
    """Pipeline execution status"""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class StepStatus(str, Enum):
    """Individual step execution status"""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"

