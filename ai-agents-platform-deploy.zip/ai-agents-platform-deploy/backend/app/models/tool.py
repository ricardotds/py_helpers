"""
Tool data models
"""

from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any, Union
from app.models.base import BaseDocument, ShareSettings, ToolType


class ToolParameter(BaseModel):
    """Tool parameter definition"""
    
    name: str = Field(..., description="Parameter name")
    type: str = Field(..., description="Parameter data type")
    description: Optional[str] = None
    required: bool = True
    default_value: Optional[Any] = None
    options: Optional[List[Any]] = None  # For enum-like parameters
    
    class Config:
        schema_extra = {
            "example": {
                "name": "model",
                "type": "string",
                "description": "AI model to use",
                "required": True,
                "options": ["gpt-4", "gpt-3.5-turbo", "claude-3"]
            }
        }


class LLMToolConfig(BaseModel):
    """Configuration for LLM tools"""
    
    provider: str = Field(..., description="LLM provider (azure_openai, aws_bedrock)")
    model: str = Field(..., description="Model name")
    max_tokens: Optional[int] = None
    temperature: Optional[float] = None
    top_p: Optional[float] = None
    frequency_penalty: Optional[float] = None
    presence_penalty: Optional[float] = None
    system_prompt: Optional[str] = None
    prompt_template: str = Field(..., description="Prompt template with placeholders")
    structured_output_schema: Optional[Dict[str, Any]] = None
    
    class Config:
        schema_extra = {
            "example": {
                "provider": "azure_openai",
                "model": "gpt-4",
                "max_tokens": 150,
                "temperature": 0.7,
                "system_prompt": "You are a helpful assistant.",
                "prompt_template": "Summarize the following text: {input_text}",
                "structured_output_schema": {
                    "type": "object",
                    "properties": {
                        "summary": {"type": "string"},
                        "key_points": {"type": "array", "items": {"type": "string"}}
                    }
                }
            }
        }


class APIToolConfig(BaseModel):
    """Configuration for API call tools"""
    
    method: str = Field(..., description="HTTP method")
    url: str = Field(..., description="API endpoint URL")
    headers: Dict[str, str] = Field(default_factory=dict)
    query_params: Dict[str, str] = Field(default_factory=dict)
    body_template: Optional[str] = None
    authentication: Optional[Dict[str, Any]] = None
    timeout: Optional[int] = 30
    retry_count: Optional[int] = 3
    
    class Config:
        schema_extra = {
            "example": {
                "method": "POST",
                "url": "https://api.example.com/process",
                "headers": {
                    "Content-Type": "application/json",
                    "Authorization": "Bearer {api_key}"
                },
                "body_template": '{"text": "{input_text}", "options": {options}}',
                "timeout": 30,
                "retry_count": 3
            }
        }


class RAGToolConfig(BaseModel):
    """Configuration for RAG interaction tools"""
    
    search_service_endpoint: str = Field(..., description="Azure AI Search endpoint")
    index_name: str = Field(..., description="Search index name")
    api_key: str = Field(..., description="Search service API key")
    search_fields: List[str] = Field(default_factory=list)
    select_fields: List[str] = Field(default_factory=list)
    top_k: int = Field(default=5, description="Number of results to retrieve")
    search_mode: str = Field(default="hybrid", description="Search mode")
    semantic_configuration: Optional[str] = None
    
    class Config:
        schema_extra = {
            "example": {
                "search_service_endpoint": "https://mysearch.search.windows.net",
                "index_name": "documents",
                "api_key": "your-search-api-key",
                "search_fields": ["content", "title"],
                "select_fields": ["content", "title", "metadata"],
                "top_k": 5,
                "search_mode": "hybrid"
            }
        }


class PythonCodeToolConfig(BaseModel):
    """Configuration for Python code execution tools"""
    
    code: str = Field(..., description="Python code to execute")
    requirements: List[str] = Field(default_factory=list, description="Python packages required")
    timeout: Optional[int] = 300  # 5 minutes default
    memory_limit: Optional[str] = "512MB"
    allowed_imports: Optional[List[str]] = None
    
    class Config:
        schema_extra = {
            "example": {
                "code": "import pandas as pd\n\ndef process_data(input_data):\n    df = pd.DataFrame(input_data)\n    return df.describe().to_dict()",
                "requirements": ["pandas", "numpy"],
                "timeout": 300,
                "memory_limit": "512MB",
                "allowed_imports": ["pandas", "numpy", "json", "datetime"]
            }
        }


class Tool(BaseDocument):
    """Tool model"""
    
    name: str = Field(..., description="Tool name")
    description: Optional[str] = None
    tool_type: ToolType = Field(..., description="Type of tool")
    owner_id: str = Field(..., description="Owner user ID")
    
    # Tool configuration based on type
    config: Union[LLMToolConfig, APIToolConfig, RAGToolConfig, PythonCodeToolConfig, Dict[str, Any]] = Field(
        ..., description="Tool-specific configuration"
    )
    
    # Input/Output definitions
    input_parameters: List[ToolParameter] = Field(default_factory=list)
    output_parameters: List[ToolParameter] = Field(default_factory=list)
    
    # Metadata
    version: str = Field(default="1.0.0")
    tags: List[str] = Field(default_factory=list)
    category: Optional[str] = None
    
    # Sharing and permissions
    share_settings: ShareSettings = Field(default_factory=ShareSettings)
    
    # Usage statistics
    usage_count: int = Field(default=0)
    last_used: Optional[str] = None
    
    class Config:
        schema_extra = {
            "example": {
                "name": "Text Summarizer",
                "description": "Summarizes text using GPT-4",
                "tool_type": "llm_call",
                "owner_id": "user123",
                "config": {
                    "provider": "azure_openai",
                    "model": "gpt-4",
                    "prompt_template": "Summarize: {text}",
                    "max_tokens": 150
                },
                "input_parameters": [
                    {
                        "name": "text",
                        "type": "string",
                        "description": "Text to summarize",
                        "required": True
                    }
                ],
                "output_parameters": [
                    {
                        "name": "summary",
                        "type": "string",
                        "description": "Generated summary"
                    }
                ],
                "tags": ["nlp", "summarization"],
                "category": "text-processing"
            }
        }


class ToolCreate(BaseModel):
    """Tool creation model"""
    
    name: str
    description: Optional[str] = None
    tool_type: ToolType
    config: Union[LLMToolConfig, APIToolConfig, RAGToolConfig, PythonCodeToolConfig, Dict[str, Any]]
    input_parameters: List[ToolParameter] = Field(default_factory=list)
    output_parameters: List[ToolParameter] = Field(default_factory=list)
    version: str = "1.0.0"
    tags: List[str] = Field(default_factory=list)
    category: Optional[str] = None


class ToolUpdate(BaseModel):
    """Tool update model"""
    
    name: Optional[str] = None
    description: Optional[str] = None
    config: Optional[Union[LLMToolConfig, APIToolConfig, RAGToolConfig, PythonCodeToolConfig, Dict[str, Any]]] = None
    input_parameters: Optional[List[ToolParameter]] = None
    output_parameters: Optional[List[ToolParameter]] = None
    version: Optional[str] = None
    tags: Optional[List[str]] = None
    category: Optional[str] = None
    share_settings: Optional[ShareSettings] = None

