"""
Prompt data models
"""

from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from app.models.base import BaseDocument, ShareSettings


class PromptVariable(BaseModel):
    """Prompt variable definition"""
    
    name: str = Field(..., description="Variable name")
    type: str = Field(..., description="Variable data type")
    description: Optional[str] = None
    required: bool = True
    default_value: Optional[Any] = None
    example_value: Optional[Any] = None
    
    class Config:
        schema_extra = {
            "example": {
                "name": "topic",
                "type": "string",
                "description": "The topic to write about",
                "required": True,
                "example_value": "artificial intelligence"
            }
        }


class Prompt(BaseDocument):
    """Prompt model"""
    
    name: str = Field(..., description="Prompt name")
    description: Optional[str] = None
    owner_id: str = Field(..., description="Owner user ID")
    
    # Prompt content
    system_prompt: Optional[str] = None
    user_prompt: str = Field(..., description="Main prompt template")
    
    # Variables and parameters
    variables: List[PromptVariable] = Field(default_factory=list)
    
    # Metadata
    version: str = Field(default="1.0.0")
    tags: List[str] = Field(default_factory=list)
    category: Optional[str] = None
    language: str = Field(default="en", description="Prompt language")
    
    # Sharing and permissions
    share_settings: ShareSettings = Field(default_factory=ShareSettings)
    
    # Usage statistics
    usage_count: int = Field(default=0)
    last_used: Optional[str] = None
    
    # Testing and validation
    test_cases: List[Dict[str, Any]] = Field(default_factory=list)
    
    class Config:
        schema_extra = {
            "example": {
                "name": "Article Writer",
                "description": "Generates articles on given topics",
                "owner_id": "user123",
                "system_prompt": "You are a professional content writer.",
                "user_prompt": "Write a comprehensive article about {topic}. The article should be {length} words long and include {sections}. Target audience: {audience}.",
                "variables": [
                    {
                        "name": "topic",
                        "type": "string",
                        "description": "Article topic",
                        "required": True,
                        "example_value": "artificial intelligence"
                    },
                    {
                        "name": "length",
                        "type": "integer",
                        "description": "Article length in words",
                        "required": True,
                        "default_value": 1000
                    },
                    {
                        "name": "sections",
                        "type": "array",
                        "description": "Sections to include",
                        "required": False,
                        "default_value": ["introduction", "main content", "conclusion"]
                    },
                    {
                        "name": "audience",
                        "type": "string",
                        "description": "Target audience",
                        "required": False,
                        "default_value": "general public"
                    }
                ],
                "tags": ["writing", "content-creation"],
                "category": "content",
                "language": "en"
            }
        }


class PromptCreate(BaseModel):
    """Prompt creation model"""
    
    name: str
    description: Optional[str] = None
    system_prompt: Optional[str] = None
    user_prompt: str
    variables: List[PromptVariable] = Field(default_factory=list)
    version: str = "1.0.0"
    tags: List[str] = Field(default_factory=list)
    category: Optional[str] = None
    language: str = "en"


class PromptUpdate(BaseModel):
    """Prompt update model"""
    
    name: Optional[str] = None
    description: Optional[str] = None
    system_prompt: Optional[str] = None
    user_prompt: Optional[str] = None
    variables: Optional[List[PromptVariable]] = None
    version: Optional[str] = None
    tags: Optional[List[str]] = None
    category: Optional[str] = None
    language: Optional[str] = None
    share_settings: Optional[ShareSettings] = None


class PromptTestCase(BaseModel):
    """Prompt test case"""
    
    name: str = Field(..., description="Test case name")
    description: Optional[str] = None
    input_variables: Dict[str, Any] = Field(..., description="Test input values")
    expected_output: Optional[str] = None
    actual_output: Optional[str] = None
    passed: Optional[bool] = None
    created_at: Optional[str] = None
    
    class Config:
        schema_extra = {
            "example": {
                "name": "AI Article Test",
                "description": "Test article generation about AI",
                "input_variables": {
                    "topic": "artificial intelligence",
                    "length": 500,
                    "sections": ["introduction", "applications", "conclusion"],
                    "audience": "beginners"
                },
                "expected_output": "Should generate a 500-word article about AI for beginners",
                "passed": True
            }
        }


class PromptExecution(BaseModel):
    """Prompt execution result"""
    
    prompt_id: str
    input_variables: Dict[str, Any]
    rendered_prompt: str
    output: Optional[str] = None
    execution_time_ms: Optional[float] = None
    model_used: Optional[str] = None
    tokens_used: Optional[int] = None
    cost: Optional[float] = None
    
    class Config:
        schema_extra = {
            "example": {
                "prompt_id": "prompt123",
                "input_variables": {
                    "topic": "machine learning",
                    "length": 800
                },
                "rendered_prompt": "Write a comprehensive article about machine learning. The article should be 800 words long...",
                "output": "Machine learning is a subset of artificial intelligence...",
                "execution_time_ms": 2500.5,
                "model_used": "gpt-4",
                "tokens_used": 1200,
                "cost": 0.024
            }
        }

