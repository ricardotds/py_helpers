"""
Schema data models for structured outputs
"""

from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from app.models.base import BaseDocument, ShareSettings


class SchemaField(BaseModel):
    """Schema field definition"""
    
    name: str = Field(..., description="Field name")
    type: str = Field(..., description="Field data type")
    description: Optional[str] = None
    required: bool = True
    default_value: Optional[Any] = None
    enum_values: Optional[List[Any]] = None
    format: Optional[str] = None  # For string types (email, date, etc.)
    minimum: Optional[float] = None  # For numeric types
    maximum: Optional[float] = None  # For numeric types
    min_length: Optional[int] = None  # For string/array types
    max_length: Optional[int] = None  # For string/array types
    pattern: Optional[str] = None  # For string types (regex)
    items: Optional[Dict[str, Any]] = None  # For array types
    properties: Optional[Dict[str, Any]] = None  # For object types
    
    class Config:
        schema_extra = {
            "example": {
                "name": "email",
                "type": "string",
                "description": "User email address",
                "required": True,
                "format": "email",
                "pattern": "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$"
            }
        }


class Schema(BaseDocument):
    """Schema model for structured outputs"""
    
    name: str = Field(..., description="Schema name")
    description: Optional[str] = None
    owner_id: str = Field(..., description="Owner user ID")
    
    # Schema definition
    schema_type: str = Field(default="object", description="Root schema type")
    fields: List[SchemaField] = Field(default_factory=list)
    json_schema: Dict[str, Any] = Field(..., description="Complete JSON Schema definition")
    
    # Metadata
    version: str = Field(default="1.0.0")
    tags: List[str] = Field(default_factory=list)
    category: Optional[str] = None
    
    # Sharing and permissions
    share_settings: ShareSettings = Field(default_factory=ShareSettings)
    
    # Usage statistics
    usage_count: int = Field(default=0)
    last_used: Optional[str] = None
    
    # Validation examples
    examples: List[Dict[str, Any]] = Field(default_factory=list)
    
    class Config:
        schema_extra = {
            "example": {
                "name": "User Profile Schema",
                "description": "Schema for user profile data",
                "owner_id": "user123",
                "schema_type": "object",
                "fields": [
                    {
                        "name": "name",
                        "type": "string",
                        "description": "Full name",
                        "required": True,
                        "min_length": 1,
                        "max_length": 100
                    },
                    {
                        "name": "email",
                        "type": "string",
                        "description": "Email address",
                        "required": True,
                        "format": "email"
                    },
                    {
                        "name": "age",
                        "type": "integer",
                        "description": "Age in years",
                        "required": False,
                        "minimum": 0,
                        "maximum": 150
                    },
                    {
                        "name": "interests",
                        "type": "array",
                        "description": "List of interests",
                        "required": False,
                        "items": {"type": "string"}
                    }
                ],
                "json_schema": {
                    "type": "object",
                    "properties": {
                        "name": {
                            "type": "string",
                            "description": "Full name",
                            "minLength": 1,
                            "maxLength": 100
                        },
                        "email": {
                            "type": "string",
                            "description": "Email address",
                            "format": "email"
                        },
                        "age": {
                            "type": "integer",
                            "description": "Age in years",
                            "minimum": 0,
                            "maximum": 150
                        },
                        "interests": {
                            "type": "array",
                            "description": "List of interests",
                            "items": {"type": "string"}
                        }
                    },
                    "required": ["name", "email"]
                },
                "tags": ["user", "profile"],
                "category": "user-data",
                "examples": [
                    {
                        "name": "John Doe",
                        "email": "john@example.com",
                        "age": 30,
                        "interests": ["technology", "sports"]
                    }
                ]
            }
        }


class SchemaCreate(BaseModel):
    """Schema creation model"""
    
    name: str
    description: Optional[str] = None
    schema_type: str = "object"
    fields: List[SchemaField] = Field(default_factory=list)
    json_schema: Dict[str, Any]
    version: str = "1.0.0"
    tags: List[str] = Field(default_factory=list)
    category: Optional[str] = None
    examples: List[Dict[str, Any]] = Field(default_factory=list)


class SchemaUpdate(BaseModel):
    """Schema update model"""
    
    name: Optional[str] = None
    description: Optional[str] = None
    schema_type: Optional[str] = None
    fields: Optional[List[SchemaField]] = None
    json_schema: Optional[Dict[str, Any]] = None
    version: Optional[str] = None
    tags: Optional[List[str]] = None
    category: Optional[str] = None
    examples: Optional[List[Dict[str, Any]]] = None
    share_settings: Optional[ShareSettings] = None


class SchemaValidationResult(BaseModel):
    """Schema validation result"""
    
    is_valid: bool
    errors: List[str] = Field(default_factory=list)
    warnings: List[str] = Field(default_factory=list)
    validated_data: Optional[Dict[str, Any]] = None
    
    class Config:
        schema_extra = {
            "example": {
                "is_valid": True,
                "errors": [],
                "warnings": ["Field 'age' is not provided but has a default value"],
                "validated_data": {
                    "name": "John Doe",
                    "email": "john@example.com",
                    "age": 25,
                    "interests": ["reading", "coding"]
                }
            }
        }


class SchemaUsage(BaseModel):
    """Schema usage tracking"""
    
    schema_id: str
    used_by_pipeline: Optional[str] = None
    used_by_tool: Optional[str] = None
    used_at: str
    validation_result: Optional[SchemaValidationResult] = None
    
    class Config:
        schema_extra = {
            "example": {
                "schema_id": "schema123",
                "used_by_pipeline": "pipeline456",
                "used_at": "2023-12-01T10:00:00Z",
                "validation_result": {
                    "is_valid": True,
                    "errors": [],
                    "warnings": []
                }
            }
        }

