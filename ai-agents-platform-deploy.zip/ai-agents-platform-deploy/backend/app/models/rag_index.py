"""
RAG Index data models
"""

from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from app.models.base import BaseDocument, ShareSettings


class IndexField(BaseModel):
    """Index field definition"""
    
    name: str = Field(..., description="Field name")
    type: str = Field(..., description="Field data type")
    searchable: bool = True
    filterable: bool = False
    sortable: bool = False
    facetable: bool = False
    retrievable: bool = True
    analyzer: Optional[str] = None
    search_analyzer: Optional[str] = None
    index_analyzer: Optional[str] = None
    
    class Config:
        schema_extra = {
            "example": {
                "name": "content",
                "type": "Edm.String",
                "searchable": True,
                "filterable": False,
                "sortable": False,
                "facetable": False,
                "retrievable": True,
                "analyzer": "standard.lucene"
            }
        }


class VectorField(BaseModel):
    """Vector field definition for semantic search"""
    
    name: str = Field(..., description="Vector field name")
    dimensions: int = Field(..., description="Vector dimensions")
    vector_search_profile: str = Field(..., description="Vector search profile name")
    
    class Config:
        schema_extra = {
            "example": {
                "name": "content_vector",
                "dimensions": 1536,
                "vector_search_profile": "default-vector-profile"
            }
        }


class SemanticConfiguration(BaseModel):
    """Semantic search configuration"""
    
    name: str = Field(..., description="Configuration name")
    prioritized_fields: Dict[str, List[str]] = Field(..., description="Prioritized fields for semantic search")
    
    class Config:
        schema_extra = {
            "example": {
                "name": "default-semantic-config",
                "prioritized_fields": {
                    "title_field": ["title"],
                    "content_fields": ["content", "description"],
                    "keywords_fields": ["tags", "keywords"]
                }
            }
        }


class RAGIndex(BaseDocument):
    """RAG Index model"""
    
    name: str = Field(..., description="Index name")
    description: Optional[str] = None
    owner_id: str = Field(..., description="Owner user ID")
    
    # Azure AI Search configuration
    search_service_endpoint: str = Field(..., description="Azure AI Search service endpoint")
    index_name: str = Field(..., description="Actual index name in Azure AI Search")
    api_key: str = Field(..., description="Search service API key")
    
    # Index schema
    fields: List[IndexField] = Field(default_factory=list)
    vector_fields: List[VectorField] = Field(default_factory=list)
    
    # Search configuration
    semantic_configurations: List[SemanticConfiguration] = Field(default_factory=list)
    default_semantic_configuration: Optional[str] = None
    
    # Indexing settings
    cors_options: Optional[Dict[str, Any]] = None
    scoring_profiles: List[Dict[str, Any]] = Field(default_factory=list)
    analyzers: List[Dict[str, Any]] = Field(default_factory=list)
    
    # Metadata
    version: str = Field(default="1.0.0")
    tags: List[str] = Field(default_factory=list)
    category: Optional[str] = None
    
    # Sharing and permissions
    share_settings: ShareSettings = Field(default_factory=ShareSettings)
    
    # Status and statistics
    status: str = Field(default="active", description="Index status")
    document_count: int = Field(default=0)
    storage_size_bytes: int = Field(default=0)
    last_updated: Optional[str] = None
    
    # Usage statistics
    usage_count: int = Field(default=0)
    last_used: Optional[str] = None
    
    class Config:
        schema_extra = {
            "example": {
                "name": "Company Documents Index",
                "description": "Search index for company documentation",
                "owner_id": "user123",
                "search_service_endpoint": "https://mysearch.search.windows.net",
                "index_name": "company-docs",
                "api_key": "your-search-api-key",
                "fields": [
                    {
                        "name": "id",
                        "type": "Edm.String",
                        "searchable": False,
                        "filterable": True,
                        "sortable": False,
                        "facetable": False,
                        "retrievable": True
                    },
                    {
                        "name": "title",
                        "type": "Edm.String",
                        "searchable": True,
                        "filterable": True,
                        "sortable": True,
                        "facetable": False,
                        "retrievable": True
                    },
                    {
                        "name": "content",
                        "type": "Edm.String",
                        "searchable": True,
                        "filterable": False,
                        "sortable": False,
                        "facetable": False,
                        "retrievable": True
                    }
                ],
                "vector_fields": [
                    {
                        "name": "content_vector",
                        "dimensions": 1536,
                        "vector_search_profile": "default-vector-profile"
                    }
                ],
                "semantic_configurations": [
                    {
                        "name": "default-semantic-config",
                        "prioritized_fields": {
                            "title_field": ["title"],
                            "content_fields": ["content"],
                            "keywords_fields": ["tags"]
                        }
                    }
                ],
                "default_semantic_configuration": "default-semantic-config",
                "tags": ["documentation", "company"],
                "category": "knowledge-base",
                "status": "active",
                "document_count": 1500,
                "storage_size_bytes": 52428800
            }
        }


class RAGIndexCreate(BaseModel):
    """RAG Index creation model"""
    
    name: str
    description: Optional[str] = None
    search_service_endpoint: str
    index_name: str
    api_key: str
    fields: List[IndexField] = Field(default_factory=list)
    vector_fields: List[VectorField] = Field(default_factory=list)
    semantic_configurations: List[SemanticConfiguration] = Field(default_factory=list)
    default_semantic_configuration: Optional[str] = None
    version: str = "1.0.0"
    tags: List[str] = Field(default_factory=list)
    category: Optional[str] = None


class RAGIndexUpdate(BaseModel):
    """RAG Index update model"""
    
    name: Optional[str] = None
    description: Optional[str] = None
    search_service_endpoint: Optional[str] = None
    api_key: Optional[str] = None
    fields: Optional[List[IndexField]] = None
    vector_fields: Optional[List[VectorField]] = None
    semantic_configurations: Optional[List[SemanticConfiguration]] = None
    default_semantic_configuration: Optional[str] = None
    version: Optional[str] = None
    tags: Optional[List[str]] = None
    category: Optional[str] = None
    share_settings: Optional[ShareSettings] = None


class SearchQuery(BaseModel):
    """Search query model"""
    
    query: str = Field(..., description="Search query text")
    search_fields: Optional[List[str]] = None
    select_fields: Optional[List[str]] = None
    filter: Optional[str] = None
    order_by: Optional[List[str]] = None
    top: int = Field(default=10, description="Number of results to return")
    skip: int = Field(default=0, description="Number of results to skip")
    search_mode: str = Field(default="any", description="Search mode (any, all)")
    query_type: str = Field(default="simple", description="Query type (simple, full, semantic)")
    semantic_configuration: Optional[str] = None
    highlight_fields: Optional[List[str]] = None
    facets: Optional[List[str]] = None
    
    class Config:
        schema_extra = {
            "example": {
                "query": "machine learning algorithms",
                "search_fields": ["title", "content"],
                "select_fields": ["id", "title", "content", "score"],
                "top": 5,
                "search_mode": "any",
                "query_type": "semantic",
                "semantic_configuration": "default-semantic-config",
                "highlight_fields": ["content"]
            }
        }


class SearchResult(BaseModel):
    """Search result model"""
    
    document: Dict[str, Any] = Field(..., description="Retrieved document")
    score: float = Field(..., description="Search relevance score")
    highlights: Optional[Dict[str, List[str]]] = None
    captions: Optional[List[Dict[str, Any]]] = None
    
    class Config:
        schema_extra = {
            "example": {
                "document": {
                    "id": "doc123",
                    "title": "Introduction to Machine Learning",
                    "content": "Machine learning is a subset of artificial intelligence...",
                    "tags": ["AI", "ML", "algorithms"]
                },
                "score": 0.85,
                "highlights": {
                    "content": ["<em>Machine learning</em> is a subset of artificial intelligence"]
                },
                "captions": [
                    {
                        "text": "Machine learning algorithms are used to...",
                        "highlights": "Machine learning <em>algorithms</em> are used to..."
                    }
                ]
            }
        }


class SearchResponse(BaseModel):
    """Search response model"""
    
    results: List[SearchResult] = Field(default_factory=list)
    total_count: int = Field(..., description="Total number of matching documents")
    facets: Optional[Dict[str, List[Dict[str, Any]]]] = None
    query_context: Optional[Dict[str, Any]] = None
    
    class Config:
        schema_extra = {
            "example": {
                "results": [
                    {
                        "document": {
                            "id": "doc123",
                            "title": "Introduction to Machine Learning",
                            "content": "Machine learning is a subset..."
                        },
                        "score": 0.85,
                        "highlights": {
                            "content": ["<em>Machine learning</em> is a subset"]
                        }
                    }
                ],
                "total_count": 42,
                "facets": {
                    "category": [
                        {"value": "AI", "count": 15},
                        {"value": "ML", "count": 27}
                    ]
                }
            }
        }

