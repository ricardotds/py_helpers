"""
User data models
"""

from pydantic import BaseModel, Field, EmailStr
from typing import Optional, List, Dict, Any
from app.models.base import BaseDocument


class User(BaseDocument):
    """User model"""
    
    email: EmailStr
    name: str
    azure_object_id: str = Field(..., description="Microsoft Entra ID object ID")
    groups: List[str] = Field(default_factory=list, description="Azure AD groups")
    is_active: bool = True
    is_admin: bool = False
    preferences: Dict[str, Any] = Field(default_factory=dict)
    
    class Config:
        schema_extra = {
            "example": {
                "email": "user@example.com",
                "name": "John Doe",
                "azure_object_id": "12345678-1234-1234-1234-123456789012",
                "groups": ["developers", "ai-team"],
                "is_active": True,
                "is_admin": False,
                "preferences": {
                    "theme": "dark",
                    "notifications": True
                }
            }
        }


class UserCreate(BaseModel):
    """User creation model"""
    
    email: EmailStr
    name: str
    azure_object_id: str
    groups: List[str] = Field(default_factory=list)
    is_admin: bool = False


class UserUpdate(BaseModel):
    """User update model"""
    
    name: Optional[str] = None
    groups: Optional[List[str]] = None
    is_active: Optional[bool] = None
    is_admin: Optional[bool] = None
    preferences: Optional[Dict[str, Any]] = None


class UserInDB(User):
    """User model as stored in database"""
    pass


class UserResponse(BaseModel):
    """User response model (public fields only)"""
    
    id: str
    email: EmailStr
    name: str
    groups: List[str]
    is_active: bool
    is_admin: bool
    created_at: str
    updated_at: str

