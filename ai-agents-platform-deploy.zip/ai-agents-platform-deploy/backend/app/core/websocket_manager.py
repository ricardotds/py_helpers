"""
Enhanced WebSocket manager for real-time communication
"""

from fastapi import WebSocket, WebSocketDisconnect
from typing import Dict, List, Set, Optional, Any
import json
import asyncio
from datetime import datetime
from app.core.logging import LoggerMixin


class ConnectionInfo:
    """Information about a WebSocket connection"""
    
    def __init__(self, websocket: WebSocket, user_id: str):
        self.websocket = websocket
        self.user_id = user_id
        self.connected_at = datetime.utcnow()
        self.last_ping = datetime.utcnow()
        self.subscriptions: Set[str] = set()


class WebSocketManager(LoggerMixin):
    """Enhanced WebSocket manager for real-time communication"""
    
    def __init__(self):
        # Connection management
        self.connections: Dict[str, ConnectionInfo] = {}  # client_id -> ConnectionInfo
        self.user_connections: Dict[str, Set[str]] = {}  # user_id -> set of client_ids
        
        # Topic subscriptions
        self.topic_subscribers: Dict[str, Set[str]] = {}  # topic -> set of client_ids
        self.pipeline_subscribers: Dict[str, Set[str]] = {}  # pipeline_id -> set of client_ids
        self.execution_subscribers: Dict[str, Set[str]] = {}  # execution_id -> set of client_ids
        
        # Connection counter for unique IDs
        self._connection_counter = 0
        
        # Heartbeat task
        self._heartbeat_task: Optional[asyncio.Task] = None
        
        self.logger.info("Enhanced WebSocket manager initialized")
    
    def _generate_client_id(self) -> str:
        """Generate unique client ID"""
        self._connection_counter += 1
        return f"client_{self._connection_counter}_{int(datetime.utcnow().timestamp())}"
    
    async def connect(self, websocket: WebSocket, user_id: str) -> str:
        """Accept a new WebSocket connection and return client ID"""
        try:
            await websocket.accept()
            
            client_id = self._generate_client_id()
            connection_info = ConnectionInfo(websocket, user_id)
            
            # Store connection
            self.connections[client_id] = connection_info
            
            # Update user connections
            if user_id not in self.user_connections:
                self.user_connections[user_id] = set()
            self.user_connections[user_id].add(client_id)
            
            # Start heartbeat if this is the first connection
            if len(self.connections) == 1 and self._heartbeat_task is None:
                self._heartbeat_task = asyncio.create_task(self._heartbeat_loop())
            
            self.logger.info(f"Client {client_id} connected for user {user_id}")
            
            # Send welcome message
            await self.send_json_message({
                "type": "connection_established",
                "client_id": client_id,
                "user_id": user_id,
                "server_time": datetime.utcnow().isoformat(),
                "message": "Connected to real-time updates"
            }, client_id)
            
            return client_id
            
        except Exception as e:
            self.logger.error(f"Error connecting WebSocket: {e}")
            raise
    
    def disconnect(self, client_id: str):
        """Remove a WebSocket connection"""
        if client_id not in self.connections:
            return
        
        connection_info = self.connections[client_id]
        user_id = connection_info.user_id
        
        # Remove from all subscriptions
        for topic in connection_info.subscriptions:
            if topic in self.topic_subscribers:
                self.topic_subscribers[topic].discard(client_id)
                if not self.topic_subscribers[topic]:
                    del self.topic_subscribers[topic]
        
        # Remove from pipeline subscriptions
        for pipeline_id, subscribers in list(self.pipeline_subscribers.items()):
            if client_id in subscribers:
                subscribers.remove(client_id)
                if not subscribers:
                    del self.pipeline_subscribers[pipeline_id]
        
        # Remove from execution subscriptions
        for execution_id, subscribers in list(self.execution_subscribers.items()):
            if client_id in subscribers:
                subscribers.remove(client_id)
                if not subscribers:
                    del self.execution_subscribers[execution_id]
        
        # Remove from user connections
        if user_id in self.user_connections:
            self.user_connections[user_id].discard(client_id)
            if not self.user_connections[user_id]:
                del self.user_connections[user_id]
        
        # Remove connection
        del self.connections[client_id]
        
        # Stop heartbeat if no connections
        if not self.connections and self._heartbeat_task:
            self._heartbeat_task.cancel()
            self._heartbeat_task = None
        
        self.logger.info(f"Client {client_id} disconnected")
    
    async def send_personal_message(self, message: str, client_id: str):
        """Send a text message to a specific client"""
        if client_id not in self.connections:
            return False
        
        try:
            await self.connections[client_id].websocket.send_text(message)
            return True
        except WebSocketDisconnect:
            self.logger.info(f"Client {client_id} disconnected during send")
            self.disconnect(client_id)
            return False
        except Exception as e:
            self.logger.error(f"Error sending message to {client_id}: {e}")
            self.disconnect(client_id)
            return False
    
    async def send_json_message(self, data: dict, client_id: str):
        """Send JSON data to a specific client"""
        if client_id not in self.connections:
            return False
        
        try:
            # Add timestamp if not present
            if 'timestamp' not in data:
                data['timestamp'] = datetime.utcnow().isoformat()
            
            await self.connections[client_id].websocket.send_text(json.dumps(data))
            return True
        except WebSocketDisconnect:
            self.logger.info(f"Client {client_id} disconnected during JSON send")
            self.disconnect(client_id)
            return False
        except Exception as e:
            self.logger.error(f"Error sending JSON to {client_id}: {e}")
            self.disconnect(client_id)
            return False
    
    async def send_to_user(self, data: dict, user_id: str) -> int:
        """Send JSON data to all connections for a specific user"""
        if user_id not in self.user_connections:
            return 0
        
        client_ids = list(self.user_connections[user_id])
        sent_count = 0
        
        for client_id in client_ids:
            if await self.send_json_message(data, client_id):
                sent_count += 1
        
        return sent_count
    
    async def broadcast_message(self, message: str):
        """Broadcast a text message to all connected clients"""
        client_ids = list(self.connections.keys())
        for client_id in client_ids:
            await self.send_personal_message(message, client_id)
    
    async def broadcast_json(self, data: dict):
        """Broadcast JSON data to all connected clients"""
        client_ids = list(self.connections.keys())
        for client_id in client_ids:
            await self.send_json_message(data, client_id)
    
    async def subscribe_to_topic(self, client_id: str, topic: str):
        """Subscribe a client to a topic"""
        if client_id not in self.connections:
            return False
        
        # Add to connection subscriptions
        self.connections[client_id].subscriptions.add(topic)
        
        # Add to topic subscribers
        if topic not in self.topic_subscribers:
            self.topic_subscribers[topic] = set()
        self.topic_subscribers[topic].add(client_id)
        
        self.logger.info(f"Client {client_id} subscribed to topic {topic}")
        
        # Send confirmation
        await self.send_json_message({
            "type": "subscription_confirmed",
            "topic": topic
        }, client_id)
        
        return True
    
    async def unsubscribe_from_topic(self, client_id: str, topic: str):
        """Unsubscribe a client from a topic"""
        if client_id not in self.connections:
            return False
        
        # Remove from connection subscriptions
        self.connections[client_id].subscriptions.discard(topic)
        
        # Remove from topic subscribers
        if topic in self.topic_subscribers:
            self.topic_subscribers[topic].discard(client_id)
            if not self.topic_subscribers[topic]:
                del self.topic_subscribers[topic]
        
        self.logger.info(f"Client {client_id} unsubscribed from topic {topic}")
        
        # Send confirmation
        await self.send_json_message({
            "type": "unsubscription_confirmed",
            "topic": topic
        }, client_id)
        
        return True
    
    async def broadcast_to_topic(self, topic: str, data: dict) -> int:
        """Broadcast data to all subscribers of a topic"""
        if topic not in self.topic_subscribers:
            return 0
        
        client_ids = list(self.topic_subscribers[topic])
        sent_count = 0
        
        for client_id in client_ids:
            if await self.send_json_message(data, client_id):
                sent_count += 1
        
        return sent_count
    
    async def subscribe_to_pipeline(self, client_id: str, pipeline_id: str):
        """Subscribe a client to pipeline execution updates"""
        if pipeline_id not in self.pipeline_subscribers:
            self.pipeline_subscribers[pipeline_id] = set()
        
        self.pipeline_subscribers[pipeline_id].add(client_id)
        
        # Also subscribe to topic
        await self.subscribe_to_topic(client_id, f"pipeline:{pipeline_id}")
        
        self.logger.info(f"Client {client_id} subscribed to pipeline {pipeline_id}")
    
    async def unsubscribe_from_pipeline(self, client_id: str, pipeline_id: str):
        """Unsubscribe a client from pipeline execution updates"""
        if pipeline_id in self.pipeline_subscribers:
            self.pipeline_subscribers[pipeline_id].discard(client_id)
            if not self.pipeline_subscribers[pipeline_id]:
                del self.pipeline_subscribers[pipeline_id]
        
        # Also unsubscribe from topic
        await self.unsubscribe_from_topic(client_id, f"pipeline:{pipeline_id}")
        
        self.logger.info(f"Client {client_id} unsubscribed from pipeline {pipeline_id}")
    
    async def subscribe_to_execution(self, client_id: str, execution_id: str):
        """Subscribe a client to execution updates"""
        if execution_id not in self.execution_subscribers:
            self.execution_subscribers[execution_id] = set()
        
        self.execution_subscribers[execution_id].add(client_id)
        
        # Also subscribe to topic
        await self.subscribe_to_topic(client_id, f"execution:{execution_id}")
        
        self.logger.info(f"Client {client_id} subscribed to execution {execution_id}")
    
    async def unsubscribe_from_execution(self, client_id: str, execution_id: str):
        """Unsubscribe a client from execution updates"""
        if execution_id in self.execution_subscribers:
            self.execution_subscribers[execution_id].discard(client_id)
            if not self.execution_subscribers[execution_id]:
                del self.execution_subscribers[execution_id]
        
        # Also unsubscribe from topic
        await self.unsubscribe_from_topic(client_id, f"execution:{execution_id}")
        
        self.logger.info(f"Client {client_id} unsubscribed from execution {execution_id}")
    
    async def notify_pipeline_subscribers(self, pipeline_id: str, event_data: dict):
        """Notify all subscribers of a pipeline about an event"""
        message = {
            "type": "pipeline_event",
            "pipeline_id": pipeline_id,
            "data": event_data
        }
        
        # Send to pipeline subscribers
        if pipeline_id in self.pipeline_subscribers:
            client_ids = list(self.pipeline_subscribers[pipeline_id])
            for client_id in client_ids:
                await self.send_json_message(message, client_id)
        
        # Also broadcast to topic
        await self.broadcast_to_topic(f"pipeline:{pipeline_id}", message)
    
    async def notify_execution_subscribers(self, execution_id: str, event_data: dict):
        """Notify all subscribers of an execution about an event"""
        message = {
            "type": "execution_update",
            "execution_id": execution_id,
            "data": event_data
        }
        
        # Send to execution subscribers
        if execution_id in self.execution_subscribers:
            client_ids = list(self.execution_subscribers[execution_id])
            for client_id in client_ids:
                await self.send_json_message(message, client_id)
        
        # Also broadcast to topic
        await self.broadcast_to_topic(f"execution:{execution_id}", message)
        
        # Broadcast to general executions topic
        await self.broadcast_to_topic("executions", message)
    
    async def handle_client_message(self, client_id: str, message_data: dict):
        """Handle incoming WebSocket message from client"""
        try:
            message_type = message_data.get('type')
            data = message_data.get('data', {})
            
            if message_type == "ping":
                # Update last ping time
                if client_id in self.connections:
                    self.connections[client_id].last_ping = datetime.utcnow()
                
                # Send pong response
                await self.send_json_message({
                    "type": "pong",
                    "server_time": datetime.utcnow().isoformat()
                }, client_id)
            
            elif message_type == "subscribe":
                topic = data.get('topic')
                if topic:
                    await self.subscribe_to_topic(client_id, topic)
            
            elif message_type == "unsubscribe":
                topic = data.get('topic')
                if topic:
                    await self.unsubscribe_from_topic(client_id, topic)
            
            elif message_type == "subscribe_pipeline":
                pipeline_id = data.get('pipeline_id')
                if pipeline_id:
                    await self.subscribe_to_pipeline(client_id, pipeline_id)
            
            elif message_type == "subscribe_execution":
                execution_id = data.get('execution_id')
                if execution_id:
                    await self.subscribe_to_execution(client_id, execution_id)
            
            else:
                self.logger.warning(f"Unknown message type: {message_type}")
                await self.send_json_message({
                    "type": "error",
                    "message": f"Unknown message type: {message_type}"
                }, client_id)
        
        except Exception as e:
            self.logger.error(f"Error handling client message: {e}")
            await self.send_json_message({
                "type": "error",
                "message": "Internal server error"
            }, client_id)
    
    async def _heartbeat_loop(self):
        """Heartbeat loop to check connection health"""
        while self.connections:
            try:
                current_time = datetime.utcnow()
                stale_connections = []
                
                for client_id, connection_info in self.connections.items():
                    # Check if connection is stale (no ping in 60 seconds)
                    time_since_ping = (current_time - connection_info.last_ping).total_seconds()
                    if time_since_ping > 60:
                        stale_connections.append(client_id)
                
                # Disconnect stale connections
                for client_id in stale_connections:
                    self.logger.info(f"Disconnecting stale connection: {client_id}")
                    self.disconnect(client_id)
                
                # Send heartbeat to all connections
                heartbeat_data = {
                    "type": "heartbeat",
                    "server_time": current_time.isoformat(),
                    "active_connections": len(self.connections)
                }
                
                client_ids = list(self.connections.keys())
                for client_id in client_ids:
                    await self.send_json_message(heartbeat_data, client_id)
                
                # Wait 30 seconds before next heartbeat
                await asyncio.sleep(30)
                
            except asyncio.CancelledError:
                self.logger.info("Heartbeat loop cancelled")
                break
            except Exception as e:
                self.logger.error(f"Error in heartbeat loop: {e}")
                await asyncio.sleep(30)
    
    def get_connected_clients(self) -> List[str]:
        """Get list of all connected client IDs"""
        return list(self.connections.keys())
    
    def get_pipeline_subscribers(self, pipeline_id: str) -> List[str]:
        """Get list of clients subscribed to a specific pipeline"""
        return list(self.pipeline_subscribers.get(pipeline_id, set()))
    
    def get_execution_subscribers(self, execution_id: str) -> List[str]:
        """Get list of clients subscribed to a specific execution"""
        return list(self.execution_subscribers.get(execution_id, set()))
    
    def get_connection_stats(self) -> Dict[str, Any]:
        """Get connection statistics"""
        return {
            "total_connections": len(self.connections),
            "unique_users": len(self.user_connections),
            "active_topics": len(self.topic_subscribers),
            "pipeline_subscriptions": len(self.pipeline_subscribers),
            "execution_subscriptions": len(self.execution_subscribers),
            "connections_by_user": {
                user_id: len(client_ids) 
                for user_id, client_ids in self.user_connections.items()
            }
        }




websocket_manager = WebSocketManager()

