"""
Configuration management for AI Agents Management Platform
"""

from pydantic_settings import BaseSettings
from typing import Optional, List
import os


class Settings(BaseSettings):
    """Application settings"""
    
    # Application
    APP_NAME: str = "AI Agents Management Platform"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = False
    
    # API
    API_V1_STR: str = "/api/v1"
    
    # Database - CosmosDB MongoDB API
    MONGODB_URL: str = "mongodb://localhost:27017"
    DATABASE_NAME: str = "ai_agents_platform"
    
    # Authentication - Microsoft Entra ID
    AZURE_CLIENT_ID: str = ""
    AZURE_CLIENT_SECRET: str = ""
    AZURE_TENANT_ID: str = ""
    AZURE_AUTHORITY: str = "https://login.microsoftonline.com"
    AZURE_SCOPE: List[str] = ["https://graph.microsoft.com/.default"]
    
    # JWT
    SECRET_KEY: str = "your-secret-key-change-in-production"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    
    # AI Services
    # Azure OpenAI
    AZURE_OPENAI_ENDPOINT: str = ""
    AZURE_OPENAI_API_KEY: str = ""
    AZURE_OPENAI_API_VERSION: str = "2023-12-01-preview"
    
    # AWS Bedrock
    AWS_ACCESS_KEY_ID: str = ""
    AWS_SECRET_ACCESS_KEY: str = ""
    AWS_REGION: str = "us-east-1"
    
    # Azure AI Search
    AZURE_SEARCH_ENDPOINT: str = ""
    AZURE_SEARCH_API_KEY: str = ""
    AZURE_SEARCH_API_VERSION: str = "2023-11-01"
    
    # Airflow
    AIRFLOW_WEBSERVER_URL: str = "http://localhost:8080"
    AIRFLOW_USERNAME: str = "admin"
    AIRFLOW_PASSWORD: str = "admin"
    
    # Kubernetes
    K8S_NAMESPACE: str = "ai-agents-platform"
    K8S_PIPELINE_NODEPOOL: str = "pipeline-execution"
    
    # Redis for Celery
    REDIS_URL: str = "redis://localhost:6379/0"
    
    # CORS
    BACKEND_CORS_ORIGINS: List[str] = ["http://localhost:3000", "http://localhost:8080"]
    
    # Logging
    LOG_LEVEL: str = "INFO"
    
    # Pipeline execution
    PIPELINE_EXECUTION_TIMEOUT: int = 3600  # 1 hour
    PYTHON_VENV_BASE_PATH: str = "/tmp/pipeline_venvs"
    
    class Config:
        env_file = ".env"
        case_sensitive = True


# Create settings instance
settings = Settings()

