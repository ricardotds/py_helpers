"""
Schema service for managing schema operations
"""

from typing import Optional, List, Dict, Any
import jsonschema
from jsonschema import validate, ValidationError
from datetime import datetime

from app.database.repository import BaseRepository
from app.models.schema import Schema, SchemaCreate, SchemaUpdate, SchemaValidationResult
from app.models.user import User
from app.auth.dependencies import PermissionChecker
from app.core.logging import LoggerMixin


class SchemaService(LoggerMixin):
    """Service for schema management operations"""
    
    def __init__(self):
        self.repository = BaseRepository("schemas", Schema)
    
    async def create_schema(self, schema_data: SchemaCreate, owner_id: str) -> Schema:
        """Create a new schema"""
        try:
            # Check if schema with same name exists for this owner
            existing_schema = await self.repository.get_by_field("name", schema_data.name)
            if existing_schema and existing_schema.owner_id == owner_id:
                raise ValueError(f"Schema with name '{schema_data.name}' already exists")
            
            # Validate JSON schema
            try:
                jsonschema.Draft7Validator.check_schema(schema_data.json_schema)
            except jsonschema.SchemaError as e:
                raise ValueError(f"Invalid JSON schema: {e.message}")
            
            # Create schema document
            schema_dict = schema_data.dict()
            schema_dict["owner_id"] = owner_id
            
            schema = await self.repository.create(schema_dict)
            
            self.logger.info(f"Created schema: {schema.name} by user {owner_id}")
            return schema
            
        except ValueError:
            raise
        except Exception as e:
            self.logger.error(f"Error creating schema: {e}")
            raise
    
    async def get_schema(self, schema_id: str, user: User) -> Optional[Schema]:
        """Get schema by ID with permission check"""
        try:
            schema = await self.repository.get_by_id(schema_id)
            if not schema:
                return None
            
            # Check permissions
            if not PermissionChecker.check_resource_permission(
                user=user,
                resource_owner_id=schema.owner_id,
                shared_with_users=schema.share_settings.shared_with_users,
                shared_with_groups=schema.share_settings.shared_with_groups,
                is_public=schema.share_settings.is_public
            ):
                return None
            
            return schema
            
        except Exception as e:
            self.logger.error(f"Error getting schema {schema_id}: {e}")
            return None
    
    async def update_schema(self, schema_id: str, schema_data: SchemaUpdate, user: User) -> Optional[Schema]:
        """Update schema with permission check"""
        try:
            # Get existing schema
            existing_schema = await self.repository.get_by_id(schema_id)
            if not existing_schema:
                return None
            
            # Check permissions (owner or write access)
            PermissionChecker.ensure_resource_access(
                user=user,
                resource_owner_id=existing_schema.owner_id,
                shared_with_users=existing_schema.share_settings.shared_with_users,
                shared_with_groups=existing_schema.share_settings.shared_with_groups,
                is_public=existing_schema.share_settings.is_public,
                required_permission="write"
            )
            
            # Validate JSON schema if provided
            update_dict = schema_data.dict(exclude_unset=True)
            if "json_schema" in update_dict:
                try:
                    jsonschema.Draft7Validator.check_schema(update_dict["json_schema"])
                except jsonschema.SchemaError as e:
                    raise ValueError(f"Invalid JSON schema: {e.message}")
            
            # Update usage count if schema is being used
            if "last_used" in update_dict:
                update_dict["usage_count"] = existing_schema.usage_count + 1
            
            updated_schema = await self.repository.update(schema_id, update_dict)
            
            if updated_schema:
                self.logger.info(f"Updated schema: {updated_schema.name}")
            
            return updated_schema
            
        except ValueError:
            raise
        except Exception as e:
            self.logger.error(f"Error updating schema {schema_id}: {e}")
            return None
    
    async def delete_schema(self, schema_id: str, user: User) -> bool:
        """Delete schema with permission check"""
        try:
            schema = await self.repository.get_by_id(schema_id)
            if not schema:
                return False
            
            # Check permissions (owner only)
            PermissionChecker.ensure_resource_access(
                user=user,
                resource_owner_id=schema.owner_id,
                required_permission="admin"
            )
            
            success = await self.repository.delete(schema_id)
            
            if success:
                self.logger.info(f"Deleted schema: {schema.name}")
            
            return success
            
        except Exception as e:
            self.logger.error(f"Error deleting schema {schema_id}: {e}")
            return False
    
    async def list_schemas(
        self,
        user: User,
        skip: int = 0,
        limit: int = 100,
        search: Optional[str] = None,
        category: Optional[str] = None,
        tags: Optional[List[str]] = None,
        owner_only: bool = False
    ) -> List[Schema]:
        """List schemas accessible to user"""
        try:
            filter_dict = {}
            
            if category:
                filter_dict["category"] = category
            
            if tags:
                filter_dict["tags"] = {"$in": tags}
            
            if owner_only:
                filter_dict["owner_id"] = str(user.id)
            
            if search:
                schemas = await self.repository.search(
                    search_term=search,
                    search_fields=["name", "description"],
                    filter_dict=filter_dict,
                    skip=skip,
                    limit=limit
                )
            else:
                schemas = await self.repository.list(
                    filter_dict=filter_dict,
                    skip=skip,
                    limit=limit,
                    sort_by="updated_at",
                    sort_order=-1
                )
            
            # Filter by permissions
            accessible_schemas = []
            for schema in schemas:
                if PermissionChecker.check_resource_permission(
                    user=user,
                    resource_owner_id=schema.owner_id,
                    shared_with_users=schema.share_settings.shared_with_users,
                    shared_with_groups=schema.share_settings.shared_with_groups,
                    is_public=schema.share_settings.is_public
                ):
                    accessible_schemas.append(schema)
            
            return accessible_schemas
            
        except Exception as e:
            self.logger.error(f"Error listing schemas: {e}")
            return []
    
    async def count_schemas(
        self,
        user: User,
        category: Optional[str] = None,
        tags: Optional[List[str]] = None,
        owner_only: bool = False
    ) -> int:
        """Count schemas accessible to user"""
        try:
            filter_dict = {}
            
            if category:
                filter_dict["category"] = category
            
            if tags:
                filter_dict["tags"] = {"$in": tags}
            
            if owner_only:
                filter_dict["owner_id"] = str(user.id)
            
            # For simplicity, get all matching schemas and filter by permissions
            schemas = await self.repository.list(filter_dict=filter_dict)
            
            accessible_count = 0
            for schema in schemas:
                if PermissionChecker.check_resource_permission(
                    user=user,
                    resource_owner_id=schema.owner_id,
                    shared_with_users=schema.share_settings.shared_with_users,
                    shared_with_groups=schema.share_settings.shared_with_groups,
                    is_public=schema.share_settings.is_public
                ):
                    accessible_count += 1
            
            return accessible_count
            
        except Exception as e:
            self.logger.error(f"Error counting schemas: {e}")
            return 0
    
    async def validate_data(self, schema_id: str, data: Dict[str, Any], user: User) -> SchemaValidationResult:
        """Validate data against schema"""
        try:
            schema = await self.get_schema(schema_id, user)
            if not schema:
                raise ValueError("Schema not found or access denied")
            
            errors = []
            warnings = []
            is_valid = True
            validated_data = None
            
            try:
                # Validate data against JSON schema
                validate(instance=data, schema=schema.json_schema)
                validated_data = data
                
            except ValidationError as e:
                is_valid = False
                errors.append(f"Validation error at {'.'.join(str(p) for p in e.absolute_path)}: {e.message}")
            
            except Exception as e:
                is_valid = False
                errors.append(f"Schema validation failed: {str(e)}")
            
            # Update usage statistics
            await self.update_schema(
                schema_id,
                SchemaUpdate(last_used=datetime.utcnow().isoformat()),
                user
            )
            
            return SchemaValidationResult(
                is_valid=is_valid,
                errors=errors,
                warnings=warnings,
                validated_data=validated_data
            )
            
        except ValueError:
            raise
        except Exception as e:
            self.logger.error(f"Error validating data against schema {schema_id}: {e}")
            raise
    
    async def get_schema_categories(self, user: User) -> List[str]:
        """Get list of schema categories accessible to user"""
        try:
            # Get all schemas accessible to user
            schemas = await self.list_schemas(user, limit=1000)
            
            # Extract unique categories
            categories = set()
            for schema in schemas:
                if schema.category:
                    categories.add(schema.category)
            
            return sorted(list(categories))
            
        except Exception as e:
            self.logger.error(f"Error getting schema categories: {e}")
            return []
    
    async def get_schema_tags(self, user: User) -> List[str]:
        """Get list of schema tags accessible to user"""
        try:
            # Get all schemas accessible to user
            schemas = await self.list_schemas(user, limit=1000)
            
            # Extract unique tags
            tags = set()
            for schema in schemas:
                tags.update(schema.tags)
            
            return sorted(list(tags))
            
        except Exception as e:
            self.logger.error(f"Error getting schema tags: {e}")
            return []

