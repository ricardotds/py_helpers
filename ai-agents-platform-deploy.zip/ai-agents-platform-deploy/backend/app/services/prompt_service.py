"""
Prompt service for managing prompt operations
"""

from typing import Optional, List, Dict, Any
from datetime import datetime

from app.database.repository import BaseRepository
from app.models.prompt import Prompt, PromptCreate, PromptUpdate
from app.models.user import User
from app.auth.dependencies import PermissionChecker
from app.core.logging import LoggerMixin


class PromptService(LoggerMixin):
    """Service for prompt management operations"""
    
    def __init__(self):
        self.repository = BaseRepository("prompts", Prompt)
    
    async def create_prompt(self, prompt_data: PromptCreate, owner_id: str) -> Prompt:
        """Create a new prompt"""
        try:
            # Check if prompt with same name exists for this owner
            existing_prompt = await self.repository.get_by_field("name", prompt_data.name)
            if existing_prompt and existing_prompt.owner_id == owner_id:
                raise ValueError(f"Prompt with name '{prompt_data.name}' already exists")
            
            # Create prompt document
            prompt_dict = prompt_data.dict()
            prompt_dict["owner_id"] = owner_id
            
            prompt = await self.repository.create(prompt_dict)
            
            self.logger.info(f"Created prompt: {prompt.name} by user {owner_id}")
            return prompt
            
        except ValueError:
            raise
        except Exception as e:
            self.logger.error(f"Error creating prompt: {e}")
            raise
    
    async def get_prompt(self, prompt_id: str, user: User) -> Optional[Prompt]:
        """Get prompt by ID with permission check"""
        try:
            prompt = await self.repository.get_by_id(prompt_id)
            if not prompt:
                return None
            
            # Check permissions
            if not PermissionChecker.check_resource_permission(
                user=user,
                resource_owner_id=prompt.owner_id,
                shared_with_users=prompt.share_settings.shared_with_users,
                shared_with_groups=prompt.share_settings.shared_with_groups,
                is_public=prompt.share_settings.is_public
            ):
                return None
            
            return prompt
            
        except Exception as e:
            self.logger.error(f"Error getting prompt {prompt_id}: {e}")
            return None
    
    async def update_prompt(self, prompt_id: str, prompt_data: PromptUpdate, user: User) -> Optional[Prompt]:
        """Update prompt with permission check"""
        try:
            # Get existing prompt
            existing_prompt = await self.repository.get_by_id(prompt_id)
            if not existing_prompt:
                return None
            
            # Check permissions (owner or write access)
            PermissionChecker.ensure_resource_access(
                user=user,
                resource_owner_id=existing_prompt.owner_id,
                shared_with_users=existing_prompt.share_settings.shared_with_users,
                shared_with_groups=existing_prompt.share_settings.shared_with_groups,
                is_public=existing_prompt.share_settings.is_public,
                required_permission="write"
            )
            
            # Prepare update data
            update_dict = prompt_data.dict(exclude_unset=True)
            
            # Update usage count if prompt is being used
            if "last_used" in update_dict:
                update_dict["usage_count"] = existing_prompt.usage_count + 1
            
            updated_prompt = await self.repository.update(prompt_id, update_dict)
            
            if updated_prompt:
                self.logger.info(f"Updated prompt: {updated_prompt.name}")
            
            return updated_prompt
            
        except Exception as e:
            self.logger.error(f"Error updating prompt {prompt_id}: {e}")
            return None
    
    async def delete_prompt(self, prompt_id: str, user: User) -> bool:
        """Delete prompt with permission check"""
        try:
            prompt = await self.repository.get_by_id(prompt_id)
            if not prompt:
                return False
            
            # Check permissions (owner only)
            PermissionChecker.ensure_resource_access(
                user=user,
                resource_owner_id=prompt.owner_id,
                required_permission="admin"
            )
            
            success = await self.repository.delete(prompt_id)
            
            if success:
                self.logger.info(f"Deleted prompt: {prompt.name}")
            
            return success
            
        except Exception as e:
            self.logger.error(f"Error deleting prompt {prompt_id}: {e}")
            return False
    
    async def list_prompts(
        self,
        user: User,
        skip: int = 0,
        limit: int = 100,
        search: Optional[str] = None,
        category: Optional[str] = None,
        tags: Optional[List[str]] = None,
        owner_only: bool = False
    ) -> List[Prompt]:
        """List prompts accessible to user"""
        try:
            filter_dict = {}
            
            if category:
                filter_dict["category"] = category
            
            if tags:
                filter_dict["tags"] = {"$in": tags}
            
            if owner_only:
                filter_dict["owner_id"] = str(user.id)
            
            if search:
                prompts = await self.repository.search(
                    search_term=search,
                    search_fields=["name", "description", "user_prompt"],
                    filter_dict=filter_dict,
                    skip=skip,
                    limit=limit
                )
            else:
                prompts = await self.repository.list(
                    filter_dict=filter_dict,
                    skip=skip,
                    limit=limit,
                    sort_by="updated_at",
                    sort_order=-1
                )
            
            # Filter by permissions
            accessible_prompts = []
            for prompt in prompts:
                if PermissionChecker.check_resource_permission(
                    user=user,
                    resource_owner_id=prompt.owner_id,
                    shared_with_users=prompt.share_settings.shared_with_users,
                    shared_with_groups=prompt.share_settings.shared_with_groups,
                    is_public=prompt.share_settings.is_public
                ):
                    accessible_prompts.append(prompt)
            
            return accessible_prompts
            
        except Exception as e:
            self.logger.error(f"Error listing prompts: {e}")
            return []
    
    async def count_prompts(
        self,
        user: User,
        category: Optional[str] = None,
        tags: Optional[List[str]] = None,
        owner_only: bool = False
    ) -> int:
        """Count prompts accessible to user"""
        try:
            filter_dict = {}
            
            if category:
                filter_dict["category"] = category
            
            if tags:
                filter_dict["tags"] = {"$in": tags}
            
            if owner_only:
                filter_dict["owner_id"] = str(user.id)
            
            # For simplicity, get all matching prompts and filter by permissions
            # In production, this should be optimized with database-level filtering
            prompts = await self.repository.list(filter_dict=filter_dict)
            
            accessible_count = 0
            for prompt in prompts:
                if PermissionChecker.check_resource_permission(
                    user=user,
                    resource_owner_id=prompt.owner_id,
                    shared_with_users=prompt.share_settings.shared_with_users,
                    shared_with_groups=prompt.share_settings.shared_with_groups,
                    is_public=prompt.share_settings.is_public
                ):
                    accessible_count += 1
            
            return accessible_count
            
        except Exception as e:
            self.logger.error(f"Error counting prompts: {e}")
            return 0
    
    async def render_prompt(self, prompt_id: str, variables: Dict[str, Any], user: User) -> str:
        """Render prompt with variables"""
        try:
            prompt = await self.get_prompt(prompt_id, user)
            if not prompt:
                raise ValueError("Prompt not found or access denied")
            
            # Simple template rendering (in production, use a proper template engine)
            rendered_prompt = prompt.user_prompt
            for var_name, var_value in variables.items():
                placeholder = "{" + var_name + "}"
                rendered_prompt = rendered_prompt.replace(placeholder, str(var_value))
            
            # Update usage statistics
            await self.update_prompt(
                prompt_id,
                PromptUpdate(last_used=datetime.utcnow().isoformat()),
                user
            )
            
            return rendered_prompt
            
        except Exception as e:
            self.logger.error(f"Error rendering prompt {prompt_id}: {e}")
            raise
    
    async def get_prompt_categories(self, user: User) -> List[str]:
        """Get list of prompt categories accessible to user"""
        try:
            # Get all prompts accessible to user
            prompts = await self.list_prompts(user, limit=1000)
            
            # Extract unique categories
            categories = set()
            for prompt in prompts:
                if prompt.category:
                    categories.add(prompt.category)
            
            return sorted(list(categories))
            
        except Exception as e:
            self.logger.error(f"Error getting prompt categories: {e}")
            return []
    
    async def get_prompt_tags(self, user: User) -> List[str]:
        """Get list of prompt tags accessible to user"""
        try:
            # Get all prompts accessible to user
            prompts = await self.list_prompts(user, limit=1000)
            
            # Extract unique tags
            tags = set()
            for prompt in prompts:
                tags.update(prompt.tags)
            
            return sorted(list(tags))
            
        except Exception as e:
            self.logger.error(f"Error getting prompt tags: {e}")
            return []

