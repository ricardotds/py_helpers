"""
Tool service for managing tool operations
"""

from typing import Optional, List, Dict, Any
from datetime import datetime

from app.database.repository import BaseRepository
from app.models.tool import Tool, ToolCreate, ToolUpdate
from app.models.user import User
from app.auth.dependencies import PermissionChecker
from app.core.logging import LoggerMixin


class ToolService(LoggerMixin):
    """Service for tool management operations"""
    
    def __init__(self):
        self.repository = BaseRepository("tools", Tool)
    
    async def create_tool(self, tool_data: ToolCreate, owner_id: str) -> Tool:
        """Create a new tool"""
        try:
            # Check if tool with same name exists for this owner
            existing_tool = await self.repository.get_by_field("name", tool_data.name)
            if existing_tool and existing_tool.owner_id == owner_id:
                raise ValueError(f"Tool with name '{tool_data.name}' already exists")
            
            # Validate tool configuration based on type
            validation_errors = await self._validate_tool_configuration(tool_data)
            if validation_errors:
                raise ValueError(f"Tool configuration errors: {', '.join(validation_errors)}")
            
            # Create tool document
            tool_dict = tool_data.dict()
            tool_dict["owner_id"] = owner_id
            
            tool = await self.repository.create(tool_dict)
            
            self.logger.info(f"Created tool: {tool.name} by user {owner_id}")
            return tool
            
        except ValueError:
            raise
        except Exception as e:
            self.logger.error(f"Error creating tool: {e}")
            raise
    
    async def get_tool(self, tool_id: str, user: User) -> Optional[Tool]:
        """Get tool by ID with permission check"""
        try:
            tool = await self.repository.get_by_id(tool_id)
            if not tool:
                return None
            
            # Check permissions
            if not PermissionChecker.check_resource_permission(
                user=user,
                resource_owner_id=tool.owner_id,
                shared_with_users=tool.share_settings.shared_with_users,
                shared_with_groups=tool.share_settings.shared_with_groups,
                is_public=tool.share_settings.is_public
            ):
                return None
            
            return tool
            
        except Exception as e:
            self.logger.error(f"Error getting tool {tool_id}: {e}")
            return None
    
    async def update_tool(self, tool_id: str, tool_data: ToolUpdate, user: User) -> Optional[Tool]:
        """Update tool with permission check"""
        try:
            # Get existing tool
            existing_tool = await self.repository.get_by_id(tool_id)
            if not existing_tool:
                return None
            
            # Check permissions (owner or write access)
            PermissionChecker.ensure_resource_access(
                user=user,
                resource_owner_id=existing_tool.owner_id,
                shared_with_users=existing_tool.share_settings.shared_with_users,
                shared_with_groups=existing_tool.share_settings.shared_with_groups,
                is_public=existing_tool.share_settings.is_public,
                required_permission="write"
            )
            
            # Prepare update data
            update_dict = tool_data.dict(exclude_unset=True)
            
            # Validate tool configuration if changed
            if "configuration" in update_dict or "tool_type" in update_dict:
                # Create a temporary tool object for validation
                temp_tool_data = ToolCreate(
                    name=update_dict.get("name", existing_tool.name),
                    description=update_dict.get("description", existing_tool.description),
                    tool_type=update_dict.get("tool_type", existing_tool.tool_type),
                    version=update_dict.get("version", existing_tool.version),
                    configuration=update_dict.get("configuration", existing_tool.configuration),
                    input_schema=update_dict.get("input_schema", existing_tool.input_schema),
                    output_schema=update_dict.get("output_schema", existing_tool.output_schema),
                    tags=update_dict.get("tags", existing_tool.tags),
                    category=update_dict.get("category", existing_tool.category)
                )
                
                validation_errors = await self._validate_tool_configuration(temp_tool_data)
                if validation_errors:
                    raise ValueError(f"Tool configuration errors: {', '.join(validation_errors)}")
            
            # Update usage count if tool is being used
            if "last_used" in update_dict:
                update_dict["usage_count"] = existing_tool.usage_count + 1
            
            updated_tool = await self.repository.update(tool_id, update_dict)
            
            if updated_tool:
                self.logger.info(f"Updated tool: {updated_tool.name}")
            
            return updated_tool
            
        except ValueError:
            raise
        except Exception as e:
            self.logger.error(f"Error updating tool {tool_id}: {e}")
            return None
    
    async def delete_tool(self, tool_id: str, user: User) -> bool:
        """Delete tool with permission check"""
        try:
            tool = await self.repository.get_by_id(tool_id)
            if not tool:
                return False
            
            # Check permissions (owner only)
            PermissionChecker.ensure_resource_access(
                user=user,
                resource_owner_id=tool.owner_id,
                required_permission="admin"
            )
            
            success = await self.repository.delete(tool_id)
            
            if success:
                self.logger.info(f"Deleted tool: {tool.name}")
            
            return success
            
        except Exception as e:
            self.logger.error(f"Error deleting tool {tool_id}: {e}")
            return False
    
    async def list_tools(
        self,
        user: User,
        skip: int = 0,
        limit: int = 100,
        search: Optional[str] = None,
        tool_type: Optional[str] = None,
        category: Optional[str] = None,
        tags: Optional[List[str]] = None,
        owner_only: bool = False
    ) -> List[Tool]:
        """List tools accessible to user"""
        try:
            filter_dict = {}
            
            if tool_type:
                filter_dict["tool_type"] = tool_type
            
            if category:
                filter_dict["category"] = category
            
            if tags:
                filter_dict["tags"] = {"$in": tags}
            
            if owner_only:
                filter_dict["owner_id"] = str(user.id)
            
            if search:
                tools = await self.repository.search(
                    search_term=search,
                    search_fields=["name", "description"],
                    filter_dict=filter_dict,
                    skip=skip,
                    limit=limit
                )
            else:
                tools = await self.repository.list(
                    filter_dict=filter_dict,
                    skip=skip,
                    limit=limit,
                    sort_by="updated_at",
                    sort_order=-1
                )
            
            # Filter by permissions
            accessible_tools = []
            for tool in tools:
                if PermissionChecker.check_resource_permission(
                    user=user,
                    resource_owner_id=tool.owner_id,
                    shared_with_users=tool.share_settings.shared_with_users,
                    shared_with_groups=tool.share_settings.shared_with_groups,
                    is_public=tool.share_settings.is_public
                ):
                    accessible_tools.append(tool)
            
            return accessible_tools
            
        except Exception as e:
            self.logger.error(f"Error listing tools: {e}")
            return []
    
    async def count_tools(
        self,
        user: User,
        tool_type: Optional[str] = None,
        category: Optional[str] = None,
        tags: Optional[List[str]] = None,
        owner_only: bool = False
    ) -> int:
        """Count tools accessible to user"""
        try:
            filter_dict = {}
            
            if tool_type:
                filter_dict["tool_type"] = tool_type
            
            if category:
                filter_dict["category"] = category
            
            if tags:
                filter_dict["tags"] = {"$in": tags}
            
            if owner_only:
                filter_dict["owner_id"] = str(user.id)
            
            # For simplicity, get all matching tools and filter by permissions
            tools = await self.repository.list(filter_dict=filter_dict)
            
            accessible_count = 0
            for tool in tools:
                if PermissionChecker.check_resource_permission(
                    user=user,
                    resource_owner_id=tool.owner_id,
                    shared_with_users=tool.share_settings.shared_with_users,
                    shared_with_groups=tool.share_settings.shared_with_groups,
                    is_public=tool.share_settings.is_public
                ):
                    accessible_count += 1
            
            return accessible_count
            
        except Exception as e:
            self.logger.error(f"Error counting tools: {e}")
            return 0
    
    async def _validate_tool_configuration(self, tool_data: ToolCreate) -> List[str]:
        """Validate tool configuration based on tool type"""
        errors = []
        
        try:
            config = tool_data.configuration
            tool_type = tool_data.tool_type
            
            if tool_type == "llm":
                # Validate LLM configuration
                required_fields = ["provider", "model"]
                for field in required_fields:
                    if field not in config:
                        errors.append(f"LLM tool missing required field: {field}")
                
                provider = config.get("provider")
                if provider not in ["azure_openai", "aws_bedrock"]:
                    errors.append(f"Unsupported LLM provider: {provider}")
                
                if provider == "azure_openai":
                    azure_fields = ["endpoint", "api_key", "api_version"]
                    for field in azure_fields:
                        if field not in config:
                            errors.append(f"Azure OpenAI missing required field: {field}")
                
                elif provider == "aws_bedrock":
                    aws_fields = ["region", "access_key_id", "secret_access_key"]
                    for field in aws_fields:
                        if field not in config:
                            errors.append(f"AWS Bedrock missing required field: {field}")
            
            elif tool_type == "api":
                # Validate API configuration
                required_fields = ["url", "method"]
                for field in required_fields:
                    if field not in config:
                        errors.append(f"API tool missing required field: {field}")
                
                method = config.get("method", "").upper()
                if method not in ["GET", "POST", "PUT", "DELETE", "PATCH"]:
                    errors.append(f"Unsupported HTTP method: {method}")
            
            elif tool_type == "rag":
                # Validate RAG configuration
                required_fields = ["rag_index_id"]
                for field in required_fields:
                    if field not in config:
                        errors.append(f"RAG tool missing required field: {field}")
            
            elif tool_type == "python":
                # Validate Python configuration
                required_fields = ["code"]
                for field in required_fields:
                    if field not in config:
                        errors.append(f"Python tool missing required field: {field}")
                
                # Basic Python syntax validation could be added here
                code = config.get("code", "")
                if not code.strip():
                    errors.append("Python tool code cannot be empty")
            
            else:
                errors.append(f"Unsupported tool type: {tool_type}")
            
        except Exception as e:
            errors.append(f"Configuration validation error: {str(e)}")
        
        return errors
    
    async def get_tool_types(self) -> List[str]:
        """Get list of supported tool types"""
        return ["llm", "api", "rag", "python"]
    
    async def get_tool_categories(self, user: User) -> List[str]:
        """Get list of tool categories accessible to user"""
        try:
            # Get all tools accessible to user
            tools = await self.list_tools(user, limit=1000)
            
            # Extract unique categories
            categories = set()
            for tool in tools:
                if tool.category:
                    categories.add(tool.category)
            
            return sorted(list(categories))
            
        except Exception as e:
            self.logger.error(f"Error getting tool categories: {e}")
            return []
    
    async def get_tool_tags(self, user: User) -> List[str]:
        """Get list of tool tags accessible to user"""
        try:
            # Get all tools accessible to user
            tools = await self.list_tools(user, limit=1000)
            
            # Extract unique tags
            tags = set()
            for tool in tools:
                tags.update(tool.tags)
            
            return sorted(list(tags))
            
        except Exception as e:
            self.logger.error(f"Error getting tool tags: {e}")
            return []

