"""
User service for managing user operations
"""

from typing import Optional, List, Dict, Any
from datetime import datetime

from app.database.repository import BaseRepository
from app.models.user import User, UserCreate, UserUpdate, UserInDB
from app.core.logging import LoggerMixin


class UserService(LoggerMixin):
    """Service for user management operations"""
    
    def __init__(self):
        self.repository = BaseRepository("users", User)
    
    async def create_user(self, user_data: UserCreate) -> User:
        """Create a new user"""
        try:
            # Check if user already exists
            existing_user = await self.get_by_email(user_data.email)
            if existing_user:
                raise ValueError(f"User with email {user_data.email} already exists")
            
            existing_user_by_azure_id = await self.get_by_azure_object_id(user_data.azure_object_id)
            if existing_user_by_azure_id:
                raise ValueError(f"User with Azure Object ID {user_data.azure_object_id} already exists")
            
            # Create user document
            user_dict = user_data.dict()
            user = await self.repository.create(user_dict)
            
            self.logger.info(f"Created user: {user.email}")
            return user
            
        except ValueError:
            raise
        except Exception as e:
            self.logger.error(f"Error creating user: {e}")
            raise
    
    async def get_user(self, user_id: str) -> Optional[User]:
        """Get user by ID"""
        return await self.repository.get_by_id(user_id)
    
    async def get_by_email(self, email: str) -> Optional[User]:
        """Get user by email"""
        return await self.repository.get_by_field("email", email)
    
    async def get_by_azure_object_id(self, azure_object_id: str) -> Optional[User]:
        """Get user by Azure Object ID"""
        return await self.repository.get_by_field("azure_object_id", azure_object_id)
    
    async def update_user(self, user_id: str, user_data: UserUpdate) -> Optional[User]:
        """Update user"""
        try:
            # Get existing user
            existing_user = await self.repository.get_by_id(user_id)
            if not existing_user:
                return None
            
            # Prepare update data
            update_dict = user_data.dict(exclude_unset=True)
            
            # Update user
            updated_user = await self.repository.update(user_id, update_dict)
            
            if updated_user:
                self.logger.info(f"Updated user: {updated_user.email}")
            
            return updated_user
            
        except Exception as e:
            self.logger.error(f"Error updating user {user_id}: {e}")
            return None
    
    async def delete_user(self, user_id: str) -> bool:
        """Delete user"""
        try:
            user = await self.repository.get_by_id(user_id)
            if not user:
                return False
            
            success = await self.repository.delete(user_id)
            
            if success:
                self.logger.info(f"Deleted user: {user.email}")
            
            return success
            
        except Exception as e:
            self.logger.error(f"Error deleting user {user_id}: {e}")
            return False
    
    async def list_users(
        self,
        skip: int = 0,
        limit: int = 100,
        search: Optional[str] = None,
        is_active: Optional[bool] = None,
        is_admin: Optional[bool] = None
    ) -> List[User]:
        """List users with optional filtering"""
        try:
            filter_dict = {}
            
            if is_active is not None:
                filter_dict["is_active"] = is_active
            
            if is_admin is not None:
                filter_dict["is_admin"] = is_admin
            
            if search:
                # Search in name and email
                users = await self.repository.search(
                    search_term=search,
                    search_fields=["name", "email"],
                    filter_dict=filter_dict,
                    skip=skip,
                    limit=limit
                )
            else:
                users = await self.repository.list(
                    filter_dict=filter_dict,
                    skip=skip,
                    limit=limit,
                    sort_by="created_at",
                    sort_order=-1
                )
            
            return users
            
        except Exception as e:
            self.logger.error(f"Error listing users: {e}")
            return []
    
    async def count_users(
        self,
        is_active: Optional[bool] = None,
        is_admin: Optional[bool] = None
    ) -> int:
        """Count users with optional filtering"""
        try:
            filter_dict = {}
            
            if is_active is not None:
                filter_dict["is_active"] = is_active
            
            if is_admin is not None:
                filter_dict["is_admin"] = is_admin
            
            return await self.repository.count(filter_dict)
            
        except Exception as e:
            self.logger.error(f"Error counting users: {e}")
            return 0
    
    async def update_user_groups(self, user_id: str, groups: List[str]) -> Optional[User]:
        """Update user groups"""
        try:
            update_data = {"groups": groups}
            updated_user = await self.repository.update(user_id, update_data)
            
            if updated_user:
                self.logger.info(f"Updated groups for user {updated_user.email}: {groups}")
            
            return updated_user
            
        except Exception as e:
            self.logger.error(f"Error updating user groups {user_id}: {e}")
            return None
    
    async def activate_user(self, user_id: str) -> Optional[User]:
        """Activate user account"""
        try:
            update_data = {"is_active": True}
            updated_user = await self.repository.update(user_id, update_data)
            
            if updated_user:
                self.logger.info(f"Activated user: {updated_user.email}")
            
            return updated_user
            
        except Exception as e:
            self.logger.error(f"Error activating user {user_id}: {e}")
            return None
    
    async def deactivate_user(self, user_id: str) -> Optional[User]:
        """Deactivate user account"""
        try:
            update_data = {"is_active": False}
            updated_user = await self.repository.update(user_id, update_data)
            
            if updated_user:
                self.logger.info(f"Deactivated user: {updated_user.email}")
            
            return updated_user
            
        except Exception as e:
            self.logger.error(f"Error deactivating user {user_id}: {e}")
            return None
    
    async def make_admin(self, user_id: str) -> Optional[User]:
        """Make user an admin"""
        try:
            update_data = {"is_admin": True}
            updated_user = await self.repository.update(user_id, update_data)
            
            if updated_user:
                self.logger.info(f"Made user admin: {updated_user.email}")
            
            return updated_user
            
        except Exception as e:
            self.logger.error(f"Error making user admin {user_id}: {e}")
            return None
    
    async def remove_admin(self, user_id: str) -> Optional[User]:
        """Remove admin privileges from user"""
        try:
            update_data = {"is_admin": False}
            updated_user = await self.repository.update(user_id, update_data)
            
            if updated_user:
                self.logger.info(f"Removed admin privileges from user: {updated_user.email}")
            
            return updated_user
            
        except Exception as e:
            self.logger.error(f"Error removing admin privileges {user_id}: {e}")
            return None
    
    async def get_or_create_user_from_azure(self, azure_user_data: Dict[str, Any]) -> User:
        """Get existing user or create new user from Azure AD data"""
        try:
            # Try to get existing user by Azure Object ID
            existing_user = await self.get_by_azure_object_id(azure_user_data["id"])
            
            if existing_user:
                # Update user groups if they've changed
                if set(existing_user.groups) != set(azure_user_data.get("groups", [])):
                    await self.update_user_groups(str(existing_user.id), azure_user_data.get("groups", []))
                    existing_user.groups = azure_user_data.get("groups", [])
                
                return existing_user
            
            # Create new user
            user_create = UserCreate(
                email=azure_user_data["email"],
                name=azure_user_data["name"],
                azure_object_id=azure_user_data["id"],
                groups=azure_user_data.get("groups", [])
            )
            
            new_user = await self.create_user(user_create)
            return new_user
            
        except Exception as e:
            self.logger.error(f"Error getting or creating user from Azure data: {e}")
            raise

