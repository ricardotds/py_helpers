"""
Pipeline service for managing pipeline operations
"""

from typing import Optional, List, Dict, Any
from datetime import datetime

from app.database.repository import BaseRepository
from app.models.pipeline import Pipeline, PipelineCreate, PipelineUpdate, PipelineStep
from app.models.user import User
from app.auth.dependencies import PermissionChecker
from app.core.logging import LoggerMixin


class PipelineService(LoggerMixin):
    """Service for pipeline management operations"""
    
    def __init__(self):
        self.repository = BaseRepository("pipelines", Pipeline)
    
    async def create_pipeline(self, pipeline_data: PipelineCreate, owner_id: str) -> Pipeline:
        """Create a new pipeline"""
        try:
            # Check if pipeline with same name exists for this owner
            existing_pipeline = await self.repository.get_by_field("name", pipeline_data.name)
            if existing_pipeline and existing_pipeline.owner_id == owner_id:
                raise ValueError(f"Pipeline with name '{pipeline_data.name}' already exists")
            
            # Validate pipeline structure
            validation_errors = await self._validate_pipeline_structure(pipeline_data)
            
            # Create pipeline document
            pipeline_dict = pipeline_data.dict()
            pipeline_dict["owner_id"] = owner_id
            pipeline_dict["is_validated"] = len(validation_errors) == 0
            pipeline_dict["validation_errors"] = validation_errors
            
            pipeline = await self.repository.create(pipeline_dict)
            
            self.logger.info(f"Created pipeline: {pipeline.name} by user {owner_id}")
            return pipeline
            
        except ValueError:
            raise
        except Exception as e:
            self.logger.error(f"Error creating pipeline: {e}")
            raise
    
    async def get_pipeline(self, pipeline_id: str, user: User) -> Optional[Pipeline]:
        """Get pipeline by ID with permission check"""
        try:
            pipeline = await self.repository.get_by_id(pipeline_id)
            if not pipeline:
                return None
            
            # Check permissions
            if not PermissionChecker.check_resource_permission(
                user=user,
                resource_owner_id=pipeline.owner_id,
                shared_with_users=pipeline.share_settings.shared_with_users,
                shared_with_groups=pipeline.share_settings.shared_with_groups,
                is_public=pipeline.share_settings.is_public
            ):
                return None
            
            return pipeline
            
        except Exception as e:
            self.logger.error(f"Error getting pipeline {pipeline_id}: {e}")
            return None
    
    async def update_pipeline(self, pipeline_id: str, pipeline_data: PipelineUpdate, user: User) -> Optional[Pipeline]:
        """Update pipeline with permission check"""
        try:
            # Get existing pipeline
            existing_pipeline = await self.repository.get_by_id(pipeline_id)
            if not existing_pipeline:
                return None
            
            # Check permissions (owner or write access)
            PermissionChecker.ensure_resource_access(
                user=user,
                resource_owner_id=existing_pipeline.owner_id,
                shared_with_users=existing_pipeline.share_settings.shared_with_users,
                shared_with_groups=existing_pipeline.share_settings.shared_with_groups,
                is_public=existing_pipeline.share_settings.is_public,
                required_permission="write"
            )
            
            # Prepare update data
            update_dict = pipeline_data.dict(exclude_unset=True)
            
            # Re-validate pipeline if structure changed
            if any(key in update_dict for key in ["steps", "inputs", "outputs"]):
                # Create a temporary pipeline object for validation
                temp_pipeline_data = PipelineCreate(
                    name=update_dict.get("name", existing_pipeline.name),
                    description=update_dict.get("description", existing_pipeline.description),
                    version=update_dict.get("version", existing_pipeline.version),
                    inputs=update_dict.get("inputs", existing_pipeline.inputs),
                    outputs=update_dict.get("outputs", existing_pipeline.outputs),
                    steps=update_dict.get("steps", existing_pipeline.steps),
                    tags=update_dict.get("tags", existing_pipeline.tags),
                    category=update_dict.get("category", existing_pipeline.category)
                )
                
                validation_errors = await self._validate_pipeline_structure(temp_pipeline_data)
                update_dict["is_validated"] = len(validation_errors) == 0
                update_dict["validation_errors"] = validation_errors
                
                # Reset deployment status if pipeline structure changed
                if not update_dict["is_validated"]:
                    update_dict["is_deployed"] = False
                    update_dict["airflow_dag_id"] = None
            
            updated_pipeline = await self.repository.update(pipeline_id, update_dict)
            
            if updated_pipeline:
                self.logger.info(f"Updated pipeline: {updated_pipeline.name}")
            
            return updated_pipeline
            
        except Exception as e:
            self.logger.error(f"Error updating pipeline {pipeline_id}: {e}")
            return None
    
    async def delete_pipeline(self, pipeline_id: str, user: User) -> bool:
        """Delete pipeline with permission check"""
        try:
            pipeline = await self.repository.get_by_id(pipeline_id)
            if not pipeline:
                return False
            
            # Check permissions (owner only)
            PermissionChecker.ensure_resource_access(
                user=user,
                resource_owner_id=pipeline.owner_id,
                required_permission="admin"
            )
            
            success = await self.repository.delete(pipeline_id)
            
            if success:
                self.logger.info(f"Deleted pipeline: {pipeline.name}")
            
            return success
            
        except Exception as e:
            self.logger.error(f"Error deleting pipeline {pipeline_id}: {e}")
            return False
    
    async def list_pipelines(
        self,
        user: User,
        skip: int = 0,
        limit: int = 100,
        search: Optional[str] = None,
        category: Optional[str] = None,
        tags: Optional[List[str]] = None,
        owner_only: bool = False,
        validated_only: bool = False
    ) -> List[Pipeline]:
        """List pipelines accessible to user"""
        try:
            filter_dict = {}
            
            if category:
                filter_dict["category"] = category
            
            if tags:
                filter_dict["tags"] = {"$in": tags}
            
            if owner_only:
                filter_dict["owner_id"] = str(user.id)
            
            if validated_only:
                filter_dict["is_validated"] = True
            
            if search:
                pipelines = await self.repository.search(
                    search_term=search,
                    search_fields=["name", "description"],
                    filter_dict=filter_dict,
                    skip=skip,
                    limit=limit
                )
            else:
                pipelines = await self.repository.list(
                    filter_dict=filter_dict,
                    skip=skip,
                    limit=limit,
                    sort_by="updated_at",
                    sort_order=-1
                )
            
            # Filter by permissions
            accessible_pipelines = []
            for pipeline in pipelines:
                if PermissionChecker.check_resource_permission(
                    user=user,
                    resource_owner_id=pipeline.owner_id,
                    shared_with_users=pipeline.share_settings.shared_with_users,
                    shared_with_groups=pipeline.share_settings.shared_with_groups,
                    is_public=pipeline.share_settings.is_public
                ):
                    accessible_pipelines.append(pipeline)
            
            return accessible_pipelines
            
        except Exception as e:
            self.logger.error(f"Error listing pipelines: {e}")
            return []
    
    async def count_pipelines(
        self,
        user: User,
        category: Optional[str] = None,
        tags: Optional[List[str]] = None,
        owner_only: bool = False,
        validated_only: bool = False
    ) -> int:
        """Count pipelines accessible to user"""
        try:
            filter_dict = {}
            
            if category:
                filter_dict["category"] = category
            
            if tags:
                filter_dict["tags"] = {"$in": tags}
            
            if owner_only:
                filter_dict["owner_id"] = str(user.id)
            
            if validated_only:
                filter_dict["is_validated"] = True
            
            # For simplicity, get all matching pipelines and filter by permissions
            pipelines = await self.repository.list(filter_dict=filter_dict)
            
            accessible_count = 0
            for pipeline in pipelines:
                if PermissionChecker.check_resource_permission(
                    user=user,
                    resource_owner_id=pipeline.owner_id,
                    shared_with_users=pipeline.share_settings.shared_with_users,
                    shared_with_groups=pipeline.share_settings.shared_with_groups,
                    is_public=pipeline.share_settings.is_public
                ):
                    accessible_count += 1
            
            return accessible_count
            
        except Exception as e:
            self.logger.error(f"Error counting pipelines: {e}")
            return 0
    
    async def _validate_pipeline_structure(self, pipeline_data: PipelineCreate) -> List[str]:
        """Validate pipeline structure and return list of errors"""
        errors = []
        
        try:
            # Check if there are steps
            if not pipeline_data.steps:
                errors.append("Pipeline must have at least one step")
                return errors
            
            # Check step dependencies
            step_ids = {step.id for step in pipeline_data.steps}
            
            for step in pipeline_data.steps:
                # Check if dependencies exist
                for dep_id in step.depends_on:
                    if dep_id not in step_ids:
                        errors.append(f"Step '{step.id}' depends on non-existent step '{dep_id}'")
                
                # Check for circular dependencies (simplified check)
                if step.id in step.depends_on:
                    errors.append(f"Step '{step.id}' cannot depend on itself")
            
            # Check pipeline outputs
            for output in pipeline_data.outputs:
                if output.source_step not in step_ids:
                    errors.append(f"Output '{output.name}' references non-existent step '{output.source_step}'")
                
                # Check if source step has the required output
                source_step = next((s for s in pipeline_data.steps if s.id == output.source_step), None)
                if source_step and output.source_output not in source_step.outputs:
                    errors.append(f"Output '{output.name}' references non-existent output '{output.source_output}' from step '{output.source_step}'")
            
            # Check for orphaned steps (steps with no path to outputs)
            output_steps = {output.source_step for output in pipeline_data.outputs}
            reachable_steps = set(output_steps)
            
            # Find all steps that lead to output steps
            changed = True
            while changed:
                changed = False
                for step in pipeline_data.steps:
                    if step.id not in reachable_steps:
                        # Check if any of this step's dependents are reachable
                        dependents = [s for s in pipeline_data.steps if step.id in s.depends_on]
                        if any(dep.id in reachable_steps for dep in dependents):
                            reachable_steps.add(step.id)
                            changed = True
            
            # Report orphaned steps
            for step in pipeline_data.steps:
                if step.id not in reachable_steps:
                    errors.append(f"Step '{step.id}' is not connected to any pipeline output")
            
        except Exception as e:
            errors.append(f"Validation error: {str(e)}")
        
        return errors
    
    async def get_pipeline_categories(self, user: User) -> List[str]:
        """Get list of pipeline categories accessible to user"""
        try:
            # Get all pipelines accessible to user
            pipelines = await self.list_pipelines(user, limit=1000)
            
            # Extract unique categories
            categories = set()
            for pipeline in pipelines:
                if pipeline.category:
                    categories.add(pipeline.category)
            
            return sorted(list(categories))
            
        except Exception as e:
            self.logger.error(f"Error getting pipeline categories: {e}")
            return []
    
    async def get_pipeline_tags(self, user: User) -> List[str]:
        """Get list of pipeline tags accessible to user"""
        try:
            # Get all pipelines accessible to user
            pipelines = await self.list_pipelines(user, limit=1000)
            
            # Extract unique tags
            tags = set()
            for pipeline in pipelines:
                tags.update(pipeline.tags)
            
            return sorted(list(tags))
            
        except Exception as e:
            self.logger.error(f"Error getting pipeline tags: {e}")
            return []




pipeline_service = PipelineService()

