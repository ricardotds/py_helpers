"""
Pipeline execution service for running pipelines
"""

import asyncio
import uuid
from typing import Dict, Any, List, Optional
from datetime import datetime
from enum import Enum

from app.database.repository import BaseRepository
from app.models.pipeline import Pipeline
from app.models.user import User
from app.services.pipeline_service import PipelineService
from app.services.tool_service import ToolService
from app.core.logging import LoggerMixin
from app.core.websocket_manager import websocket_manager


class ExecutionStatus(str, Enum):
    """Execution status enumeration"""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class StepStatus(str, Enum):
    """Step execution status enumeration"""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"


class ExecutionResult:
    """Execution result container"""
    def __init__(self, execution_id: str):
        self.execution_id = execution_id
        self.status = ExecutionStatus.PENDING
        self.pipeline_id: Optional[str] = None
        self.user_id: Optional[str] = None
        self.inputs: Dict[str, Any] = {}
        self.outputs: Dict[str, Any] = {}
        self.step_results: Dict[str, Dict[str, Any]] = {}
        self.step_status: Dict[str, StepStatus] = {}
        self.error_message: Optional[str] = None
        self.start_time: Optional[datetime] = None
        self.end_time: Optional[datetime] = None
        self.logs: List[str] = []


class ExecutionService(LoggerMixin):
    """Service for pipeline execution operations"""
    
    def __init__(self):
        self.pipeline_service = PipelineService()
        self.tool_service = ToolService()
        self.websocket_manager = websocket_manager
        self.active_executions: Dict[str, ExecutionResult] = {}
        
        # Import tool executors
        from app.tools.llm_executor import LLMExecutor
        from app.tools.api_executor import APIExecutor
        from app.tools.rag_executor import RAGExecutor
        from app.tools.python_executor import PythonExecutor
        
        self.tool_executors = {
            "llm": LLMExecutor(),
            "api": APIExecutor(),
            "rag": RAGExecutor(),
            "python": PythonExecutor()
        }
    
    async def execute_pipeline(
        self, 
        pipeline_id: str, 
        inputs: Dict[str, Any], 
        user: User
    ) -> str:
        """Execute a pipeline and return execution ID"""
        try:
            # Get pipeline
            pipeline = await self.pipeline_service.get_pipeline(pipeline_id, user)
            if not pipeline:
                raise ValueError("Pipeline not found or access denied")
            
            if not pipeline.is_validated:
                raise ValueError("Pipeline is not validated")
            
            # Create execution ID
            execution_id = str(uuid.uuid4())
            
            # Initialize execution result
            execution_result = ExecutionResult(execution_id)
            execution_result.pipeline_id = pipeline_id
            execution_result.user_id = str(user.id)
            execution_result.inputs = inputs
            execution_result.start_time = datetime.utcnow()
            
            # Initialize step status
            for step in pipeline.steps:
                execution_result.step_status[step.id] = StepStatus.PENDING
                execution_result.step_results[step.id] = {}
            
            # Store execution
            self.active_executions[execution_id] = execution_result
            
            # Start execution in background
            asyncio.create_task(self._execute_pipeline_async(pipeline, execution_result, user))
            
            self.logger.info(f"Started pipeline execution: {execution_id}")
            return execution_id
            
        except Exception as e:
            self.logger.error(f"Error starting pipeline execution: {e}")
            raise
    
    async def _execute_pipeline_async(
        self, 
        pipeline: Pipeline, 
        execution_result: ExecutionResult, 
        user: User
    ):
        """Execute pipeline asynchronously"""
        try:
            execution_result.status = ExecutionStatus.RUNNING
            await self._notify_execution_update(execution_result)
            
            # Build execution graph
            execution_graph = self._build_execution_graph(pipeline)
            
            # Execute steps in dependency order
            completed_steps = set()
            
            while len(completed_steps) < len(pipeline.steps):
                # Find steps that can be executed (all dependencies completed)
                ready_steps = []
                for step in pipeline.steps:
                    if (step.id not in completed_steps and 
                        all(dep in completed_steps for dep in step.depends_on)):
                        ready_steps.append(step)
                
                if not ready_steps:
                    # Check for circular dependencies or other issues
                    remaining_steps = [s.id for s in pipeline.steps if s.id not in completed_steps]
                    raise Exception(f"Cannot execute remaining steps due to unresolved dependencies: {remaining_steps}")
                
                # Execute ready steps in parallel
                tasks = []
                for step in ready_steps:
                    task = asyncio.create_task(
                        self._execute_step(step, execution_result, user)
                    )
                    tasks.append((step.id, task))
                
                # Wait for all tasks to complete
                for step_id, task in tasks:
                    try:
                        await task
                        completed_steps.add(step_id)
                        execution_result.step_status[step_id] = StepStatus.COMPLETED
                    except Exception as e:
                        execution_result.step_status[step_id] = StepStatus.FAILED
                        execution_result.error_message = f"Step {step_id} failed: {str(e)}"
                        execution_result.status = ExecutionStatus.FAILED
                        execution_result.end_time = datetime.utcnow()
                        await self._notify_execution_update(execution_result)
                        return
                
                await self._notify_execution_update(execution_result)
            
            # Extract pipeline outputs
            execution_result.outputs = self._extract_pipeline_outputs(pipeline, execution_result)
            
            # Mark execution as completed
            execution_result.status = ExecutionStatus.COMPLETED
            execution_result.end_time = datetime.utcnow()
            await self._notify_execution_update(execution_result)
            
            self.logger.info(f"Pipeline execution completed: {execution_result.execution_id}")
            
        except Exception as e:
            execution_result.status = ExecutionStatus.FAILED
            execution_result.error_message = str(e)
            execution_result.end_time = datetime.utcnow()
            await self._notify_execution_update(execution_result)
            self.logger.error(f"Pipeline execution failed: {execution_result.execution_id}: {e}")
    
    async def _execute_step(
        self, 
        step, 
        execution_result: ExecutionResult, 
        user: User
    ):
        """Execute a single pipeline step"""
        try:
            execution_result.step_status[step.id] = StepStatus.RUNNING
            await self._notify_execution_update(execution_result)
            
            # Get tool for this step
            tool = await self.tool_service.get_tool(step.tool_id, user)
            if not tool:
                raise Exception(f"Tool not found: {step.tool_id}")
            
            # Get tool executor
            executor = self.tool_executors.get(tool.tool_type)
            if not executor:
                raise Exception(f"No executor found for tool type: {tool.tool_type}")
            
            # Prepare step inputs
            step_inputs = self._prepare_step_inputs(step, execution_result)
            
            # Execute tool
            step_outputs = await executor.execute(tool, step_inputs, step.configuration)
            
            # Store step results
            execution_result.step_results[step.id] = {
                "inputs": step_inputs,
                "outputs": step_outputs,
                "tool_id": step.tool_id,
                "tool_type": tool.tool_type
            }
            
            self.logger.info(f"Step {step.id} completed successfully")
            
        except Exception as e:
            self.logger.error(f"Step {step.id} failed: {e}")
            raise
    
    def _prepare_step_inputs(self, step, execution_result: ExecutionResult) -> Dict[str, Any]:
        """Prepare inputs for a step based on its input mappings"""
        step_inputs = {}
        
        for input_mapping in step.inputs:
            input_name = input_mapping.name
            
            if input_mapping.source_type == "pipeline_input":
                # Get from pipeline inputs
                if input_mapping.source in execution_result.inputs:
                    step_inputs[input_name] = execution_result.inputs[input_mapping.source]
                else:
                    raise Exception(f"Pipeline input not found: {input_mapping.source}")
            
            elif input_mapping.source_type == "step_output":
                # Get from previous step output
                source_step, source_output = input_mapping.source.split(".", 1)
                if (source_step in execution_result.step_results and 
                    source_output in execution_result.step_results[source_step]["outputs"]):
                    step_inputs[input_name] = execution_result.step_results[source_step]["outputs"][source_output]
                else:
                    raise Exception(f"Step output not found: {input_mapping.source}")
            
            elif input_mapping.source_type == "constant":
                # Use constant value
                step_inputs[input_name] = input_mapping.value
            
            else:
                raise Exception(f"Unknown input source type: {input_mapping.source_type}")
        
        return step_inputs
    
    def _extract_pipeline_outputs(self, pipeline: Pipeline, execution_result: ExecutionResult) -> Dict[str, Any]:
        """Extract pipeline outputs from step results"""
        outputs = {}
        
        for output_mapping in pipeline.outputs:
            source_step = output_mapping.source_step
            source_output = output_mapping.source_output
            
            if (source_step in execution_result.step_results and 
                source_output in execution_result.step_results[source_step]["outputs"]):
                outputs[output_mapping.name] = execution_result.step_results[source_step]["outputs"][source_output]
            else:
                self.logger.warning(f"Pipeline output not found: {output_mapping.name}")
        
        return outputs
    
    def _build_execution_graph(self, pipeline: Pipeline) -> Dict[str, List[str]]:
        """Build execution dependency graph"""
        graph = {}
        for step in pipeline.steps:
            graph[step.id] = step.depends_on.copy()
        return graph
    
    async def _notify_execution_update(self, execution_result: ExecutionResult):
        """Notify WebSocket clients about execution updates"""
        try:
            update_data = {
                "type": "execution_update",
                "execution_id": execution_result.execution_id,
                "status": execution_result.status,
                "step_status": {k: v.value for k, v in execution_result.step_status.items()},
                "outputs": execution_result.outputs,
                "error_message": execution_result.error_message,
                "timestamp": datetime.utcnow().isoformat()
            }
            
            # Send to execution-specific subscribers
            await self.websocket_manager.broadcast_to_topic(
                f"execution_{execution_result.execution_id}",
                update_data
            )
            
            # Also send to user
            await self.websocket_manager.send_to_user(
                update_data,
                execution_result.user_id
            )
            
        except Exception as e:
            self.logger.error(f"Error notifying execution update: {e}")
    
    async def get_execution_status(self, execution_id: str, user: User) -> Optional[ExecutionResult]:
        """Get execution status"""
        try:
            if execution_id not in self.active_executions:
                return None
            
            execution_result = self.active_executions[execution_id]
            
            # Check if user has access to this execution
            if execution_result.user_id != str(user.id) and not user.is_admin:
                return None
            
            return execution_result
            
        except Exception as e:
            self.logger.error(f"Error getting execution status: {e}")
            return None
    
    async def cancel_execution(self, execution_id: str, user: User) -> bool:
        """Cancel a running execution"""
        try:
            if execution_id not in self.active_executions:
                return False
            
            execution_result = self.active_executions[execution_id]
            
            # Check if user has access to this execution
            if execution_result.user_id != str(user.id) and not user.is_admin:
                return False
            
            if execution_result.status in [ExecutionStatus.COMPLETED, ExecutionStatus.FAILED, ExecutionStatus.CANCELLED]:
                return False
            
            execution_result.status = ExecutionStatus.CANCELLED
            execution_result.end_time = datetime.utcnow()
            await self._notify_execution_update(execution_result)
            
            self.logger.info(f"Execution cancelled: {execution_id}")
            return True
            
        except Exception as e:
            self.logger.error(f"Error cancelling execution: {e}")
            return False
    
    async def list_executions(self, user: User, limit: int = 100) -> List[ExecutionResult]:
        """List executions for user"""
        try:
            user_executions = []
            
            for execution_result in self.active_executions.values():
                if execution_result.user_id == str(user.id) or user.is_admin:
                    user_executions.append(execution_result)
            
            # Sort by start time (most recent first)
            user_executions.sort(
                key=lambda x: x.start_time or datetime.min, 
                reverse=True
            )
            
            return user_executions[:limit]
            
        except Exception as e:
            self.logger.error(f"Error listing executions: {e}")
            return []

