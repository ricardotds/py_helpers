"""
Airflow integration service for pipeline deployment and management
"""

import os
import json
import yaml
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional
from jinja2 import Template
from app.core.logging import LoggerMixin
from app.models.pipeline import Pipeline
from app.models.user import User


class AirflowService(LoggerMixin):
    """Service for Airflow integration and pipeline deployment"""
    
    def __init__(self):
        self.airflow_dags_path = os.getenv("AIRFLOW_DAGS_PATH", "/opt/airflow/dags")
        self.k8s_namespace = os.getenv("K8S_NAMESPACE", "ai-agents-platform")
        self.k8s_execution_namespace = os.getenv("K8S_EXECUTION_NAMESPACE", "pipeline-execution")
        
        self.logger.info("Airflow service initialized")
    
    async def deploy_pipeline_to_airflow(
        self,
        pipeline: Pipeline,
        user: User,
        schedule_interval: Optional[str] = None,
        start_date: Optional[datetime] = None
    ) -> Dict[str, Any]:
        """Deploy a validated pipeline to Airflow as a DAG"""
        try:
            if not pipeline.is_validated:
                raise ValueError("Pipeline must be validated before deployment")
            
            # Generate DAG ID
            dag_id = f"pipeline_{pipeline.id}_{user.id}"
            
            # Generate DAG Python file
            dag_content = self._generate_dag_content(
                pipeline=pipeline,
                user=user,
                dag_id=dag_id,
                schedule_interval=schedule_interval,
                start_date=start_date or datetime.utcnow()
            )
            
            # Write DAG file
            dag_file_path = os.path.join(self.airflow_dags_path, f"{dag_id}.py")
            with open(dag_file_path, 'w') as f:
                f.write(dag_content)
            
            # Generate Kubernetes manifests for pipeline execution
            k8s_manifests = self._generate_k8s_manifests(pipeline, user, dag_id)
            
            # Save manifests
            manifests_dir = os.path.join(self.airflow_dags_path, "k8s_manifests", dag_id)
            os.makedirs(manifests_dir, exist_ok=True)
            
            for manifest_name, manifest_content in k8s_manifests.items():
                manifest_path = os.path.join(manifests_dir, f"{manifest_name}.yaml")
                with open(manifest_path, 'w') as f:
                    yaml.dump(manifest_content, f, default_flow_style=False)
            
            deployment_info = {
                "dag_id": dag_id,
                "dag_file_path": dag_file_path,
                "manifests_dir": manifests_dir,
                "schedule_interval": schedule_interval,
                "start_date": start_date.isoformat() if start_date else None,
                "deployed_at": datetime.utcnow().isoformat(),
                "status": "deployed"
            }
            
            self.logger.info(f"Pipeline {pipeline.id} deployed to Airflow as DAG {dag_id}")
            return deployment_info
            
        except Exception as e:
            self.logger.error(f"Error deploying pipeline to Airflow: {e}")
            raise
    
    def _generate_dag_content(
        self,
        pipeline: Pipeline,
        user: User,
        dag_id: str,
        schedule_interval: Optional[str],
        start_date: datetime
    ) -> str:
        """Generate Airflow DAG Python content"""
        
        dag_template = Template("""
from datetime import datetime, timedelta
from airflow import DAG
from airflow.providers.kubernetes.operators.kubernetes_pod import KubernetesPodOperator
from airflow.operators.python import PythonOperator
from airflow.operators.dummy import DummyOperator
import json

# DAG configuration
default_args = {
    'owner': '{{ user_email }}',
    'depends_on_past': False,
    'start_date': datetime({{ start_year }}, {{ start_month }}, {{ start_day }}),
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
    'email': ['{{ user_email }}']
}

# Create DAG
dag = DAG(
    '{{ dag_id }}',
    default_args=default_args,
    description='{{ pipeline_description }}',
    schedule_interval={{ schedule_interval }},
    catchup=False,
    tags=['ai-agents-platform', 'pipeline', '{{ pipeline_name }}']
)

# Pipeline configuration
pipeline_config = {{ pipeline_config | tojson }}

def validate_inputs(**context):
    \"\"\"Validate pipeline inputs\"\"\"
    # Add input validation logic here
    print("Validating pipeline inputs...")
    return True

def notify_completion(**context):
    \"\"\"Notify pipeline completion\"\"\"
    # Add notification logic here
    print("Pipeline execution completed")
    return True

# Start task
start_task = DummyOperator(
    task_id='start_pipeline',
    dag=dag
)

# Input validation task
validate_task = PythonOperator(
    task_id='validate_inputs',
    python_callable=validate_inputs,
    dag=dag
)

# Pipeline steps
{% for step in steps %}
{{ step.task_id }} = KubernetesPodOperator(
    task_id='{{ step.task_id }}',
    name='{{ step.name }}',
    namespace='{{ k8s_execution_namespace }}',
    image='{{ step.image }}',
    cmds=['python'],
    arguments=['/app/execute_step.py'],
    env_vars={
        'STEP_CONFIG': json.dumps({{ step.config | tojson }}),
        'STEP_TYPE': '{{ step.type }}',
        'STEP_ID': '{{ step.id }}',
        'PIPELINE_ID': '{{ pipeline_id }}',
        'USER_ID': '{{ user_id }}'
    },
    labels={'app': 'ai-agents-platform', 'component': 'pipeline-step'},
    get_logs=True,
    dag=dag
)
{% endfor %}

# End task
end_task = PythonOperator(
    task_id='notify_completion',
    python_callable=notify_completion,
    dag=dag
)

# Define task dependencies
start_task >> validate_task
{% for step in steps %}
{% if step.depends_on %}
{% for dep in step.depends_on %}
{{ dep }} >> {{ step.task_id }}
{% endfor %}
{% else %}
validate_task >> {{ step.task_id }}
{% endif %}
{% endfor %}

# Connect to end task
{% for step in steps %}
{% if not step.has_dependents %}
{{ step.task_id }} >> end_task
{% endif %}
{% endfor %}
""")
        
        # Prepare template variables
        steps = []
        for step in pipeline.steps:
            step_data = {
                "task_id": f"step_{step.id}",
                "name": step.name.replace(" ", "_").lower(),
                "id": step.id,
                "type": step.type,
                "config": step.config,
                "depends_on": [f"step_{dep}" for dep in step.depends_on],
                "has_dependents": any(step.id in other_step.depends_on for other_step in pipeline.steps),
                "image": self._get_step_image(step.type)
            }
            steps.append(step_data)
        
        template_vars = {
            "dag_id": dag_id,
            "user_email": user.email,
            "start_year": start_date.year,
            "start_month": start_date.month,
            "start_day": start_date.day,
            "schedule_interval": f"'{schedule_interval}'" if schedule_interval else "None",
            "pipeline_description": pipeline.description or f"AI Agents Pipeline: {pipeline.name}",
            "pipeline_name": pipeline.name,
            "pipeline_id": str(pipeline.id),
            "user_id": str(user.id),
            "pipeline_config": pipeline.to_dict(),
            "steps": steps,
            "k8s_execution_namespace": self.k8s_execution_namespace
        }
        
        return dag_template.render(**template_vars)
    
    def _get_step_image(self, step_type: str) -> str:
        """Get Docker image for step type"""
        images = {
            "llm": "ai-agents-platform/llm-executor:latest",
            "api": "ai-agents-platform/api-executor:latest",
            "rag": "ai-agents-platform/rag-executor:latest",
            "python": "ai-agents-platform/python-executor:latest"
        }
        return images.get(step_type, "ai-agents-platform/generic-executor:latest")
    
    def _generate_k8s_manifests(
        self,
        pipeline: Pipeline,
        user: User,
        dag_id: str
    ) -> Dict[str, Dict[str, Any]]:
        """Generate Kubernetes manifests for pipeline execution"""
        
        manifests = {}
        
        # Namespace for pipeline execution
        manifests["namespace"] = {
            "apiVersion": "v1",
            "kind": "Namespace",
            "metadata": {
                "name": self.k8s_execution_namespace,
                "labels": {
                    "app": "ai-agents-platform",
                    "component": "pipeline-execution"
                }
            }
        }
        
        # Service Account
        manifests["serviceaccount"] = {
            "apiVersion": "v1",
            "kind": "ServiceAccount",
            "metadata": {
                "name": f"pipeline-{pipeline.id}",
                "namespace": self.k8s_execution_namespace,
                "labels": {
                    "app": "ai-agents-platform",
                    "pipeline-id": str(pipeline.id)
                }
            }
        }
        
        # Role for pipeline execution
        manifests["role"] = {
            "apiVersion": "rbac.authorization.k8s.io/v1",
            "kind": "Role",
            "metadata": {
                "name": f"pipeline-{pipeline.id}",
                "namespace": self.k8s_execution_namespace
            },
            "rules": [
                {
                    "apiGroups": [""],
                    "resources": ["pods", "pods/log"],
                    "verbs": ["get", "list", "create", "delete"]
                },
                {
                    "apiGroups": [""],
                    "resources": ["secrets", "configmaps"],
                    "verbs": ["get", "list"]
                }
            ]
        }
        
        # Role Binding
        manifests["rolebinding"] = {
            "apiVersion": "rbac.authorization.k8s.io/v1",
            "kind": "RoleBinding",
            "metadata": {
                "name": f"pipeline-{pipeline.id}",
                "namespace": self.k8s_execution_namespace
            },
            "subjects": [
                {
                    "kind": "ServiceAccount",
                    "name": f"pipeline-{pipeline.id}",
                    "namespace": self.k8s_execution_namespace
                }
            ],
            "roleRef": {
                "kind": "Role",
                "name": f"pipeline-{pipeline.id}",
                "apiGroup": "rbac.authorization.k8s.io"
            }
        }
        
        # ConfigMap for pipeline configuration
        manifests["configmap"] = {
            "apiVersion": "v1",
            "kind": "ConfigMap",
            "metadata": {
                "name": f"pipeline-{pipeline.id}-config",
                "namespace": self.k8s_execution_namespace,
                "labels": {
                    "app": "ai-agents-platform",
                    "pipeline-id": str(pipeline.id)
                }
            },
            "data": {
                "pipeline.json": json.dumps(pipeline.to_dict(), indent=2),
                "user.json": json.dumps({
                    "id": str(user.id),
                    "email": user.email,
                    "name": user.name
                }, indent=2)
            }
        }
        
        # Secret for sensitive configuration
        manifests["secret"] = {
            "apiVersion": "v1",
            "kind": "Secret",
            "metadata": {
                "name": f"pipeline-{pipeline.id}-secrets",
                "namespace": self.k8s_execution_namespace,
                "labels": {
                    "app": "ai-agents-platform",
                    "pipeline-id": str(pipeline.id)
                }
            },
            "type": "Opaque",
            "data": {
                # Add base64 encoded secrets here
                "api-key": "",  # Will be populated with actual secrets
                "database-url": ""
            }
        }
        
        return manifests
    
    async def undeploy_pipeline(self, dag_id: str) -> bool:
        """Remove pipeline DAG from Airflow"""
        try:
            # Remove DAG file
            dag_file_path = os.path.join(self.airflow_dags_path, f"{dag_id}.py")
            if os.path.exists(dag_file_path):
                os.remove(dag_file_path)
            
            # Remove manifests directory
            manifests_dir = os.path.join(self.airflow_dags_path, "k8s_manifests", dag_id)
            if os.path.exists(manifests_dir):
                import shutil
                shutil.rmtree(manifests_dir)
            
            self.logger.info(f"Pipeline DAG {dag_id} undeployed from Airflow")
            return True
            
        except Exception as e:
            self.logger.error(f"Error undeploying pipeline DAG: {e}")
            return False
    
    async def list_deployed_pipelines(self) -> List[Dict[str, Any]]:
        """List all deployed pipeline DAGs"""
        try:
            deployed_pipelines = []
            
            if not os.path.exists(self.airflow_dags_path):
                return deployed_pipelines
            
            for filename in os.listdir(self.airflow_dags_path):
                if filename.startswith("pipeline_") and filename.endswith(".py"):
                    dag_id = filename[:-3]  # Remove .py extension
                    
                    # Parse DAG ID to extract pipeline and user info
                    parts = dag_id.split("_")
                    if len(parts) >= 3:
                        pipeline_id = parts[1]
                        user_id = parts[2]
                        
                        deployed_pipelines.append({
                            "dag_id": dag_id,
                            "pipeline_id": pipeline_id,
                            "user_id": user_id,
                            "file_path": os.path.join(self.airflow_dags_path, filename),
                            "deployed_at": datetime.fromtimestamp(
                                os.path.getctime(os.path.join(self.airflow_dags_path, filename))
                            ).isoformat()
                        })
            
            return deployed_pipelines
            
        except Exception as e:
            self.logger.error(f"Error listing deployed pipelines: {e}")
            return []
    
    async def get_dag_status(self, dag_id: str) -> Optional[Dict[str, Any]]:
        """Get status of a deployed DAG"""
        try:
            # This would typically integrate with Airflow's REST API
            # For now, we'll return basic file-based status
            
            dag_file_path = os.path.join(self.airflow_dags_path, f"{dag_id}.py")
            if not os.path.exists(dag_file_path):
                return None
            
            stat = os.stat(dag_file_path)
            
            return {
                "dag_id": dag_id,
                "status": "deployed",
                "file_path": dag_file_path,
                "created_at": datetime.fromtimestamp(stat.st_ctime).isoformat(),
                "modified_at": datetime.fromtimestamp(stat.st_mtime).isoformat(),
                "size": stat.st_size
            }
            
        except Exception as e:
            self.logger.error(f"Error getting DAG status: {e}")
            return None


# Global Airflow service instance
airflow_service = AirflowService()

