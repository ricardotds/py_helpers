"""
RAG Index service for managing RAG index operations
"""

from typing import Optional, List, Dict, Any
import httpx
from datetime import datetime

from app.database.repository import BaseRepository
from app.models.rag_index import RAGIndex, RAGIndexCreate, RAGIndexUpdate, SearchQuery, SearchResponse, SearchResult
from app.models.user import User
from app.auth.dependencies import PermissionChecker
from app.core.logging import LoggerMixin


class RAGIndexService(LoggerMixin):
    """Service for RAG index management operations"""
    
    def __init__(self):
        self.repository = BaseRepository("rag_indexes", RAGIndex)
    
    async def create_rag_index(self, rag_index_data: RAGIndexCreate, owner_id: str) -> RAGIndex:
        """Create a new RAG index"""
        try:
            # Check if RAG index with same name exists for this owner
            existing_index = await self.repository.get_by_field("name", rag_index_data.name)
            if existing_index and existing_index.owner_id == owner_id:
                raise ValueError(f"RAG index with name '{rag_index_data.name}' already exists")
            
            # Test connection to Azure AI Search
            await self._test_search_connection(
                rag_index_data.search_service_endpoint,
                rag_index_data.api_key
            )
            
            # Create RAG index document
            rag_index_dict = rag_index_data.dict()
            rag_index_dict["owner_id"] = owner_id
            
            rag_index = await self.repository.create(rag_index_dict)
            
            self.logger.info(f"Created RAG index: {rag_index.name} by user {owner_id}")
            return rag_index
            
        except ValueError:
            raise
        except Exception as e:
            self.logger.error(f"Error creating RAG index: {e}")
            raise
    
    async def get_rag_index(self, rag_index_id: str, user: User) -> Optional[RAGIndex]:
        """Get RAG index by ID with permission check"""
        try:
            rag_index = await self.repository.get_by_id(rag_index_id)
            if not rag_index:
                return None
            
            # Check permissions
            if not PermissionChecker.check_resource_permission(
                user=user,
                resource_owner_id=rag_index.owner_id,
                shared_with_users=rag_index.share_settings.shared_with_users,
                shared_with_groups=rag_index.share_settings.shared_with_groups,
                is_public=rag_index.share_settings.is_public
            ):
                return None
            
            return rag_index
            
        except Exception as e:
            self.logger.error(f"Error getting RAG index {rag_index_id}: {e}")
            return None
    
    async def update_rag_index(self, rag_index_id: str, rag_index_data: RAGIndexUpdate, user: User) -> Optional[RAGIndex]:
        """Update RAG index with permission check"""
        try:
            # Get existing RAG index
            existing_index = await self.repository.get_by_id(rag_index_id)
            if not existing_index:
                return None
            
            # Check permissions (owner or write access)
            PermissionChecker.ensure_resource_access(
                user=user,
                resource_owner_id=existing_index.owner_id,
                shared_with_users=existing_index.share_settings.shared_with_users,
                shared_with_groups=existing_index.share_settings.shared_with_groups,
                is_public=existing_index.share_settings.is_public,
                required_permission="write"
            )
            
            # Prepare update data
            update_dict = rag_index_data.dict(exclude_unset=True)
            
            # Test connection if endpoint or API key changed
            if "search_service_endpoint" in update_dict or "api_key" in update_dict:
                endpoint = update_dict.get("search_service_endpoint", existing_index.search_service_endpoint)
                api_key = update_dict.get("api_key", existing_index.api_key)
                await self._test_search_connection(endpoint, api_key)
            
            # Update usage count if index is being used
            if "last_used" in update_dict:
                update_dict["usage_count"] = existing_index.usage_count + 1
            
            updated_index = await self.repository.update(rag_index_id, update_dict)
            
            if updated_index:
                self.logger.info(f"Updated RAG index: {updated_index.name}")
            
            return updated_index
            
        except ValueError:
            raise
        except Exception as e:
            self.logger.error(f"Error updating RAG index {rag_index_id}: {e}")
            return None
    
    async def delete_rag_index(self, rag_index_id: str, user: User) -> bool:
        """Delete RAG index with permission check"""
        try:
            rag_index = await self.repository.get_by_id(rag_index_id)
            if not rag_index:
                return False
            
            # Check permissions (owner only)
            PermissionChecker.ensure_resource_access(
                user=user,
                resource_owner_id=rag_index.owner_id,
                required_permission="admin"
            )
            
            success = await self.repository.delete(rag_index_id)
            
            if success:
                self.logger.info(f"Deleted RAG index: {rag_index.name}")
            
            return success
            
        except Exception as e:
            self.logger.error(f"Error deleting RAG index {rag_index_id}: {e}")
            return False
    
    async def list_rag_indexes(
        self,
        user: User,
        skip: int = 0,
        limit: int = 100,
        search: Optional[str] = None,
        category: Optional[str] = None,
        tags: Optional[List[str]] = None,
        owner_only: bool = False
    ) -> List[RAGIndex]:
        """List RAG indexes accessible to user"""
        try:
            filter_dict = {}
            
            if category:
                filter_dict["category"] = category
            
            if tags:
                filter_dict["tags"] = {"$in": tags}
            
            if owner_only:
                filter_dict["owner_id"] = str(user.id)
            
            if search:
                rag_indexes = await self.repository.search(
                    search_term=search,
                    search_fields=["name", "description"],
                    filter_dict=filter_dict,
                    skip=skip,
                    limit=limit
                )
            else:
                rag_indexes = await self.repository.list(
                    filter_dict=filter_dict,
                    skip=skip,
                    limit=limit,
                    sort_by="updated_at",
                    sort_order=-1
                )
            
            # Filter by permissions
            accessible_indexes = []
            for rag_index in rag_indexes:
                if PermissionChecker.check_resource_permission(
                    user=user,
                    resource_owner_id=rag_index.owner_id,
                    shared_with_users=rag_index.share_settings.shared_with_users,
                    shared_with_groups=rag_index.share_settings.shared_with_groups,
                    is_public=rag_index.share_settings.is_public
                ):
                    accessible_indexes.append(rag_index)
            
            return accessible_indexes
            
        except Exception as e:
            self.logger.error(f"Error listing RAG indexes: {e}")
            return []
    
    async def count_rag_indexes(
        self,
        user: User,
        category: Optional[str] = None,
        tags: Optional[List[str]] = None,
        owner_only: bool = False
    ) -> int:
        """Count RAG indexes accessible to user"""
        try:
            filter_dict = {}
            
            if category:
                filter_dict["category"] = category
            
            if tags:
                filter_dict["tags"] = {"$in": tags}
            
            if owner_only:
                filter_dict["owner_id"] = str(user.id)
            
            # For simplicity, get all matching indexes and filter by permissions
            rag_indexes = await self.repository.list(filter_dict=filter_dict)
            
            accessible_count = 0
            for rag_index in rag_indexes:
                if PermissionChecker.check_resource_permission(
                    user=user,
                    resource_owner_id=rag_index.owner_id,
                    shared_with_users=rag_index.share_settings.shared_with_users,
                    shared_with_groups=rag_index.share_settings.shared_with_groups,
                    is_public=rag_index.share_settings.is_public
                ):
                    accessible_count += 1
            
            return accessible_count
            
        except Exception as e:
            self.logger.error(f"Error counting RAG indexes: {e}")
            return 0
    
    async def search_index(self, rag_index_id: str, search_query: SearchQuery, user: User) -> SearchResponse:
        """Search in RAG index"""
        try:
            rag_index = await self.get_rag_index(rag_index_id, user)
            if not rag_index:
                raise ValueError("RAG index not found or access denied")
            
            # Prepare search request
            search_url = f"{rag_index.search_service_endpoint}/indexes/{rag_index.index_name}/docs/search"
            
            headers = {
                "Content-Type": "application/json",
                "api-key": rag_index.api_key
            }
            
            # Build search payload
            search_payload = {
                "search": search_query.query,
                "top": search_query.top,
                "skip": search_query.skip,
                "searchMode": search_query.search_mode,
                "queryType": search_query.query_type
            }
            
            if search_query.search_fields:
                search_payload["searchFields"] = ",".join(search_query.search_fields)
            
            if search_query.select_fields:
                search_payload["select"] = ",".join(search_query.select_fields)
            
            if search_query.filter:
                search_payload["filter"] = search_query.filter
            
            if search_query.order_by:
                search_payload["orderby"] = ",".join(search_query.order_by)
            
            if search_query.highlight_fields:
                search_payload["highlight"] = ",".join(search_query.highlight_fields)
            
            if search_query.facets:
                search_payload["facets"] = search_query.facets
            
            if search_query.semantic_configuration:
                search_payload["semanticConfiguration"] = search_query.semantic_configuration
            
            # Execute search
            async with httpx.AsyncClient() as client:
                response = await client.post(
                    search_url,
                    headers=headers,
                    json=search_payload,
                    timeout=30.0
                )
                response.raise_for_status()
                
                search_result = response.json()
                
                # Parse results
                results = []
                for doc in search_result.get("value", []):
                    score = doc.pop("@search.score", 0.0)
                    highlights = doc.pop("@search.highlights", None)
                    captions = doc.pop("@search.captions", None)
                    
                    results.append(SearchResult(
                        document=doc,
                        score=score,
                        highlights=highlights,
                        captions=captions
                    ))
                
                # Update usage statistics
                await self.update_rag_index(
                    rag_index_id,
                    RAGIndexUpdate(last_used=datetime.utcnow().isoformat()),
                    user
                )
                
                return SearchResponse(
                    results=results,
                    total_count=search_result.get("@odata.count", len(results)),
                    facets=search_result.get("@search.facets"),
                    query_context=search_result.get("@search.queryContext")
                )
            
        except ValueError:
            raise
        except httpx.HTTPStatusError as e:
            self.logger.error(f"Search API error: {e}")
            raise ValueError(f"Search failed: {e.response.text}")
        except Exception as e:
            self.logger.error(f"Error searching RAG index {rag_index_id}: {e}")
            raise
    
    async def _test_search_connection(self, endpoint: str, api_key: str) -> bool:
        """Test connection to Azure AI Search service"""
        try:
            test_url = f"{endpoint}/indexes"
            headers = {
                "Content-Type": "application/json",
                "api-key": api_key
            }
            
            async with httpx.AsyncClient() as client:
                response = await client.get(test_url, headers=headers, timeout=10.0)
                response.raise_for_status()
                return True
                
        except httpx.HTTPStatusError as e:
            raise ValueError(f"Failed to connect to search service: {e.response.text}")
        except Exception as e:
            raise ValueError(f"Failed to connect to search service: {str(e)}")
    
    async def get_rag_index_categories(self, user: User) -> List[str]:
        """Get list of RAG index categories accessible to user"""
        try:
            # Get all RAG indexes accessible to user
            rag_indexes = await self.list_rag_indexes(user, limit=1000)
            
            # Extract unique categories
            categories = set()
            for rag_index in rag_indexes:
                if rag_index.category:
                    categories.add(rag_index.category)
            
            return sorted(list(categories))
            
        except Exception as e:
            self.logger.error(f"Error getting RAG index categories: {e}")
            return []
    
    async def get_rag_index_tags(self, user: User) -> List[str]:
        """Get list of RAG index tags accessible to user"""
        try:
            # Get all RAG indexes accessible to user
            rag_indexes = await self.list_rag_indexes(user, limit=1000)
            
            # Extract unique tags
            tags = set()
            for rag_index in rag_indexes:
                tags.update(rag_index.tags)
            
            return sorted(list(tags))
            
        except Exception as e:
            self.logger.error(f"Error getting RAG index tags: {e}")
            return []

