"""
Authentication endpoints
"""

from fastapi import APIRouter, HTTPException, status, Depends, Query
from fastapi.responses import RedirectResponse
from pydantic import BaseModel
from typing import Optional
import secrets

from app.auth.oauth import entra_auth
from app.auth.dependencies import get_current_user
from app.services.user_service import UserService
from app.models.user import User, UserResponse
from app.core.logging import get_logger

logger = get_logger(__name__)

router = APIRouter()


class AuthURL(BaseModel):
    """Authorization URL response"""
    auth_url: str
    state: str


class TokenResponse(BaseModel):
    """Token response"""
    access_token: str
    token_type: str = "bearer"
    expires_in: int
    user: UserResponse


class LoginRequest(BaseModel):
    """Login request"""
    redirect_uri: str


@router.post("/login", response_model=AuthURL)
async def login(request: LoginRequest):
    """Initiate OAuth2 login flow"""
    try:
        # Generate state parameter for security
        state = secrets.token_urlsafe(32)
        
        # Get authorization URL
        auth_url = entra_auth.get_authorization_url(
            redirect_uri=request.redirect_uri,
            state=state
        )
        
        return AuthURL(auth_url=auth_url, state=state)
        
    except Exception as e:
        logger.error(f"Error initiating login: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to initiate login"
        )


@router.get("/callback")
async def auth_callback(
    code: str = Query(..., description="Authorization code"),
    state: Optional[str] = Query(None, description="State parameter"),
    redirect_uri: str = Query(..., description="Redirect URI")
):
    """Handle OAuth2 callback"""
    try:
        # Exchange code for token
        token_result = await entra_auth.exchange_code_for_token(code, redirect_uri)
        access_token = token_result["access_token"]
        
        # Get user information from Microsoft Graph
        user_info = await entra_auth.get_user_info(access_token)
        
        # Get or create user in database
        user_service = UserService()
        user = await user_service.get_or_create_user_from_azure(user_info)
        
        # Create JWT token for our application
        token_data = {
            "sub": user.azure_object_id,
            "email": user.email,
            "name": user.name,
            "groups": user.groups
        }
        
        jwt_token = entra_auth.create_access_token(token_data)
        
        # Return token response
        user_response = UserResponse(
            id=str(user.id),
            email=user.email,
            name=user.name,
            groups=user.groups,
            is_active=user.is_active,
            is_admin=user.is_admin,
            created_at=user.created_at.isoformat(),
            updated_at=user.updated_at.isoformat()
        )
        
        return TokenResponse(
            access_token=jwt_token,
            expires_in=1800,  # 30 minutes
            user=user_response
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error in auth callback: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Authentication failed"
        )


@router.post("/refresh")
async def refresh_token(
    refresh_token: str,
    current_user: User = Depends(get_current_user)
):
    """Refresh access token"""
    try:
        # Refresh token with Microsoft
        token_result = await entra_auth.refresh_token(refresh_token)
        access_token = token_result["access_token"]
        
        # Get updated user information
        user_info = await entra_auth.get_user_info(access_token)
        
        # Update user in database if needed
        user_service = UserService()
        user = await user_service.get_or_create_user_from_azure(user_info)
        
        # Create new JWT token
        token_data = {
            "sub": user.azure_object_id,
            "email": user.email,
            "name": user.name,
            "groups": user.groups
        }
        
        jwt_token = entra_auth.create_access_token(token_data)
        
        user_response = UserResponse(
            id=str(user.id),
            email=user.email,
            name=user.name,
            groups=user.groups,
            is_active=user.is_active,
            is_admin=user.is_admin,
            created_at=user.created_at.isoformat(),
            updated_at=user.updated_at.isoformat()
        )
        
        return TokenResponse(
            access_token=jwt_token,
            expires_in=1800,
            user=user_response
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error refreshing token: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to refresh token"
        )


@router.get("/me", response_model=UserResponse)
async def get_current_user_info(current_user: User = Depends(get_current_user)):
    """Get current user information"""
    return UserResponse(
        id=str(current_user.id),
        email=current_user.email,
        name=current_user.name,
        groups=current_user.groups,
        is_active=current_user.is_active,
        is_admin=current_user.is_admin,
        created_at=current_user.created_at.isoformat(),
        updated_at=current_user.updated_at.isoformat()
    )


@router.post("/logout")
async def logout(current_user: User = Depends(get_current_user)):
    """Logout user (client should discard token)"""
    logger.info(f"User {current_user.email} logged out")
    return {"message": "Successfully logged out"}


@router.get("/validate")
async def validate_token(current_user: User = Depends(get_current_user)):
    """Validate current token"""
    return {
        "valid": True,
        "user_id": str(current_user.id),
        "email": current_user.email,
        "is_active": current_user.is_active
    }

