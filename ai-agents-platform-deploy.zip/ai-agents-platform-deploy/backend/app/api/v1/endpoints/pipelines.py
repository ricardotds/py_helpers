"""
Pipelines management endpoints
"""

from fastapi import APIRouter, HTTPException, status, Depends, Query
from typing import Optional, List
from pydantic import BaseModel

from app.auth.dependencies import get_current_user
from app.services.pipeline_service import PipelineService
from app.models.pipeline import Pipeline, PipelineCreate, PipelineUpdate
from app.models.user import User
from app.core.logging import get_logger

logger = get_logger(__name__)

router = APIRouter()


class PipelineListResponse(BaseModel):
    """Pipeline list response"""
    pipelines: List[Pipeline]
    total: int
    skip: int
    limit: int


@router.post("/", response_model=Pipeline)
async def create_pipeline(
    pipeline_data: PipelineCreate,
    current_user: User = Depends(get_current_user)
):
    """Create a new pipeline"""
    try:
        pipeline_service = PipelineService()
        pipeline = await pipeline_service.create_pipeline(pipeline_data, str(current_user.id))
        return pipeline
        
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except Exception as e:
        logger.error(f"Error creating pipeline: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to create pipeline"
        )


@router.get("/", response_model=PipelineListResponse)
async def list_pipelines(
    skip: int = Query(0, ge=0, description="Number of pipelines to skip"),
    limit: int = Query(100, ge=1, le=1000, description="Number of pipelines to return"),
    search: Optional[str] = Query(None, description="Search term"),
    category: Optional[str] = Query(None, description="Filter by category"),
    tags: Optional[str] = Query(None, description="Filter by tags (comma-separated)"),
    owner_only: bool = Query(False, description="Show only owned pipelines"),
    validated_only: bool = Query(False, description="Show only validated pipelines"),
    current_user: User = Depends(get_current_user)
):
    """List pipelines accessible to user"""
    try:
        pipeline_service = PipelineService()
        
        # Parse tags
        tag_list = None
        if tags:
            tag_list = [tag.strip() for tag in tags.split(",") if tag.strip()]
        
        pipelines = await pipeline_service.list_pipelines(
            user=current_user,
            skip=skip,
            limit=limit,
            search=search,
            category=category,
            tags=tag_list,
            owner_only=owner_only,
            validated_only=validated_only
        )
        
        total = await pipeline_service.count_pipelines(
            user=current_user,
            category=category,
            tags=tag_list,
            owner_only=owner_only,
            validated_only=validated_only
        )
        
        return PipelineListResponse(
            pipelines=pipelines,
            total=total,
            skip=skip,
            limit=limit
        )
        
    except Exception as e:
        logger.error(f"Error listing pipelines: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to list pipelines"
        )


@router.get("/categories", response_model=List[str])
async def get_pipeline_categories(current_user: User = Depends(get_current_user)):
    """Get list of pipeline categories"""
    try:
        pipeline_service = PipelineService()
        categories = await pipeline_service.get_pipeline_categories(current_user)
        return categories
        
    except Exception as e:
        logger.error(f"Error getting pipeline categories: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get pipeline categories"
        )


@router.get("/tags", response_model=List[str])
async def get_pipeline_tags(current_user: User = Depends(get_current_user)):
    """Get list of pipeline tags"""
    try:
        pipeline_service = PipelineService()
        tags = await pipeline_service.get_pipeline_tags(current_user)
        return tags
        
    except Exception as e:
        logger.error(f"Error getting pipeline tags: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get pipeline tags"
        )


@router.get("/{pipeline_id}", response_model=Pipeline)
async def get_pipeline(
    pipeline_id: str,
    current_user: User = Depends(get_current_user)
):
    """Get pipeline by ID"""
    try:
        pipeline_service = PipelineService()
        pipeline = await pipeline_service.get_pipeline(pipeline_id, current_user)
        
        if not pipeline:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Pipeline not found"
            )
        
        return pipeline
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting pipeline {pipeline_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get pipeline"
        )


@router.put("/{pipeline_id}", response_model=Pipeline)
async def update_pipeline(
    pipeline_id: str,
    pipeline_data: PipelineUpdate,
    current_user: User = Depends(get_current_user)
):
    """Update pipeline"""
    try:
        pipeline_service = PipelineService()
        updated_pipeline = await pipeline_service.update_pipeline(pipeline_id, pipeline_data, current_user)
        
        if not updated_pipeline:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Pipeline not found"
            )
        
        return updated_pipeline
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating pipeline {pipeline_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to update pipeline"
        )


@router.delete("/{pipeline_id}")
async def delete_pipeline(
    pipeline_id: str,
    current_user: User = Depends(get_current_user)
):
    """Delete pipeline"""
    try:
        pipeline_service = PipelineService()
        success = await pipeline_service.delete_pipeline(pipeline_id, current_user)
        
        if not success:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Pipeline not found"
            )
        
        return {"message": "Pipeline deleted successfully"}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting pipeline {pipeline_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to delete pipeline"
        )

