"""
Pipeline execution endpoints
"""

from fastapi import APIRouter, HTTPException, status, Depends, WebSocket, WebSocketDisconnect
from typing import Dict, Any, List
from pydantic import BaseModel

from app.auth.dependencies import get_current_user
from app.services.execution_service import ExecutionService, ExecutionResult
from app.models.user import User
from app.core.logging import get_logger
from app.core.websocket_manager import WebSocketManager

logger = get_logger(__name__)

router = APIRouter()


class ExecutionRequest(BaseModel):
    """Pipeline execution request"""
    inputs: Dict[str, Any]


class ExecutionResponse(BaseModel):
    """Pipeline execution response"""
    execution_id: str
    status: str
    message: str


class ExecutionStatusResponse(BaseModel):
    """Execution status response"""
    execution_id: str
    status: str
    pipeline_id: str
    user_id: str
    inputs: Dict[str, Any]
    outputs: Dict[str, Any]
    step_status: Dict[str, str]
    error_message: str = None
    start_time: str = None
    end_time: str = None


@router.post("/{pipeline_id}/run", response_model=ExecutionResponse)
async def execute_pipeline(
    pipeline_id: str,
    execution_request: ExecutionRequest,
    current_user: User = Depends(get_current_user)
):
    """Execute a pipeline"""
    try:
        execution_service = ExecutionService()
        execution_id = await execution_service.execute_pipeline(
            pipeline_id, 
            execution_request.inputs, 
            current_user
        )
        
        return ExecutionResponse(
            execution_id=execution_id,
            status="started",
            message="Pipeline execution started successfully"
        )
        
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except Exception as e:
        logger.error(f"Error starting pipeline execution: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to start pipeline execution"
        )


@router.get("/{execution_id}/status", response_model=ExecutionStatusResponse)
async def get_execution_status(
    execution_id: str,
    current_user: User = Depends(get_current_user)
):
    """Get execution status"""
    try:
        execution_service = ExecutionService()
        execution_result = await execution_service.get_execution_status(execution_id, current_user)
        
        if not execution_result:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Execution not found"
            )
        
        return ExecutionStatusResponse(
            execution_id=execution_result.execution_id,
            status=execution_result.status.value,
            pipeline_id=execution_result.pipeline_id,
            user_id=execution_result.user_id,
            inputs=execution_result.inputs,
            outputs=execution_result.outputs,
            step_status={k: v.value for k, v in execution_result.step_status.items()},
            error_message=execution_result.error_message,
            start_time=execution_result.start_time.isoformat() if execution_result.start_time else None,
            end_time=execution_result.end_time.isoformat() if execution_result.end_time else None
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting execution status: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get execution status"
        )


@router.post("/{execution_id}/cancel")
async def cancel_execution(
    execution_id: str,
    current_user: User = Depends(get_current_user)
):
    """Cancel a running execution"""
    try:
        execution_service = ExecutionService()
        success = await execution_service.cancel_execution(execution_id, current_user)
        
        if not success:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Execution not found or cannot be cancelled"
            )
        
        return {"message": "Execution cancelled successfully"}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error cancelling execution: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to cancel execution"
        )


@router.get("/", response_model=List[ExecutionStatusResponse])
async def list_executions(
    current_user: User = Depends(get_current_user)
):
    """List user's executions"""
    try:
        execution_service = ExecutionService()
        executions = await execution_service.list_executions(current_user)
        
        execution_responses = []
        for execution_result in executions:
            execution_responses.append(ExecutionStatusResponse(
                execution_id=execution_result.execution_id,
                status=execution_result.status.value,
                pipeline_id=execution_result.pipeline_id,
                user_id=execution_result.user_id,
                inputs=execution_result.inputs,
                outputs=execution_result.outputs,
                step_status={k: v.value for k, v in execution_result.step_status.items()},
                error_message=execution_result.error_message,
                start_time=execution_result.start_time.isoformat() if execution_result.start_time else None,
                end_time=execution_result.end_time.isoformat() if execution_result.end_time else None
            ))
        
        return execution_responses
        
    except Exception as e:
        logger.error(f"Error listing executions: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to list executions"
        )


@router.websocket("/{execution_id}/ws")
async def execution_websocket(
    websocket: WebSocket,
    execution_id: str
):
    """WebSocket endpoint for real-time execution monitoring"""
    try:
        await websocket.accept()
        
        # Add client to execution room
        websocket_manager = WebSocketManager()
        room_name = f"execution_{execution_id}"
        await websocket_manager.add_to_room(websocket, room_name)
        
        try:
            # Keep connection alive and handle messages
            while True:
                # Wait for messages (ping/pong, etc.)
                try:
                    data = await websocket.receive_text()
                    # Handle any client messages if needed
                    logger.debug(f"Received WebSocket message: {data}")
                except WebSocketDisconnect:
                    break
                    
        except WebSocketDisconnect:
            pass
        finally:
            # Remove client from room
            await websocket_manager.remove_from_room(websocket, room_name)
            
    except Exception as e:
        logger.error(f"WebSocket error: {e}")
        try:
            await websocket.close()
        except:
            pass

