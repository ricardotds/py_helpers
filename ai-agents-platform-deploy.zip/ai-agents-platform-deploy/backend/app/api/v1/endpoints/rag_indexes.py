"""
RAG Indexes management endpoints
"""

from fastapi import APIRouter, HTTPException, status, Depends, Query
from typing import Optional, List
from pydantic import BaseModel

from app.auth.dependencies import get_current_user
from app.services.rag_index_service import RAGIndexService
from app.models.rag_index import RAGIndex, RAGIndexCreate, RAGIndexUpdate, SearchQuery, SearchResponse
from app.models.user import User
from app.core.logging import get_logger

logger = get_logger(__name__)

router = APIRouter()


class RAGIndexListResponse(BaseModel):
    """RAG Index list response"""
    rag_indexes: List[RAGIndex]
    total: int
    skip: int
    limit: int


@router.post("/", response_model=RAGIndex)
async def create_rag_index(
    rag_index_data: RAGIndexCreate,
    current_user: User = Depends(get_current_user)
):
    """Create a new RAG index"""
    try:
        rag_index_service = RAGIndexService()
        rag_index = await rag_index_service.create_rag_index(rag_index_data, str(current_user.id))
        return rag_index
        
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except Exception as e:
        logger.error(f"Error creating RAG index: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to create RAG index"
        )


@router.get("/", response_model=RAGIndexListResponse)
async def list_rag_indexes(
    skip: int = Query(0, ge=0, description="Number of RAG indexes to skip"),
    limit: int = Query(100, ge=1, le=1000, description="Number of RAG indexes to return"),
    search: Optional[str] = Query(None, description="Search term"),
    category: Optional[str] = Query(None, description="Filter by category"),
    tags: Optional[str] = Query(None, description="Filter by tags (comma-separated)"),
    owner_only: bool = Query(False, description="Show only owned RAG indexes"),
    current_user: User = Depends(get_current_user)
):
    """List RAG indexes accessible to user"""
    try:
        rag_index_service = RAGIndexService()
        
        # Parse tags
        tag_list = None
        if tags:
            tag_list = [tag.strip() for tag in tags.split(",") if tag.strip()]
        
        rag_indexes = await rag_index_service.list_rag_indexes(
            user=current_user,
            skip=skip,
            limit=limit,
            search=search,
            category=category,
            tags=tag_list,
            owner_only=owner_only
        )
        
        total = await rag_index_service.count_rag_indexes(
            user=current_user,
            category=category,
            tags=tag_list,
            owner_only=owner_only
        )
        
        return RAGIndexListResponse(
            rag_indexes=rag_indexes,
            total=total,
            skip=skip,
            limit=limit
        )
        
    except Exception as e:
        logger.error(f"Error listing RAG indexes: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to list RAG indexes"
        )


@router.get("/categories", response_model=List[str])
async def get_rag_index_categories(current_user: User = Depends(get_current_user)):
    """Get list of RAG index categories"""
    try:
        rag_index_service = RAGIndexService()
        categories = await rag_index_service.get_rag_index_categories(current_user)
        return categories
        
    except Exception as e:
        logger.error(f"Error getting RAG index categories: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get RAG index categories"
        )


@router.get("/tags", response_model=List[str])
async def get_rag_index_tags(current_user: User = Depends(get_current_user)):
    """Get list of RAG index tags"""
    try:
        rag_index_service = RAGIndexService()
        tags = await rag_index_service.get_rag_index_tags(current_user)
        return tags
        
    except Exception as e:
        logger.error(f"Error getting RAG index tags: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get RAG index tags"
        )


@router.get("/{rag_index_id}", response_model=RAGIndex)
async def get_rag_index(
    rag_index_id: str,
    current_user: User = Depends(get_current_user)
):
    """Get RAG index by ID"""
    try:
        rag_index_service = RAGIndexService()
        rag_index = await rag_index_service.get_rag_index(rag_index_id, current_user)
        
        if not rag_index:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="RAG index not found"
            )
        
        return rag_index
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting RAG index {rag_index_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get RAG index"
        )


@router.put("/{rag_index_id}", response_model=RAGIndex)
async def update_rag_index(
    rag_index_id: str,
    rag_index_data: RAGIndexUpdate,
    current_user: User = Depends(get_current_user)
):
    """Update RAG index"""
    try:
        rag_index_service = RAGIndexService()
        updated_rag_index = await rag_index_service.update_rag_index(rag_index_id, rag_index_data, current_user)
        
        if not updated_rag_index:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="RAG index not found"
            )
        
        return updated_rag_index
        
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating RAG index {rag_index_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to update RAG index"
        )


@router.delete("/{rag_index_id}")
async def delete_rag_index(
    rag_index_id: str,
    current_user: User = Depends(get_current_user)
):
    """Delete RAG index"""
    try:
        rag_index_service = RAGIndexService()
        success = await rag_index_service.delete_rag_index(rag_index_id, current_user)
        
        if not success:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="RAG index not found"
            )
        
        return {"message": "RAG index deleted successfully"}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting RAG index {rag_index_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to delete RAG index"
        )


@router.post("/{rag_index_id}/search", response_model=SearchResponse)
async def search_rag_index(
    rag_index_id: str,
    search_query: SearchQuery,
    current_user: User = Depends(get_current_user)
):
    """Search in RAG index"""
    try:
        rag_index_service = RAGIndexService()
        search_response = await rag_index_service.search_index(
            rag_index_id, 
            search_query, 
            current_user
        )
        
        return search_response
        
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except Exception as e:
        logger.error(f"Error searching RAG index {rag_index_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to search RAG index"
        )

