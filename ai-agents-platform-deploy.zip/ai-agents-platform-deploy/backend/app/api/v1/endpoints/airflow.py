"""
Airflow endpoints for pipeline deployment and management
"""

from datetime import datetime
from typing import Dict, Any, List, Optional
from fastapi import APIRouter, Depends, HTTPException, status, Query
from pydantic import BaseModel

from app.auth.dependencies import get_current_active_user, get_current_admin_user
from app.models.user import User
from app.services.airflow_service import airflow_service
from app.services.pipeline_service import pipeline_service
from app.core.logging import get_logger

logger = get_logger(__name__)
router = APIRouter()


class PipelineDeploymentRequest(BaseModel):
    """Request model for pipeline deployment"""
    pipeline_id: str
    schedule_interval: Optional[str] = None
    start_date: Optional[datetime] = None
    description: Optional[str] = None


class PipelineDeploymentResponse(BaseModel):
    """Response model for pipeline deployment"""
    success: bool
    dag_id: str
    message: str
    deployment_info: Dict[str, Any]


class DAGStatusResponse(BaseModel):
    """Response model for DAG status"""
    dag_id: str
    status: str
    created_at: str
    modified_at: str
    file_path: str
    size: int


@router.post("/deploy", response_model=PipelineDeploymentResponse)
async def deploy_pipeline_to_airflow(
    request: PipelineDeploymentRequest,
    current_user: User = Depends(get_current_active_user)
):
    """
    Deploy a validated pipeline to Airflow as a DAG
    """
    try:
        # Get pipeline
        pipeline = await pipeline_service.get_pipeline(request.pipeline_id, current_user)
        if not pipeline:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Pipeline not found or access denied"
            )
        
        if not pipeline.is_validated:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Pipeline must be validated before deployment"
            )
        
        # Deploy to Airflow
        deployment_info = await airflow_service.deploy_pipeline_to_airflow(
            pipeline=pipeline,
            user=current_user,
            schedule_interval=request.schedule_interval,
            start_date=request.start_date
        )
        
        return PipelineDeploymentResponse(
            success=True,
            dag_id=deployment_info["dag_id"],
            message=f"Pipeline '{pipeline.name}' successfully deployed to Airflow",
            deployment_info=deployment_info
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deploying pipeline to Airflow: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error deploying pipeline: {str(e)}"
        )


@router.delete("/undeploy/{dag_id}")
async def undeploy_pipeline_from_airflow(
    dag_id: str,
    current_user: User = Depends(get_current_active_user)
):
    """
    Remove a pipeline DAG from Airflow
    """
    try:
        # Check if user owns the DAG or is admin
        if not current_user.is_admin:
            # Extract user ID from DAG ID to check ownership
            dag_parts = dag_id.split("_")
            if len(dag_parts) < 3 or dag_parts[2] != str(current_user.id):
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Not authorized to undeploy this pipeline"
                )
        
        # Undeploy from Airflow
        success = await airflow_service.undeploy_pipeline(dag_id)
        
        if not success:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="DAG not found or already undeployed"
            )
        
        return {
            "success": True,
            "message": f"Pipeline DAG '{dag_id}' successfully undeployed from Airflow"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error undeploying pipeline from Airflow: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error undeploying pipeline: {str(e)}"
        )


@router.get("/deployed", response_model=List[Dict[str, Any]])
async def list_deployed_pipelines(
    current_user: User = Depends(get_current_active_user)
):
    """
    List all deployed pipeline DAGs
    """
    try:
        deployed_pipelines = await airflow_service.list_deployed_pipelines()
        
        # Filter by user if not admin
        if not current_user.is_admin:
            deployed_pipelines = [
                pipeline for pipeline in deployed_pipelines
                if pipeline.get("user_id") == str(current_user.id)
            ]
        
        return {
            "success": True,
            "data": deployed_pipelines,
            "total": len(deployed_pipelines)
        }
        
    except Exception as e:
        logger.error(f"Error listing deployed pipelines: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error listing deployed pipelines: {str(e)}"
        )


@router.get("/dag/{dag_id}/status", response_model=DAGStatusResponse)
async def get_dag_status(
    dag_id: str,
    current_user: User = Depends(get_current_active_user)
):
    """
    Get status of a deployed DAG
    """
    try:
        # Check if user owns the DAG or is admin
        if not current_user.is_admin:
            dag_parts = dag_id.split("_")
            if len(dag_parts) < 3 or dag_parts[2] != str(current_user.id):
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Not authorized to view this DAG"
                )
        
        # Get DAG status
        dag_status = await airflow_service.get_dag_status(dag_id)
        
        if not dag_status:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="DAG not found"
            )
        
        return {
            "success": True,
            "data": dag_status
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting DAG status: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error getting DAG status: {str(e)}"
        )


@router.post("/dag/{dag_id}/trigger")
async def trigger_dag_run(
    dag_id: str,
    conf: Optional[Dict[str, Any]] = None,
    current_user: User = Depends(get_current_active_user)
):
    """
    Trigger a DAG run manually
    """
    try:
        # Check if user owns the DAG or is admin
        if not current_user.is_admin:
            dag_parts = dag_id.split("_")
            if len(dag_parts) < 3 or dag_parts[2] != str(current_user.id):
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Not authorized to trigger this DAG"
                )
        
        # This would typically integrate with Airflow's REST API
        # For now, we'll return a placeholder response
        
        return {
            "success": True,
            "message": f"DAG '{dag_id}' triggered successfully",
            "run_id": f"manual__{datetime.utcnow().strftime('%Y%m%dT%H%M%S')}",
            "conf": conf or {}
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error triggering DAG: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error triggering DAG: {str(e)}"
        )


@router.get("/dag/{dag_id}/runs")
async def get_dag_runs(
    dag_id: str,
    limit: int = Query(default=10, ge=1, le=100),
    offset: int = Query(default=0, ge=0),
    current_user: User = Depends(get_current_active_user)
):
    """
    Get DAG run history
    """
    try:
        # Check if user owns the DAG or is admin
        if not current_user.is_admin:
            dag_parts = dag_id.split("_")
            if len(dag_parts) < 3 or dag_parts[2] != str(current_user.id):
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Not authorized to view this DAG"
                )
        
        # This would typically integrate with Airflow's REST API
        # For now, we'll return a placeholder response
        
        return {
            "success": True,
            "data": {
                "dag_runs": [],
                "total_entries": 0
            },
            "message": "DAG runs retrieved successfully"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting DAG runs: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error getting DAG runs: {str(e)}"
        )


@router.get("/health")
async def airflow_health_check(
    current_user: User = Depends(get_current_admin_user)
):
    """
    Check Airflow service health (Admin only)
    """
    try:
        # This would typically check Airflow's health endpoint
        # For now, we'll return a basic health check
        
        return {
            "success": True,
            "status": "healthy",
            "airflow_version": "2.7.0",  # Placeholder
            "dags_folder": airflow_service.airflow_dags_path,
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Error checking Airflow health: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error checking Airflow health: {str(e)}"
        )


@router.get("/config")
async def get_airflow_config(
    current_user: User = Depends(get_current_admin_user)
):
    """
    Get Airflow configuration (Admin only)
    """
    try:
        return {
            "success": True,
            "config": {
                "dags_path": airflow_service.airflow_dags_path,
                "k8s_namespace": airflow_service.k8s_namespace,
                "k8s_execution_namespace": airflow_service.k8s_execution_namespace,
                "supported_step_types": ["llm", "api", "rag", "python"]
            }
        }
        
    except Exception as e:
        logger.error(f"Error getting Airflow config: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error getting Airflow config: {str(e)}"
        )

