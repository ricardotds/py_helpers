"""
Schemas management endpoints
"""

from fastapi import APIRouter, HTTPException, status, Depends, Query
from typing import Optional, List, Dict, Any
from pydantic import BaseModel

from app.auth.dependencies import get_current_user
from app.services.schema_service import SchemaService
from app.models.schema import Schema, SchemaCreate, SchemaUpdate, SchemaValidationResult
from app.models.user import User
from app.core.logging import get_logger

logger = get_logger(__name__)

router = APIRouter()


class SchemaListResponse(BaseModel):
    """Schema list response"""
    schemas: List[Schema]
    total: int
    skip: int
    limit: int


class SchemaValidateRequest(BaseModel):
    """Schema validation request"""
    data: Dict[str, Any]


@router.post("/", response_model=Schema)
async def create_schema(
    schema_data: SchemaCreate,
    current_user: User = Depends(get_current_user)
):
    """Create a new schema"""
    try:
        schema_service = SchemaService()
        schema = await schema_service.create_schema(schema_data, str(current_user.id))
        return schema
        
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except Exception as e:
        logger.error(f"Error creating schema: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to create schema"
        )


@router.get("/", response_model=SchemaListResponse)
async def list_schemas(
    skip: int = Query(0, ge=0, description="Number of schemas to skip"),
    limit: int = Query(100, ge=1, le=1000, description="Number of schemas to return"),
    search: Optional[str] = Query(None, description="Search term"),
    category: Optional[str] = Query(None, description="Filter by category"),
    tags: Optional[str] = Query(None, description="Filter by tags (comma-separated)"),
    owner_only: bool = Query(False, description="Show only owned schemas"),
    current_user: User = Depends(get_current_user)
):
    """List schemas accessible to user"""
    try:
        schema_service = SchemaService()
        
        # Parse tags
        tag_list = None
        if tags:
            tag_list = [tag.strip() for tag in tags.split(",") if tag.strip()]
        
        schemas = await schema_service.list_schemas(
            user=current_user,
            skip=skip,
            limit=limit,
            search=search,
            category=category,
            tags=tag_list,
            owner_only=owner_only
        )
        
        total = await schema_service.count_schemas(
            user=current_user,
            category=category,
            tags=tag_list,
            owner_only=owner_only
        )
        
        return SchemaListResponse(
            schemas=schemas,
            total=total,
            skip=skip,
            limit=limit
        )
        
    except Exception as e:
        logger.error(f"Error listing schemas: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to list schemas"
        )


@router.get("/categories", response_model=List[str])
async def get_schema_categories(current_user: User = Depends(get_current_user)):
    """Get list of schema categories"""
    try:
        schema_service = SchemaService()
        categories = await schema_service.get_schema_categories(current_user)
        return categories
        
    except Exception as e:
        logger.error(f"Error getting schema categories: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get schema categories"
        )


@router.get("/tags", response_model=List[str])
async def get_schema_tags(current_user: User = Depends(get_current_user)):
    """Get list of schema tags"""
    try:
        schema_service = SchemaService()
        tags = await schema_service.get_schema_tags(current_user)
        return tags
        
    except Exception as e:
        logger.error(f"Error getting schema tags: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get schema tags"
        )


@router.get("/{schema_id}", response_model=Schema)
async def get_schema(
    schema_id: str,
    current_user: User = Depends(get_current_user)
):
    """Get schema by ID"""
    try:
        schema_service = SchemaService()
        schema = await schema_service.get_schema(schema_id, current_user)
        
        if not schema:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Schema not found"
            )
        
        return schema
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting schema {schema_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get schema"
        )


@router.put("/{schema_id}", response_model=Schema)
async def update_schema(
    schema_id: str,
    schema_data: SchemaUpdate,
    current_user: User = Depends(get_current_user)
):
    """Update schema"""
    try:
        schema_service = SchemaService()
        updated_schema = await schema_service.update_schema(schema_id, schema_data, current_user)
        
        if not updated_schema:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Schema not found"
            )
        
        return updated_schema
        
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating schema {schema_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to update schema"
        )


@router.delete("/{schema_id}")
async def delete_schema(
    schema_id: str,
    current_user: User = Depends(get_current_user)
):
    """Delete schema"""
    try:
        schema_service = SchemaService()
        success = await schema_service.delete_schema(schema_id, current_user)
        
        if not success:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Schema not found"
            )
        
        return {"message": "Schema deleted successfully"}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting schema {schema_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to delete schema"
        )


@router.post("/{schema_id}/validate", response_model=SchemaValidationResult)
async def validate_data(
    schema_id: str,
    validate_request: SchemaValidateRequest,
    current_user: User = Depends(get_current_user)
):
    """Validate data against schema"""
    try:
        schema_service = SchemaService()
        validation_result = await schema_service.validate_data(
            schema_id, 
            validate_request.data, 
            current_user
        )
        
        return validation_result
        
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except Exception as e:
        logger.error(f"Error validating data against schema {schema_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to validate data"
        )

