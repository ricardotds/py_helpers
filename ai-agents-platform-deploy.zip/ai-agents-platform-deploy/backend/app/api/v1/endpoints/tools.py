"""
Tools management endpoints
"""

from fastapi import APIRouter, HTTPException, status, Depends, Query
from typing import Optional, List
from pydantic import BaseModel

from app.auth.dependencies import get_current_user
from app.services.tool_service import ToolService
from app.models.tool import Tool, ToolCreate, ToolUpdate
from app.models.user import User
from app.core.logging import get_logger

logger = get_logger(__name__)

router = APIRouter()


class ToolListResponse(BaseModel):
    """Tool list response"""
    tools: List[Tool]
    total: int
    skip: int
    limit: int


@router.post("/", response_model=Tool)
async def create_tool(
    tool_data: ToolCreate,
    current_user: User = Depends(get_current_user)
):
    """Create a new tool"""
    try:
        tool_service = ToolService()
        tool = await tool_service.create_tool(tool_data, str(current_user.id))
        return tool
        
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except Exception as e:
        logger.error(f"Error creating tool: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to create tool"
        )


@router.get("/", response_model=ToolListResponse)
async def list_tools(
    skip: int = Query(0, ge=0, description="Number of tools to skip"),
    limit: int = Query(100, ge=1, le=1000, description="Number of tools to return"),
    search: Optional[str] = Query(None, description="Search term"),
    tool_type: Optional[str] = Query(None, description="Filter by tool type"),
    category: Optional[str] = Query(None, description="Filter by category"),
    tags: Optional[str] = Query(None, description="Filter by tags (comma-separated)"),
    owner_only: bool = Query(False, description="Show only owned tools"),
    current_user: User = Depends(get_current_user)
):
    """List tools accessible to user"""
    try:
        tool_service = ToolService()
        
        # Parse tags
        tag_list = None
        if tags:
            tag_list = [tag.strip() for tag in tags.split(",") if tag.strip()]
        
        tools = await tool_service.list_tools(
            user=current_user,
            skip=skip,
            limit=limit,
            search=search,
            tool_type=tool_type,
            category=category,
            tags=tag_list,
            owner_only=owner_only
        )
        
        total = await tool_service.count_tools(
            user=current_user,
            tool_type=tool_type,
            category=category,
            tags=tag_list,
            owner_only=owner_only
        )
        
        return ToolListResponse(
            tools=tools,
            total=total,
            skip=skip,
            limit=limit
        )
        
    except Exception as e:
        logger.error(f"Error listing tools: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to list tools"
        )


@router.get("/types", response_model=List[str])
async def get_tool_types():
    """Get list of supported tool types"""
    try:
        tool_service = ToolService()
        tool_types = await tool_service.get_tool_types()
        return tool_types
        
    except Exception as e:
        logger.error(f"Error getting tool types: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get tool types"
        )


@router.get("/categories", response_model=List[str])
async def get_tool_categories(current_user: User = Depends(get_current_user)):
    """Get list of tool categories"""
    try:
        tool_service = ToolService()
        categories = await tool_service.get_tool_categories(current_user)
        return categories
        
    except Exception as e:
        logger.error(f"Error getting tool categories: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get tool categories"
        )


@router.get("/tags", response_model=List[str])
async def get_tool_tags(current_user: User = Depends(get_current_user)):
    """Get list of tool tags"""
    try:
        tool_service = ToolService()
        tags = await tool_service.get_tool_tags(current_user)
        return tags
        
    except Exception as e:
        logger.error(f"Error getting tool tags: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get tool tags"
        )


@router.get("/{tool_id}", response_model=Tool)
async def get_tool(
    tool_id: str,
    current_user: User = Depends(get_current_user)
):
    """Get tool by ID"""
    try:
        tool_service = ToolService()
        tool = await tool_service.get_tool(tool_id, current_user)
        
        if not tool:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Tool not found"
            )
        
        return tool
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting tool {tool_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get tool"
        )


@router.put("/{tool_id}", response_model=Tool)
async def update_tool(
    tool_id: str,
    tool_data: ToolUpdate,
    current_user: User = Depends(get_current_user)
):
    """Update tool"""
    try:
        tool_service = ToolService()
        updated_tool = await tool_service.update_tool(tool_id, tool_data, current_user)
        
        if not updated_tool:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Tool not found"
            )
        
        return updated_tool
        
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating tool {tool_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to update tool"
        )


@router.delete("/{tool_id}")
async def delete_tool(
    tool_id: str,
    current_user: User = Depends(get_current_user)
):
    """Delete tool"""
    try:
        tool_service = ToolService()
        success = await tool_service.delete_tool(tool_id, current_user)
        
        if not success:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Tool not found"
            )
        
        return {"message": "Tool deleted successfully"}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting tool {tool_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to delete tool"
        )

