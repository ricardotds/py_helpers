"""
Prompts management endpoints
"""

from fastapi import APIRouter, HTTPException, status, Depends, Query
from typing import Optional, List, Dict, Any
from pydantic import BaseModel

from app.auth.dependencies import get_current_user
from app.services.prompt_service import PromptService
from app.models.prompt import Prompt, PromptCreate, PromptUpdate, PromptExecution
from app.models.user import User
from app.core.logging import get_logger

logger = get_logger(__name__)

router = APIRouter()


class PromptListResponse(BaseModel):
    """Prompt list response"""
    prompts: List[Prompt]
    total: int
    skip: int
    limit: int


class PromptRenderRequest(BaseModel):
    """Prompt render request"""
    variables: Dict[str, Any]


class PromptRenderResponse(BaseModel):
    """Prompt render response"""
    rendered_prompt: str
    prompt_id: str
    variables: Dict[str, Any]


@router.post("/", response_model=Prompt)
async def create_prompt(
    prompt_data: PromptCreate,
    current_user: User = Depends(get_current_user)
):
    """Create a new prompt"""
    try:
        prompt_service = PromptService()
        prompt = await prompt_service.create_prompt(prompt_data, str(current_user.id))
        return prompt
        
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except Exception as e:
        logger.error(f"Error creating prompt: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to create prompt"
        )


@router.get("/", response_model=PromptListResponse)
async def list_prompts(
    skip: int = Query(0, ge=0, description="Number of prompts to skip"),
    limit: int = Query(100, ge=1, le=1000, description="Number of prompts to return"),
    search: Optional[str] = Query(None, description="Search term"),
    category: Optional[str] = Query(None, description="Filter by category"),
    tags: Optional[str] = Query(None, description="Filter by tags (comma-separated)"),
    owner_only: bool = Query(False, description="Show only owned prompts"),
    current_user: User = Depends(get_current_user)
):
    """List prompts accessible to user"""
    try:
        prompt_service = PromptService()
        
        # Parse tags
        tag_list = None
        if tags:
            tag_list = [tag.strip() for tag in tags.split(",") if tag.strip()]
        
        prompts = await prompt_service.list_prompts(
            user=current_user,
            skip=skip,
            limit=limit,
            search=search,
            category=category,
            tags=tag_list,
            owner_only=owner_only
        )
        
        total = await prompt_service.count_prompts(
            user=current_user,
            category=category,
            tags=tag_list,
            owner_only=owner_only
        )
        
        return PromptListResponse(
            prompts=prompts,
            total=total,
            skip=skip,
            limit=limit
        )
        
    except Exception as e:
        logger.error(f"Error listing prompts: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to list prompts"
        )


@router.get("/categories", response_model=List[str])
async def get_prompt_categories(current_user: User = Depends(get_current_user)):
    """Get list of prompt categories"""
    try:
        prompt_service = PromptService()
        categories = await prompt_service.get_prompt_categories(current_user)
        return categories
        
    except Exception as e:
        logger.error(f"Error getting prompt categories: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get prompt categories"
        )


@router.get("/tags", response_model=List[str])
async def get_prompt_tags(current_user: User = Depends(get_current_user)):
    """Get list of prompt tags"""
    try:
        prompt_service = PromptService()
        tags = await prompt_service.get_prompt_tags(current_user)
        return tags
        
    except Exception as e:
        logger.error(f"Error getting prompt tags: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get prompt tags"
        )


@router.get("/{prompt_id}", response_model=Prompt)
async def get_prompt(
    prompt_id: str,
    current_user: User = Depends(get_current_user)
):
    """Get prompt by ID"""
    try:
        prompt_service = PromptService()
        prompt = await prompt_service.get_prompt(prompt_id, current_user)
        
        if not prompt:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Prompt not found"
            )
        
        return prompt
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting prompt {prompt_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get prompt"
        )


@router.put("/{prompt_id}", response_model=Prompt)
async def update_prompt(
    prompt_id: str,
    prompt_data: PromptUpdate,
    current_user: User = Depends(get_current_user)
):
    """Update prompt"""
    try:
        prompt_service = PromptService()
        updated_prompt = await prompt_service.update_prompt(prompt_id, prompt_data, current_user)
        
        if not updated_prompt:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Prompt not found"
            )
        
        return updated_prompt
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating prompt {prompt_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to update prompt"
        )


@router.delete("/{prompt_id}")
async def delete_prompt(
    prompt_id: str,
    current_user: User = Depends(get_current_user)
):
    """Delete prompt"""
    try:
        prompt_service = PromptService()
        success = await prompt_service.delete_prompt(prompt_id, current_user)
        
        if not success:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Prompt not found"
            )
        
        return {"message": "Prompt deleted successfully"}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting prompt {prompt_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to delete prompt"
        )


@router.post("/{prompt_id}/render", response_model=PromptRenderResponse)
async def render_prompt(
    prompt_id: str,
    render_request: PromptRenderRequest,
    current_user: User = Depends(get_current_user)
):
    """Render prompt with variables"""
    try:
        prompt_service = PromptService()
        rendered_prompt = await prompt_service.render_prompt(
            prompt_id, 
            render_request.variables, 
            current_user
        )
        
        return PromptRenderResponse(
            rendered_prompt=rendered_prompt,
            prompt_id=prompt_id,
            variables=render_request.variables
        )
        
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except Exception as e:
        logger.error(f"Error rendering prompt {prompt_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to render prompt"
        )

