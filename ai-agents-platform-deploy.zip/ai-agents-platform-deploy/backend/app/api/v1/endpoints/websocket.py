"""
WebSocket endpoints for real-time communication
"""

import json
import asyncio
from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Depends, HTTPException, status
from typing import Dict, Any
from app.core.websocket_manager import websocket_manager
from app.auth.dependencies import get_current_user_websocket
from app.core.logging import LoggerMixin

router = APIRouter()


class WebSocketHandler(LoggerMixin):
    """Handles WebSocket connections and messages"""
    
    def __init__(self):
        self.manager = websocket_manager
    
    async def handle_connection(self, websocket: WebSocket, user_id: str):
        """Handle a WebSocket connection lifecycle"""
        client_id = None
        
        try:
            # Connect and get client ID
            client_id = await self.manager.connect(websocket, user_id)
            self.logger.info(f"WebSocket connection established: {client_id} for user {user_id}")
            
            # Listen for messages
            while True:
                try:
                    # Receive message from client
                    data = await websocket.receive_text()
                    message_data = json.loads(data)
                    
                    # Handle the message
                    await self.manager.handle_client_message(client_id, message_data)
                    
                except WebSocketDisconnect:
                    self.logger.info(f"WebSocket disconnected: {client_id}")
                    break
                except json.JSONDecodeError:
                    self.logger.warning(f"Invalid JSON received from {client_id}")
                    await self.manager.send_json_message({
                        "type": "error",
                        "message": "Invalid JSON format"
                    }, client_id)
                except Exception as e:
                    self.logger.error(f"Error handling message from {client_id}: {e}")
                    await self.manager.send_json_message({
                        "type": "error",
                        "message": "Internal server error"
                    }, client_id)
        
        except Exception as e:
            self.logger.error(f"Error in WebSocket connection: {e}")
        
        finally:
            # Clean up connection
            if client_id:
                self.manager.disconnect(client_id)


# Global handler instance
websocket_handler = WebSocketHandler()


@router.websocket("/ws")
async def websocket_endpoint(
    websocket: WebSocket,
    user_id: str = Depends(get_current_user_websocket)
):
    """
    WebSocket endpoint for real-time communication
    
    Supports the following message types:
    - ping: Health check
    - subscribe: Subscribe to a topic
    - unsubscribe: Unsubscribe from a topic
    - subscribe_pipeline: Subscribe to pipeline updates
    - subscribe_execution: Subscribe to execution updates
    """
    await websocket_handler.handle_connection(websocket, user_id)


@router.get("/ws/stats")
async def get_websocket_stats(
    current_user: Dict[str, Any] = Depends(get_current_user_websocket)
):
    """Get WebSocket connection statistics"""
    try:
        stats = websocket_manager.get_connection_stats()
        return {
            "success": True,
            "data": stats
        }
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error getting WebSocket stats: {str(e)}"
        )


@router.post("/ws/broadcast")
async def broadcast_message(
    message_data: Dict[str, Any],
    current_user: Dict[str, Any] = Depends(get_current_user_websocket)
):
    """
    Broadcast a message to all connected clients
    (Admin only functionality)
    """
    try:
        # Check if user is admin
        if not current_user.get("is_admin", False):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Admin access required"
            )
        
        # Add sender information
        message_data["sender"] = current_user.get("id")
        message_data["sender_name"] = current_user.get("name", "Admin")
        
        # Broadcast message
        await websocket_manager.broadcast_json(message_data)
        
        return {
            "success": True,
            "message": "Message broadcasted successfully"
        }
    
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error broadcasting message: {str(e)}"
        )


@router.post("/ws/send-to-user/{user_id}")
async def send_to_user(
    user_id: str,
    message_data: Dict[str, Any],
    current_user: Dict[str, Any] = Depends(get_current_user_websocket)
):
    """
    Send a message to a specific user
    (Admin only functionality)
    """
    try:
        # Check if user is admin or sending to self
        if not current_user.get("is_admin", False) and current_user.get("id") != user_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Admin access required or can only send to self"
            )
        
        # Add sender information
        message_data["sender"] = current_user.get("id")
        message_data["sender_name"] = current_user.get("name", "System")
        
        # Send message to user
        sent_count = await websocket_manager.send_to_user(message_data, user_id)
        
        return {
            "success": True,
            "message": f"Message sent to {sent_count} connections for user {user_id}"
        }
    
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error sending message to user: {str(e)}"
        )


@router.post("/ws/broadcast-to-topic/{topic}")
async def broadcast_to_topic(
    topic: str,
    message_data: Dict[str, Any],
    current_user: Dict[str, Any] = Depends(get_current_user_websocket)
):
    """
    Broadcast a message to all subscribers of a topic
    """
    try:
        # Add sender information
        message_data["sender"] = current_user.get("id")
        message_data["sender_name"] = current_user.get("name", "User")
        
        # Broadcast to topic
        sent_count = await websocket_manager.broadcast_to_topic(topic, message_data)
        
        return {
            "success": True,
            "message": f"Message sent to {sent_count} subscribers of topic '{topic}'"
        }
    
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error broadcasting to topic: {str(e)}"
        )


@router.get("/ws/topics")
async def get_active_topics(
    current_user: Dict[str, Any] = Depends(get_current_user_websocket)
):
    """Get list of active topics with subscriber counts"""
    try:
        stats = websocket_manager.get_connection_stats()
        
        # Get topic information
        topics = []
        for topic, client_ids in websocket_manager.topic_subscribers.items():
            topics.append({
                "topic": topic,
                "subscriber_count": len(client_ids),
                "subscribers": list(client_ids) if current_user.get("is_admin", False) else None
            })
        
        return {
            "success": True,
            "data": {
                "topics": topics,
                "total_topics": len(topics),
                "total_connections": stats["total_connections"]
            }
        }
    
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error getting topics: {str(e)}"
        )


@router.get("/ws/connections")
async def get_active_connections(
    current_user: Dict[str, Any] = Depends(get_current_user_websocket)
):
    """
    Get list of active connections
    (Admin only functionality)
    """
    try:
        # Check if user is admin
        if not current_user.get("is_admin", False):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Admin access required"
            )
        
        connections = []
        for client_id, connection_info in websocket_manager.connections.items():
            connections.append({
                "client_id": client_id,
                "user_id": connection_info.user_id,
                "connected_at": connection_info.connected_at.isoformat(),
                "last_ping": connection_info.last_ping.isoformat() if connection_info.last_ping else None,
                "subscriptions": list(connection_info.subscriptions)
            })
        
        return {
            "success": True,
            "data": {
                "connections": connections,
                "total_connections": len(connections)
            }
        }
    
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error getting connections: {str(e)}"
        )


@router.delete("/ws/connections/{client_id}")
async def disconnect_client(
    client_id: str,
    current_user: Dict[str, Any] = Depends(get_current_user_websocket)
):
    """
    Disconnect a specific client
    (Admin only functionality)
    """
    try:
        # Check if user is admin
        if not current_user.get("is_admin", False):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Admin access required"
            )
        
        # Check if client exists
        if client_id not in websocket_manager.connections:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Client {client_id} not found"
            )
        
        # Disconnect client
        websocket_manager.disconnect(client_id)
        
        return {
            "success": True,
            "message": f"Client {client_id} disconnected successfully"
        }
    
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error disconnecting client: {str(e)}"
        )

