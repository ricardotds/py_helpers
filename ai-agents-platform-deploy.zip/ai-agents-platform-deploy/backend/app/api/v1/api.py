"""
API v1 router configuration
"""

from fastapi import APIRouter
from app.api.v1.endpoints import (
    auth,
    pipelines,
    tools,
    prompts,
    schemas,
    rag_indexes,
    execution,
    users,
    websocket,
    airflow
)

api_router = APIRouter()

# Include all endpoint routers
api_router.include_router(auth.router, prefix="/auth", tags=["authentication"])
api_router.include_router(users.router, prefix="/users", tags=["users"])
api_router.include_router(pipelines.router, prefix="/pipelines", tags=["pipelines"])
api_router.include_router(tools.router, prefix="/tools", tags=["tools"])
api_router.include_router(prompts.router, prefix="/prompts", tags=["prompts"])
api_router.include_router(schemas.router, prefix="/schemas", tags=["schemas"])
api_router.include_router(rag_indexes.router, prefix="/rag-indexes", tags=["rag-indexes"])
api_router.include_router(execution.router, prefix="/execution", tags=["execution"])
api_router.include_router(websocket.router, prefix="/websocket", tags=["websocket"])
api_router.include_router(airflow.router, prefix="/airflow", tags=["airflow"])

