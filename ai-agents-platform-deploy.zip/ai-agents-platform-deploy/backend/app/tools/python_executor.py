"""
Python tool executor for custom Python code execution
"""

import asyncio
import tempfile
import os
import sys
import json
import subprocess
from typing import Dict, Any
from app.tools.base_executor import BaseToolExecutor
from app.models.tool import Tool


class PythonExecutor(BaseToolExecutor):
    """Executor for Python tools (custom code execution)"""
    
    async def execute(
        self, 
        tool: Tool, 
        inputs: Dict[str, Any], 
        step_config: Dict[str, Any] = None
    ) -> Dict[str, Any]:
        """Execute Python tool"""
        try:
            # Merge configurations
            config = self._merge_config(tool.configuration, step_config)
            
            # Validate configuration
            self._validate_config(config, ["code"])
            
            code = config["code"]
            requirements = config.get("requirements", [])
            timeout = config.get("timeout", 60)
            
            # Create temporary directory for execution
            with tempfile.TemporaryDirectory() as temp_dir:
                # Create virtual environment
                venv_path = await self._create_venv(temp_dir, requirements)
                
                # Execute code
                result = await self._execute_code(venv_path, code, inputs, timeout)
                
                return result
                
        except Exception as e:
            self.logger.error(f"Python execution failed: {e}")
            raise Exception(f"Python execution failed: {str(e)}")
    
    async def _create_venv(self, temp_dir: str, requirements: list) -> str:
        """Create virtual environment with required packages"""
        try:
            venv_path = os.path.join(temp_dir, "venv")
            
            # Create virtual environment
            process = await asyncio.create_subprocess_exec(
                sys.executable, "-m", "venv", venv_path,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await process.communicate()
            
            if process.returncode != 0:
                raise Exception(f"Failed to create virtual environment: {stderr.decode()}")
            
            # Install requirements if any
            if requirements:
                pip_path = os.path.join(venv_path, "bin", "pip")
                if os.name == "nt":  # Windows
                    pip_path = os.path.join(venv_path, "Scripts", "pip.exe")
                
                for requirement in requirements:
                    process = await asyncio.create_subprocess_exec(
                        pip_path, "install", requirement,
                        stdout=asyncio.subprocess.PIPE,
                        stderr=asyncio.subprocess.PIPE
                    )
                    stdout, stderr = await process.communicate()
                    
                    if process.returncode != 0:
                        self.logger.warning(f"Failed to install {requirement}: {stderr.decode()}")
            
            return venv_path
            
        except Exception as e:
            raise Exception(f"Virtual environment creation failed: {str(e)}")
    
    async def _execute_code(
        self, 
        venv_path: str, 
        code: str, 
        inputs: Dict[str, Any], 
        timeout: int
    ) -> Dict[str, Any]:
        """Execute Python code in virtual environment"""
        try:
            # Prepare Python executable path
            python_path = os.path.join(venv_path, "bin", "python")
            if os.name == "nt":  # Windows
                python_path = os.path.join(venv_path, "Scripts", "python.exe")
            
            # Create execution script
            execution_script = self._create_execution_script(code, inputs)
            
            # Write script to temporary file
            script_path = os.path.join(os.path.dirname(venv_path), "script.py")
            with open(script_path, "w", encoding="utf-8") as f:
                f.write(execution_script)
            
            # Execute script
            process = await asyncio.create_subprocess_exec(
                python_path, script_path,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=os.path.dirname(venv_path)
            )
            
            try:
                stdout, stderr = await asyncio.wait_for(
                    process.communicate(), 
                    timeout=timeout
                )
            except asyncio.TimeoutError:
                process.kill()
                await process.wait()
                raise Exception(f"Code execution timed out after {timeout} seconds")
            
            # Parse results
            if process.returncode != 0:
                error_message = stderr.decode() if stderr else "Unknown error"
                raise Exception(f"Code execution failed: {error_message}")
            
            # Parse output
            output = stdout.decode() if stdout else ""
            
            try:
                # Try to parse as JSON (our execution wrapper should output JSON)
                result = json.loads(output)
                return result
            except json.JSONDecodeError:
                # If not JSON, return as text output
                return {
                    "output": output,
                    "error": stderr.decode() if stderr else None,
                    "return_code": process.returncode
                }
                
        except Exception as e:
            raise Exception(f"Code execution failed: {str(e)}")
    
    def _create_execution_script(self, user_code: str, inputs: Dict[str, Any]) -> str:
        """Create execution script that wraps user code"""
        
        # Prepare inputs as variables
        inputs_setup = ""
        for key, value in inputs.items():
            # Sanitize variable name
            if key.isidentifier():
                inputs_setup += f"{key} = {repr(value)}\n"
        
        # Create the execution script
        script = f"""
import json
import sys
import traceback
from typing import Any, Dict

# Set up inputs
inputs = {repr(inputs)}
{inputs_setup}

# Initialize outputs
outputs = {{}}

try:
    # User code execution
{self._indent_code(user_code, 4)}
    
    # Capture outputs
    result = {{
        "success": True,
        "outputs": outputs,
        "inputs": inputs
    }}
    
except Exception as e:
    result = {{
        "success": False,
        "error": str(e),
        "traceback": traceback.format_exc(),
        "inputs": inputs
    }}

# Output result as JSON
print(json.dumps(result, default=str))
"""
        return script
    
    def _indent_code(self, code: str, spaces: int) -> str:
        """Indent code by specified number of spaces"""
        indent = " " * spaces
        lines = code.split("\n")
        indented_lines = [indent + line if line.strip() else line for line in lines]
        return "\n".join(indented_lines)
    
    def _sanitize_code(self, code: str) -> str:
        """Basic code sanitization (remove dangerous imports/functions)"""
        # This is a basic implementation - in production, you'd want more sophisticated sandboxing
        dangerous_patterns = [
            "import os",
            "import subprocess",
            "import sys",
            "__import__",
            "eval(",
            "exec(",
            "open(",
            "file(",
            "input(",
            "raw_input("
        ]
        
        for pattern in dangerous_patterns:
            if pattern in code:
                self.logger.warning(f"Potentially dangerous code pattern detected: {pattern}")
        
        return code

