"""
LLM tool executor for Azure OpenAI and AWS Bedrock
"""

import json
import httpx
import boto3
from typing import Dict, Any, Optional
from app.tools.base_executor import BaseToolExecutor
from app.models.tool import Tool


class LLMExecutor(BaseToolExecutor):
    """Executor for LLM tools (Azure OpenAI and AWS Bedrock)"""
    
    async def execute(
        self, 
        tool: Tool, 
        inputs: Dict[str, Any], 
        step_config: Dict[str, Any] = None
    ) -> Dict[str, Any]:
        """Execute LLM tool"""
        try:
            # Merge configurations
            config = self._merge_config(tool.configuration, step_config)
            
            # Validate inputs
            self._validate_inputs(inputs, ["prompt"])
            
            # Validate configuration
            self._validate_config(config, ["provider", "model"])
            
            provider = config["provider"]
            
            if provider == "azure_openai":
                return await self._execute_azure_openai(config, inputs)
            elif provider == "aws_bedrock":
                return await self._execute_aws_bedrock(config, inputs)
            else:
                raise ValueError(f"Unsupported LLM provider: {provider}")
                
        except Exception as e:
            self.logger.error(f"LLM execution failed: {e}")
            raise
    
    async def _execute_azure_openai(self, config: Dict[str, Any], inputs: Dict[str, Any]) -> Dict[str, Any]:
        """Execute Azure OpenAI request"""
        try:
            # Validate Azure OpenAI configuration
            self._validate_config(config, ["endpoint", "api_key", "api_version"])
            
            endpoint = config["endpoint"].rstrip("/")
            api_key = config["api_key"]
            api_version = config["api_version"]
            model = config["model"]
            
            # Prepare request
            url = f"{endpoint}/openai/deployments/{model}/chat/completions"
            headers = {
                "Content-Type": "application/json",
                "api-key": api_key
            }
            
            # Build messages
            messages = []
            
            # Add system prompt if provided
            if "system_prompt" in inputs and inputs["system_prompt"]:
                messages.append({
                    "role": "system",
                    "content": inputs["system_prompt"]
                })
            
            # Add user prompt
            messages.append({
                "role": "user",
                "content": inputs["prompt"]
            })
            
            # Prepare request body
            request_body = {
                "messages": messages,
                "max_tokens": config.get("max_tokens", 1000),
                "temperature": config.get("temperature", 0.7),
                "top_p": config.get("top_p", 1.0),
                "frequency_penalty": config.get("frequency_penalty", 0.0),
                "presence_penalty": config.get("presence_penalty", 0.0)
            }
            
            # Add response format if structured output is requested
            if "response_format" in config:
                request_body["response_format"] = config["response_format"]
            
            # Make request
            async with httpx.AsyncClient() as client:
                response = await client.post(
                    url,
                    headers=headers,
                    json=request_body,
                    params={"api-version": api_version},
                    timeout=60.0
                )
                response.raise_for_status()
                
                result = response.json()
                
                # Extract response
                if "choices" in result and len(result["choices"]) > 0:
                    content = result["choices"][0]["message"]["content"]
                    
                    # Try to parse as JSON if structured output was requested
                    if "response_format" in config and config["response_format"].get("type") == "json_object":
                        try:
                            parsed_content = json.loads(content)
                            return {
                                "response": content,
                                "parsed_response": parsed_content,
                                "usage": result.get("usage", {}),
                                "model": result.get("model", model)
                            }
                        except json.JSONDecodeError:
                            self.logger.warning("Failed to parse JSON response")
                    
                    return {
                        "response": content,
                        "usage": result.get("usage", {}),
                        "model": result.get("model", model)
                    }
                else:
                    raise Exception("No response from Azure OpenAI")
                    
        except httpx.HTTPStatusError as e:
            error_detail = e.response.text if hasattr(e, 'response') else str(e)
            raise Exception(f"Azure OpenAI API error: {error_detail}")
        except Exception as e:
            raise Exception(f"Azure OpenAI execution failed: {str(e)}")
    
    async def _execute_aws_bedrock(self, config: Dict[str, Any], inputs: Dict[str, Any]) -> Dict[str, Any]:
        """Execute AWS Bedrock request"""
        try:
            # Validate AWS Bedrock configuration
            self._validate_config(config, ["region", "access_key_id", "secret_access_key"])
            
            region = config["region"]
            access_key_id = config["access_key_id"]
            secret_access_key = config["secret_access_key"]
            model = config["model"]
            
            # Create Bedrock client
            bedrock_client = boto3.client(
                "bedrock-runtime",
                region_name=region,
                aws_access_key_id=access_key_id,
                aws_secret_access_key=secret_access_key
            )
            
            # Prepare request based on model
            if model.startswith("anthropic.claude"):
                return await self._execute_claude(bedrock_client, model, config, inputs)
            elif model.startswith("amazon.titan"):
                return await self._execute_titan(bedrock_client, model, config, inputs)
            elif model.startswith("ai21.j2"):
                return await self._execute_jurassic(bedrock_client, model, config, inputs)
            else:
                raise ValueError(f"Unsupported Bedrock model: {model}")
                
        except Exception as e:
            raise Exception(f"AWS Bedrock execution failed: {str(e)}")
    
    async def _execute_claude(self, client, model: str, config: Dict[str, Any], inputs: Dict[str, Any]) -> Dict[str, Any]:
        """Execute Claude model on Bedrock"""
        try:
            # Build prompt for Claude
            prompt = ""
            
            if "system_prompt" in inputs and inputs["system_prompt"]:
                prompt += f"System: {inputs['system_prompt']}\n\n"
            
            prompt += f"Human: {inputs['prompt']}\n\nAssistant:"
            
            # Prepare request body
            request_body = {
                "prompt": prompt,
                "max_tokens_to_sample": config.get("max_tokens", 1000),
                "temperature": config.get("temperature", 0.7),
                "top_p": config.get("top_p", 1.0),
                "stop_sequences": config.get("stop_sequences", ["\n\nHuman:"])
            }
            
            # Make request
            response = client.invoke_model(
                modelId=model,
                body=json.dumps(request_body),
                contentType="application/json",
                accept="application/json"
            )
            
            # Parse response
            response_body = json.loads(response["body"].read())
            
            return {
                "response": response_body.get("completion", ""),
                "stop_reason": response_body.get("stop_reason"),
                "model": model
            }
            
        except Exception as e:
            raise Exception(f"Claude execution failed: {str(e)}")
    
    async def _execute_titan(self, client, model: str, config: Dict[str, Any], inputs: Dict[str, Any]) -> Dict[str, Any]:
        """Execute Titan model on Bedrock"""
        try:
            # Build prompt
            prompt = inputs["prompt"]
            if "system_prompt" in inputs and inputs["system_prompt"]:
                prompt = f"{inputs['system_prompt']}\n\n{prompt}"
            
            # Prepare request body
            request_body = {
                "inputText": prompt,
                "textGenerationConfig": {
                    "maxTokenCount": config.get("max_tokens", 1000),
                    "temperature": config.get("temperature", 0.7),
                    "topP": config.get("top_p", 1.0),
                    "stopSequences": config.get("stop_sequences", [])
                }
            }
            
            # Make request
            response = client.invoke_model(
                modelId=model,
                body=json.dumps(request_body),
                contentType="application/json",
                accept="application/json"
            )
            
            # Parse response
            response_body = json.loads(response["body"].read())
            
            results = response_body.get("results", [])
            if results:
                return {
                    "response": results[0].get("outputText", ""),
                    "completion_reason": results[0].get("completionReason"),
                    "model": model
                }
            else:
                raise Exception("No results from Titan model")
                
        except Exception as e:
            raise Exception(f"Titan execution failed: {str(e)}")
    
    async def _execute_jurassic(self, client, model: str, config: Dict[str, Any], inputs: Dict[str, Any]) -> Dict[str, Any]:
        """Execute Jurassic model on Bedrock"""
        try:
            # Build prompt
            prompt = inputs["prompt"]
            if "system_prompt" in inputs and inputs["system_prompt"]:
                prompt = f"{inputs['system_prompt']}\n\n{prompt}"
            
            # Prepare request body
            request_body = {
                "prompt": prompt,
                "maxTokens": config.get("max_tokens", 1000),
                "temperature": config.get("temperature", 0.7),
                "topP": config.get("top_p", 1.0),
                "stopSequences": config.get("stop_sequences", [])
            }
            
            # Make request
            response = client.invoke_model(
                modelId=model,
                body=json.dumps(request_body),
                contentType="application/json",
                accept="application/json"
            )
            
            # Parse response
            response_body = json.loads(response["body"].read())
            
            completions = response_body.get("completions", [])
            if completions:
                return {
                    "response": completions[0].get("data", {}).get("text", ""),
                    "finish_reason": completions[0].get("finishReason"),
                    "model": model
                }
            else:
                raise Exception("No completions from Jurassic model")
                
        except Exception as e:
            raise Exception(f"Jurassic execution failed: {str(e)}")

