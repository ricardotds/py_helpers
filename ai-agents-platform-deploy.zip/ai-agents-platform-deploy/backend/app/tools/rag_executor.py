"""
RAG tool executor for Azure AI Search integration
"""

import httpx
from typing import Dict, Any, List
from app.tools.base_executor import BaseToolExecutor
from app.models.tool import Tool
from app.services.rag_index_service import RAGIndexService
from app.models.rag_index import SearchQuery


class RAGExecutor(BaseToolExecutor):
    """Executor for RAG tools (Azure AI Search integration)"""
    
    def __init__(self):
        super().__init__()
        self.rag_service = RAGIndexService()
    
    async def execute(
        self, 
        tool: Tool, 
        inputs: Dict[str, Any], 
        step_config: Dict[str, Any] = None
    ) -> Dict[str, Any]:
        """Execute RAG tool"""
        try:
            # Merge configurations
            config = self._merge_config(tool.configuration, step_config)
            
            # Validate inputs
            self._validate_inputs(inputs, ["query"])
            
            # Validate configuration
            self._validate_config(config, ["rag_index_id"])
            
            rag_index_id = config["rag_index_id"]
            query = inputs["query"]
            
            # Get RAG index (we'll need to pass a user context here)
            # For now, we'll create a mock user or get it from the execution context
            # In a real implementation, this would be passed through the execution context
            
            # Prepare search query
            search_query = SearchQuery(
                query=query,
                top=config.get("top_k", 5),
                search_mode=config.get("search_mode", "any"),
                query_type=config.get("query_type", "simple"),
                search_fields=config.get("search_fields"),
                select_fields=config.get("select_fields"),
                filter=config.get("filter"),
                order_by=config.get("order_by"),
                highlight_fields=config.get("highlight_fields"),
                facets=config.get("facets"),
                semantic_configuration=config.get("semantic_configuration")
            )
            
            # Execute search directly using the RAG index configuration
            # We'll bypass the service layer for tool execution to avoid user context issues
            search_results = await self._execute_search_direct(rag_index_id, search_query, config)
            
            # Process results
            processed_results = self._process_search_results(search_results, config)
            
            return {
                "results": processed_results["documents"],
                "total_count": processed_results["total_count"],
                "query": query,
                "context": processed_results["context"],
                "sources": processed_results["sources"]
            }
            
        except Exception as e:
            self.logger.error(f"RAG execution failed: {e}")
            raise Exception(f"RAG execution failed: {str(e)}")
    
    async def _execute_search_direct(
        self, 
        rag_index_id: str, 
        search_query: SearchQuery, 
        config: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Execute search directly against Azure AI Search"""
        try:
            # Get RAG index configuration from database
            # For now, we'll use the configuration from the tool
            # In a real implementation, we'd fetch the RAG index from the database
            
            search_endpoint = config.get("search_endpoint")
            api_key = config.get("api_key")
            index_name = config.get("index_name")
            
            if not all([search_endpoint, api_key, index_name]):
                raise ValueError("Missing required RAG configuration: search_endpoint, api_key, or index_name")
            
            # Prepare search request
            search_url = f"{search_endpoint}/indexes/{index_name}/docs/search"
            
            headers = {
                "Content-Type": "application/json",
                "api-key": api_key
            }
            
            # Build search payload
            search_payload = {
                "search": search_query.query,
                "top": search_query.top,
                "skip": search_query.skip,
                "searchMode": search_query.search_mode,
                "queryType": search_query.query_type
            }
            
            if search_query.search_fields:
                search_payload["searchFields"] = ",".join(search_query.search_fields)
            
            if search_query.select_fields:
                search_payload["select"] = ",".join(search_query.select_fields)
            
            if search_query.filter:
                search_payload["filter"] = search_query.filter
            
            if search_query.order_by:
                search_payload["orderby"] = ",".join(search_query.order_by)
            
            if search_query.highlight_fields:
                search_payload["highlight"] = ",".join(search_query.highlight_fields)
            
            if search_query.facets:
                search_payload["facets"] = search_query.facets
            
            if search_query.semantic_configuration:
                search_payload["semanticConfiguration"] = search_query.semantic_configuration
            
            # Execute search
            async with httpx.AsyncClient() as client:
                response = await client.post(
                    search_url,
                    headers=headers,
                    json=search_payload,
                    timeout=30.0
                )
                response.raise_for_status()
                
                return response.json()
                
        except httpx.HTTPStatusError as e:
            error_detail = e.response.text if hasattr(e, 'response') else str(e)
            raise Exception(f"Azure AI Search API error: {error_detail}")
        except Exception as e:
            raise Exception(f"Search execution failed: {str(e)}")
    
    def _process_search_results(self, search_results: Dict[str, Any], config: Dict[str, Any]) -> Dict[str, Any]:
        """Process and format search results"""
        try:
            documents = []
            sources = []
            context_parts = []
            
            for doc in search_results.get("value", []):
                score = doc.pop("@search.score", 0.0)
                highlights = doc.pop("@search.highlights", None)
                captions = doc.pop("@search.captions", None)
                
                # Extract content for context
                content_field = config.get("content_field", "content")
                content = doc.get(content_field, "")
                
                if content:
                    context_parts.append(content)
                
                # Extract source information
                source_field = config.get("source_field", "source")
                source = doc.get(source_field, "")
                if source and source not in sources:
                    sources.append(source)
                
                # Format document
                formatted_doc = {
                    "content": content,
                    "score": score,
                    "metadata": doc,
                    "highlights": highlights,
                    "captions": captions
                }
                
                documents.append(formatted_doc)
            
            # Create context string
            context = self._create_context(context_parts, config)
            
            return {
                "documents": documents,
                "total_count": search_results.get("@odata.count", len(documents)),
                "context": context,
                "sources": sources,
                "facets": search_results.get("@search.facets")
            }
            
        except Exception as e:
            self.logger.warning(f"Result processing failed: {e}")
            return {
                "documents": [],
                "total_count": 0,
                "context": "",
                "sources": []
            }
    
    def _create_context(self, content_parts: List[str], config: Dict[str, Any]) -> str:
        """Create context string from search results"""
        try:
            max_context_length = config.get("max_context_length", 4000)
            separator = config.get("context_separator", "\n\n---\n\n")
            
            context = separator.join(content_parts)
            
            # Truncate if too long
            if len(context) > max_context_length:
                context = context[:max_context_length] + "..."
            
            return context
            
        except Exception as e:
            self.logger.warning(f"Context creation failed: {e}")
            return ""

