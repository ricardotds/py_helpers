"""
Base tool executor class
"""

from abc import ABC, abstractmethod
from typing import Dict, Any
from app.models.tool import Tool
from app.core.logging import LoggerMixin


class BaseToolExecutor(ABC, LoggerMixin):
    """Base class for all tool executors"""
    
    @abstractmethod
    async def execute(
        self, 
        tool: Tool, 
        inputs: Dict[str, Any], 
        step_config: Dict[str, Any] = None
    ) -> Dict[str, Any]:
        """
        Execute the tool with given inputs
        
        Args:
            tool: Tool configuration
            inputs: Input data for the tool
            step_config: Step-specific configuration overrides
            
        Returns:
            Dictionary containing tool outputs
        """
        pass
    
    def _merge_config(self, tool_config: Dict[str, Any], step_config: Dict[str, Any] = None) -> Dict[str, Any]:
        """Merge tool configuration with step-specific overrides"""
        merged_config = tool_config.copy()
        if step_config:
            merged_config.update(step_config)
        return merged_config
    
    def _validate_inputs(self, inputs: Dict[str, Any], required_inputs: list) -> None:
        """Validate that all required inputs are present"""
        missing_inputs = [inp for inp in required_inputs if inp not in inputs]
        if missing_inputs:
            raise ValueError(f"Missing required inputs: {missing_inputs}")
    
    def _validate_config(self, config: Dict[str, Any], required_config: list) -> None:
        """Validate that all required configuration parameters are present"""
        missing_config = [cfg for cfg in required_config if cfg not in config]
        if missing_config:
            raise ValueError(f"Missing required configuration: {missing_config}")

