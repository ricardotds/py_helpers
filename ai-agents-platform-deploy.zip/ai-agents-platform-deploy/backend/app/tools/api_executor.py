"""
API tool executor for generic HTTP API calls
"""

import httpx
import json
from typing import Dict, Any, Optional
from app.tools.base_executor import BaseToolExecutor
from app.models.tool import Tool


class APIExecutor(BaseToolExecutor):
    """Executor for API tools (generic HTTP requests)"""
    
    async def execute(
        self, 
        tool: Tool, 
        inputs: Dict[str, Any], 
        step_config: Dict[str, Any] = None
    ) -> Dict[str, Any]:
        """Execute API tool"""
        try:
            # Merge configurations
            config = self._merge_config(tool.configuration, step_config)
            
            # Validate configuration
            self._validate_config(config, ["url", "method"])
            
            url = config["url"]
            method = config["method"].upper()
            
            # Prepare headers
            headers = config.get("headers", {})
            if "Content-Type" not in headers and method in ["POST", "PUT", "PATCH"]:
                headers["Content-Type"] = "application/json"
            
            # Prepare authentication
            auth_config = config.get("authentication", {})
            auth = None
            
            if auth_config.get("type") == "basic":
                auth = httpx.BasicAuth(
                    auth_config["username"], 
                    auth_config["password"]
                )
            elif auth_config.get("type") == "bearer":
                headers["Authorization"] = f"Bearer {auth_config['token']}"
            elif auth_config.get("type") == "api_key":
                if auth_config.get("location") == "header":
                    headers[auth_config["key"]] = auth_config["value"]
                elif auth_config.get("location") == "query":
                    # Will be added to params below
                    pass
            
            # Prepare query parameters
            params = config.get("query_params", {})
            if auth_config.get("type") == "api_key" and auth_config.get("location") == "query":
                params[auth_config["key"]] = auth_config["value"]
            
            # Add dynamic parameters from inputs
            if "query_params" in inputs:
                params.update(inputs["query_params"])
            
            # Prepare request body
            body = None
            if method in ["POST", "PUT", "PATCH"]:
                if "body" in inputs:
                    body = inputs["body"]
                elif "json_body" in inputs:
                    body = inputs["json_body"]
                elif config.get("body_template"):
                    # Use body template with input substitution
                    body = self._substitute_template(config["body_template"], inputs)
            
            # URL parameter substitution
            url = self._substitute_url_params(url, inputs)
            
            # Make HTTP request
            async with httpx.AsyncClient() as client:
                response = await client.request(
                    method=method,
                    url=url,
                    headers=headers,
                    params=params,
                    json=body if isinstance(body, dict) else None,
                    content=body if isinstance(body, str) else None,
                    auth=auth,
                    timeout=config.get("timeout", 30.0),
                    follow_redirects=config.get("follow_redirects", True)
                )
                
                # Prepare response data
                response_data = {
                    "status_code": response.status_code,
                    "headers": dict(response.headers),
                    "url": str(response.url)
                }
                
                # Parse response body
                content_type = response.headers.get("content-type", "").lower()
                
                if "application/json" in content_type:
                    try:
                        response_data["json"] = response.json()
                        response_data["text"] = response.text
                    except json.JSONDecodeError:
                        response_data["text"] = response.text
                        response_data["json"] = None
                else:
                    response_data["text"] = response.text
                    response_data["json"] = None
                
                # Check if request was successful
                if config.get("raise_for_status", True):
                    response.raise_for_status()
                
                # Extract specific fields if configured
                if config.get("response_mapping"):
                    mapped_response = self._map_response(response_data, config["response_mapping"])
                    response_data.update(mapped_response)
                
                self.logger.info(f"API request completed: {method} {url} -> {response.status_code}")
                
                return response_data
                
        except httpx.HTTPStatusError as e:
            error_detail = {
                "status_code": e.response.status_code,
                "error": e.response.text,
                "url": str(e.response.url)
            }
            self.logger.error(f"API request failed: {error_detail}")
            raise Exception(f"API request failed: {error_detail}")
        except Exception as e:
            self.logger.error(f"API execution failed: {e}")
            raise Exception(f"API execution failed: {str(e)}")
    
    def _substitute_template(self, template: str, inputs: Dict[str, Any]) -> Any:
        """Substitute template variables with input values"""
        try:
            if isinstance(template, str):
                # Simple string substitution
                result = template
                for key, value in inputs.items():
                    placeholder = "{" + key + "}"
                    result = result.replace(placeholder, str(value))
                
                # Try to parse as JSON if it looks like JSON
                if result.strip().startswith(("{", "[")):
                    try:
                        return json.loads(result)
                    except json.JSONDecodeError:
                        pass
                
                return result
            elif isinstance(template, dict):
                # Recursive substitution for dict templates
                result = {}
                for key, value in template.items():
                    if isinstance(value, str):
                        result[key] = self._substitute_template(value, inputs)
                    elif isinstance(value, dict):
                        result[key] = self._substitute_template(value, inputs)
                    elif isinstance(value, list):
                        result[key] = [self._substitute_template(item, inputs) for item in value]
                    else:
                        result[key] = value
                return result
            else:
                return template
                
        except Exception as e:
            self.logger.warning(f"Template substitution failed: {e}")
            return template
    
    def _substitute_url_params(self, url: str, inputs: Dict[str, Any]) -> str:
        """Substitute URL path parameters"""
        try:
            result = url
            for key, value in inputs.items():
                placeholder = "{" + key + "}"
                result = result.replace(placeholder, str(value))
            return result
        except Exception as e:
            self.logger.warning(f"URL parameter substitution failed: {e}")
            return url
    
    def _map_response(self, response_data: Dict[str, Any], mapping: Dict[str, str]) -> Dict[str, Any]:
        """Map response fields to output fields"""
        try:
            mapped = {}
            
            for output_field, source_path in mapping.items():
                value = self._extract_nested_value(response_data, source_path)
                if value is not None:
                    mapped[output_field] = value
            
            return mapped
            
        except Exception as e:
            self.logger.warning(f"Response mapping failed: {e}")
            return {}
    
    def _extract_nested_value(self, data: Dict[str, Any], path: str) -> Any:
        """Extract nested value using dot notation (e.g., 'json.data.items[0].name')"""
        try:
            current = data
            parts = path.split(".")
            
            for part in parts:
                if "[" in part and "]" in part:
                    # Handle array indexing
                    field, index_part = part.split("[", 1)
                    index = int(index_part.rstrip("]"))
                    
                    if field:
                        current = current[field]
                    current = current[index]
                else:
                    current = current[part]
            
            return current
            
        except (KeyError, IndexError, ValueError, TypeError):
            return None

