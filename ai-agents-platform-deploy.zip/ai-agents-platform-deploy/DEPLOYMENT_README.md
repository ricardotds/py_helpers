# AI Agents Management Platform - Deployment Package

This deployment package contains everything you need to deploy the AI Agents Management Platform in various environments.

## 📦 Package Contents

```
ai-agents-platform-deploy/
├── deploy.sh                   # Automated deployment script
├── DEPLOYMENT_README.md        # This file
├── README.md                   # Main project documentation
├── FINAL_DELIVERY.md          # Complete project overview
├── backend/                   # FastAPI backend application
├── frontend/                  # React/TypeScript frontend
├── k8s/                      # Kubernetes deployment manifests
├── docker/                   # Docker configurations
└── docs/                     # Complete documentation
```

## 🚀 Quick Deployment

### Option 1: Automated Deployment Script

The `deploy.sh` script provides automated deployment for different environments:

```bash
# Setup development environment
./deploy.sh setup

# Deploy locally with Docker
./deploy.sh local

# Build Docker images
./deploy.sh build

# Deploy to Kubernetes
./deploy.sh k8s

# Show help
./deploy.sh help
```

### Option 2: Manual Deployment

#### Local Development

1. **Backend Setup**:
   ```bash
   cd backend
   python3 -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   cp .env.template .env
   # Edit .env with your configuration
   uvicorn app.main:app --reload
   ```

2. **Frontend Setup**:
   ```bash
   cd frontend
   npm install
   cp .env.example .env
   # Edit .env with your configuration
   npm run dev
   ```

#### Docker Deployment

```bash
# Build images
docker build -t ai-agents-backend:latest ./backend
docker build -t ai-agents-frontend:latest ./frontend

# Run with Docker Compose
docker-compose up -d
```

#### Kubernetes Deployment

```bash
cd k8s
kubectl apply -k overlays/production/
```

## 🔧 Configuration

### Required Environment Variables

#### Backend (.env)
```bash
# Database
MONGODB_URL=mongodb://your-cosmosdb.mongo.cosmos.azure.com:10255
DATABASE_NAME=ai_agents_platform

# Authentication
AZURE_CLIENT_ID=your-client-id
AZURE_CLIENT_SECRET=your-client-secret
AZURE_TENANT_ID=your-tenant-id

# AI Services
AZURE_OPENAI_ENDPOINT=https://your-openai.openai.azure.com
AZURE_OPENAI_API_KEY=your-openai-key
AWS_ACCESS_KEY_ID=your-aws-key
AWS_SECRET_ACCESS_KEY=your-aws-secret
AZURE_SEARCH_ENDPOINT=https://your-search.search.windows.net
AZURE_SEARCH_API_KEY=your-search-key
```

#### Frontend (.env)
```bash
REACT_APP_API_URL=http://localhost:8000
REACT_APP_AZURE_CLIENT_ID=your-client-id
REACT_APP_AZURE_TENANT_ID=your-tenant-id
```

## 📋 Prerequisites

### Local Development
- Python 3.11+
- Node.js 18+
- npm or yarn

### Docker Deployment
- Docker 20.10+
- Docker Compose 2.0+

### Kubernetes Deployment
- kubectl configured with cluster access
- Kubernetes 1.25+
- Helm 3.10+ (optional)

### Azure Resources
- Azure CosmosDB with MongoDB API
- Microsoft Entra ID application
- Azure OpenAI service (optional)
- Azure AI Search service (optional)
- Azure Kubernetes Service (for production)

## 🔐 Security Setup

### Microsoft Entra ID Configuration

1. **Create Azure AD Application**:
   ```bash
   az ad app create --display-name "AI Agents Platform"
   ```

2. **Configure Redirect URIs**:
   - Add your application URLs to the redirect URIs
   - For local development: `http://localhost:3000/auth/callback`
   - For production: `https://your-domain.com/auth/callback`

3. **Create Client Secret**:
   ```bash
   az ad app credential reset --id <app-id>
   ```

### Database Setup

1. **Create CosmosDB Account**:
   ```bash
   az cosmosdb create --name ai-agents-cosmosdb --resource-group your-rg --kind MongoDB
   ```

2. **Get Connection String**:
   ```bash
   az cosmosdb keys list --name ai-agents-cosmosdb --resource-group your-rg --type connection-strings
   ```

## 🚀 Deployment Environments

### Development
- Local development with hot reload
- Local MongoDB or CosmosDB emulator
- Development Azure AD application

### Staging
- Docker containers
- Staging database
- Staging Azure AD application
- Basic monitoring

### Production
- Kubernetes deployment on AKS
- Production CosmosDB
- Production Azure AD application
- Full monitoring and logging
- SSL/TLS certificates
- Auto-scaling

## 📊 Monitoring

### Health Checks
- Backend: `http://localhost:8000/health`
- Frontend: Application loads successfully
- Database: Connection test in backend logs

### Logs
- Backend logs: Check console output or container logs
- Frontend logs: Browser developer console
- Kubernetes logs: `kubectl logs -f deployment/backend -n ai-agents-platform`

## 🔧 Troubleshooting

### Common Issues

1. **Authentication Errors**:
   - Verify Azure AD application configuration
   - Check redirect URIs
   - Validate client ID and secret

2. **Database Connection**:
   - Verify CosmosDB connection string
   - Check network connectivity
   - Validate database name

3. **Docker Issues**:
   - Ensure Docker is running
   - Check port conflicts
   - Verify image builds

4. **Kubernetes Issues**:
   - Check cluster connectivity: `kubectl cluster-info`
   - Verify namespace creation
   - Check pod status: `kubectl get pods -n ai-agents-platform`

### Getting Help

1. **Documentation**: Check the `docs/` directory for comprehensive guides
2. **API Documentation**: Visit `/docs` endpoint for interactive API docs
3. **Logs**: Review application logs for error details
4. **Health Checks**: Use health endpoints to verify system status

## 📚 Documentation

- **README.md**: Main project documentation
- **FINAL_DELIVERY.md**: Complete project overview
- **docs/API_DOCUMENTATION.md**: REST API reference
- **docs/USER_GUIDE.md**: User manual and tutorials
- **docs/DEPLOYMENT_GUIDE.md**: Detailed deployment instructions
- **k8s/README.md**: Kubernetes-specific documentation

## 🎯 Next Steps

1. **Configure Environment**: Set up your Azure resources and environment variables
2. **Choose Deployment**: Select local, Docker, or Kubernetes deployment
3. **Run Deployment**: Use the automated script or manual instructions
4. **Verify Installation**: Check health endpoints and logs
5. **Create First Pipeline**: Start building your AI workflows!

## 📞 Support

For deployment support:
- Review the troubleshooting section above
- Check the comprehensive documentation in `docs/`
- Verify all prerequisites are met
- Ensure all environment variables are configured correctly

---

**Ready to deploy your AI Agents Management Platform!** 🚀

