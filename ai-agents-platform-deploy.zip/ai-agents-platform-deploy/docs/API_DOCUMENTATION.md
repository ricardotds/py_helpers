# AI Agents Management Platform - API Documentation

## Overview

The AI Agents Management Platform provides a comprehensive REST API for managing AI pipelines, tools, prompts, schemas, and RAG indexes. The API is built with FastAPI and provides automatic OpenAPI/Swagger documentation.

## Base URL

```
Production: https://your-domain.com/api/v1
Development: http://localhost:8000/api/v1
```

## Authentication

The API uses Microsoft Entra ID (Azure AD) OAuth2 authentication. All endpoints except authentication endpoints require a valid JWT token.

### Authentication Flow

1. **Get Authorization URL**
   ```http
   GET /api/v1/auth/login
   ```
   Returns the Microsoft OAuth2 authorization URL.

2. **Exchange Code for Token**
   ```http
   POST /api/v1/auth/callback
   Content-Type: application/json
   
   {
     "code": "authorization_code",
     "redirect_uri": "your_redirect_uri"
   }
   ```

3. **Use Token in Requests**
   ```http
   Authorization: Bearer <jwt_token>
   ```

## Core Resources

### Pipelines

Pipelines are the core orchestration units that define sequences of AI operations.

#### Pipeline Model

```json
{
  "id": "string",
  "name": "string",
  "description": "string",
  "owner_id": "string",
  "steps": [
    {
      "id": "string",
      "name": "string",
      "type": "llm|api|rag|python",
      "config": {},
      "depends_on": ["string"],
      "outputs": ["string"]
    }
  ],
  "outputs": [
    {
      "name": "string",
      "source_step": "string",
      "source_output": "string"
    }
  ],
  "created_at": "2023-01-01T00:00:00Z",
  "updated_at": "2023-01-01T00:00:00Z"
}
```

#### Pipeline Endpoints

- `GET /api/v1/pipelines` - List user's pipelines
- `POST /api/v1/pipelines` - Create new pipeline
- `GET /api/v1/pipelines/{id}` - Get pipeline by ID
- `PUT /api/v1/pipelines/{id}` - Update pipeline
- `DELETE /api/v1/pipelines/{id}` - Delete pipeline

### Tools

Tools define reusable AI capabilities that can be used in pipeline steps.

#### Tool Types

1. **LLM Tool** - Large Language Model interactions
   ```json
   {
     "type": "llm",
     "config": {
       "provider": "azure_openai|aws_bedrock",
       "model": "gpt-4|claude-3",
       "temperature": 0.7,
       "max_tokens": 1000
     }
   }
   ```

2. **API Tool** - HTTP API calls
   ```json
   {
     "type": "api",
     "config": {
       "url": "https://api.example.com/endpoint",
       "method": "GET|POST|PUT|DELETE",
       "headers": {},
       "auth": {}
     }
   }
   ```

3. **RAG Tool** - Retrieval Augmented Generation
   ```json
   {
     "type": "rag",
     "config": {
       "index_id": "string",
       "top_k": 5,
       "similarity_threshold": 0.8
     }
   }
   ```

4. **Python Tool** - Custom Python code execution
   ```json
   {
     "type": "python",
     "config": {
       "code": "def process(input_data): return input_data.upper()",
       "requirements": ["pandas", "numpy"]
     }
   }
   ```

#### Tool Endpoints

- `GET /api/v1/tools` - List user's tools
- `POST /api/v1/tools` - Create new tool
- `GET /api/v1/tools/{id}` - Get tool by ID
- `PUT /api/v1/tools/{id}` - Update tool
- `DELETE /api/v1/tools/{id}` - Delete tool

### Prompts

Prompts are reusable text templates for LLM interactions.

#### Prompt Model

```json
{
  "id": "string",
  "name": "string",
  "description": "string",
  "template": "string",
  "variables": ["string"],
  "owner_id": "string",
  "created_at": "2023-01-01T00:00:00Z",
  "updated_at": "2023-01-01T00:00:00Z"
}
```

#### Prompt Endpoints

- `GET /api/v1/prompts` - List user's prompts
- `POST /api/v1/prompts` - Create new prompt
- `GET /api/v1/prompts/{id}` - Get prompt by ID
- `PUT /api/v1/prompts/{id}` - Update prompt
- `DELETE /api/v1/prompts/{id}` - Delete prompt

### Schemas

Schemas define data structures for pipeline inputs and outputs.

#### Schema Model

```json
{
  "id": "string",
  "name": "string",
  "description": "string",
  "schema": {
    "type": "object",
    "properties": {},
    "required": []
  },
  "owner_id": "string",
  "created_at": "2023-01-01T00:00:00Z",
  "updated_at": "2023-01-01T00:00:00Z"
}
```

#### Schema Endpoints

- `GET /api/v1/schemas` - List user's schemas
- `POST /api/v1/schemas` - Create new schema
- `GET /api/v1/schemas/{id}` - Get schema by ID
- `PUT /api/v1/schemas/{id}` - Update schema
- `DELETE /api/v1/schemas/{id}` - Delete schema

### RAG Indexes

RAG indexes store and manage document embeddings for retrieval operations.

#### RAG Index Model

```json
{
  "id": "string",
  "name": "string",
  "description": "string",
  "index_name": "string",
  "embedding_model": "string",
  "chunk_size": 1000,
  "chunk_overlap": 200,
  "owner_id": "string",
  "created_at": "2023-01-01T00:00:00Z",
  "updated_at": "2023-01-01T00:00:00Z"
}
```

#### RAG Index Endpoints

- `GET /api/v1/rag-indexes` - List user's RAG indexes
- `POST /api/v1/rag-indexes` - Create new RAG index
- `GET /api/v1/rag-indexes/{id}` - Get RAG index by ID
- `PUT /api/v1/rag-indexes/{id}` - Update RAG index
- `DELETE /api/v1/rag-indexes/{id}` - Delete RAG index
- `POST /api/v1/rag-indexes/{id}/documents` - Add documents to index
- `DELETE /api/v1/rag-indexes/{id}/documents/{doc_id}` - Remove document from index

## Pipeline Execution

### Execute Pipeline

Execute a pipeline with input data.

```http
POST /api/v1/execution/run/{pipeline_id}
Content-Type: application/json

{
  "inputs": {
    "key": "value"
  },
  "config": {
    "timeout": 300,
    "retry_count": 3
  }
}
```

### Monitor Execution

Monitor pipeline execution in real-time using WebSocket.

```javascript
const ws = new WebSocket('ws://localhost:8000/api/v1/ws/execution/{execution_id}');
ws.onmessage = function(event) {
  const data = JSON.parse(event.data);
  console.log('Execution update:', data);
};
```

### Execution Status

Get execution status and results.

```http
GET /api/v1/execution/{execution_id}
```

## Airflow Integration

### Deploy Pipeline

Deploy a pipeline to Airflow for scheduled execution.

```http
POST /api/v1/airflow/deploy/{pipeline_id}
Content-Type: application/json

{
  "schedule_interval": "@daily",
  "start_date": "2023-01-01",
  "catchup": false,
  "tags": ["production"]
}
```

### Manage DAGs

- `GET /api/v1/airflow/dags` - List deployed DAGs
- `POST /api/v1/airflow/dags/{dag_id}/trigger` - Trigger DAG run
- `DELETE /api/v1/airflow/dags/{dag_id}` - Remove DAG

## Error Handling

The API uses standard HTTP status codes and returns error details in JSON format.

### Error Response Format

```json
{
  "detail": "Error message",
  "error_code": "VALIDATION_ERROR",
  "timestamp": "2023-01-01T00:00:00Z"
}
```

### Common Status Codes

- `200` - Success
- `201` - Created
- `204` - No Content
- `400` - Bad Request
- `401` - Unauthorized
- `403` - Forbidden
- `404` - Not Found
- `422` - Validation Error
- `500` - Internal Server Error

## Rate Limiting

The API implements rate limiting to ensure fair usage:

- **Authenticated users**: 1000 requests per hour
- **Pipeline execution**: 100 executions per hour
- **File uploads**: 50 uploads per hour

Rate limit headers are included in responses:

```http
X-RateLimit-Limit: 1000
X-RateLimit-Remaining: 999
X-RateLimit-Reset: 1640995200
```

## Pagination

List endpoints support pagination using query parameters:

```http
GET /api/v1/pipelines?skip=0&limit=20&sort=created_at&order=desc
```

### Pagination Response

```json
{
  "data": [],
  "total": 100,
  "skip": 0,
  "limit": 20,
  "has_more": true
}
```

## WebSocket Events

Real-time events are available via WebSocket connections:

### Connection

```javascript
const ws = new WebSocket('ws://localhost:8000/api/v1/ws');
```

### Event Types

- `execution.started` - Pipeline execution started
- `execution.step_completed` - Pipeline step completed
- `execution.completed` - Pipeline execution completed
- `execution.failed` - Pipeline execution failed
- `system.maintenance` - System maintenance notifications

## SDK and Examples

### Python SDK Example

```python
from ai_agents_client import AIAgentsClient

client = AIAgentsClient(
    base_url="https://api.example.com",
    token="your_jwt_token"
)

# Create a pipeline
pipeline = client.pipelines.create({
    "name": "My Pipeline",
    "description": "A sample pipeline",
    "steps": [
        {
            "id": "step1",
            "name": "Generate Text",
            "type": "llm",
            "config": {
                "model": "gpt-4",
                "temperature": 0.7
            }
        }
    ]
})

# Execute the pipeline
execution = client.execution.run(pipeline.id, {
    "inputs": {"prompt": "Hello, world!"}
})
```

### JavaScript SDK Example

```javascript
import { AIAgentsClient } from '@ai-agents/client';

const client = new AIAgentsClient({
  baseUrl: 'https://api.example.com',
  token: 'your_jwt_token'
});

// Create and execute pipeline
const pipeline = await client.pipelines.create({
  name: 'My Pipeline',
  steps: [/* ... */]
});

const execution = await client.execution.run(pipeline.id, {
  inputs: { prompt: 'Hello, world!' }
});
```

## OpenAPI Specification

The complete OpenAPI specification is available at:

- **Swagger UI**: `http://localhost:8000/docs`
- **ReDoc**: `http://localhost:8000/redoc`
- **OpenAPI JSON**: `http://localhost:8000/openapi.json`

## Support

For API support and questions:

- **Documentation**: [https://docs.ai-agents-platform.com](https://docs.ai-agents-platform.com)
- **GitHub Issues**: [https://github.com/your-org/ai-agents-platform/issues](https://github.com/your-org/ai-agents-platform/issues)
- **Email**: support@ai-agents-platform.com

