# AI Agents Management Platform - User Guide

## Table of Contents

1. [Getting Started](#getting-started)
2. [Dashboard Overview](#dashboard-overview)
3. [Managing Prompts](#managing-prompts)
4. [Creating Tools](#creating-tools)
5. [Defining Schemas](#defining-schemas)
6. [Setting up RAG Indexes](#setting-up-rag-indexes)
7. [Building Pipelines](#building-pipelines)
8. [Executing Pipelines](#executing-pipelines)
9. [Monitoring and Logs](#monitoring-and-logs)
10. [Airflow Integration](#airflow-integration)
11. [Best Practices](#best-practices)
12. [Troubleshooting](#troubleshooting)

## Getting Started

### Prerequisites

- Microsoft Entra ID (Azure AD) account
- Access to the AI Agents Management Platform
- Basic understanding of AI/ML concepts

### First Login

1. Navigate to the platform URL
2. Click "Sign in with Microsoft"
3. Complete the OAuth2 authentication flow
4. You'll be redirected to the dashboard

### Initial Setup

After your first login:

1. **Review your profile** - Check your user information and permissions
2. **Explore the dashboard** - Familiarize yourself with the interface
3. **Create your first prompt** - Start with a simple text template
4. **Set up a basic tool** - Configure an LLM tool for text generation

## Dashboard Overview

The dashboard provides a comprehensive view of your AI agents platform:

### Key Metrics

- **Total Pipelines**: Number of pipelines you've created
- **Active Executions**: Currently running pipeline executions
- **Tools Available**: Number of tools in your toolkit
- **Recent Activity**: Latest pipeline runs and system events

### Quick Actions

- **Create Pipeline**: Start building a new AI workflow
- **Run Pipeline**: Execute an existing pipeline
- **View Executions**: Monitor pipeline execution history
- **Manage Resources**: Access tools, prompts, schemas, and RAG indexes

### Navigation

- **Pipelines**: Main workflow management
- **Tools**: AI tool configuration and management
- **Prompts**: Text template library
- **Schemas**: Data structure definitions
- **RAG Indexes**: Document knowledge bases
- **Executions**: Execution history and monitoring

## Managing Prompts

Prompts are reusable text templates that can include variables for dynamic content.

### Creating a Prompt

1. Navigate to **Prompts** section
2. Click **"Create Prompt"**
3. Fill in the details:
   - **Name**: Descriptive name for the prompt
   - **Description**: Purpose and usage notes
   - **Template**: The prompt text with variables
   - **Variables**: List of variable names used in the template

### Prompt Template Syntax

Use `{variable_name}` syntax for variables:

```text
You are a helpful assistant. Please {task} the following text:

Text: {input_text}

Please provide a {output_format} response.
```

Variables: `task`, `input_text`, `output_format`

### Example Prompts

**Text Summarization**:
```text
Summarize the following text in {max_sentences} sentences:

{text_to_summarize}

Focus on the main points and key insights.
```

**Code Review**:
```text
Review the following {programming_language} code for:
- Code quality
- Best practices
- Potential bugs
- Performance improvements

Code:
{code_to_review}
```

## Creating Tools

Tools define reusable AI capabilities that can be used in pipeline steps.

### LLM Tools

Configure Large Language Model tools for text generation and analysis.

#### Azure OpenAI Tool

1. **Provider**: Select "Azure OpenAI"
2. **Model**: Choose from available models (gpt-4, gpt-3.5-turbo, etc.)
3. **Configuration**:
   - **Temperature**: 0.0-1.0 (creativity level)
   - **Max Tokens**: Maximum response length
   - **Top P**: Nucleus sampling parameter
   - **Frequency Penalty**: Repetition reduction

#### AWS Bedrock Tool

1. **Provider**: Select "AWS Bedrock"
2. **Model**: Choose from Bedrock models (Claude, Jurassic, etc.)
3. **Configuration**: Model-specific parameters

### API Tools

Create tools for HTTP API integrations.

#### Configuration

1. **URL**: API endpoint URL
2. **Method**: HTTP method (GET, POST, PUT, DELETE)
3. **Headers**: Required headers (Authorization, Content-Type, etc.)
4. **Authentication**: API key, OAuth, or other auth methods
5. **Request Body**: Template for POST/PUT requests

#### Example API Tool

```json
{
  "name": "Weather API",
  "url": "https://api.weather.com/v1/current",
  "method": "GET",
  "headers": {
    "X-API-Key": "{api_key}"
  },
  "query_params": {
    "location": "{location}",
    "units": "metric"
  }
}
```

### RAG Tools

Configure Retrieval Augmented Generation tools for knowledge-based responses.

#### Setup

1. **Index Selection**: Choose a RAG index
2. **Retrieval Parameters**:
   - **Top K**: Number of documents to retrieve
   - **Similarity Threshold**: Minimum similarity score
   - **Rerank**: Enable result reranking

### Python Tools

Create custom Python code execution tools.

#### Code Requirements

- Function must be named `process`
- Accept input parameters
- Return serializable output
- Handle errors gracefully

#### Example Python Tool

```python
def process(input_data):
    """
    Process input data and return results
    """
    import pandas as pd
    
    # Convert input to DataFrame
    df = pd.DataFrame(input_data)
    
    # Perform analysis
    summary = {
        'total_rows': len(df),
        'columns': list(df.columns),
        'summary_stats': df.describe().to_dict()
    }
    
    return summary
```

## Defining Schemas

Schemas define data structures for pipeline inputs and outputs using JSON Schema format.

### Creating a Schema

1. Navigate to **Schemas** section
2. Click **"Create Schema"**
3. Define the JSON schema structure

### Example Schemas

**User Profile Schema**:
```json
{
  "type": "object",
  "properties": {
    "name": {
      "type": "string",
      "minLength": 1
    },
    "email": {
      "type": "string",
      "format": "email"
    },
    "age": {
      "type": "integer",
      "minimum": 0,
      "maximum": 150
    },
    "preferences": {
      "type": "array",
      "items": {
        "type": "string"
      }
    }
  },
  "required": ["name", "email"]
}
```

**API Response Schema**:
```json
{
  "type": "object",
  "properties": {
    "status": {
      "type": "string",
      "enum": ["success", "error"]
    },
    "data": {
      "type": "object"
    },
    "message": {
      "type": "string"
    },
    "timestamp": {
      "type": "string",
      "format": "date-time"
    }
  },
  "required": ["status"]
}
```

## Setting up RAG Indexes

RAG (Retrieval Augmented Generation) indexes store document embeddings for knowledge-based AI responses.

### Creating a RAG Index

1. Navigate to **RAG Indexes** section
2. Click **"Create RAG Index"**
3. Configure the index:
   - **Name**: Descriptive name
   - **Description**: Purpose and content description
   - **Embedding Model**: Text embedding model
   - **Chunk Size**: Document chunk size (default: 1000)
   - **Chunk Overlap**: Overlap between chunks (default: 200)

### Adding Documents

1. Select your RAG index
2. Click **"Add Documents"**
3. Upload files or paste text content
4. Wait for processing and embedding generation

### Supported Document Types

- **Text files** (.txt, .md)
- **PDF documents** (.pdf)
- **Word documents** (.docx)
- **Web pages** (via URL)
- **JSON data** (.json)

### Best Practices for RAG

- **Chunk Size**: Use 500-1500 characters for optimal retrieval
- **Document Quality**: Ensure clean, well-formatted content
- **Metadata**: Add relevant metadata for better filtering
- **Regular Updates**: Keep content current and relevant

## Building Pipelines

Pipelines orchestrate multiple AI tools into complex workflows.

### Pipeline Structure

A pipeline consists of:
- **Steps**: Individual AI operations
- **Dependencies**: Step execution order
- **Inputs**: Pipeline input parameters
- **Outputs**: Final pipeline results

### Creating a Pipeline

1. Navigate to **Pipelines** section
2. Click **"Create Pipeline"**
3. Define pipeline metadata:
   - **Name**: Descriptive pipeline name
   - **Description**: Purpose and functionality

### Adding Steps

1. Click **"Add Step"**
2. Configure step details:
   - **Step ID**: Unique identifier
   - **Name**: Human-readable name
   - **Type**: Tool type (LLM, API, RAG, Python)
   - **Tool**: Select configured tool
   - **Configuration**: Step-specific settings
   - **Dependencies**: Previous steps this step depends on

### Step Configuration Examples

**LLM Step**:
```json
{
  "id": "summarize_text",
  "name": "Summarize Content",
  "type": "llm",
  "tool_id": "gpt4_tool",
  "config": {
    "prompt_id": "summarization_prompt",
    "variables": {
      "max_sentences": 3,
      "text_to_summarize": "{input.content}"
    }
  },
  "depends_on": []
}
```

**API Step**:
```json
{
  "id": "fetch_weather",
  "name": "Get Weather Data",
  "type": "api",
  "tool_id": "weather_api",
  "config": {
    "variables": {
      "location": "{input.location}",
      "api_key": "{env.WEATHER_API_KEY}"
    }
  },
  "depends_on": []
}
```

**RAG Step**:
```json
{
  "id": "knowledge_lookup",
  "name": "Search Knowledge Base",
  "type": "rag",
  "tool_id": "company_docs_rag",
  "config": {
    "query": "{steps.summarize_text.output}",
    "top_k": 5
  },
  "depends_on": ["summarize_text"]
}
```

### Pipeline Outputs

Define what data the pipeline should return:

```json
{
  "outputs": [
    {
      "name": "summary",
      "source_step": "summarize_text",
      "source_output": "text"
    },
    {
      "name": "weather_info",
      "source_step": "fetch_weather",
      "source_output": "data"
    }
  ]
}
```

## Executing Pipelines

### Manual Execution

1. Navigate to your pipeline
2. Click **"Execute"**
3. Provide input data in JSON format
4. Click **"Run Pipeline"**
5. Monitor execution progress

### Input Data Format

Provide inputs as JSON object:

```json
{
  "content": "Long article text to summarize...",
  "location": "New York, NY",
  "user_preferences": {
    "format": "bullet_points",
    "length": "short"
  }
}
```

### Execution Monitoring

- **Real-time Updates**: Watch step-by-step progress
- **Logs**: View detailed execution logs
- **Errors**: See error messages and stack traces
- **Results**: Access final pipeline outputs

## Monitoring and Logs

### Execution History

View all pipeline executions:
- **Status**: Success, Failed, Running
- **Duration**: Execution time
- **Inputs/Outputs**: Data used and produced
- **Logs**: Detailed execution information

### Real-time Monitoring

Use WebSocket connections for live updates:
- Step completion notifications
- Progress indicators
- Error alerts
- Performance metrics

### Log Analysis

Execution logs include:
- **Timestamps**: When each step executed
- **Input/Output Data**: Data flow between steps
- **Performance Metrics**: Execution times and resource usage
- **Error Details**: Stack traces and error messages

## Airflow Integration

Deploy pipelines to Apache Airflow for scheduled and automated execution.

### Deploying a Pipeline

1. Navigate to your pipeline
2. Click **"Deploy to Airflow"**
3. Configure deployment settings:
   - **Schedule**: Cron expression or preset intervals
   - **Start Date**: When to begin scheduling
   - **Catchup**: Whether to run missed executions
   - **Tags**: Organizational labels

### Schedule Examples

- **Daily at 9 AM**: `0 9 * * *`
- **Every hour**: `0 * * * *`
- **Weekdays only**: `0 9 * * 1-5`
- **Monthly**: `0 0 1 * *`

### Managing DAGs

- **View DAGs**: See all deployed pipelines
- **Trigger Runs**: Manually start executions
- **Monitor Status**: Check DAG health and performance
- **Update Configuration**: Modify scheduling and parameters

## Best Practices

### Pipeline Design

1. **Modular Steps**: Keep steps focused and reusable
2. **Error Handling**: Plan for failure scenarios
3. **Data Validation**: Validate inputs and outputs
4. **Documentation**: Document step purposes and configurations

### Performance Optimization

1. **Parallel Execution**: Design independent steps to run in parallel
2. **Caching**: Cache expensive operations when possible
3. **Resource Limits**: Set appropriate timeouts and limits
4. **Monitoring**: Track performance metrics

### Security

1. **Sensitive Data**: Use environment variables for secrets
2. **Access Control**: Implement proper user permissions
3. **Input Validation**: Sanitize all user inputs
4. **Audit Logs**: Maintain execution audit trails

### Maintenance

1. **Regular Updates**: Keep tools and prompts current
2. **Testing**: Test pipelines before production deployment
3. **Backup**: Regularly backup pipeline configurations
4. **Monitoring**: Set up alerts for failures and performance issues

## Troubleshooting

### Common Issues

#### Pipeline Execution Failures

**Symptom**: Pipeline stops with error
**Solutions**:
- Check step dependencies and data flow
- Verify tool configurations
- Review input data format
- Check API credentials and endpoints

#### Slow Performance

**Symptom**: Pipelines take too long to execute
**Solutions**:
- Optimize step configurations
- Reduce data processing overhead
- Check network connectivity
- Review resource allocation

#### Authentication Errors

**Symptom**: "Unauthorized" or "Forbidden" errors
**Solutions**:
- Refresh authentication token
- Check user permissions
- Verify API credentials
- Contact administrator for access

### Getting Help

1. **Documentation**: Check this user guide and API documentation
2. **Logs**: Review execution logs for error details
3. **Support**: Contact support team with specific error messages
4. **Community**: Join user forums and discussion groups

### Error Codes

- **400**: Bad Request - Check input data format
- **401**: Unauthorized - Authentication required
- **403**: Forbidden - Insufficient permissions
- **404**: Not Found - Resource doesn't exist
- **422**: Validation Error - Data validation failed
- **500**: Internal Server Error - System issue, contact support

## Advanced Features

### Custom Python Tools

Create sophisticated data processing tools:

```python
def process(input_data):
    import pandas as pd
    import numpy as np
    from sklearn.feature_extraction.text import TfidfVectorizer
    
    # Advanced text analysis
    texts = input_data.get('texts', [])
    
    # TF-IDF analysis
    vectorizer = TfidfVectorizer(max_features=100)
    tfidf_matrix = vectorizer.fit_transform(texts)
    
    # Extract key terms
    feature_names = vectorizer.get_feature_names_out()
    scores = tfidf_matrix.sum(axis=0).A1
    
    # Return analysis results
    return {
        'key_terms': dict(zip(feature_names, scores)),
        'document_count': len(texts),
        'vocabulary_size': len(feature_names)
    }
```

### Conditional Logic

Implement conditional execution in pipelines:

```json
{
  "id": "conditional_step",
  "name": "Conditional Processing",
  "type": "python",
  "config": {
    "code": "def process(input_data): return input_data if input_data.get('score', 0) > 0.8 else None"
  },
  "condition": "{steps.analysis.output.confidence} > 0.8"
}
```

### Batch Processing

Process multiple items in parallel:

```json
{
  "id": "batch_process",
  "name": "Batch Text Analysis",
  "type": "llm",
  "config": {
    "batch_size": 10,
    "parallel": true
  }
}
```

This completes the comprehensive user guide for the AI Agents Management Platform. Users can refer to this guide to understand all aspects of the platform, from basic usage to advanced features.

