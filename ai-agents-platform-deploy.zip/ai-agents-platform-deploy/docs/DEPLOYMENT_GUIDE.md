# AI Agents Management Platform - Deployment Guide

## Table of Contents

1. [Overview](#overview)
2. [Prerequisites](#prerequisites)
3. [Environment Setup](#environment-setup)
4. [Azure Resources](#azure-resources)
5. [Local Development](#local-development)
6. [Docker Deployment](#docker-deployment)
7. [Kubernetes Deployment](#kubernetes-deployment)
8. [Production Deployment](#production-deployment)
9. [Configuration](#configuration)
10. [Monitoring and Logging](#monitoring-and-logging)
11. [Security](#security)
12. [Troubleshooting](#troubleshooting)

## Overview

The AI Agents Management Platform is designed for cloud-native deployment on Azure Kubernetes Service (AKS) with support for local development and Docker-based deployments.

### Architecture Components

- **Backend**: FastAPI application with CosmosDB
- **Frontend**: React application with TypeScript
- **Database**: Azure CosmosDB with MongoDB API
- **Authentication**: Microsoft Entra ID (Azure AD)
- **Container Registry**: Azure Container Registry (ACR)
- **Orchestration**: Azure Kubernetes Service (AKS)
- **Pipeline Execution**: Apache Airflow
- **Monitoring**: Azure Monitor and Application Insights

## Prerequisites

### Required Tools

- **Azure CLI** (v2.50+)
- **kubectl** (v1.25+)
- **Docker** (v20.10+)
- **Node.js** (v18+)
- **Python** (v3.11+)
- **Helm** (v3.10+)

### Azure Subscriptions and Permissions

- Azure subscription with Owner or Contributor role
- Permission to create Azure AD applications
- Access to create AKS clusters and associated resources

### Install Required Tools

```bash
# Install Azure CLI
curl -sL https://aka.ms/InstallAzureCLIDeb | sudo bash

# Install kubectl
curl -LO "https://dl.k8s.io/release/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/linux/amd64/kubectl"
sudo install -o root -g root -m 0755 kubectl /usr/local/bin/kubectl

# Install Helm
curl https://get.helm.sh/helm-v3.12.0-linux-amd64.tar.gz | tar xz
sudo mv linux-amd64/helm /usr/local/bin/

# Install Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh
```

## Environment Setup

### Clone Repository

```bash
git clone https://github.com/your-org/ai-agents-platform.git
cd ai-agents-platform
```

### Environment Variables

Create environment files for different deployment stages:

#### Development (.env.development)

```bash
# Application
APP_NAME=AI Agents Management Platform
DEBUG=true
API_V1_STR=/api/v1

# Database
MONGODB_URL=mongodb://localhost:27017
DATABASE_NAME=ai_agents_platform_dev

# Authentication
AZURE_CLIENT_ID=your-dev-client-id
AZURE_CLIENT_SECRET=your-dev-client-secret
AZURE_TENANT_ID=your-tenant-id
AZURE_AUTHORITY=https://login.microsoftonline.com

# JWT
SECRET_KEY=your-development-secret-key
ACCESS_TOKEN_EXPIRE_MINUTES=30

# AI Services
AZURE_OPENAI_ENDPOINT=https://your-openai.openai.azure.com
AZURE_OPENAI_API_KEY=your-openai-key
AWS_ACCESS_KEY_ID=your-aws-key
AWS_SECRET_ACCESS_KEY=your-aws-secret
AZURE_SEARCH_ENDPOINT=https://your-search.search.windows.net
AZURE_SEARCH_API_KEY=your-search-key

# Airflow
AIRFLOW_WEBSERVER_URL=http://localhost:8080
AIRFLOW_USERNAME=admin
AIRFLOW_PASSWORD=admin
```

#### Production (.env.production)

```bash
# Application
APP_NAME=AI Agents Management Platform
DEBUG=false
API_V1_STR=/api/v1

# Database
MONGODB_URL=mongodb://your-cosmosdb.mongo.cosmos.azure.com:10255
DATABASE_NAME=ai_agents_platform

# Authentication
AZURE_CLIENT_ID=your-prod-client-id
AZURE_CLIENT_SECRET=your-prod-client-secret
AZURE_TENANT_ID=your-tenant-id

# JWT
SECRET_KEY=your-production-secret-key-very-secure
ACCESS_TOKEN_EXPIRE_MINUTES=60

# AI Services (use Azure Key Vault references)
AZURE_OPENAI_ENDPOINT=https://your-prod-openai.openai.azure.com
AZURE_OPENAI_API_KEY=@Microsoft.KeyVault(SecretUri=https://your-kv.vault.azure.net/secrets/openai-key/)
```

## Azure Resources

### Create Resource Group

```bash
# Set variables
RESOURCE_GROUP="ai-agents-platform-rg"
LOCATION="eastus"
SUBSCRIPTION_ID="your-subscription-id"

# Create resource group
az group create --name $RESOURCE_GROUP --location $LOCATION
```

### Azure Container Registry

```bash
ACR_NAME="aiagentsplatformacr"

# Create ACR
az acr create \
  --resource-group $RESOURCE_GROUP \
  --name $ACR_NAME \
  --sku Standard \
  --admin-enabled true

# Get ACR credentials
az acr credential show --name $ACR_NAME
```

### CosmosDB Setup

```bash
COSMOSDB_ACCOUNT="ai-agents-cosmosdb"

# Create CosmosDB account with MongoDB API
az cosmosdb create \
  --resource-group $RESOURCE_GROUP \
  --name $COSMOSDB_ACCOUNT \
  --kind MongoDB \
  --server-version 4.2 \
  --default-consistency-level Session \
  --locations regionName=$LOCATION failoverPriority=0 isZoneRedundant=False

# Create database
az cosmosdb mongodb database create \
  --account-name $COSMOSDB_ACCOUNT \
  --resource-group $RESOURCE_GROUP \
  --name ai_agents_platform

# Get connection string
az cosmosdb keys list \
  --name $COSMOSDB_ACCOUNT \
  --resource-group $RESOURCE_GROUP \
  --type connection-strings
```

### Azure Kubernetes Service

```bash
AKS_CLUSTER="ai-agents-aks"
NODE_COUNT=3

# Create AKS cluster
az aks create \
  --resource-group $RESOURCE_GROUP \
  --name $AKS_CLUSTER \
  --node-count $NODE_COUNT \
  --node-vm-size Standard_D4s_v3 \
  --enable-addons monitoring \
  --attach-acr $ACR_NAME \
  --generate-ssh-keys

# Get AKS credentials
az aks get-credentials \
  --resource-group $RESOURCE_GROUP \
  --name $AKS_CLUSTER
```

### Azure AD Application

```bash
# Create Azure AD application
az ad app create \
  --display-name "AI Agents Platform" \
  --web-redirect-uris "https://your-domain.com/auth/callback" \
  --required-resource-accesses @manifest.json

# Create service principal
az ad sp create --id <app-id>

# Create client secret
az ad app credential reset --id <app-id>
```

## Local Development

### Backend Setup

```bash
cd backend

# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Set up environment
cp .env.template .env
# Edit .env with your configuration

# Run database migrations (if any)
python -m alembic upgrade head

# Start development server
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

### Frontend Setup

```bash
cd frontend

# Install dependencies
npm install

# Set up environment
cp .env.example .env
# Edit .env with your configuration

# Start development server
npm run dev
```

### Local Airflow Setup

```bash
# Install Airflow
pip install apache-airflow[postgres,redis]==2.7.0

# Initialize database
airflow db init

# Create admin user
airflow users create \
  --username admin \
  --firstname Admin \
  --lastname User \
  --role Admin \
  --email admin@example.com

# Start Airflow services
airflow webserver --port 8080 &
airflow scheduler &
```

## Docker Deployment

### Build Images

```bash
# Build backend image
docker build -t ai-agents-backend:latest ./backend

# Build frontend image
docker build -t ai-agents-frontend:latest ./frontend

# Build executor image
docker build -t ai-agents-executor:latest ./docker/generic-executor
```

### Docker Compose

Create `docker-compose.yml`:

```yaml
version: '3.8'

services:
  mongodb:
    image: mongo:6.0
    ports:
      - "27017:27017"
    environment:
      MONGO_INITDB_ROOT_USERNAME: admin
      MONGO_INITDB_ROOT_PASSWORD: password
    volumes:
      - mongodb_data:/data/db

  backend:
    build: ./backend
    ports:
      - "8000:8000"
    environment:
      - MONGODB_URL=mongodb://admin:password@mongodb:27017
      - DATABASE_NAME=ai_agents_platform
    depends_on:
      - mongodb
    volumes:
      - ./backend:/app

  frontend:
    build: ./frontend
    ports:
      - "3000:3000"
    environment:
      - REACT_APP_API_URL=http://localhost:8000
    depends_on:
      - backend

  airflow-webserver:
    image: apache/airflow:2.7.0
    ports:
      - "8080:8080"
    environment:
      - AIRFLOW__CORE__EXECUTOR=LocalExecutor
      - AIRFLOW__DATABASE__SQL_ALCHEMY_CONN=postgresql+psycopg2://airflow:airflow@postgres/airflow
    depends_on:
      - postgres

  postgres:
    image: postgres:13
    environment:
      - POSTGRES_USER=airflow
      - POSTGRES_PASSWORD=airflow
      - POSTGRES_DB=airflow
    volumes:
      - postgres_data:/var/lib/postgresql/data

volumes:
  mongodb_data:
  postgres_data:
```

### Run with Docker Compose

```bash
# Start all services
docker-compose up -d

# View logs
docker-compose logs -f

# Stop services
docker-compose down
```

## Kubernetes Deployment

### Push Images to ACR

```bash
# Tag and push backend image
docker tag ai-agents-backend:latest $ACR_NAME.azurecr.io/ai-agents-backend:latest
docker push $ACR_NAME.azurecr.io/ai-agents-backend:latest

# Tag and push frontend image
docker tag ai-agents-frontend:latest $ACR_NAME.azurecr.io/ai-agents-frontend:latest
docker push $ACR_NAME.azurecr.io/ai-agents-frontend:latest

# Tag and push executor image
docker tag ai-agents-executor:latest $ACR_NAME.azurecr.io/ai-agents-executor:latest
docker push $ACR_NAME.azurecr.io/ai-agents-executor:latest
```

### Deploy to Kubernetes

```bash
# Navigate to k8s directory
cd k8s

# Create namespaces
kubectl apply -f base/namespaces.yaml

# Deploy base components
kubectl apply -k base/

# Deploy production overlay
kubectl apply -k overlays/production/
```

### Verify Deployment

```bash
# Check pod status
kubectl get pods -n ai-agents-platform

# Check services
kubectl get services -n ai-agents-platform

# Check ingress
kubectl get ingress -n ai-agents-platform

# View logs
kubectl logs -f deployment/backend -n ai-agents-platform
```

## Production Deployment

### SSL/TLS Setup

```bash
# Install cert-manager
kubectl apply -f https://github.com/cert-manager/cert-manager/releases/download/v1.12.0/cert-manager.yaml

# Create ClusterIssuer for Let's Encrypt
kubectl apply -f - <<EOF
apiVersion: cert-manager.io/v1
kind: ClusterIssuer
metadata:
  name: letsencrypt-prod
spec:
  acme:
    server: https://acme-v02.api.letsencrypt.org/directory
    email: your-email@example.com
    privateKeySecretRef:
      name: letsencrypt-prod
    solvers:
    - http01:
        ingress:
          class: nginx
EOF
```

### Domain Configuration

Update ingress with your domain:

```yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: ai-agents-ingress
  annotations:
    cert-manager.io/cluster-issuer: letsencrypt-prod
    nginx.ingress.kubernetes.io/ssl-redirect: "true"
spec:
  tls:
  - hosts:
    - your-domain.com
    secretName: ai-agents-tls
  rules:
  - host: your-domain.com
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: frontend
            port:
              number: 80
      - path: /api
        pathType: Prefix
        backend:
          service:
            name: backend
            port:
              number: 8000
```

### Scaling Configuration

```bash
# Enable cluster autoscaler
az aks update \
  --resource-group $RESOURCE_GROUP \
  --name $AKS_CLUSTER \
  --enable-cluster-autoscaler \
  --min-count 1 \
  --max-count 10

# Configure horizontal pod autoscaler
kubectl apply -f - <<EOF
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: backend-hpa
  namespace: ai-agents-platform
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: backend
  minReplicas: 2
  maxReplicas: 10
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
EOF
```

## Configuration

### Environment-Specific Configurations

#### Development

```yaml
# k8s/overlays/development/kustomization.yaml
apiVersion: kustomize.config.k8s.io/v1beta1
kind: Kustomization

resources:
- ../../base

patchesStrategicMerge:
- backend-patch.yaml
- frontend-patch.yaml

configMapGenerator:
- name: backend-config
  literals:
  - DEBUG=true
  - LOG_LEVEL=DEBUG
```

#### Staging

```yaml
# k8s/overlays/staging/kustomization.yaml
apiVersion: kustomize.config.k8s.io/v1beta1
kind: Kustomization

resources:
- ../../base

patchesStrategicMerge:
- backend-patch.yaml
- frontend-patch.yaml

configMapGenerator:
- name: backend-config
  literals:
  - DEBUG=false
  - LOG_LEVEL=INFO
```

#### Production

```yaml
# k8s/overlays/production/kustomization.yaml
apiVersion: kustomize.config.k8s.io/v1beta1
kind: Kustomization

resources:
- ../../base

patchesStrategicMerge:
- backend-patch.yaml
- frontend-patch.yaml
- ingress-patch.yaml

configMapGenerator:
- name: backend-config
  literals:
  - DEBUG=false
  - LOG_LEVEL=WARNING
```

### Secret Management

```bash
# Create secrets for production
kubectl create secret generic backend-secrets \
  --from-literal=SECRET_KEY="your-production-secret" \
  --from-literal=AZURE_CLIENT_SECRET="your-client-secret" \
  --from-literal=MONGODB_URL="your-cosmosdb-connection-string" \
  -n ai-agents-platform

# Create secrets for AI services
kubectl create secret generic ai-services-secrets \
  --from-literal=AZURE_OPENAI_API_KEY="your-openai-key" \
  --from-literal=AWS_SECRET_ACCESS_KEY="your-aws-secret" \
  --from-literal=AZURE_SEARCH_API_KEY="your-search-key" \
  -n ai-agents-platform
```

## Monitoring and Logging

### Azure Monitor Integration

```bash
# Enable Azure Monitor for containers
az aks enable-addons \
  --resource-group $RESOURCE_GROUP \
  --name $AKS_CLUSTER \
  --addons monitoring
```

### Application Insights

```yaml
# Add to backend deployment
apiVersion: apps/v1
kind: Deployment
metadata:
  name: backend
spec:
  template:
    spec:
      containers:
      - name: backend
        env:
        - name: APPLICATIONINSIGHTS_CONNECTION_STRING
          value: "your-app-insights-connection-string"
```

### Prometheus and Grafana

```bash
# Install Prometheus
helm repo add prometheus-community https://prometheus-community.github.io/helm-charts
helm install prometheus prometheus-community/kube-prometheus-stack \
  --namespace monitoring \
  --create-namespace

# Access Grafana
kubectl port-forward svc/prometheus-grafana 3000:80 -n monitoring
```

### Log Aggregation

```yaml
# Fluentd configuration for log collection
apiVersion: v1
kind: ConfigMap
metadata:
  name: fluentd-config
data:
  fluent.conf: |
    <source>
      @type tail
      path /var/log/containers/*.log
      pos_file /var/log/fluentd-containers.log.pos
      tag kubernetes.*
      format json
    </source>
    
    <match kubernetes.**>
      @type azure-loganalytics
      customer_id "your-workspace-id"
      shared_key "your-workspace-key"
      log_type ContainerLogs
    </match>
```

## Security

### Network Security

```yaml
# Network policy for backend
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: backend-network-policy
  namespace: ai-agents-platform
spec:
  podSelector:
    matchLabels:
      app: backend
  policyTypes:
  - Ingress
  - Egress
  ingress:
  - from:
    - podSelector:
        matchLabels:
          app: frontend
    - namespaceSelector:
        matchLabels:
          name: ingress-nginx
    ports:
    - protocol: TCP
      port: 8000
```

### Pod Security Standards

```yaml
# Pod security policy
apiVersion: v1
kind: Namespace
metadata:
  name: ai-agents-platform
  labels:
    pod-security.kubernetes.io/enforce: restricted
    pod-security.kubernetes.io/audit: restricted
    pod-security.kubernetes.io/warn: restricted
```

### RBAC Configuration

```yaml
# Service account and RBAC
apiVersion: v1
kind: ServiceAccount
metadata:
  name: ai-agents-backend
  namespace: ai-agents-platform
---
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  name: ai-agents-backend-role
  namespace: ai-agents-platform
rules:
- apiGroups: [""]
  resources: ["pods", "services"]
  verbs: ["get", "list", "create", "delete"]
---
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: ai-agents-backend-binding
  namespace: ai-agents-platform
subjects:
- kind: ServiceAccount
  name: ai-agents-backend
  namespace: ai-agents-platform
roleRef:
  kind: Role
  name: ai-agents-backend-role
  apiGroup: rbac.authorization.k8s.io
```

## Troubleshooting

### Common Issues

#### Pod Startup Failures

```bash
# Check pod status
kubectl get pods -n ai-agents-platform

# Describe pod for events
kubectl describe pod <pod-name> -n ai-agents-platform

# Check logs
kubectl logs <pod-name> -n ai-agents-platform

# Check resource limits
kubectl top pods -n ai-agents-platform
```

#### Database Connection Issues

```bash
# Test CosmosDB connectivity
kubectl run -it --rm debug --image=mongo:6.0 --restart=Never -- \
  mongo "mongodb://username:password@cosmosdb-host:10255/database?ssl=true"

# Check DNS resolution
kubectl run -it --rm debug --image=busybox --restart=Never -- \
  nslookup your-cosmosdb.mongo.cosmos.azure.com
```

#### Authentication Problems

```bash
# Verify Azure AD configuration
az ad app show --id <app-id>

# Check redirect URIs
az ad app show --id <app-id> --query "web.redirectUris"

# Test token validation
curl -H "Authorization: Bearer <token>" \
  https://your-domain.com/api/v1/auth/me
```

### Performance Issues

```bash
# Check resource usage
kubectl top nodes
kubectl top pods -n ai-agents-platform

# Analyze slow queries (if using MongoDB)
kubectl exec -it <backend-pod> -n ai-agents-platform -- \
  python -c "
import pymongo
client = pymongo.MongoClient('connection-string')
db = client.ai_agents_platform
print(db.command('currentOp'))
"
```

### Debugging Tools

```bash
# Port forward for local debugging
kubectl port-forward svc/backend 8000:8000 -n ai-agents-platform

# Execute commands in pods
kubectl exec -it <pod-name> -n ai-agents-platform -- /bin/bash

# Copy files from pods
kubectl cp <pod-name>:/path/to/file ./local-file -n ai-agents-platform
```

## Backup and Recovery

### Database Backup

```bash
# CosmosDB backup (automatic by default)
az cosmosdb backup show \
  --resource-group $RESOURCE_GROUP \
  --account-name $COSMOSDB_ACCOUNT

# Manual export
az cosmosdb collection export \
  --resource-group $RESOURCE_GROUP \
  --account-name $COSMOSDB_ACCOUNT \
  --database-name ai_agents_platform \
  --collection-name pipelines \
  --output-file pipelines-backup.json
```

### Configuration Backup

```bash
# Backup Kubernetes configurations
kubectl get all -n ai-agents-platform -o yaml > k8s-backup.yaml

# Backup secrets (be careful with sensitive data)
kubectl get secrets -n ai-agents-platform -o yaml > secrets-backup.yaml
```

### Disaster Recovery

```bash
# Restore from backup
kubectl apply -f k8s-backup.yaml

# Restore secrets
kubectl apply -f secrets-backup.yaml

# Verify restoration
kubectl get pods -n ai-agents-platform
```

This comprehensive deployment guide covers all aspects of deploying the AI Agents Management Platform from local development to production-ready Kubernetes deployment on Azure.

