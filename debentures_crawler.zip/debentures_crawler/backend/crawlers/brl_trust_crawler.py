from .base_crawler import BaseCrawler
from typing import Dict, List, Any
import asyncio

class BRLTrustCrawler(BaseCrawler):
    """Crawler for BRL Trust DTVM S.A."""
    
    def __init__(self):
        super().__init__()
        self.base_url = "https://www.apexgroup.com"
        self.documents_url = "https://www.apexgroup.com/apex-brazil/documentos-regulatorios/"
        self.agent_name = "BRL Trust DTVM S.A."
        self.agent_id = "brl_trust"
    
    async def crawl(self) -> Dict[str, Any]:
        """Crawl BRL Trust (Apex Group) website for debenture documents"""
        documents = []
        
        try:
            # Navigate to the regulatory documents page
            page = self.get_page(self.documents_url)
            soup = self.parse_html(page.text)
            
            # Look for PDF links on the page
            pdf_links = self.extract_pdf_links(soup, self.base_url)
            
            # Convert PDF links to document entries
            for pdf_link in pdf_links:
                doc_type = "Documento Regulatório"
                title_lower = pdf_link['title'].lower()
                
                if any(keyword in title_lower for keyword in ['debênture', 'debenture']):
                    doc_type = "Debênture"
                elif any(keyword in title_lower for keyword in ['assembleia', 'assembly']):
                    doc_type = "Assembleia"
                elif any(keyword in title_lower for keyword in ['evento', 'event']):
                    doc_type = "Evento"
                elif any(keyword in title_lower for keyword in ['emissão', 'emission']):
                    doc_type = "Emissão"
                elif any(keyword in title_lower for keyword in ['brl trust', 'dtvm']):
                    doc_type = "Documento DTVM"
                elif any(keyword in title_lower for keyword in ['demonstrações', 'financeiras']):
                    doc_type = "Demonstrações Financeiras"
                
                document = self.create_document_entry(
                    title=pdf_link['title'],
                    doc_type=doc_type,
                    pdf_url=pdf_link['url'],
                    description=f"Documento extraído do site {self.agent_name}"
                )
                documents.append(document)
            
            # Remove duplicates based on URL
            seen_urls = set()
            unique_documents = []
            for doc in documents:
                if doc['pdf_url'] not in seen_urls:
                    seen_urls.add(doc['pdf_url'])
                    unique_documents.append(doc)
            
            return self.create_response(self.agent_name, self.agent_id, unique_documents)
            
        except Exception as e:
            return {
                'agent_name': self.agent_name,
                'agent_id': self.agent_id,
                'documents': [],
                'total_documents': 0,
                'last_updated': None,
                'status': 'error',
                'error': str(e)
            }

