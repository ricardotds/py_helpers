from .base_crawler import BaseCrawler
from typing import Dict, List, Any
import asyncio
import time

class PentagonoCrawler(BaseCrawler):
    """Crawler for Pentágono S.A. DTVM"""
    
    def __init__(self):
        super().__init__()
        self.base_url = "https://www.pentagonotrustee.com.br"
        self.agent_name = "Pentágono S.A. DTVM"
        self.agent_id = "pentagono"
    
    async def crawl(self) -> Dict[str, Any]:
        """Crawl Pentágono website for debenture documents"""
        documents = []
        
        try:
            # Navigate to main page
            main_page = self.get_page(self.base_url)
            soup = self.parse_html(main_page.text)
            
            # Simulate the process we identified:
            # 1. Select product 'Debêntures'
            # 2. Select year (2024)
            # 3. Click 'Ver Relatórios'
            
            # For now, we'll try to find direct links to debenture documents
            # In a real implementation, we would use Selenium to interact with dropdowns
            
            # Look for any PDF links on the main page
            pdf_links = self.extract_pdf_links(soup, self.base_url)
            
            # Try to find a reports or documents section
            reports_links = soup.find_all('a', href=True)
            for link in reports_links:
                href = link.get('href', '')
                text = link.get_text(strip=True).lower()
                
                if any(keyword in text for keyword in ['relatório', 'documento', 'debênture', 'emissão']):
                    try:
                        # Visit the link to find more documents
                        if href.startswith('http'):
                            page_url = href
                        else:
                            page_url = self.base_url.rstrip('/') + '/' + href.lstrip('/')
                        
                        page = self.get_page(page_url)
                        page_soup = self.parse_html(page.text)
                        page_pdfs = self.extract_pdf_links(page_soup, self.base_url)
                        pdf_links.extend(page_pdfs)
                        
                        # Add delay to be respectful
                        await asyncio.sleep(1)
                        
                    except Exception as e:
                        print(f"Error accessing {href}: {e}")
                        continue
            
            # Convert PDF links to document entries
            for pdf_link in pdf_links:
                doc_type = "Debênture"
                if any(keyword in pdf_link['title'].lower() for keyword in ['assembleia', 'assembly']):
                    doc_type = "Assembleia"
                elif any(keyword in pdf_link['title'].lower() for keyword in ['evento', 'event']):
                    doc_type = "Evento"
                elif any(keyword in pdf_link['title'].lower() for keyword in ['emissão', 'emission']):
                    doc_type = "Emissão"
                
                document = self.create_document_entry(
                    title=pdf_link['title'],
                    doc_type=doc_type,
                    pdf_url=pdf_link['url'],
                    description=f"Documento extraído do site {self.agent_name}"
                )
                documents.append(document)
            
            # Remove duplicates based on URL
            seen_urls = set()
            unique_documents = []
            for doc in documents:
                if doc['pdf_url'] not in seen_urls:
                    seen_urls.add(doc['pdf_url'])
                    unique_documents.append(doc)
            
            return self.create_response(self.agent_name, self.agent_id, unique_documents)
            
        except Exception as e:
            return {
                'agent_name': self.agent_name,
                'agent_id': self.agent_id,
                'documents': [],
                'total_documents': 0,
                'last_updated': None,
                'status': 'error',
                'error': str(e)
            }

