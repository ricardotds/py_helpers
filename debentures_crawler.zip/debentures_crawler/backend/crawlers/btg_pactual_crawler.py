from .base_crawler import BaseCrawler
from typing import Dict, List, Any
import asyncio

class BTGPactualCrawler(BaseCrawler):
    """Crawler for BTG Pactual Serviços Financeiros S.A. DTVM"""
    
    def __init__(self):
        super().__init__()
        self.base_url = "https://www.btgpactual.com"
        self.agent_name = "BTG Pactual Serviços Financeiros S.A. DTVM"
        self.agent_id = "btg_pactual"
    
    async def crawl(self) -> Dict[str, Any]:
        """Crawl BTG Pactual website for debenture documents"""
        documents = []
        
        try:
            # Navigate to main page
            main_page = self.get_page(self.base_url)
            soup = self.parse_html(main_page.text)
            
            # Look for investor relations or documents sections
            ri_links = soup.find_all('a', href=True)
            for link in ri_links:
                text = link.get_text(strip=True).lower()
                if any(keyword in text for keyword in ['investidor', 'investor', 'ri', 'documentos', 'documents']):
                    try:
                        href = link.get('href', '')
                        if href.startswith('http'):
                            link_url = href
                        else:
                            link_url = self.base_url.rstrip('/') + '/' + href.lstrip('/')
                        
                        # Visit the link
                        link_page = self.get_page(link_url)
                        link_soup = self.parse_html(link_page.text)
                        
                        # Look for PDF links
                        pdf_links = self.extract_pdf_links(link_soup, self.base_url)
                        
                        # Convert PDF links to document entries
                        for pdf_link in pdf_links:
                            doc_type = "Documento"
                            title_lower = pdf_link['title'].lower()
                            
                            if any(keyword in title_lower for keyword in ['debênture', 'debenture']):
                                doc_type = "Debênture"
                            elif any(keyword in title_lower for keyword in ['assembleia', 'assembly']):
                                doc_type = "Assembleia"
                            elif any(keyword in title_lower for keyword in ['evento', 'event']):
                                doc_type = "Evento"
                            elif any(keyword in title_lower for keyword in ['emissão', 'emission']):
                                doc_type = "Emissão"
                            elif any(keyword in title_lower for keyword in ['renda fixa', 'fixed income']):
                                doc_type = "Renda Fixa"
                            
                            document = self.create_document_entry(
                                title=pdf_link['title'],
                                doc_type=doc_type,
                                pdf_url=pdf_link['url'],
                                description=f"Documento extraído do site {self.agent_name}"
                            )
                            documents.append(document)
                        
                        await asyncio.sleep(1)
                        
                    except Exception as e:
                        print(f"Error accessing {href}: {e}")
                        continue
            
            # Remove duplicates based on URL
            seen_urls = set()
            unique_documents = []
            for doc in documents:
                if doc['pdf_url'] not in seen_urls:
                    seen_urls.add(doc['pdf_url'])
                    unique_documents.append(doc)
            
            return self.create_response(self.agent_name, self.agent_id, unique_documents)
            
        except Exception as e:
            return {
                'agent_name': self.agent_name,
                'agent_id': self.agent_id,
                'documents': [],
                'total_documents': 0,
                'last_updated': None,
                'status': 'error',
                'error': str(e)
            }

