from .base_crawler import BaseCrawler
from typing import Dict, List, Any
import asyncio

class XPCrawler(BaseCrawler):
    """Crawler for XP Investimentos CCTVM S.A."""
    
    def __init__(self):
        super().__init__()
        self.base_url = "https://www.xpi.com.br"
        self.ri_url = "https://investors.xpinc.com"
        self.agent_name = "XP Investimentos CCTVM S.A."
        self.agent_id = "xp"
    
    async def crawl(self) -> Dict[str, Any]:
        """Crawl XP Investimentos website for debenture documents"""
        documents = []
        
        try:
            # Try the main XP website first
            main_page = self.get_page(self.base_url)
            soup = self.parse_html(main_page.text)
            
            # Look for PDF links on the main page
            pdf_links = self.extract_pdf_links(soup, self.base_url)
            
            # Try the investor relations website
            try:
                ri_page = self.get_page(self.ri_url)
                ri_soup = self.parse_html(ri_page.text)
                ri_pdfs = self.extract_pdf_links(ri_soup, self.ri_url)
                pdf_links.extend(ri_pdfs)
            except Exception as e:
                print(f"Error accessing RI website: {e}")
            
            # Look for documents or investor relations sections
            doc_links = soup.find_all('a', href=True)
            for link in doc_links:
                text = link.get_text(strip=True).lower()
                if any(keyword in text for keyword in ['documento', 'document', 'investidor', 'investor', 'ri']):
                    try:
                        href = link.get('href', '')
                        if href.startswith('http'):
                            link_url = href
                        else:
                            link_url = self.base_url.rstrip('/') + '/' + href.lstrip('/')
                        
                        # Visit the link
                        link_page = self.get_page(link_url)
                        link_soup = self.parse_html(link_page.text)
                        link_pdfs = self.extract_pdf_links(link_soup, self.base_url)
                        pdf_links.extend(link_pdfs)
                        
                        await asyncio.sleep(1)
                        
                    except Exception as e:
                        print(f"Error accessing {href}: {e}")
                        continue
            
            # Convert PDF links to document entries
            for pdf_link in pdf_links:
                doc_type = "Documento"
                title_lower = pdf_link['title'].lower()
                
                if any(keyword in title_lower for keyword in ['debênture', 'debenture']):
                    doc_type = "Debênture"
                elif any(keyword in title_lower for keyword in ['assembleia', 'assembly']):
                    doc_type = "Assembleia"
                elif any(keyword in title_lower for keyword in ['evento', 'event']):
                    doc_type = "Evento"
                elif any(keyword in title_lower for keyword in ['emissão', 'emission']):
                    doc_type = "Emissão"
                elif any(keyword in title_lower for keyword in ['prospecto', 'prospectus']):
                    doc_type = "Prospecto"
                elif any(keyword in title_lower for keyword in ['relatório', 'report']):
                    doc_type = "Relatório"
                
                document = self.create_document_entry(
                    title=pdf_link['title'],
                    doc_type=doc_type,
                    pdf_url=pdf_link['url'],
                    description=f"Documento extraído do site {self.agent_name}"
                )
                documents.append(document)
            
            # Remove duplicates based on URL
            seen_urls = set()
            unique_documents = []
            for doc in documents:
                if doc['pdf_url'] not in seen_urls:
                    seen_urls.add(doc['pdf_url'])
                    unique_documents.append(doc)
            
            return self.create_response(self.agent_name, self.agent_id, unique_documents)
            
        except Exception as e:
            return {
                'agent_name': self.agent_name,
                'agent_id': self.agent_id,
                'documents': [],
                'total_documents': 0,
                'last_updated': None,
                'status': 'error',
                'error': str(e)
            }

