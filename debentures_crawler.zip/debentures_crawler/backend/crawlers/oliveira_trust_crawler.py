from .base_crawler import BaseCrawler
from typing import Dict, List, Any
import asyncio

class OliveiraTrustCrawler(BaseCrawler):
    """Crawler for Oliveira Trust DTVM"""
    
    def __init__(self):
        super().__init__()
        self.base_url = "https://www.oliveiratrust.com.br"
        self.agent_name = "Oliveira Trust DTVM"
        self.agent_id = "oliveira_trust"
    
    async def crawl(self) -> Dict[str, Any]:
        """Crawl Oliveira Trust website for debenture documents"""
        documents = []
        
        try:
            # Navigate to the documents page
            documents_url = f"{self.base_url}/investidor/documentos"
            page = self.get_page(documents_url)
            soup = self.parse_html(page.text)
            
            # Look for PDF links on the page
            pdf_links = self.extract_pdf_links(soup, self.base_url)
            
            # Look for debenture-related sections or filters
            debenture_sections = soup.find_all(['div', 'section', 'table'], class_=True)
            for section in debenture_sections:
                section_text = section.get_text(strip=True).lower()
                if any(keyword in section_text for keyword in ['debênture', 'debenture']):
                    section_pdfs = self.extract_pdf_links(section, self.base_url)
                    pdf_links.extend(section_pdfs)
            
            # Look for table rows that might contain debenture documents
            table_rows = soup.find_all('tr')
            for row in table_rows:
                row_text = row.get_text(strip=True).lower()
                if any(keyword in row_text for keyword in ['debênture', 'debenture']):
                    row_pdfs = self.extract_pdf_links(row, self.base_url)
                    pdf_links.extend(row_pdfs)
            
            # Convert PDF links to document entries
            for pdf_link in pdf_links:
                doc_type = "Debênture"
                title_lower = pdf_link['title'].lower()
                
                if any(keyword in title_lower for keyword in ['assembleia', 'assembly']):
                    doc_type = "Assembleia"
                elif any(keyword in title_lower for keyword in ['evento', 'event']):
                    doc_type = "Evento"
                elif any(keyword in title_lower for keyword in ['emissão', 'emission']):
                    doc_type = "Emissão"
                elif any(keyword in title_lower for keyword in ['nota promissória', 'np']):
                    doc_type = "Nota Promissória"
                elif any(keyword in title_lower for keyword in ['letra financeira', 'lf']):
                    doc_type = "Letra Financeira"
                
                document = self.create_document_entry(
                    title=pdf_link['title'],
                    doc_type=doc_type,
                    pdf_url=pdf_link['url'],
                    description=f"Documento extraído do site {self.agent_name}"
                )
                documents.append(document)
            
            # Remove duplicates based on URL
            seen_urls = set()
            unique_documents = []
            for doc in documents:
                if doc['pdf_url'] not in seen_urls:
                    seen_urls.add(doc['pdf_url'])
                    unique_documents.append(doc)
            
            return self.create_response(self.agent_name, self.agent_id, unique_documents)
            
        except Exception as e:
            return {
                'agent_name': self.agent_name,
                'agent_id': self.agent_id,
                'documents': [],
                'total_documents': 0,
                'last_updated': None,
                'status': 'error',
                'error': str(e)
            }

