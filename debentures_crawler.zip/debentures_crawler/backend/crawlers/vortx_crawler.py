from .base_crawler import BaseCrawler
from typing import Dict, List, Any
import asyncio

class VortxCrawler(BaseCrawler):
    """Crawler for Vórtx DTVM"""
    
    def __init__(self):
        super().__init__()
        self.base_url = "https://www.vortx.com.br"
        self.agent_name = "Vórtx DTVM"
        self.agent_id = "vortx"
    
    async def crawl(self) -> Dict[str, Any]:
        """Crawl Vórtx website for debenture documents"""
        documents = []
        
        try:
            # Navigate to the escrituração page
            escrituracao_url = f"{self.base_url}/servicos/escrituracao"
            page = self.get_page(escrituracao_url)
            soup = self.parse_html(page.text)
            
            # Look for PDF links on the page
            pdf_links = self.extract_pdf_links(soup, self.base_url)
            
            # Look for debenture-related links
            debenture_links = soup.find_all('a', href=True)
            for link in debenture_links:
                text = link.get_text(strip=True).lower()
                if any(keyword in text for keyword in ['debênture', 'debenture', 'securitização']):
                    try:
                        href = link.get('href', '')
                        if href.startswith('http'):
                            link_url = href
                        else:
                            link_url = self.base_url.rstrip('/') + '/' + href.lstrip('/')
                        
                        # Visit the link
                        link_page = self.get_page(link_url)
                        link_soup = self.parse_html(link_page.text)
                        link_pdfs = self.extract_pdf_links(link_soup, self.base_url)
                        pdf_links.extend(link_pdfs)
                        
                        await asyncio.sleep(1)
                        
                    except Exception as e:
                        print(f"Error accessing {href}: {e}")
                        continue
            
            # Convert PDF links to document entries
            for pdf_link in pdf_links:
                doc_type = "Debênture"
                if any(keyword in pdf_link['title'].lower() for keyword in ['assembleia', 'assembly']):
                    doc_type = "Assembleia"
                elif any(keyword in pdf_link['title'].lower() for keyword in ['evento', 'event']):
                    doc_type = "Evento"
                elif any(keyword in pdf_link['title'].lower() for keyword in ['emissão', 'emission']):
                    doc_type = "Emissão"
                elif any(keyword in pdf_link['title'].lower() for keyword in ['securitização']):
                    doc_type = "Securitização"
                
                document = self.create_document_entry(
                    title=pdf_link['title'],
                    doc_type=doc_type,
                    pdf_url=pdf_link['url'],
                    description=f"Documento extraído do site {self.agent_name}"
                )
                documents.append(document)
            
            # Remove duplicates based on URL
            seen_urls = set()
            unique_documents = []
            for doc in documents:
                if doc['pdf_url'] not in seen_urls:
                    seen_urls.add(doc['pdf_url'])
                    unique_documents.append(doc)
            
            return self.create_response(self.agent_name, self.agent_id, unique_documents)
            
        except Exception as e:
            return {
                'agent_name': self.agent_name,
                'agent_id': self.agent_id,
                'documents': [],
                'total_documents': 0,
                'last_updated': None,
                'status': 'error',
                'error': str(e)
            }

