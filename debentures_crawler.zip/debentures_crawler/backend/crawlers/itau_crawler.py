from .base_crawler import BaseCrawler
from typing import Dict, List, Any
import asyncio

class ItauCrawler(BaseCrawler):
    """Crawler for Itaú DTVM S.A."""
    
    def __init__(self):
        super().__init__()
        self.base_url = "https://www.itau.com.br"
        self.ri_url = "https://www.itau.com.br/relacoes-com-investidores/"
        self.comunicados_url = "https://www.itau.com.br/relacoes-com-investidores/informacoes-ao-mercado/comunicados-ao-mercado/"
        self.agent_name = "Itaú DTVM S.A."
        self.agent_id = "itau"
    
    async def crawl(self) -> Dict[str, Any]:
        """Crawl Itaú RI website for debenture documents"""
        documents = []
        
        try:
            # Navigate to the comunicados page
            page = self.get_page(self.comunicados_url)
            soup = self.parse_html(page.text)
            
            # Look for PDF links on the page
            pdf_links = self.extract_pdf_links(soup, self.base_url)
            
            # Look for other RI sections that might contain documents
            ri_sections = [
                "/relacoes-com-investidores/resultados-e-relatorios/",
                "/relacoes-com-investidores/informacoes-ao-mercado/",
                "/relacoes-com-investidores/servicos-ao-investidor/"
            ]
            
            for section in ri_sections:
                try:
                    section_url = self.base_url.rstrip('/') + section
                    section_page = self.get_page(section_url)
                    section_soup = self.parse_html(section_page.text)
                    section_pdfs = self.extract_pdf_links(section_soup, self.base_url)
                    pdf_links.extend(section_pdfs)
                    
                    await asyncio.sleep(1)
                    
                except Exception as e:
                    print(f"Error accessing {section}: {e}")
                    continue
            
            # Convert PDF links to document entries
            for pdf_link in pdf_links:
                doc_type = "Documento RI"
                title_lower = pdf_link['title'].lower()
                
                if any(keyword in title_lower for keyword in ['debênture', 'debenture']):
                    doc_type = "Debênture"
                elif any(keyword in title_lower for keyword in ['assembleia', 'assembly']):
                    doc_type = "Assembleia"
                elif any(keyword in title_lower for keyword in ['evento', 'event']):
                    doc_type = "Evento"
                elif any(keyword in title_lower for keyword in ['emissão', 'emission']):
                    doc_type = "Emissão"
                elif any(keyword in title_lower for keyword in ['relatório', 'report']):
                    doc_type = "Relatório"
                elif any(keyword in title_lower for keyword in ['demonstrações', 'financeiras']):
                    doc_type = "Demonstrações Financeiras"
                elif any(keyword in title_lower for keyword in ['comunicado', 'fato relevante']):
                    doc_type = "Comunicado"
                elif any(keyword in title_lower for keyword in ['letra financeira', 'subordinada']):
                    doc_type = "Letra Financeira"
                elif any(keyword in title_lower for keyword in ['nota subordinada']):
                    doc_type = "Nota Subordinada"
                
                document = self.create_document_entry(
                    title=pdf_link['title'],
                    doc_type=doc_type,
                    pdf_url=pdf_link['url'],
                    description=f"Documento extraído do site {self.agent_name}"
                )
                documents.append(document)
            
            # Remove duplicates based on URL
            seen_urls = set()
            unique_documents = []
            for doc in documents:
                if doc['pdf_url'] not in seen_urls:
                    seen_urls.add(doc['pdf_url'])
                    unique_documents.append(doc)
            
            return self.create_response(self.agent_name, self.agent_id, unique_documents)
            
        except Exception as e:
            return {
                'agent_name': self.agent_name,
                'agent_id': self.agent_id,
                'documents': [],
                'total_documents': 0,
                'last_updated': None,
                'status': 'error',
                'error': str(e)
            }

