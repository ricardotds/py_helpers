from abc import ABC, abstractmethod
from typing import Dict, List, Any
from datetime import datetime
import requests
from bs4 import BeautifulSoup
import asyncio

class BaseCrawler(ABC):
    """Base class for all fiduciary agent crawlers"""
    
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        })
    
    @abstractmethod
    async def crawl(self) -> Dict[str, Any]:
        """
        Main crawling method to be implemented by each crawler
        
        Returns:
            Dict containing:
            - agent_name: str
            - agent_id: str
            - documents: List[Dict] with document information
            - last_updated: str (ISO format)
            - total_documents: int
        """
        pass
    
    def get_page(self, url: str, timeout: int = 30) -> requests.Response:
        """Get a web page with error handling"""
        try:
            response = self.session.get(url, timeout=timeout)
            response.raise_for_status()
            return response
        except requests.RequestException as e:
            raise Exception(f"Failed to fetch {url}: {str(e)}")
    
    def parse_html(self, html_content: str) -> BeautifulSoup:
        """Parse HTML content using BeautifulSoup"""
        return BeautifulSoup(html_content, 'html.parser')
    
    def extract_pdf_links(self, soup: BeautifulSoup, base_url: str = "") -> List[Dict[str, str]]:
        """Extract PDF links from parsed HTML"""
        pdf_links = []
        
        # Find all links ending with .pdf
        for link in soup.find_all('a', href=True):
            href = link['href']
            if href.lower().endswith('.pdf'):
                # Make absolute URL if needed
                if href.startswith('http'):
                    pdf_url = href
                else:
                    pdf_url = base_url.rstrip('/') + '/' + href.lstrip('/')
                
                # Extract link text
                link_text = link.get_text(strip=True)
                
                pdf_links.append({
                    'url': pdf_url,
                    'title': link_text or 'Untitled Document',
                    'type': 'PDF'
                })
        
        return pdf_links
    
    def create_document_entry(self, title: str, doc_type: str, pdf_url: str, 
                            publication_date: str = None, description: str = None) -> Dict[str, Any]:
        """Create a standardized document entry"""
        return {
            'title': title,
            'type': doc_type,
            'pdf_url': pdf_url,
            'publication_date': publication_date or datetime.now().isoformat(),
            'description': description or '',
            'extracted_at': datetime.now().isoformat()
        }
    
    def create_response(self, agent_name: str, agent_id: str, documents: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Create standardized response format"""
        return {
            'agent_name': agent_name,
            'agent_id': agent_id,
            'documents': documents,
            'total_documents': len(documents),
            'last_updated': datetime.now().isoformat(),
            'status': 'success'
        }

