from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import Dict, List, Optional
import json
import os
import asyncio
from datetime import datetime
import uuid

from crawlers.pentagono_crawler import PentagonoCrawler
from crawlers.vortx_crawler import VortxCrawler
from crawlers.oliveira_trust_crawler import OliveiraTrustCrawler
from crawlers.planner_crawler import PlannerCrawler
from crawlers.btg_pactual_crawler import BTGPactualCrawler
from crawlers.brl_trust_crawler import BRLTrustCrawler
from crawlers.xp_crawler import XPCrawler
from crawlers.bb_crawler import BBCrawler
from crawlers.itau_crawler import ItauCrawler

app = FastAPI(title="Debentures Crawler Controller", version="1.0.0")

# Enable CORS for all origins
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Data directory
DATA_DIR = "../data"
os.makedirs(DATA_DIR, exist_ok=True)

# Global variables to track crawler status
crawler_status = {}
crawler_results = {}

# Fiduciary agents configuration
AGENTS = {
    "pentagono": {
        "name": "Pentágono S.A. DTVM",
        "crawler": PentagonoCrawler,
        "status": "idle"
    },
    "vortx": {
        "name": "Vórtx DTVM",
        "crawler": VortxCrawler,
        "status": "idle"
    },
    "oliveira_trust": {
        "name": "Oliveira Trust DTVM",
        "crawler": OliveiraTrustCrawler,
        "status": "idle"
    },
    "planner": {
        "name": "Planner Trustee DTVM Ltda",
        "crawler": PlannerCrawler,
        "status": "idle"
    },
    "btg_pactual": {
        "name": "BTG Pactual Serviços Financeiros S.A. DTVM",
        "crawler": BTGPactualCrawler,
        "status": "idle"
    },
    "brl_trust": {
        "name": "BRL Trust DTVM S.A.",
        "crawler": BRLTrustCrawler,
        "status": "idle"
    },
    "xp": {
        "name": "XP Investimentos CCTVM S.A.",
        "crawler": XPCrawler,
        "status": "idle"
    },
    "bb": {
        "name": "Banco do Brasil S.A.",
        "crawler": BBCrawler,
        "status": "idle"
    },
    "itau": {
        "name": "Itaú DTVM S.A.",
        "crawler": ItauCrawler,
        "status": "idle"
    }
}

class CrawlerRequest(BaseModel):
    agent_id: str

class CrawlerResponse(BaseModel):
    task_id: str
    agent_id: str
    status: str
    message: str

async def run_crawler(agent_id: str, task_id: str):
    """Run crawler for a specific agent"""
    try:
        crawler_status[task_id] = {
            "agent_id": agent_id,
            "status": "running",
            "started_at": datetime.now().isoformat(),
            "progress": 0
        }
        
        # Initialize crawler
        crawler_class = AGENTS[agent_id]["crawler"]
        crawler = crawler_class()
        
        # Update progress
        crawler_status[task_id]["progress"] = 25
        
        # Run crawler
        results = await crawler.crawl()
        
        # Update progress
        crawler_status[task_id]["progress"] = 75
        
        # Save results to JSON file
        output_file = os.path.join(DATA_DIR, f"{agent_id}_documents.json")
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(results, f, ensure_ascii=False, indent=2)
        
        # Update status
        crawler_status[task_id].update({
            "status": "completed",
            "completed_at": datetime.now().isoformat(),
            "progress": 100,
            "documents_found": len(results.get("documents", [])),
            "output_file": output_file
        })
        
        crawler_results[task_id] = results
        
    except Exception as e:
        crawler_status[task_id].update({
            "status": "failed",
            "error": str(e),
            "completed_at": datetime.now().isoformat(),
            "progress": 0
        })

@app.get("/")
async def root():
    return {"message": "Debentures Crawler Controller API", "version": "1.0.0"}

@app.get("/agents")
async def get_agents():
    """Get list of all fiduciary agents"""
    return {
        "agents": [
            {
                "id": agent_id,
                "name": config["name"],
                "status": config["status"]
            }
            for agent_id, config in AGENTS.items()
        ]
    }

@app.post("/crawl/{agent_id}")
async def start_crawler(agent_id: str, background_tasks: BackgroundTasks):
    """Start crawler for a specific agent"""
    if agent_id not in AGENTS:
        raise HTTPException(status_code=404, detail="Agent not found")
    
    # Check if crawler is already running for this agent
    running_tasks = [
        task_id for task_id, status in crawler_status.items()
        if status["agent_id"] == agent_id and status["status"] == "running"
    ]
    
    if running_tasks:
        raise HTTPException(
            status_code=409, 
            detail=f"Crawler for {agent_id} is already running"
        )
    
    # Generate task ID
    task_id = str(uuid.uuid4())
    
    # Start crawler in background
    background_tasks.add_task(run_crawler, agent_id, task_id)
    
    return CrawlerResponse(
        task_id=task_id,
        agent_id=agent_id,
        status="started",
        message=f"Crawler for {AGENTS[agent_id]['name']} started successfully"
    )

@app.get("/status/{task_id}")
async def get_crawler_status(task_id: str):
    """Get status of a specific crawler task"""
    if task_id not in crawler_status:
        raise HTTPException(status_code=404, detail="Task not found")
    
    return crawler_status[task_id]

@app.get("/status")
async def get_all_status():
    """Get status of all crawler tasks"""
    return {"tasks": crawler_status}

@app.get("/results/{task_id}")
async def get_crawler_results(task_id: str):
    """Get results of a specific crawler task"""
    if task_id not in crawler_status:
        raise HTTPException(status_code=404, detail="Task not found")
    
    status = crawler_status[task_id]
    if status["status"] != "completed":
        raise HTTPException(
            status_code=400, 
            detail=f"Task is not completed. Current status: {status['status']}"
        )
    
    if task_id in crawler_results:
        return crawler_results[task_id]
    
    # Try to load from file
    agent_id = status["agent_id"]
    output_file = os.path.join(DATA_DIR, f"{agent_id}_documents.json")
    
    if os.path.exists(output_file):
        with open(output_file, 'r', encoding='utf-8') as f:
            return json.load(f)
    
    raise HTTPException(status_code=404, detail="Results not found")

@app.get("/documents/{agent_id}")
async def get_agent_documents(agent_id: str):
    """Get latest documents for a specific agent"""
    if agent_id not in AGENTS:
        raise HTTPException(status_code=404, detail="Agent not found")
    
    output_file = os.path.join(DATA_DIR, f"{agent_id}_documents.json")
    
    if not os.path.exists(output_file):
        return {"agent_id": agent_id, "documents": [], "last_updated": None}
    
    with open(output_file, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    return data

@app.get("/documents")
async def get_all_documents():
    """Get latest documents for all agents"""
    all_documents = {}
    
    for agent_id in AGENTS.keys():
        output_file = os.path.join(DATA_DIR, f"{agent_id}_documents.json")
        
        if os.path.exists(output_file):
            with open(output_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
                all_documents[agent_id] = data
        else:
            all_documents[agent_id] = {
                "agent_id": agent_id,
                "documents": [],
                "last_updated": None
            }
    
    return all_documents

@app.delete("/results/{task_id}")
async def delete_task_results(task_id: str):
    """Delete results of a specific crawler task"""
    if task_id not in crawler_status:
        raise HTTPException(status_code=404, detail="Task not found")
    
    # Remove from memory
    if task_id in crawler_results:
        del crawler_results[task_id]
    
    del crawler_status[task_id]
    
    return {"message": "Task results deleted successfully"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)

