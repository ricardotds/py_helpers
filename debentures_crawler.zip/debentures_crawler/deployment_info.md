# Debentures Crawler Controller - Deployment Information

## Application Overview

The Debentures Crawler Controller is a full-stack web application that manages 9 individual crawlers for Brazilian fiduciary agents to collect debentures document information.

## Architecture

- **Backend**: FastAPI with Python
- **Frontend**: React with Material UI
- **Data Storage**: JSON files
- **Crawling**: Custom crawlers for each fiduciary agent

## Deployed URLs

### Frontend (React Dashboard)
- **Production URL**: https://zncqgnyk.manus.space
- **Framework**: Static React build
- **Features**: 
  - Dashboard with summary statistics
  - Individual agent cards with status indicators
  - Real-time crawler status updates
  - Document viewing with PDF download links
  - Progress tracking for running crawlers

### Backend (FastAPI API)
- **Production URL**: https://8000-im2y1cgv56wzeoukt31pt-1ff93a90.manusvm.computer
- **Framework**: FastAPI
- **Features**:
  - RESTful API endpoints
  - Asynchronous crawler execution
  - Real-time status tracking
  - JSON data storage
  - CORS enabled for frontend integration

## API Endpoints

- `GET /` - API information
- `GET /agents` - List all fiduciary agents
- `POST /crawl/{agent_id}` - Start crawler for specific agent
- `GET /status/{task_id}` - Get crawler task status
- `GET /status` - Get all crawler task statuses
- `GET /results/{task_id}` - Get crawler results
- `GET /documents/{agent_id}` - Get documents for specific agent
- `GET /documents` - Get all documents
- `DELETE /results/{task_id}` - Delete task results

## Fiduciary Agents Covered

1. **Pentágono S.A. DTVM**
2. **Vórtx DTVM**
3. **Oliveira Trust DTVM**
4. **Planner Trustee DTVM Ltda**
5. **BTG Pactual Serviços Financeiros S.A. DTVM**
6. **BRL Trust DTVM S.A.**
7. **XP Investimentos CCTVM S.A.**
8. **Banco do Brasil S.A.**
9. **Itaú DTVM S.A.**

## Features Implemented

### Dashboard Features
- **Summary Cards**: Total agents, running crawlers, total documents, last updated time
- **Agent Management**: Individual cards for each fiduciary agent
- **Status Indicators**: Real-time status (idle, running, completed, failed)
- **Progress Tracking**: Progress bars for running crawlers
- **Document Viewing**: Modal dialog with document table
- **PDF Downloads**: Direct links to PDF documents
- **Auto-refresh**: Automatic status updates every 5 seconds

### Crawler Features
- **Asynchronous Execution**: Non-blocking crawler execution
- **Individual Crawlers**: Specialized crawler for each agent
- **Document Extraction**: PDF link extraction and metadata collection
- **Error Handling**: Graceful error handling and reporting
- **Data Persistence**: JSON file storage for collected data

### Technical Features
- **CORS Support**: Cross-origin requests enabled
- **Responsive Design**: Mobile-friendly Material UI components
- **Real-time Updates**: Live status polling and updates
- **Error Notifications**: User-friendly error messages
- **Professional UI**: Modern Material UI design

## Current Status

- **Total Agents**: 9
- **Successfully Tested**: BRL Trust DTVM S.A. (65 documents collected)
- **Deployment Status**: Both frontend and backend successfully deployed
- **Integration Status**: Frontend and backend fully integrated and tested

## Usage Instructions

1. **Access the Dashboard**: Visit https://gjpamxtc.manus.space
2. **Start a Crawler**: Click "Start Crawler" button for any agent
3. **Monitor Progress**: Watch the progress bar and status updates
4. **View Documents**: Click "View Documents" to see collected documents
5. **Download PDFs**: Click download icons to access PDF documents
6. **Refresh Data**: Use the "Refresh" button to update all data

## Technical Notes

- The frontend is deployed as a static build for optimal performance
- The backend uses temporary port exposure for demonstration purposes
- All crawlers implement the same base interface for consistency
- Document data is stored in JSON format for easy access and manipulation
- The application supports concurrent crawler execution
- Real-time status updates provide immediate feedback to users

