import React, { useState, useEffect } from 'react';
import {
  AppBar,
  Toolbar,
  Typography,
  Container,
  Grid,
  Card,
  CardContent,
  CardActions,
  Button,
  Box,
  Chip,
  LinearProgress,
  Alert,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  IconButton,
  Tooltip,
  Snackbar,
  CircularProgress
} from '@mui/material';
import {
  PlayArrow,
  Stop,
  Refresh,
  Download,
  Info,
  CheckCircle,
  Error,
  Schedule,
  Description
} from '@mui/icons-material';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import './App.css';

const theme = createTheme({
  palette: {
    mode: 'light',
    primary: {
      main: '#1976d2',
    },
    secondary: {
      main: '#dc004e',
    },
    background: {
      default: '#f5f5f5',
    },
  },
  typography: {
    h4: {
      fontWeight: 600,
    },
    h6: {
      fontWeight: 500,
    },
  },
});

const API_BASE_URL = 'https://8000-im2y1cgv56wzeoukt31pt-1ff93a90.manusvm.computer';

function App() {
  const [agents, setAgents] = useState([]);
  const [crawlerStatus, setCrawlerStatus] = useState({});
  const [documents, setDocuments] = useState({});
  const [loading, setLoading] = useState(true);
  const [selectedAgent, setSelectedAgent] = useState(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'info' });

  // Fetch agents on component mount
  useEffect(() => {
    fetchAgents();
    fetchAllDocuments();
  }, []);

  // Poll for status updates every 5 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      fetchAllStatus();
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const fetchAgents = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/agents`);
      const data = await response.json();
      setAgents(data.agents);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching agents:', error);
      showSnackbar('Error fetching agents', 'error');
      setLoading(false);
    }
  };

  const fetchAllStatus = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/status`);
      const data = await response.json();
      setCrawlerStatus(data.tasks);
    } catch (error) {
      console.error('Error fetching status:', error);
    }
  };

  const fetchAllDocuments = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/documents`);
      const data = await response.json();
      setDocuments(data);
    } catch (error) {
      console.error('Error fetching documents:', error);
    }
  };

  const startCrawler = async (agentId) => {
    try {
      const response = await fetch(`${API_BASE_URL}/crawl/${agentId}`, {
        method: 'POST',
      });
      const data = await response.json();
      
      if (response.ok) {
        showSnackbar(`Crawler started for ${agentId}`, 'success');
        fetchAllStatus();
      } else {
        showSnackbar(data.detail || 'Error starting crawler', 'error');
      }
    } catch (error) {
      console.error('Error starting crawler:', error);
      showSnackbar('Error starting crawler', 'error');
    }
  };

  const showSnackbar = (message, severity = 'info') => {
    setSnackbar({ open: true, message, severity });
  };

  const handleCloseSnackbar = () => {
    setSnackbar({ ...snackbar, open: false });
  };

  const openDocumentsDialog = (agent) => {
    setSelectedAgent(agent);
    setDialogOpen(true);
  };

  const closeDocumentsDialog = () => {
    setDialogOpen(false);
    setSelectedAgent(null);
  };

  const getAgentStatus = (agentId) => {
    const runningTasks = Object.values(crawlerStatus).filter(
      task => task.agent_id === agentId && task.status === 'running'
    );
    return runningTasks.length > 0 ? 'running' : 'idle';
  };

  const getAgentProgress = (agentId) => {
    const runningTasks = Object.values(crawlerStatus).filter(
      task => task.agent_id === agentId && task.status === 'running'
    );
    return runningTasks.length > 0 ? runningTasks[0].progress : 0;
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'running': return 'warning';
      case 'completed': return 'success';
      case 'failed': return 'error';
      default: return 'default';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'running': return <Schedule />;
      case 'completed': return <CheckCircle />;
      case 'failed': return <Error />;
      default: return <Info />;
    }
  };

  const getTotalDocuments = () => {
    return Object.values(documents).reduce((total, agent) => {
      return total + (agent.documents ? agent.documents.length : 0);
    }, 0);
  };

  const getRunningCrawlers = () => {
    return Object.values(crawlerStatus).filter(task => task.status === 'running').length;
  };

  if (loading) {
    return (
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <Box display="flex" justifyContent="center" alignItems="center" minHeight="100vh">
          <CircularProgress />
        </Box>
      </ThemeProvider>
    );
  }

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <AppBar position="static" elevation={2}>
        <Toolbar>
          <Description sx={{ mr: 2 }} />
          <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
            Debentures Crawler Controller
          </Typography>
          <Button color="inherit" onClick={fetchAllDocuments} startIcon={<Refresh />}>
            Refresh
          </Button>
        </Toolbar>
      </AppBar>

      <Container maxWidth="xl" sx={{ mt: 4, mb: 4 }}>
        {/* Summary Cards */}
        <Grid container spacing={3} sx={{ mb: 4 }}>
          <Grid item xs={12} sm={6} md={3}>
            <Card>
              <CardContent>
                <Typography color="textSecondary" gutterBottom>
                  Total Agents
                </Typography>
                <Typography variant="h4">
                  {agents.length}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <Card>
              <CardContent>
                <Typography color="textSecondary" gutterBottom>
                  Running Crawlers
                </Typography>
                <Typography variant="h4" color="warning.main">
                  {getRunningCrawlers()}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <Card>
              <CardContent>
                <Typography color="textSecondary" gutterBottom>
                  Total Documents
                </Typography>
                <Typography variant="h4" color="primary.main">
                  {getTotalDocuments()}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <Card>
              <CardContent>
                <Typography color="textSecondary" gutterBottom>
                  Last Updated
                </Typography>
                <Typography variant="body2">
                  {new Date().toLocaleTimeString()}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
        </Grid>

        {/* Agents Grid */}
        <Typography variant="h4" gutterBottom>
          Fiduciary Agents
        </Typography>
        <Grid container spacing={3}>
          {agents.map((agent) => {
            const status = getAgentStatus(agent.id);
            const progress = getAgentProgress(agent.id);
            const agentDocs = documents[agent.id] || { documents: [] };
            
            return (
              <Grid item xs={12} md={6} lg={4} key={agent.id}>
                <Card sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
                  <CardContent sx={{ flexGrow: 1 }}>
                    <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
                      <Typography variant="h6" component="h2">
                        {agent.name}
                      </Typography>
                      <Chip
                        icon={getStatusIcon(status)}
                        label={status}
                        color={getStatusColor(status)}
                        size="small"
                      />
                    </Box>
                    
                    <Typography color="textSecondary" gutterBottom>
                      Documents: {agentDocs.documents.length}
                    </Typography>
                    
                    {agentDocs.last_updated && (
                      <Typography variant="body2" color="textSecondary">
                        Last updated: {new Date(agentDocs.last_updated).toLocaleString()}
                      </Typography>
                    )}
                    
                    {status === 'running' && (
                      <Box mt={2}>
                        <Typography variant="body2" color="textSecondary">
                          Progress: {progress}%
                        </Typography>
                        <LinearProgress variant="determinate" value={progress} sx={{ mt: 1 }} />
                      </Box>
                    )}
                  </CardContent>
                  
                  <CardActions>
                    <Button
                      size="small"
                      startIcon={<PlayArrow />}
                      onClick={() => startCrawler(agent.id)}
                      disabled={status === 'running'}
                      variant="contained"
                    >
                      {status === 'running' ? 'Running...' : 'Start Crawler'}
                    </Button>
                    <Button
                      size="small"
                      startIcon={<Info />}
                      onClick={() => openDocumentsDialog(agent)}
                      disabled={agentDocs.documents.length === 0}
                    >
                      View Documents
                    </Button>
                  </CardActions>
                </Card>
              </Grid>
            );
          })}
        </Grid>
      </Container>

      {/* Documents Dialog */}
      <Dialog
        open={dialogOpen}
        onClose={closeDocumentsDialog}
        maxWidth="lg"
        fullWidth
      >
        <DialogTitle>
          Documents - {selectedAgent?.name}
        </DialogTitle>
        <DialogContent>
          {selectedAgent && documents[selectedAgent.id] && (
            <TableContainer component={Paper}>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell>Title</TableCell>
                    <TableCell>Type</TableCell>
                    <TableCell>Publication Date</TableCell>
                    <TableCell>Actions</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {documents[selectedAgent.id].documents.map((doc, index) => (
                    <TableRow key={index}>
                      <TableCell>{doc.title}</TableCell>
                      <TableCell>
                        <Chip label={doc.type} size="small" />
                      </TableCell>
                      <TableCell>
                        {new Date(doc.publication_date).toLocaleDateString()}
                      </TableCell>
                      <TableCell>
                        <Tooltip title="Download PDF">
                          <IconButton
                            size="small"
                            onClick={() => window.open(doc.pdf_url, '_blank')}
                          >
                            <Download />
                          </IconButton>
                        </Tooltip>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={closeDocumentsDialog}>Close</Button>
        </DialogActions>
      </Dialog>

      {/* Snackbar for notifications */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={6000}
        onClose={handleCloseSnackbar}
      >
        <Alert onClose={handleCloseSnackbar} severity={snackbar.severity}>
          {snackbar.message}
        </Alert>
      </Snackbar>
    </ThemeProvider>
  );
}

export default App;

