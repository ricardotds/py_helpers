#!/usr/bin/env python3
"""
Pentágono SA DTVM PDF Crawler
Crawls and downloads PDF files about debenture emissions, events, and related documents
from Pentágono SA DTVM (Brazilian fiduciary agent)
"""

import os
import re
import time
import requests
import logging
from datetime import datetime
from urllib.parse import urljoin, urlparse
from typing import List, Dict, Tuple, Optional
from dataclasses import dataclass

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
from selenium.common.exceptions import TimeoutException, NoSuchElementException


@dataclass
class Asset:
    """Represents a financial asset with its metadata"""
    code: str
    company_name: str
    series_emission: str
    asset_type: str
    detail_url: str


@dataclass
class Document:
    """Represents a PDF document with its metadata"""
    asset_code: str
    filename: str
    download_url: str
    document_type: str
    date_extracted: str


class PentagonoCrawler:
    """Main crawler class for Pentágono SA DTVM website"""
    
    BASE_URL = "https://www.pentagonotrustee.com.br"
    INVESTOR_URL = f"{BASE_URL}/Site/Investidores"
    
    # Financial instrument types
    INSTRUMENT_TYPES = {
        1: "Debentures",
        2: "Notas_Promissorias_Comerciais", 
        3: "Certificado_Recebiveis_Imobiliarios",
        4: "Letras_Financeiras",
        5: "Certificado_Recebiveis_Agronegocio"
    }
    
    def __init__(self, download_dir: str = "pentagono_documents", headless: bool = True):
        """
        Initialize the crawler
        
        Args:
            download_dir: Directory to save downloaded PDFs
            headless: Whether to run browser in headless mode
        """
        self.download_dir = download_dir
        self.headless = headless
        self.driver = None
        self.session = requests.Session()
        
        # Setup logging
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler('pentagono_crawler.log'),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger(__name__)
        
        # Create download directory
        os.makedirs(download_dir, exist_ok=True)
        
        # Storage for discovered assets and documents
        self.assets: List[Asset] = []
        self.documents: List[Document] = []
    
    def setup_driver(self) -> webdriver.Chrome:
        """Setup Chrome WebDriver with appropriate options"""
        chrome_options = Options()
        if self.headless:
            chrome_options.add_argument("--headless")
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument("--disable-gpu")
        chrome_options.add_argument("--window-size=1920,1080")
        chrome_options.add_argument("--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
        
        self.driver = webdriver.Chrome(options=chrome_options)
        self.driver.implicitly_wait(10)
        return self.driver
    
    def close_driver(self):
        """Close the WebDriver"""
        if self.driver:
            self.driver.quit()
            self.driver = None
    
    def wait_and_find_element(self, by: By, value: str, timeout: int = 10):
        """Wait for element to be present and return it"""
        try:
            element = WebDriverWait(self.driver, timeout).until(
                EC.presence_of_element_located((by, value))
            )
            return element
        except TimeoutException:
            self.logger.warning(f"Element not found: {by}={value}")
            return None
    
    def wait_and_find_elements(self, by: By, value: str, timeout: int = 10):
        """Wait for elements to be present and return them"""
        try:
            elements = WebDriverWait(self.driver, timeout).until(
                EC.presence_of_all_elements_located((by, value))
            )
            return elements
        except TimeoutException:
            self.logger.warning(f"Elements not found: {by}={value}")
            return []
    
    def extract_assets_by_type(self, instrument_type: int) -> List[Asset]:
        """
        Extract all assets for a specific financial instrument type
        
        Args:
            instrument_type: Type of financial instrument (1-5)
            
        Returns:
            List of Asset objects
        """
        assets = []
        type_name = self.INSTRUMENT_TYPES.get(instrument_type, f"Type_{instrument_type}")
        
        self.logger.info(f"Extracting assets for {type_name}")
        
        # Navigate to filtered page
        url = f"{self.INVESTOR_URL}?tipo={instrument_type}&emissor=&ativo="
        self.driver.get(url)
        time.sleep(3)
        
        # Wait for table to load - try multiple selectors
        table_rows = self.wait_and_find_elements(By.CSS_SELECTOR, "table tbody tr")
        
        if not table_rows:
            # Try alternative selectors
            table_rows = self.wait_and_find_elements(By.CSS_SELECTOR, "table tr")
            
        if not table_rows:
            # Try finding any rows with asset links
            table_rows = self.wait_and_find_elements(By.XPATH, "//tr[.//a[contains(@href, 'DetalhesEmissor')]]")
        
        if not table_rows:
            self.logger.warning(f"No table rows found for {type_name}")
            # Debug: log page source snippet
            page_source = self.driver.page_source
            if "Razão Social" in page_source or "Ativo" in page_source:
                self.logger.info("Page contains expected table headers, but rows not found with current selectors")
                # Try a more general approach
                all_links = self.driver.find_elements(By.TAG_NAME, "a")
                asset_links = [link for link in all_links if link.get_attribute('href') and 'DetalhesEmissor' in link.get_attribute('href')]
                self.logger.info(f"Found {len(asset_links)} asset links using general approach")
                
                # Process asset links directly
                for link in asset_links:
                    try:
                        asset_code = link.text.strip()
                        if not asset_code:
                            continue
                            
                        href = link.get_attribute('href')
                        # Extract company name from nearby elements
                        parent_row = link.find_element(By.XPATH, "./ancestor::tr[1]")
                        cells = parent_row.find_elements(By.TAG_NAME, "td")
                        
                        if len(cells) >= 3:
                            company_name = cells[0].text.strip()
                            series_emission = cells[1].text.strip() if len(cells) > 1 else "N/A"
                        else:
                            company_name = "Unknown"
                            series_emission = "N/A"
                        
                        asset = Asset(
                            code=asset_code,
                            company_name=company_name,
                            series_emission=series_emission,
                            asset_type=type_name,
                            detail_url=href
                        )
                        assets.append(asset)
                        
                    except Exception as e:
                        self.logger.error(f"Error processing asset link: {e}")
                        continue
            
            return assets
        
        for row in table_rows:
            try:
                cells = row.find_elements(By.TAG_NAME, "td")
                if len(cells) >= 3:
                    company_name = cells[0].text.strip()
                    series_emission = cells[1].text.strip()
                    
                    # Find asset code link
                    asset_link = cells[2].find_element(By.TAG_NAME, "a")
                    asset_code = asset_link.text.strip()
                    
                    # Construct detail URL
                    detail_url = f"{self.BASE_URL}/Site/DetalhesEmissor?ativo={asset_code}&tipo={instrument_type}"
                    
                    asset = Asset(
                        code=asset_code,
                        company_name=company_name,
                        series_emission=series_emission,
                        asset_type=type_name,
                        detail_url=detail_url
                    )
                    assets.append(asset)
                    
            except Exception as e:
                self.logger.error(f"Error extracting asset from row: {e}")
                continue
        
        self.logger.info(f"Found {len(assets)} assets for {type_name}")
        return assets
    
    def extract_documents_for_asset(self, asset: Asset) -> List[Document]:
        """
        Extract all PDF documents for a specific asset
        
        Args:
            asset: Asset object to extract documents for
            
        Returns:
            List of Document objects
        """
        documents = []
        
        self.logger.info(f"Extracting documents for asset {asset.code}")
        
        # Navigate to asset detail page
        self.driver.get(asset.detail_url)
        time.sleep(2)
        
        # Click on Documents tab
        try:
            docs_tab = self.wait_and_find_element(By.XPATH, "//a[contains(text(), 'Documentos')]")
            if docs_tab:
                docs_tab.click()
                time.sleep(2)
            else:
                self.logger.warning(f"Documents tab not found for asset {asset.code}")
                return documents
        except Exception as e:
            self.logger.error(f"Error clicking documents tab for {asset.code}: {e}")
            return documents
        
        # Find all PDF links
        pdf_links = self.wait_and_find_elements(By.XPATH, "//a[contains(@href, 'DownloadBinario') or contains(text(), '.pdf')]")
        
        for link in pdf_links:
            try:
                filename = link.text.strip()
                if not filename or not filename.endswith('.pdf'):
                    # Try to get filename from link text or construct it
                    filename = self._extract_filename_from_link(link, asset.code)
                
                download_url = link.get_attribute('href')
                if not download_url:
                    continue
                
                # Determine document type from filename
                document_type = self._classify_document_type(filename)
                
                document = Document(
                    asset_code=asset.code,
                    filename=filename,
                    download_url=download_url,
                    document_type=document_type,
                    date_extracted=datetime.now().isoformat()
                )
                documents.append(document)
                
            except Exception as e:
                self.logger.error(f"Error extracting document link for {asset.code}: {e}")
                continue
        
        self.logger.info(f"Found {len(documents)} documents for asset {asset.code}")
        return documents
    
    def _extract_filename_from_link(self, link_element, asset_code: str) -> str:
        """Extract or construct filename from link element"""
        try:
            # Try to get text content
            text = link_element.text.strip()
            if text and '.pdf' in text.lower():
                return text
            
            # Try to get title attribute
            title = link_element.get_attribute('title')
            if title and '.pdf' in title.lower():
                return title
            
            # Construct filename from href if it contains an ID
            href = link_element.get_attribute('href')
            if 'DownloadBinario?id=' in href:
                doc_id = href.split('id=')[-1]
                return f"{asset_code}_document_{doc_id}.pdf"
            
            # Fallback
            return f"{asset_code}_document_{int(time.time())}.pdf"
            
        except Exception:
            return f"{asset_code}_document_{int(time.time())}.pdf"
    
    def _classify_document_type(self, filename: str) -> str:
        """Classify document type based on filename"""
        filename_lower = filename.lower()
        
        # Remove accents for better matching
        import unicodedata
        filename_normalized = unicodedata.normalize('NFD', filename_lower)
        filename_normalized = ''.join(c for c in filename_normalized if unicodedata.category(c) != 'Mn')
        
        # Check aditamento first as it's more specific
        if 'aditamento' in filename_lower:
            return 'Aditamento'
        elif ('escritura' in filename_normalized and 'emissao' in filename_normalized) or \
           ('escritura' in filename_lower and 'emissão' in filename_lower):
            return 'Escritura_Emissao'
        elif ('cessao' in filename_normalized and 'fiduciaria' in filename_normalized) or \
             ('cessão' in filename_lower and 'fiduciária' in filename_lower):
            return 'Cessao_Fiduciaria'
        elif 'ata' in filename_lower and ('agt' in filename_lower or 'assembleia' in filename_lower):
            return 'Ata_Assembleia'
        elif filename_lower.startswith('agt') or ' agt ' in filename_lower or filename_lower.endswith('agt') or \
             ' agt-' in filename_lower or '-agt-' in filename_lower:
            return 'Assembleia_Geral_Titulares'
        elif 'aporte' in filename_lower:
            return 'Aporte'
        elif 'reabertura' in filename_lower:
            return 'Reabertura'
        elif 'descumprimento' in filename_lower:
            return 'Descumprimento'
        else:
            return 'Outros'
    
    def download_document(self, document: Document, asset: Asset) -> bool:
        """
        Download a PDF document
        
        Args:
            document: Document object to download
            asset: Asset object the document belongs to
            
        Returns:
            True if download successful, False otherwise
        """
        try:
            # Create directory structure
            asset_dir = os.path.join(self.download_dir, asset.asset_type, asset.code)
            os.makedirs(asset_dir, exist_ok=True)
            
            # Clean filename for filesystem
            safe_filename = self._sanitize_filename(document.filename)
            file_path = os.path.join(asset_dir, safe_filename)
            
            # Skip if file already exists
            if os.path.exists(file_path):
                self.logger.info(f"File already exists: {safe_filename}")
                return True
            
            # Download the file
            self.logger.info(f"Downloading: {safe_filename}")
            response = self.session.get(document.download_url, timeout=30)
            response.raise_for_status()
            
            # Save the file
            with open(file_path, 'wb') as f:
                f.write(response.content)
            
            self.logger.info(f"Successfully downloaded: {safe_filename}")
            return True
            
        except Exception as e:
            self.logger.error(f"Error downloading {document.filename}: {e}")
            return False
    
    def _sanitize_filename(self, filename: str) -> str:
        """Sanitize filename for filesystem compatibility"""
        # Remove or replace invalid characters
        filename = re.sub(r'[<>:"/\\|?*]', '_', filename)
        filename = re.sub(r'\s+', '_', filename)
        filename = filename.strip('._')
        
        # Ensure .pdf extension
        if not filename.lower().endswith('.pdf'):
            filename += '.pdf'
        
        return filename
    
    def save_metadata(self):
        """Save extracted metadata to CSV files"""
        import csv
        
        # Save assets metadata
        assets_file = os.path.join(self.download_dir, 'assets_metadata.csv')
        with open(assets_file, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow(['Asset Code', 'Company Name', 'Series/Emission', 'Asset Type', 'Detail URL'])
            for asset in self.assets:
                writer.writerow([asset.code, asset.company_name, asset.series_emission, 
                               asset.asset_type, asset.detail_url])
        
        # Save documents metadata
        docs_file = os.path.join(self.download_dir, 'documents_metadata.csv')
        with open(docs_file, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow(['Asset Code', 'Filename', 'Download URL', 'Document Type', 'Date Extracted'])
            for doc in self.documents:
                writer.writerow([doc.asset_code, doc.filename, doc.download_url, 
                               doc.document_type, doc.date_extracted])
        
        self.logger.info(f"Metadata saved to {assets_file} and {docs_file}")
    
    def crawl_all(self, instrument_types: List[int] = None, max_assets_per_type: int = None):
        """
        Main crawling method - crawls all specified instrument types
        
        Args:
            instrument_types: List of instrument types to crawl (1-5). If None, crawls all.
            max_assets_per_type: Maximum number of assets to process per type (for testing)
        """
        if instrument_types is None:
            instrument_types = list(self.INSTRUMENT_TYPES.keys())
        
        self.logger.info("Starting Pentágono SA DTVM crawler")
        
        try:
            # Setup WebDriver
            self.setup_driver()
            
            # Process each instrument type
            for instrument_type in instrument_types:
                self.logger.info(f"Processing instrument type: {self.INSTRUMENT_TYPES[instrument_type]}")
                
                # Extract assets
                assets = self.extract_assets_by_type(instrument_type)
                
                # Limit assets for testing if specified
                if max_assets_per_type:
                    assets = assets[:max_assets_per_type]
                
                self.assets.extend(assets)
                
                # Extract documents for each asset
                for asset in assets:
                    documents = self.extract_documents_for_asset(asset)
                    self.documents.extend(documents)
                    
                    # Download documents
                    for document in documents:
                        self.download_document(document, asset)
                    
                    # Small delay between assets
                    time.sleep(1)
                
                # Delay between instrument types
                time.sleep(2)
            
            # Save metadata
            self.save_metadata()
            
            self.logger.info(f"Crawling completed. Found {len(self.assets)} assets and {len(self.documents)} documents")
            
        except Exception as e:
            self.logger.error(f"Error during crawling: {e}")
            raise
        finally:
            self.close_driver()


def main():
    """Main function to run the crawler"""
    import argparse
    
    parser = argparse.ArgumentParser(description='Pentágono SA DTVM PDF Crawler')
    parser.add_argument('--download-dir', default='pentagono_documents', 
                       help='Directory to save downloaded PDFs')
    parser.add_argument('--headless', action='store_true', default=True,
                       help='Run browser in headless mode')
    parser.add_argument('--instrument-types', nargs='+', type=int, 
                       choices=[1, 2, 3, 4, 5], default=None,
                       help='Instrument types to crawl (1=Debentures, 2=Promissory Notes, etc.)')
    parser.add_argument('--max-assets', type=int, default=None,
                       help='Maximum number of assets to process per type (for testing)')
    parser.add_argument('--verbose', action='store_true',
                       help='Enable verbose logging')
    
    args = parser.parse_args()
    
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    
    # Create and run crawler
    crawler = PentagonoCrawler(
        download_dir=args.download_dir,
        headless=args.headless
    )
    
    crawler.crawl_all(
        instrument_types=args.instrument_types,
        max_assets_per_type=args.max_assets
    )


if __name__ == "__main__":
    main()

