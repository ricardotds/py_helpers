# Pentágono SA DTVM Website Analysis

## Website Structure
- Main URL: https://www.pentagonotrustee.com.br/
- Investor Information URL: https://www.pentagonotrustee.com.br/Site/Investidores

## Navigation Structure
1. **Main Menu:**
   - A Pentágono (About)
   - Informações aos Investidores (Investor Information)
   - Contatos (Contacts)

2. **Investor Information Sections:**
   - Relatórios Anuais (Annual Reports)
   - Preços Unitários (Unit Prices)
   - Emissões (Emissions/Issues)

## Financial Instruments Categories
1. **Debêntures** (Debentures)
2. **Notas Promissórias Comerciais** (Commercial Promissory Notes)
3. **Certificado de Recebíveis Imobiliários** (Real Estate Receivables Certificates)
4. **Letras Financeiras** (Financial Letters)
5. **Certificado de Recebíveis do Agronegócio** (Agribusiness Receivables Certificates)

## Document Structure (Example: Asset 11C0035926)
- **Asset Details Page URL Pattern:** 
  `https://www.pentagonotrustee.com.br/Site/DetalhesEmissor?ativo={ASSET_CODE}&tipo=`

- **Available Tabs:**
  - Características (Characteristics)
  - Documentos (Documents) - **KEY FOR PDF CRAWLING**
  - Publicações (Publications)
  - Preços Unitários (Unit Prices)
  - Pagamentos (Payments)
  - Saldo Devedor (Outstanding Balance)
  - Rating

## PDF Document Types Found
- **AGT** - Assembleia Geral de Titulares (General Assembly of Holders)
- **Ata da AGT** - Minutes of General Assembly
- **AGT Aporte** - Assembly for Capital Contribution
- **AGT Reabertura** - Assembly for Reopening
- **AGT Descumprimento** - Assembly for Non-compliance

## Key Observations
1. Each financial instrument has a unique asset code (e.g., 11C0035926)
2. PDF documents are organized by asset code and document type
3. Document URLs follow pattern with asset code prefix
4. Multiple document versions with dates are available
5. Documents are directly downloadable via clickable links



## Detailed URL Patterns Analysis

### Main Investor Page
- **URL:** `https://www.pentagonotrustee.com.br/Site/Investidores`
- **Filtered by Type:** `https://www.pentagonotrustee.com.br/Site/Investidores?tipo={TYPE}&emissor=&ativo=`
  - `tipo=1` for Debêntures (Debentures)
  - `tipo=3` for Certificado de Recebíveis Imobiliários (Real Estate Receivables Certificates)

### Asset Detail Pages
- **URL Pattern:** `https://www.pentagonotrustee.com.br/Site/DetalhesEmissor?ativo={ASSET_CODE}&tipo={TYPE}`
- **Documents Tab:** `https://www.pentagonotrustee.com.br/Site/DetalhesEmissor?ativo={ASSET_CODE}&aba=tab-2&tipo={TYPE}`

## Document Types by Financial Instrument

### Debentures (Debêntures)
**Example Asset:** ADAG11 (Adecoagro Vale do Ivinhema S.A.)
**Document Types Found:**
- **Aditamento da Cessão Fiduciária** - Fiduciary Assignment Amendment
- **Contrato de Cessão Fiduciária** - Fiduciary Assignment Contract  
- **Escritura de Emissão** - Emission Deed

### Real Estate Receivables Certificates (CRI)
**Example Asset:** 11C0035926 (Habitasec Securitizadora S.A.)
**Document Types Found:**
- **AGT** - Assembleia Geral de Titulares (General Assembly of Holders)
- **Ata da AGT** - Minutes of General Assembly
- **AGT Aporte** - Assembly for Capital Contribution
- **AGT Reabertura** - Assembly for Reopening
- **AGT Descumprimento** - Assembly for Non-compliance
- **AGT Reabertura e Suspensão** - Assembly for Reopening and Suspension

## PDF Document Naming Convention
Documents follow this pattern: `{ASSET_CODE} - {DOCUMENT_TYPE} - {DATE} {VERSION}.pdf`

Examples:
- `ADAG11 - Escritura de Emissão - 2020.11.24 vf Registrada JUCEMS.pdf`
- `11C0035926 - AGT - 2016.08.23 vf Assinada.pdf`
- `2023.03.31 - 1º Aditamento da Cessão Fiduciária.pdf`

## Crawler Strategy

### Step 1: Get All Asset Codes
1. Visit main investor page for each financial instrument type
2. Extract all asset codes from the table
3. Store asset codes with their corresponding company names and types

### Step 2: For Each Asset Code
1. Navigate to asset detail page
2. Click on "Documentos" tab
3. Extract all PDF document links
4. Download each PDF with proper naming

### Step 3: Document Organization
- Create folders by financial instrument type (Debentures, CRI, etc.)
- Create subfolders by company/asset code
- Save PDFs with descriptive names including date and document type

## Technical Implementation Notes
- The website uses JavaScript for navigation and content loading
- PDF links are direct download links
- No authentication required for document access
- Rate limiting may be needed to avoid overwhelming the server
- Should implement retry logic for failed downloads
- Need to handle special characters in filenames

