#!/usr/bin/env python3
"""
Demo script for Pentágono SA DTVM crawler
Runs a very limited crawl to demonstrate functionality
"""

import os
import logging
from pentagono_crawler import PentagonoCrawler

def run_demo():
    """Run a limited demo crawl"""
    print("=" * 60)
    print("Pentágono SA DTVM Crawler - Demo")
    print("=" * 60)
    print("This demo will crawl a very limited set of data to demonstrate functionality.")
    print("It will only process 1 asset from debentures to avoid overwhelming the server.")
    print()
    
    # Setup logging to show progress
    logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')
    
    try:
        # Create crawler with demo settings
        crawler = PentagonoCrawler(
            download_dir="demo_downloads",
            headless=True  # Set to False to see browser in action
        )
        
        print("Starting demo crawl...")
        print("- Target: Debentures only")
        print("- Limit: 1 asset maximum")
        print("- Mode: Headless browser")
        print()
        
        # Run limited crawl
        crawler.crawl_all(
            instrument_types=[1],  # Only debentures
            max_assets_per_type=1  # Very limited for demo
        )
        
        # Show results
        print("\n" + "=" * 60)
        print("DEMO RESULTS")
        print("=" * 60)
        
        print(f"Assets discovered: {len(crawler.assets)}")
        print(f"Documents found: {len(crawler.documents)}")
        
        if crawler.assets:
            print("\nAssets:")
            for asset in crawler.assets:
                print(f"  - {asset.code}: {asset.company_name} ({asset.asset_type})")
        
        if crawler.documents:
            print("\nDocuments:")
            for doc in crawler.documents:
                print(f"  - {doc.filename} ({doc.document_type})")
        
        # Check if files were actually downloaded
        download_dir = "demo_downloads"
        if os.path.exists(download_dir):
            total_files = 0
            for root, dirs, files in os.walk(download_dir):
                pdf_files = [f for f in files if f.endswith('.pdf')]
                total_files += len(pdf_files)
                if pdf_files:
                    rel_path = os.path.relpath(root, download_dir)
                    print(f"\nFiles in {rel_path}:")
                    for pdf_file in pdf_files:
                        file_path = os.path.join(root, pdf_file)
                        file_size = os.path.getsize(file_path)
                        print(f"  - {pdf_file} ({file_size:,} bytes)")
            
            print(f"\nTotal PDF files downloaded: {total_files}")
            
            # Show metadata files
            metadata_files = ['assets_metadata.csv', 'documents_metadata.csv']
            for meta_file in metadata_files:
                meta_path = os.path.join(download_dir, meta_file)
                if os.path.exists(meta_path):
                    print(f"Metadata file created: {meta_file}")
        
        print("\n" + "=" * 60)
        print("Demo completed successfully!")
        print("Check the 'demo_downloads' directory for downloaded files.")
        print("=" * 60)
        
    except Exception as e:
        print(f"\nDemo failed with error: {e}")
        logging.error(f"Demo error: {e}")
        return False
    
    return True

if __name__ == "__main__":
    success = run_demo()
    if not success:
        exit(1)

