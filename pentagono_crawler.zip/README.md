# Pentágono SA DTVM PDF Crawler

A Python web crawler designed to gather PDF files about debenture emissions, events, and related documents from Pentágono SA DTVM, a Brazilian fiduciary agent.

## Overview

Pentágono SA DTVM is a specialized Brazilian financial institution that acts as a fiduciary agent for various financial instruments including debentures, real estate receivables certificates (CRI), agribusiness receivables certificates (CRA), and other securities. This crawler automates the process of discovering and downloading PDF documents related to these financial instruments.

## Features

- **Multi-instrument Support**: Crawls 5 types of financial instruments:
  1. Debêntures (Debentures)
  2. Notas Promissórias Comerciais (Commercial Promissory Notes)
  3. Certificado de Recebíveis Imobiliários (Real Estate Receivables Certificates)
  4. Letras Financeiras (Financial Letters)
  5. Certificado de Recebíveis do Agronegócio (Agribusiness Receivables Certificates)

- **Comprehensive Document Types**: Downloads various document types including:
  - Escritura de Emissão (Emission Deeds)
  - Contratos de Cessão Fiduciária (Fiduciary Assignment Contracts)
  - Aditamentos (Amendments)
  - Atas de Assembleia (Assembly Minutes)
  - AGT documents (General Assembly of Holders)

- **Organized Storage**: Creates structured directory hierarchy by instrument type and asset code
- **Metadata Export**: Generates CSV files with asset and document metadata
- **Robust Error Handling**: Includes retry logic and comprehensive logging
- **Configurable**: Supports headless/GUI mode, custom download directories, and selective crawling

## Installation

### Prerequisites

- Python 3.8 or higher
- Google Chrome browser
- ChromeDriver (automatically managed by webdriver-manager)

### Setup

1. **Clone or download the crawler files**:
   ```bash
   # Download the main files:
   # - pentagono_crawler.py
   # - requirements.txt
   # - example_usage.py
   # - README.md
   ```

2. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

3. **Verify Chrome installation**:
   Make sure Google Chrome is installed on your system. The crawler uses Chrome WebDriver for web automation.

## Usage

### Command Line Usage

**Basic usage** (crawl all instrument types):
```bash
python pentagono_crawler.py
```

**Crawl specific instrument types**:
```bash
# Crawl only debentures (type 1)
python pentagono_crawler.py --instrument-types 1

# Crawl debentures and CRI (types 1 and 3)
python pentagono_crawler.py --instrument-types 1 3
```

**Custom download directory**:
```bash
python pentagono_crawler.py --download-dir my_documents
```

**Testing with limited assets**:
```bash
# Limit to 5 assets per instrument type
python pentagono_crawler.py --max-assets 5 --instrument-types 1
```

**Run with visible browser** (for debugging):
```bash
python pentagono_crawler.py --no-headless
```

### Programmatic Usage

```python
from pentagono_crawler import PentagonoCrawler

# Create crawler instance
crawler = PentagonoCrawler(
    download_dir="my_downloads",
    headless=True
)

# Crawl specific instrument types
crawler.crawl_all(
    instrument_types=[1, 3],  # Debentures and CRI
    max_assets_per_type=10    # Limit for testing
)

# Access results
print(f"Found {len(crawler.assets)} assets")
print(f"Downloaded {len(crawler.documents)} documents")
```

### Command Line Arguments

- `--download-dir`: Directory to save downloaded PDFs (default: 'pentagono_documents')
- `--headless`: Run browser in headless mode (default: True)
- `--instrument-types`: Specific instrument types to crawl (1-5)
- `--max-assets`: Maximum number of assets to process per type
- `--verbose`: Enable verbose logging

### Instrument Type Codes

- `1`: Debêntures (Debentures)
- `2`: Notas Promissórias Comerciais (Commercial Promissory Notes)
- `3`: Certificado de Recebíveis Imobiliários (Real Estate Receivables Certificates)
- `4`: Letras Financeiras (Financial Letters)
- `5`: Certificado de Recebíveis do Agronegócio (Agribusiness Receivables Certificates)

## Output Structure

The crawler creates the following directory structure:

```
pentagono_documents/
├── assets_metadata.csv
├── documents_metadata.csv
├── Debentures/
│   ├── ADAG11/
│   │   ├── Escritura_Emissao_2020.11.24.pdf
│   │   └── Cessao_Fiduciaria_2020.11.24.pdf
│   └── AECY11/
│       └── ...
├── Certificado_Recebiveis_Imobiliarios/
│   ├── 11C0035926/
│   │   ├── AGT_2016.08.23.pdf
│   │   └── Ata_AGT_2016.07.04.pdf
│   └── ...
└── pentagono_crawler.log
```

### Metadata Files

- **assets_metadata.csv**: Contains asset information (code, company name, series, type, URL)
- **documents_metadata.csv**: Contains document information (asset code, filename, URL, type, extraction date)

## Document Types

The crawler automatically classifies documents into the following types:

- **Escritura_Emissao**: Emission deeds and indentures
- **Cessao_Fiduciaria**: Fiduciary assignment contracts
- **Aditamento**: Amendments and modifications
- **Assembleia_Geral_Titulares**: General assembly documents
- **Ata_Assembleia**: Assembly minutes
- **Aporte**: Capital contribution documents
- **Reabertura**: Reopening documents
- **Descumprimento**: Non-compliance documents
- **Outros**: Other document types

## Configuration

### Environment Variables

You can set the following environment variables:

- `PENTAGONO_DOWNLOAD_DIR`: Default download directory
- `PENTAGONO_HEADLESS`: Run in headless mode (true/false)
- `PENTAGONO_LOG_LEVEL`: Logging level (DEBUG, INFO, WARNING, ERROR)

### Logging

The crawler generates detailed logs in `pentagono_crawler.log`. Log levels can be adjusted:

```python
import logging
logging.getLogger('pentagono_crawler').setLevel(logging.DEBUG)
```

## Rate Limiting and Best Practices

- The crawler includes built-in delays between requests to avoid overwhelming the server
- Default delays: 1 second between assets, 2 seconds between instrument types
- For large-scale crawling, consider running during off-peak hours
- Monitor the log files for any rate limiting or blocking issues

## Error Handling

The crawler includes comprehensive error handling:

- **Network errors**: Automatic retries with exponential backoff
- **Missing elements**: Graceful handling of page structure changes
- **Download failures**: Logged with detailed error messages
- **File system errors**: Proper directory creation and permission handling

## Troubleshooting

### Common Issues

1. **ChromeDriver not found**:
   ```bash
   pip install --upgrade webdriver-manager
   ```

2. **Permission denied errors**:
   - Ensure write permissions for the download directory
   - Run with appropriate user permissions

3. **Network timeouts**:
   - Check internet connection
   - Increase timeout values in the code if needed

4. **Empty results**:
   - Website structure may have changed
   - Check logs for specific error messages
   - Try running with `--no-headless` to see browser behavior

### Debug Mode

Run with visible browser for debugging:
```bash
python pentagono_crawler.py --no-headless --verbose --max-assets 1
```

## Legal and Ethical Considerations

- This crawler accesses publicly available documents from Pentágono SA DTVM's website
- Respect the website's terms of service and robots.txt
- Use reasonable delays between requests to avoid overloading the server
- The downloaded documents are official financial documents and should be handled appropriately
- Ensure compliance with data protection and financial regulations in your jurisdiction

## Contributing

To contribute to this project:

1. Test the crawler with different instrument types
2. Report any issues with website structure changes
3. Suggest improvements for document classification
4. Add support for additional document types

## License

This project is provided as-is for educational and research purposes. Users are responsible for ensuring compliance with applicable laws and regulations.

## Changelog

### Version 1.0.0
- Initial release
- Support for all 5 financial instrument types
- Comprehensive document classification
- Metadata export functionality
- Command-line interface
- Robust error handling and logging

## Support

For issues and questions:
1. Check the troubleshooting section
2. Review the log files for error details
3. Test with a small subset of data first
4. Ensure all dependencies are properly installed

---

**Note**: This crawler is designed for the current structure of the Pentágono SA DTVM website as of 2025. Website changes may require updates to the crawler code.

