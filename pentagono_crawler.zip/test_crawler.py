#!/usr/bin/env python3
"""
Test script for Pentágono SA DTVM crawler
Tests basic functionality without full crawl
"""

import sys
import os
import logging
from selenium.webdriver.common.by import By
from pentagono_crawler import PentagonoCrawler

def test_crawler_initialization():
    """Test crawler initialization"""
    print("Testing crawler initialization...")
    
    try:
        crawler = PentagonoCrawler(
            download_dir="test_downloads",
            headless=True
        )
        print("✓ Crawler initialized successfully")
        return True
    except Exception as e:
        print(f"✗ Crawler initialization failed: {e}")
        return False

def test_webdriver_setup():
    """Test WebDriver setup"""
    print("Testing WebDriver setup...")
    
    try:
        crawler = PentagonoCrawler(
            download_dir="test_downloads",
            headless=True
        )
        
        driver = crawler.setup_driver()
        if driver:
            print("✓ WebDriver setup successful")
            
            # Test basic navigation
            driver.get("https://www.google.com")
            if "Google" in driver.title:
                print("✓ Basic navigation test passed")
                crawler.close_driver()
                return True
            else:
                print("✗ Basic navigation test failed")
                crawler.close_driver()
                return False
        else:
            print("✗ WebDriver setup failed")
            return False
            
    except Exception as e:
        print(f"✗ WebDriver test failed: {e}")
        return False

def test_pentagono_website_access():
    """Test access to Pentágono website"""
    print("Testing Pentágono website access...")
    
    try:
        crawler = PentagonoCrawler(
            download_dir="test_downloads",
            headless=True
        )
        
        crawler.setup_driver()
        crawler.driver.get(crawler.BASE_URL)
        
        if "Pentágono" in crawler.driver.title:
            print("✓ Pentágono website accessible")
            crawler.close_driver()
            return True
        else:
            print(f"✗ Unexpected page title: {crawler.driver.title}")
            crawler.close_driver()
            return False
            
    except Exception as e:
        print(f"✗ Pentágono website access failed: {e}")
        return False

def test_investor_page_access():
    """Test access to investor information page"""
    print("Testing investor page access...")
    
    try:
        crawler = PentagonoCrawler(
            download_dir="test_downloads",
            headless=True
        )
        
        crawler.setup_driver()
        crawler.driver.get(crawler.INVESTOR_URL)
        
        # Check if we can find the main sections
        sections = crawler.driver.find_elements(By.TAG_NAME, "a")
        section_texts = [section.text for section in sections if section.text]
        
        if any("debêntures" in text.lower() or "debentures" in text.lower() for text in section_texts):
            print("✓ Investor page accessible and contains expected content")
            crawler.close_driver()
            return True
        else:
            print("✗ Investor page doesn't contain expected content")
            print(f"Found sections: {section_texts[:10]}")  # Show first 10
            crawler.close_driver()
            return False
            
    except Exception as e:
        print(f"✗ Investor page access failed: {e}")
        return False

def test_document_classification():
    """Test document type classification"""
    print("Testing document classification...")
    
    crawler = PentagonoCrawler(
        download_dir="test_downloads",
        headless=True
    )
    
    test_cases = [
        ("ADAG11 - Escritura de Emissão - 2020.11.24.pdf", "Escritura_Emissao"),
        ("11C0035926 - AGT - 2016.08.23.pdf", "Assembleia_Geral_Titulares"),
        ("Contrato de Cessão Fiduciária - 2020.11.24.pdf", "Cessao_Fiduciaria"),
        ("1º Aditamento da Cessão Fiduciária.pdf", "Aditamento"),
        ("Ata da AGT - 2016.07.04.pdf", "Ata_Assembleia"),
        ("Unknown document.pdf", "Outros")
    ]
    
    all_passed = True
    for filename, expected_type in test_cases:
        result = crawler._classify_document_type(filename)
        if result == expected_type:
            print(f"✓ {filename} -> {result}")
        else:
            print(f"✗ {filename} -> {result} (expected {expected_type})")
            all_passed = False
    
    return all_passed

def test_filename_sanitization():
    """Test filename sanitization"""
    print("Testing filename sanitization...")
    
    crawler = PentagonoCrawler(
        download_dir="test_downloads",
        headless=True
    )
    
    test_cases = [
        ("File with spaces.pdf", "File_with_spaces.pdf"),
        ("File<with>invalid:chars.pdf", "File_with_invalid_chars.pdf"),
        ("File without extension", "File_without_extension.pdf"),
        ("Normal_file.pdf", "Normal_file.pdf")
    ]
    
    all_passed = True
    for input_name, expected in test_cases:
        result = crawler._sanitize_filename(input_name)
        if result == expected:
            print(f"✓ '{input_name}' -> '{result}'")
        else:
            print(f"✗ '{input_name}' -> '{result}' (expected '{expected}')")
            all_passed = False
    
    return all_passed

def run_all_tests():
    """Run all tests"""
    print("=" * 60)
    print("Pentágono SA DTVM Crawler - Test Suite")
    print("=" * 60)
    
    tests = [
        ("Crawler Initialization", test_crawler_initialization),
        ("WebDriver Setup", test_webdriver_setup),
        ("Pentágono Website Access", test_pentagono_website_access),
        ("Investor Page Access", test_investor_page_access),
        ("Document Classification", test_document_classification),
        ("Filename Sanitization", test_filename_sanitization)
    ]
    
    results = []
    
    for test_name, test_func in tests:
        print(f"\n{test_name}:")
        print("-" * 40)
        try:
            result = test_func()
            results.append((test_name, result))
        except Exception as e:
            print(f"✗ Test failed with exception: {e}")
            results.append((test_name, False))
    
    # Summary
    print("\n" + "=" * 60)
    print("TEST SUMMARY")
    print("=" * 60)
    
    passed = 0
    total = len(results)
    
    for test_name, result in results:
        status = "PASS" if result else "FAIL"
        print(f"{test_name}: {status}")
        if result:
            passed += 1
    
    print(f"\nTotal: {passed}/{total} tests passed")
    
    if passed == total:
        print("🎉 All tests passed!")
        return True
    else:
        print("❌ Some tests failed. Check the output above for details.")
        return False

if __name__ == "__main__":
    # Setup basic logging
    logging.basicConfig(level=logging.WARNING)
    
    success = run_all_tests()
    sys.exit(0 if success else 1)

