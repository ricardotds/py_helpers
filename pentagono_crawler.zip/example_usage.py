#!/usr/bin/env python3
"""
Example usage of the Pentágono SA DTVM crawler
"""

from pentagono_crawler import PentagonoCrawler
import logging

def example_basic_usage():
    """Basic usage example - crawl all debentures"""
    print("=== Basic Usage Example ===")
    
    # Create crawler instance
    crawler = PentagonoCrawler(
        download_dir="example_downloads",
        headless=True  # Set to False to see browser in action
    )
    
    # Crawl only debentures (type 1) with limit for testing
    crawler.crawl_all(
        instrument_types=[1],  # Only debentures
        max_assets_per_type=5  # Limit to 5 assets for testing
    )
    
    print(f"Found {len(crawler.assets)} assets")
    print(f"Found {len(crawler.documents)} documents")

def example_specific_types():
    """Example crawling specific instrument types"""
    print("=== Specific Types Example ===")
    
    crawler = PentagonoCrawler(
        download_dir="specific_types_downloads",
        headless=True
    )
    
    # Crawl debentures and real estate receivables certificates
    crawler.crawl_all(
        instrument_types=[1, 3],  # Debentures and CRI
        max_assets_per_type=3
    )
    
    print(f"Found {len(crawler.assets)} assets")
    print(f"Found {len(crawler.documents)} documents")

def example_full_crawl():
    """Example full crawl (use with caution - will download many files)"""
    print("=== Full Crawl Example (Commented Out) ===")
    print("Uncomment the code below to run a full crawl")
    
    # WARNING: This will download potentially thousands of files
    # Uncomment only if you want to crawl everything
    
    # crawler = PentagonoCrawler(
    #     download_dir="full_crawl_downloads",
    #     headless=True
    # )
    # 
    # # Crawl all instrument types
    # crawler.crawl_all()
    # 
    # print(f"Found {len(crawler.assets)} assets")
    # print(f"Found {len(crawler.documents)} documents")

def example_with_custom_settings():
    """Example with custom settings and error handling"""
    print("=== Custom Settings Example ===")
    
    # Setup custom logging
    logging.basicConfig(level=logging.INFO)
    
    try:
        crawler = PentagonoCrawler(
            download_dir="custom_downloads",
            headless=False  # Show browser for debugging
        )
        
        # Crawl with custom parameters
        crawler.crawl_all(
            instrument_types=[1],  # Only debentures
            max_assets_per_type=2   # Very limited for demo
        )
        
        # Print some statistics
        print("\n=== Crawl Statistics ===")
        print(f"Total assets found: {len(crawler.assets)}")
        print(f"Total documents found: {len(crawler.documents)}")
        
        # Show asset types distribution
        asset_types = {}
        for asset in crawler.assets:
            asset_types[asset.asset_type] = asset_types.get(asset.asset_type, 0) + 1
        
        print("\nAssets by type:")
        for asset_type, count in asset_types.items():
            print(f"  {asset_type}: {count}")
        
        # Show document types distribution
        doc_types = {}
        for doc in crawler.documents:
            doc_types[doc.document_type] = doc_types.get(doc.document_type, 0) + 1
        
        print("\nDocuments by type:")
        for doc_type, count in doc_types.items():
            print(f"  {doc_type}: {count}")
            
    except Exception as e:
        print(f"Error during crawling: {e}")
        logging.error(f"Crawling failed: {e}")

if __name__ == "__main__":
    print("Pentágono SA DTVM Crawler - Usage Examples")
    print("=" * 50)
    
    # Run basic example
    example_basic_usage()
    
    print("\n" + "=" * 50)
    
    # Run specific types example
    example_specific_types()
    
    print("\n" + "=" * 50)
    
    # Show full crawl example (commented)
    example_full_crawl()
    
    print("\n" + "=" * 50)
    
    # Run custom settings example
    example_with_custom_settings()
    
    print("\nAll examples completed!")

