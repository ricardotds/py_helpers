#!/bin/bash

# Brazilian Debenture Management System - Update Script
# Usage: ./scripts/update.sh [development|production]

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Default environment
ENVIRONMENT=${1:-development}

echo -e "${BLUE}🔄 Starting update process for ${ENVIRONMENT} environment${NC}"

# Create backup before update
echo -e "${BLUE}💾 Creating backup before update${NC}"
./scripts/backup.sh

# Pull latest code (if using git)
if [ -d ".git" ]; then
    echo -e "${BLUE}📥 Pulling latest code${NC}"
    git pull origin main
fi

# Update dependencies
echo -e "${BLUE}📦 Updating dependencies${NC}"
if [ "$ENVIRONMENT" = "production" ]; then
    docker-compose -f docker-compose.prod.yml pull
    docker-compose -f docker-compose.prod.yml build --no-cache
else
    docker-compose pull
    docker-compose build --no-cache
fi

# Stop services gracefully
echo -e "${BLUE}🛑 Stopping services${NC}"
if [ "$ENVIRONMENT" = "production" ]; then
    docker-compose -f docker-compose.prod.yml down
else
    docker-compose down
fi

# Start updated services
echo -e "${BLUE}🚀 Starting updated services${NC}"
if [ "$ENVIRONMENT" = "production" ]; then
    docker-compose -f docker-compose.prod.yml up -d
else
    docker-compose up -d
fi

# Wait for services to be ready
echo -e "${BLUE}⏳ Waiting for services to be ready${NC}"
sleep 30

# Run database migrations if needed
echo -e "${BLUE}🗄️  Running database migrations${NC}"
if [ "$ENVIRONMENT" = "production" ]; then
    docker-compose -f docker-compose.prod.yml exec backend python run.py --migrate
else
    docker-compose exec backend python run.py --migrate
fi

# Check service health
echo -e "${BLUE}🏥 Checking service health${NC}"
sleep 10

# Check backend health
if curl -f http://localhost:8000/health > /dev/null 2>&1; then
    echo -e "${GREEN}✅ Backend is healthy${NC}"
else
    echo -e "${RED}❌ Backend health check failed${NC}"
    echo -e "${YELLOW}🔄 Rolling back to previous version${NC}"
    # Add rollback logic here if needed
    exit 1
fi

# Check frontend health
if curl -f http://localhost/health > /dev/null 2>&1; then
    echo -e "${GREEN}✅ Frontend is healthy${NC}"
else
    echo -e "${RED}❌ Frontend health check failed${NC}"
fi

# Clean up old images
echo -e "${BLUE}🧹 Cleaning up old Docker images${NC}"
docker image prune -f

echo -e "${GREEN}🎉 Update completed successfully!${NC}"
echo -e "${BLUE}📊 Service Status:${NC}"
if [ "$ENVIRONMENT" = "production" ]; then
    docker-compose -f docker-compose.prod.yml ps
else
    docker-compose ps
fi

