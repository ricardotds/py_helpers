#!/bin/bash

# Brazilian Debenture Management System - Restore Script
# Usage: ./scripts/restore.sh [backup_date]

set -e

# Configuration
BACKUP_DIR="/backups"
BACKUP_DATE=${1}

# Database configuration
DB_HOST="postgres"
DB_NAME="${POSTGRES_DB:-debenture_management}"
DB_USER="${POSTGRES_USER:-postgres}"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

if [ -z "$BACKUP_DATE" ]; then
    echo -e "${YELLOW}📅 Available backups:${NC}"
    ls -la ${BACKUP_DIR}/database/ | grep "db_backup_" | awk '{print $9}' | sed 's/db_backup_//g' | sed 's/.sql.gz//g'
    echo -e "${BLUE}Usage: ./scripts/restore.sh [backup_date]${NC}"
    echo -e "${BLUE}Example: ./scripts/restore.sh 20241221_143000${NC}"
    exit 1
fi

echo -e "${BLUE}🔄 Starting restore process for backup: ${BACKUP_DATE}${NC}"

# Check if backup files exist
DB_BACKUP_FILE="${BACKUP_DIR}/database/db_backup_${BACKUP_DATE}.sql.gz"
STORAGE_BACKUP_FILE="${BACKUP_DIR}/files/storage_backup_${BACKUP_DATE}.tar.gz"
CONFIG_BACKUP_FILE="${BACKUP_DIR}/config_backup_${BACKUP_DATE}.env"
LOGS_BACKUP_FILE="${BACKUP_DIR}/logs/logs_backup_${BACKUP_DATE}.tar.gz"

if [ ! -f "$DB_BACKUP_FILE" ]; then
    echo -e "${RED}❌ Database backup file not found: ${DB_BACKUP_FILE}${NC}"
    exit 1
fi

# Confirm restore operation
echo -e "${YELLOW}⚠️  WARNING: This will overwrite the current database and files!${NC}"
read -p "Are you sure you want to continue? (y/N): " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo -e "${BLUE}ℹ️  Restore operation cancelled${NC}"
    exit 0
fi

# Stop application services
echo -e "${BLUE}🛑 Stopping application services${NC}"
docker-compose stop backend

# Restore database
echo -e "${BLUE}🗄️  Restoring database${NC}"
gunzip -c ${DB_BACKUP_FILE} | psql -h ${DB_HOST} -U ${DB_USER} -d ${DB_NAME}

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✅ Database restore completed${NC}"
else
    echo -e "${RED}❌ Database restore failed${NC}"
    exit 1
fi

# Restore storage files
if [ -f "$STORAGE_BACKUP_FILE" ]; then
    echo -e "${BLUE}📁 Restoring storage files${NC}"
    rm -rf /app/storage/*
    tar -xzf ${STORAGE_BACKUP_FILE} -C /app/
    echo -e "${GREEN}✅ Storage files restored${NC}"
else
    echo -e "${YELLOW}⚠️  Storage backup file not found, skipping${NC}"
fi

# Restore configuration
if [ -f "$CONFIG_BACKUP_FILE" ]; then
    echo -e "${BLUE}⚙️  Restoring configuration${NC}"
    cp ${CONFIG_BACKUP_FILE} /app/.env
    echo -e "${GREEN}✅ Configuration restored${NC}"
else
    echo -e "${YELLOW}⚠️  Configuration backup file not found, skipping${NC}"
fi

# Restore logs
if [ -f "$LOGS_BACKUP_FILE" ]; then
    echo -e "${BLUE}📋 Restoring logs${NC}"
    rm -rf /app/logs/*
    tar -xzf ${LOGS_BACKUP_FILE} -C /app/
    echo -e "${GREEN}✅ Logs restored${NC}"
else
    echo -e "${YELLOW}⚠️  Logs backup file not found, skipping${NC}"
fi

# Start application services
echo -e "${BLUE}🚀 Starting application services${NC}"
docker-compose start backend

# Wait for services to be ready
echo -e "${BLUE}⏳ Waiting for services to be ready${NC}"
sleep 10

# Check service health
if curl -f http://localhost:8000/health > /dev/null 2>&1; then
    echo -e "${GREEN}✅ Backend is healthy after restore${NC}"
else
    echo -e "${RED}❌ Backend health check failed after restore${NC}"
fi

echo -e "${GREEN}🎉 Restore process completed successfully!${NC}"
echo -e "${BLUE}📊 Restored from backup: ${BACKUP_DATE}${NC}"

