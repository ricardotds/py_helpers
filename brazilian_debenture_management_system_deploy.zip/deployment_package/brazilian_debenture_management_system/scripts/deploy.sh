#!/bin/bash

# Brazilian Debenture Management System - Deployment Script
# Usage: ./scripts/deploy.sh [development|production]

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Default environment
ENVIRONMENT=${1:-development}

echo -e "${BLUE}🚀 Starting deployment for ${ENVIRONMENT} environment${NC}"

# Check if Docker is installed
if ! command -v docker &> /dev/null; then
    echo -e "${RED}❌ Docker is not installed. Please install Docker first.${NC}"
    exit 1
fi

# Check if Docker Compose is installed
if ! command -v docker-compose &> /dev/null; then
    echo -e "${RED}❌ Docker Compose is not installed. Please install Docker Compose first.${NC}"
    exit 1
fi

# Create .env file if it doesn't exist
if [ ! -f .env ]; then
    echo -e "${YELLOW}⚠️  .env file not found. Creating from .env.example${NC}"
    cp .env.example .env
    echo -e "${YELLOW}⚠️  Please edit .env file with your configuration before continuing${NC}"
    read -p "Press Enter to continue after editing .env file..."
fi

# Create necessary directories
echo -e "${BLUE}📁 Creating necessary directories${NC}"
mkdir -p storage/documents storage/logs backups logs/nginx

# Set proper permissions
echo -e "${BLUE}🔒 Setting proper permissions${NC}"
chmod +x scripts/*.sh
chmod 755 storage logs backups

# Build and start services based on environment
if [ "$ENVIRONMENT" = "production" ]; then
    echo -e "${BLUE}🏭 Deploying to production environment${NC}"
    
    # Pull latest images
    echo -e "${BLUE}📥 Pulling latest images${NC}"
    docker-compose -f docker-compose.prod.yml pull
    
    # Build and start services
    echo -e "${BLUE}🔨 Building and starting services${NC}"
    docker-compose -f docker-compose.prod.yml up -d --build
    
    # Wait for services to be healthy
    echo -e "${BLUE}⏳ Waiting for services to be healthy${NC}"
    sleep 30
    
    # Initialize database
    echo -e "${BLUE}🗄️  Initializing database${NC}"
    docker-compose -f docker-compose.prod.yml exec backend python run.py --init-db
    
    # Setup SSL certificates (if needed)
    if [ ! -f nginx/ssl/cert.pem ]; then
        echo -e "${YELLOW}⚠️  SSL certificates not found. Please configure SSL certificates for production${NC}"
    fi
    
else
    echo -e "${BLUE}🛠️  Deploying to development environment${NC}"
    
    # Build and start services
    echo -e "${BLUE}🔨 Building and starting services${NC}"
    docker-compose up -d --build
    
    # Wait for services to be healthy
    echo -e "${BLUE}⏳ Waiting for services to be healthy${NC}"
    sleep 20
    
    # Initialize database
    echo -e "${BLUE}🗄️  Initializing database${NC}"
    docker-compose exec backend python run.py --init-db
fi

# Check service health
echo -e "${BLUE}🏥 Checking service health${NC}"
sleep 10

# Check backend health
if curl -f http://localhost:8000/health > /dev/null 2>&1; then
    echo -e "${GREEN}✅ Backend is healthy${NC}"
else
    echo -e "${RED}❌ Backend health check failed${NC}"
fi

# Check frontend health
if curl -f http://localhost/health > /dev/null 2>&1; then
    echo -e "${GREEN}✅ Frontend is healthy${NC}"
else
    echo -e "${RED}❌ Frontend health check failed${NC}"
fi

# Show service status
echo -e "${BLUE}📊 Service Status${NC}"
if [ "$ENVIRONMENT" = "production" ]; then
    docker-compose -f docker-compose.prod.yml ps
else
    docker-compose ps
fi

# Show access URLs
echo -e "${GREEN}🎉 Deployment completed successfully!${NC}"
echo -e "${BLUE}📱 Access URLs:${NC}"
echo -e "   Frontend: ${GREEN}http://localhost${NC}"
echo -e "   Backend API: ${GREEN}http://localhost:8000${NC}"
echo -e "   API Documentation: ${GREEN}http://localhost:8000/docs${NC}"

if [ "$ENVIRONMENT" = "production" ]; then
    echo -e "   HTTPS Frontend: ${GREEN}https://localhost${NC}"
    echo -e "   Monitoring (if enabled): ${GREEN}http://localhost:3000${NC}"
fi

echo -e "${BLUE}📝 Useful commands:${NC}"
echo -e "   View logs: ${YELLOW}docker-compose logs -f${NC}"
echo -e "   Stop services: ${YELLOW}docker-compose down${NC}"
echo -e "   Restart services: ${YELLOW}docker-compose restart${NC}"
echo -e "   Update services: ${YELLOW}./scripts/deploy.sh ${ENVIRONMENT}${NC}"

echo -e "${GREEN}✨ Happy crawling!${NC}"

