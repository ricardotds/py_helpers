#!/bin/bash

# Brazilian Debenture Management System - Backup Script
# This script creates backups of the database and important files

set -e

# Configuration
BACKUP_DIR="/backups"
DATE=$(date +%Y%m%d_%H%M%S)
RETENTION_DAYS=30

# Database configuration
DB_HOST="postgres"
DB_NAME="${POSTGRES_DB:-debenture_management}"
DB_USER="${POSTGRES_USER:-postgres}"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}🔄 Starting backup process - ${DATE}${NC}"

# Create backup directory if it doesn't exist
mkdir -p ${BACKUP_DIR}/database
mkdir -p ${BACKUP_DIR}/files
mkdir -p ${BACKUP_DIR}/logs

# Database backup
echo -e "${BLUE}🗄️  Creating database backup${NC}"
pg_dump -h ${DB_HOST} -U ${DB_USER} -d ${DB_NAME} | gzip > ${BACKUP_DIR}/database/db_backup_${DATE}.sql.gz

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✅ Database backup completed: db_backup_${DATE}.sql.gz${NC}"
else
    echo -e "${RED}❌ Database backup failed${NC}"
    exit 1
fi

# Files backup
echo -e "${BLUE}📁 Creating files backup${NC}"
if [ -d "/app/storage" ]; then
    tar -czf ${BACKUP_DIR}/files/storage_backup_${DATE}.tar.gz -C /app storage/
    echo -e "${GREEN}✅ Storage backup completed: storage_backup_${DATE}.tar.gz${NC}"
fi

# Configuration backup
echo -e "${BLUE}⚙️  Creating configuration backup${NC}"
if [ -f "/app/.env" ]; then
    cp /app/.env ${BACKUP_DIR}/config_backup_${DATE}.env
    echo -e "${GREEN}✅ Configuration backup completed: config_backup_${DATE}.env${NC}"
fi

# Logs backup
echo -e "${BLUE}📋 Creating logs backup${NC}"
if [ -d "/app/logs" ]; then
    tar -czf ${BACKUP_DIR}/logs/logs_backup_${DATE}.tar.gz -C /app logs/
    echo -e "${GREEN}✅ Logs backup completed: logs_backup_${DATE}.tar.gz${NC}"
fi

# Cleanup old backups
echo -e "${BLUE}🧹 Cleaning up old backups (older than ${RETENTION_DAYS} days)${NC}"
find ${BACKUP_DIR} -type f -mtime +${RETENTION_DAYS} -delete
echo -e "${GREEN}✅ Cleanup completed${NC}"

# Create backup summary
echo -e "${BLUE}📊 Backup Summary${NC}"
echo "Backup Date: ${DATE}" > ${BACKUP_DIR}/backup_summary_${DATE}.txt
echo "Database: ${DB_NAME}" >> ${BACKUP_DIR}/backup_summary_${DATE}.txt
echo "Files:" >> ${BACKUP_DIR}/backup_summary_${DATE}.txt
ls -la ${BACKUP_DIR}/database/db_backup_${DATE}.sql.gz >> ${BACKUP_DIR}/backup_summary_${DATE}.txt 2>/dev/null || echo "No database backup" >> ${BACKUP_DIR}/backup_summary_${DATE}.txt
ls -la ${BACKUP_DIR}/files/storage_backup_${DATE}.tar.gz >> ${BACKUP_DIR}/backup_summary_${DATE}.txt 2>/dev/null || echo "No storage backup" >> ${BACKUP_DIR}/backup_summary_${DATE}.txt
ls -la ${BACKUP_DIR}/logs/logs_backup_${DATE}.tar.gz >> ${BACKUP_DIR}/backup_summary_${DATE}.txt 2>/dev/null || echo "No logs backup" >> ${BACKUP_DIR}/backup_summary_${DATE}.txt

echo -e "${GREEN}🎉 Backup process completed successfully!${NC}"
echo -e "${BLUE}📁 Backup location: ${BACKUP_DIR}${NC}"
echo -e "${BLUE}📝 Summary: backup_summary_${DATE}.txt${NC}"

