#!/usr/bin/env python3
"""
Application startup script
"""

import os
import sys
import logging
import uvicorn
from pathlib import Path

# Add the app directory to Python path
app_dir = Path(__file__).parent / "app"
sys.path.insert(0, str(app_dir))

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

logger = logging.getLogger(__name__)


def init_database():
    """Initialize database with tables and default data"""
    try:
        from app.db.init_db import init_db
        logger.info("Initializing database...")
        init_db()
        logger.info("Database initialization completed")
    except Exception as e:
        logger.error(f"Database initialization failed: {str(e)}")
        sys.exit(1)


def run_server():
    """Run the FastAPI server"""
    logger.info("Starting FastAPI server...")
    
    # Set environment variables if not set
    if not os.getenv("DATABASE_URL"):
        os.environ["DATABASE_URL"] = "sqlite:///./debenture_management.db"
    
    if not os.getenv("OPENAI_API_KEY"):
        logger.warning("OPENAI_API_KEY not set. LangChain features will not work.")
    
    # Run the server
    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )


if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Brazilian Debenture Management System")
    parser.add_argument("--init-db", action="store_true", help="Initialize database only")
    parser.add_argument("--no-init", action="store_true", help="Skip database initialization")
    
    args = parser.parse_args()
    
    if args.init_db:
        init_database()
    else:
        if not args.no_init:
            init_database()
        run_server()

