"""
Database initialization script
"""

import logging
from sqlalchemy.orm import Session

from app.config.database import engine, SessionLocal
from app.models.base import Base
from app.models.fiduciary_agent import FiduciaryAgent
from app.models.prompt import SystemPrompt
from app.models.schema import OutputSchema

logger = logging.getLogger(__name__)


def create_tables():
    """Create all database tables"""
    logger.info("Creating database tables...")
    Base.metadata.create_all(bind=engine)
    logger.info("Database tables created successfully")


def init_fiduciary_agents(db: Session):
    """Initialize fiduciary agents"""
    agents_data = [
        {
            "name": "Pentágono S.A. Distribuidora de Títulos e Valores Mobiliários",
            "short_name": "Pentágono",
            "website_url": "https://www.pentagonotrustee.com.br/",
            "crawler_class": "PentagonoCrawler",
            "is_active": True
        },
        {
            "name": "Vórtx DTVM Ltda.",
            "short_name": "Vórtx",
            "website_url": "https://www.vortx.com.br/",
            "crawler_class": "VortxCrawler",
            "is_active": True
        },
        {
            "name": "Oliveira Trust DTVM S.A.",
            "short_name": "Oliveira Trust",
            "website_url": "https://www.oliveiratrust.com.br/",
            "crawler_class": "OliveiraTrustCrawler",
            "is_active": True
        },
        {
            "name": "Planner Trustee DTVM Ltda",
            "short_name": "Planner",
            "website_url": "https://www.plannercorretora.com.br/",
            "crawler_class": "PlannerCrawler",
            "is_active": True
        },
        {
            "name": "BTG Pactual Serviços Financeiros S.A. DTVM",
            "short_name": "BTG Pactual",
            "website_url": "https://www.btgpactual.com/",
            "crawler_class": "BTGPactualCrawler",
            "is_active": True
        },
        {
            "name": "BRL Trust DTVM S.A.",
            "short_name": "BRL Trust",
            "website_url": "https://www.brltrust.com.br/",
            "crawler_class": "BRLTrustCrawler",
            "is_active": True
        },
        {
            "name": "XP Investimentos CCTVM S.A.",
            "short_name": "XP Investimentos",
            "website_url": "https://www.xpi.com.br/",
            "crawler_class": "XPInvestimentosCrawler",
            "is_active": True
        },
        {
            "name": "Banco do Brasil S.A.",
            "short_name": "Banco do Brasil",
            "website_url": "https://www.bb.com.br/",
            "crawler_class": "BancoBrasilCrawler",
            "is_active": True
        },
        {
            "name": "Itaú DTVM S.A.",
            "short_name": "Itaú",
            "website_url": "https://www.itau.com.br/",
            "crawler_class": "ItauCrawler",
            "is_active": True
        }
    ]
    
    for agent_data in agents_data:
        existing_agent = db.query(FiduciaryAgent).filter(
            FiduciaryAgent.short_name == agent_data["short_name"]
        ).first()
        
        if not existing_agent:
            agent = FiduciaryAgent(**agent_data)
            db.add(agent)
            logger.info(f"Created fiduciary agent: {agent_data['short_name']}")
    
    db.commit()


def init_system_prompts(db: Session):
    """Initialize default system prompts"""
    prompts_data = [
        {
            "name": "Debenture Analysis - General",
            "description": "General analysis prompt for debenture documents",
            "prompt_text": """Analyze the following debenture document and extract key information.

Focus on:
- Company name and asset code
- Emission details (number, series, total value)
- Financial terms (interest rate, indexer, maturity)
- Guarantees and covenants
- Purpose of the emission

Document text:
{document_text}

Please provide a structured analysis of the document.""",
            "category": "debenture",
            "is_active": True,
            "version": "1.0",
            "created_by": "system"
        },
        {
            "name": "Covenant Analysis",
            "description": "Specific analysis for covenant documents",
            "prompt_text": """Analyze the following covenant document and extract compliance information.

Focus on:
- Covenant types and requirements
- Compliance status
- Financial ratios and limits
- Breach conditions
- Remedial actions

Document text:
{document_text}

Provide detailed covenant analysis.""",
            "category": "covenant",
            "is_active": True,
            "version": "1.0",
            "created_by": "system"
        },
        {
            "name": "Financial Report Analysis",
            "description": "Analysis prompt for financial reports",
            "prompt_text": """Analyze the following financial report and extract key metrics.

Focus on:
- Financial performance indicators
- Revenue and profitability
- Debt levels and ratios
- Cash flow information
- Risk factors

Document text:
{document_text}

Provide comprehensive financial analysis.""",
            "category": "financial",
            "is_active": True,
            "version": "1.0",
            "created_by": "system"
        }
    ]
    
    for prompt_data in prompts_data:
        existing_prompt = db.query(SystemPrompt).filter(
            SystemPrompt.name == prompt_data["name"]
        ).first()
        
        if not existing_prompt:
            prompt = SystemPrompt(**prompt_data)
            db.add(prompt)
            logger.info(f"Created system prompt: {prompt_data['name']}")
    
    db.commit()


def init_output_schemas(db: Session):
    """Initialize default output schemas"""
    schemas_data = [
        {
            "name": "Debenture Basic Info",
            "description": "Basic information schema for debenture documents",
            "schema_definition": {
                "type": "object",
                "properties": {
                    "company_name": {
                        "type": "string",
                        "description": "Name of the issuing company"
                    },
                    "asset_code": {
                        "type": "string",
                        "description": "Asset code (e.g., ADAG11)"
                    },
                    "emission_number": {
                        "type": "string",
                        "description": "Emission number"
                    },
                    "series": {
                        "type": "string",
                        "description": "Series information"
                    },
                    "total_value": {
                        "type": "number",
                        "description": "Total emission value in BRL"
                    },
                    "unit_value": {
                        "type": "number",
                        "description": "Unit value of each debenture"
                    },
                    "maturity_date": {
                        "type": "string",
                        "format": "date",
                        "description": "Maturity date of the debenture"
                    },
                    "interest_rate": {
                        "type": "number",
                        "description": "Interest rate percentage"
                    },
                    "indexer": {
                        "type": "string",
                        "description": "Indexer (e.g., CDI, IPCA)",
                        "enum": ["CDI", "IPCA", "SELIC", "PRE", "IGP-M"]
                    }
                },
                "required": ["company_name", "asset_code", "total_value", "maturity_date"]
            },
            "category": "debenture",
            "is_active": True,
            "version": "1.0",
            "created_by": "system"
        },
        {
            "name": "Covenant Compliance",
            "description": "Schema for covenant compliance analysis",
            "schema_definition": {
                "type": "object",
                "properties": {
                    "covenant_type": {
                        "type": "string",
                        "description": "Type of covenant"
                    },
                    "requirement": {
                        "type": "string",
                        "description": "Covenant requirement description"
                    },
                    "current_value": {
                        "type": "number",
                        "description": "Current measured value"
                    },
                    "limit_value": {
                        "type": "number",
                        "description": "Covenant limit value"
                    },
                    "compliance_status": {
                        "type": "string",
                        "enum": ["compliant", "non_compliant", "warning"],
                        "description": "Compliance status"
                    },
                    "measurement_date": {
                        "type": "string",
                        "format": "date",
                        "description": "Date of measurement"
                    }
                },
                "required": ["covenant_type", "compliance_status"]
            },
            "category": "covenant",
            "is_active": True,
            "version": "1.0",
            "created_by": "system"
        },
        {
            "name": "Financial Metrics",
            "description": "Schema for financial metrics extraction",
            "schema_definition": {
                "type": "object",
                "properties": {
                    "revenue": {
                        "type": "number",
                        "description": "Total revenue"
                    },
                    "net_income": {
                        "type": "number",
                        "description": "Net income"
                    },
                    "total_debt": {
                        "type": "number",
                        "description": "Total debt"
                    },
                    "equity": {
                        "type": "number",
                        "description": "Total equity"
                    },
                    "debt_to_equity_ratio": {
                        "type": "number",
                        "description": "Debt to equity ratio"
                    },
                    "ebitda": {
                        "type": "number",
                        "description": "EBITDA"
                    },
                    "period": {
                        "type": "string",
                        "description": "Reporting period"
                    }
                },
                "required": ["revenue", "period"]
            },
            "category": "financial",
            "is_active": True,
            "version": "1.0",
            "created_by": "system"
        }
    ]
    
    for schema_data in schemas_data:
        existing_schema = db.query(OutputSchema).filter(
            OutputSchema.name == schema_data["name"]
        ).first()
        
        if not existing_schema:
            schema = OutputSchema(**schema_data)
            db.add(schema)
            logger.info(f"Created output schema: {schema_data['name']}")
    
    db.commit()


def init_db():
    """Initialize the database with tables and default data"""
    logger.info("Initializing database...")
    
    # Create tables
    create_tables()
    
    # Create session
    db = SessionLocal()
    
    try:
        # Initialize default data
        init_fiduciary_agents(db)
        init_system_prompts(db)
        init_output_schemas(db)
        
        logger.info("Database initialization completed successfully")
        
    except Exception as e:
        logger.error(f"Database initialization failed: {str(e)}")
        db.rollback()
        raise
    finally:
        db.close()


if __name__ == "__main__":
    init_db()

