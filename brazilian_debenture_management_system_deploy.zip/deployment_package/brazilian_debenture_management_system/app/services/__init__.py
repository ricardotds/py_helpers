"""Services package for business logic"""

from app.services.crawler_service import CrawlerService

__all__ = ["CrawlerService"]

