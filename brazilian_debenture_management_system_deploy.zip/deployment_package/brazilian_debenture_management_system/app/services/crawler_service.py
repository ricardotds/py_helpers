"""
Crawler Service for managing crawler execution and database integration
"""

from typing import Optional, Set, Dict, Type
from datetime import datetime, date
from pathlib import Path
import logging
from sqlalchemy.orm import Session

from app.models.fiduciary_agent import FiduciaryAgent
from app.models.document import Document
from app.models.crawler import CrawlerRun
from app.crawlers.base_crawler import BaseCrawler, DocumentInfo, CrawlerResult
from app.crawlers.pentagono_crawler import PentagonoCrawler
from app.crawlers.vortx_crawler import VortxCrawler
from app.crawlers.oliveira_trust_crawler import OliveiraTrustCrawler
from app.config.settings import get_settings

logger = logging.getLogger(__name__)
settings = get_settings()


class CrawlerService:
    """Service for managing crawler execution"""
    
    # Mapping of crawler class names to actual classes
    CRAWLER_CLASSES: Dict[str, Type[BaseCrawler]] = {
        'PentagonoCrawler': PentagonoCrawler,
        'VortxCrawler': VortxCrawler,
        'OliveiraTrustCrawler': OliveiraTrustCrawler,
    }
    
    def __init__(self, db: Session):
        self.db = db
        self.storage_path = Path(settings.DOCUMENTS_PATH)
        self.storage_path.mkdir(parents=True, exist_ok=True)
    
    def get_crawler_class(self, crawler_class_name: str) -> Optional[Type[BaseCrawler]]:
        """Get crawler class by name"""
        return self.CRAWLER_CLASSES.get(crawler_class_name)
    
    def create_crawler_instance(self, agent: FiduciaryAgent) -> Optional[BaseCrawler]:
        """Create crawler instance for fiduciary agent"""
        crawler_class = self.get_crawler_class(agent.crawler_class)
        if not crawler_class:
            logger.error(f"Unknown crawler class: {agent.crawler_class}")
            return None
        
        return crawler_class(agent.id, self.storage_path)
    
    def get_existing_document_hashes(self, agent_id: int) -> Set[str]:
        """Get set of existing document hashes for an agent"""
        documents = self.db.query(Document).filter(
            Document.fiduciary_agent_id == agent_id,
            Document.file_hash.isnot(None)
        ).all()
        
        return {doc.file_hash for doc in documents if doc.file_hash}
    
    def execute_crawler(self, agent_id: int, 
                       date_from: Optional[date] = None,
                       date_to: Optional[date] = None,
                       force_full_crawl: bool = False) -> CrawlerResult:
        """Execute crawler for specific agent"""
        
        # Get fiduciary agent
        agent = self.db.query(FiduciaryAgent).filter(
            FiduciaryAgent.id == agent_id
        ).first()
        
        if not agent:
            raise ValueError(f"Fiduciary agent with ID {agent_id} not found")
        
        if not agent.is_active:
            raise ValueError(f"Fiduciary agent {agent.short_name} is not active")
        
        # Create crawler run record
        crawler_run = CrawlerRun(
            fiduciary_agent_id=agent_id,
            status="running",
            start_time=datetime.now(),
            force_full_crawl=str(force_full_crawl).lower(),
            date_range_from=datetime.combine(date_from, datetime.min.time()) if date_from else None,
            date_range_to=datetime.combine(date_to, datetime.min.time()) if date_to else None
        )
        
        self.db.add(crawler_run)
        self.db.commit()
        self.db.refresh(crawler_run)
        
        try:
            logger.info(f"Starting crawler for {agent.short_name} (ID: {agent_id})")
            
            # Create crawler instance
            crawler = self.create_crawler_instance(agent)
            if not crawler:
                raise ValueError(f"Failed to create crawler for {agent.short_name}")
            
            # Get existing document hashes to avoid duplicates
            existing_hashes = self.get_existing_document_hashes(agent_id) if not force_full_crawl else set()
            
            # Execute crawler
            result = crawler.execute(
                date_from=date_from,
                date_to=date_to,
                force_full_crawl=force_full_crawl,
                existing_hashes=existing_hashes
            )
            
            # Save discovered documents to database
            documents_saved = self.save_documents_to_database(
                crawler.documents_downloaded, 
                agent_id, 
                crawler_run.id
            )
            
            # Update crawler run with results
            crawler_run.status = "completed"
            crawler_run.end_time = datetime.now()
            crawler_run.documents_found = result.documents_found
            crawler_run.documents_downloaded = documents_saved
            crawler_run.documents_skipped = result.documents_skipped
            crawler_run.errors_count = len(result.errors)
            crawler_run.error_details = "\n".join(result.errors) if result.errors else None
            crawler_run.execution_time_seconds = int(result.execution_time)
            crawler_run.last_page_processed = result.last_page_processed
            crawler_run.pages_processed = result.total_pages
            
            self.db.commit()
            
            logger.info(f"Crawler completed for {agent.short_name}: {documents_saved} documents saved")
            
            return result
            
        except Exception as e:
            # Update crawler run with error
            crawler_run.status = "failed"
            crawler_run.end_time = datetime.now()
            crawler_run.error_details = str(e)
            crawler_run.errors_count = 1
            
            self.db.commit()
            
            logger.error(f"Crawler failed for {agent.short_name}: {str(e)}")
            raise
    
    def save_documents_to_database(self, downloaded_documents, agent_id: int, crawler_run_id: int) -> int:
        """Save downloaded documents to database"""
        documents_saved = 0
        
        for doc_info, file_path, file_hash in downloaded_documents:
            try:
                # Check if document already exists (by hash)
                existing_doc = self.db.query(Document).filter(
                    Document.file_hash == file_hash
                ).first()
                
                if existing_doc:
                    logger.info(f"Document already exists: {doc_info.document_name}")
                    continue
                
                # Create new document record
                document = Document(
                    fiduciary_agent_id=agent_id,
                    company_name=doc_info.company_name,
                    asset_code=doc_info.asset_code,
                    emission_number=doc_info.emission_number,
                    series=doc_info.series,
                    document_type=doc_info.document_type,
                    document_name=doc_info.document_name,
                    file_path=file_path,
                    file_size=doc_info.file_size,
                    file_hash=file_hash,
                    document_date=doc_info.document_date,
                    download_date=datetime.now(),
                    last_modified=doc_info.last_modified,
                    source_url=doc_info.source_url,
                    is_processed=False
                )
                
                self.db.add(document)
                documents_saved += 1
                
                logger.info(f"Saved document: {doc_info.document_name}")
                
            except Exception as e:
                logger.error(f"Failed to save document {doc_info.document_name}: {str(e)}")
                continue
        
        # Commit all documents
        try:
            self.db.commit()
            logger.info(f"Successfully saved {documents_saved} documents to database")
        except Exception as e:
            self.db.rollback()
            logger.error(f"Failed to commit documents to database: {str(e)}")
            documents_saved = 0
        
        return documents_saved
    
    def get_crawler_status(self, agent_id: int) -> Dict:
        """Get current status of crawler for agent"""
        agent = self.db.query(FiduciaryAgent).filter(
            FiduciaryAgent.id == agent_id
        ).first()
        
        if not agent:
            raise ValueError(f"Fiduciary agent with ID {agent_id} not found")
        
        # Get latest crawler run
        latest_run = self.db.query(CrawlerRun).filter(
            CrawlerRun.fiduciary_agent_id == agent_id
        ).order_by(CrawlerRun.start_time.desc()).first()
        
        # Get running crawler
        running_crawler = self.db.query(CrawlerRun).filter(
            CrawlerRun.fiduciary_agent_id == agent_id,
            CrawlerRun.status == "running"
        ).first()
        
        # Determine status
        status = "idle"
        if running_crawler:
            status = "running"
        elif latest_run:
            status = latest_run.status
        
        # Get document count
        document_count = self.db.query(Document).filter(
            Document.fiduciary_agent_id == agent_id
        ).count()
        
        return {
            "agent_id": agent_id,
            "agent_name": agent.short_name,
            "status": status,
            "last_run": latest_run.start_time if latest_run else None,
            "documents_found_last_run": latest_run.documents_found if latest_run else 0,
            "documents_downloaded_last_run": latest_run.documents_downloaded if latest_run else 0,
            "errors_last_run": latest_run.errors_count if latest_run else 0,
            "total_documents": document_count,
            "is_active": agent.is_active
        }
    
    def stop_crawler(self, agent_id: int) -> bool:
        """Stop running crawler for agent"""
        running_crawler = self.db.query(CrawlerRun).filter(
            CrawlerRun.fiduciary_agent_id == agent_id,
            CrawlerRun.status == "running"
        ).first()
        
        if not running_crawler:
            return False
        
        # Update status to stopped
        running_crawler.status = "stopped"
        running_crawler.end_time = datetime.now()
        
        self.db.commit()
        
        logger.info(f"Stopped crawler for agent {agent_id}")
        return True
    
    def get_crawler_statistics(self, agent_id: Optional[int] = None) -> Dict:
        """Get crawler statistics"""
        query = self.db.query(CrawlerRun)
        
        if agent_id:
            query = query.filter(CrawlerRun.fiduciary_agent_id == agent_id)
        
        runs = query.all()
        
        total_runs = len(runs)
        successful_runs = len([r for r in runs if r.status == "completed"])
        failed_runs = len([r for r in runs if r.status == "failed"])
        
        total_documents_found = sum(r.documents_found or 0 for r in runs)
        total_documents_downloaded = sum(r.documents_downloaded or 0 for r in runs)
        
        execution_times = [r.execution_time_seconds for r in runs if r.execution_time_seconds]
        avg_execution_time = sum(execution_times) / len(execution_times) if execution_times else 0
        
        return {
            "total_runs": total_runs,
            "successful_runs": successful_runs,
            "failed_runs": failed_runs,
            "success_rate": (successful_runs / total_runs * 100) if total_runs > 0 else 0,
            "total_documents_found": total_documents_found,
            "total_documents_downloaded": total_documents_downloaded,
            "average_execution_time": avg_execution_time,
            "last_run": runs[0].start_time if runs else None
        }

