"""
WebSocket Service
Handles real-time communication for crawler status updates and notifications
"""

import json
import asyncio
from typing import Dict, List, Any, Optional
from datetime import datetime
import logging

from fastapi import WebSocket, WebSocketDisconnect
from sqlalchemy.orm import Session

logger = logging.getLogger(__name__)


class ConnectionManager:
    """Manages WebSocket connections"""
    
    def __init__(self):
        self.active_connections: List[WebSocket] = []
        self.user_connections: Dict[str, List[WebSocket]] = {}
    
    async def connect(self, websocket: WebSocket, user_id: Optional[str] = None):
        """Accept a new WebSocket connection"""
        await websocket.accept()
        self.active_connections.append(websocket)
        
        if user_id:
            if user_id not in self.user_connections:
                self.user_connections[user_id] = []
            self.user_connections[user_id].append(websocket)
        
        logger.info(f"WebSocket connected. Total connections: {len(self.active_connections)}")
    
    def disconnect(self, websocket: WebSocket, user_id: Optional[str] = None):
        """Remove a WebSocket connection"""
        if websocket in self.active_connections:
            self.active_connections.remove(websocket)
        
        if user_id and user_id in self.user_connections:
            if websocket in self.user_connections[user_id]:
                self.user_connections[user_id].remove(websocket)
            
            # Clean up empty user connection lists
            if not self.user_connections[user_id]:
                del self.user_connections[user_id]
        
        logger.info(f"WebSocket disconnected. Total connections: {len(self.active_connections)}")
    
    async def send_personal_message(self, message: str, websocket: WebSocket):
        """Send a message to a specific WebSocket"""
        try:
            await websocket.send_text(message)
        except Exception as e:
            logger.error(f"Error sending personal message: {e}")
    
    async def send_to_user(self, message: str, user_id: str):
        """Send a message to all connections of a specific user"""
        if user_id in self.user_connections:
            disconnected = []
            for websocket in self.user_connections[user_id]:
                try:
                    await websocket.send_text(message)
                except Exception as e:
                    logger.error(f"Error sending message to user {user_id}: {e}")
                    disconnected.append(websocket)
            
            # Clean up disconnected websockets
            for ws in disconnected:
                self.disconnect(ws, user_id)
    
    async def broadcast(self, message: str):
        """Send a message to all connected clients"""
        disconnected = []
        for websocket in self.active_connections:
            try:
                await websocket.send_text(message)
            except Exception as e:
                logger.error(f"Error broadcasting message: {e}")
                disconnected.append(websocket)
        
        # Clean up disconnected websockets
        for ws in disconnected:
            self.disconnect(ws)


class WebSocketService:
    """Service for WebSocket communication"""
    
    def __init__(self):
        self.manager = ConnectionManager()
    
    async def handle_connection(self, websocket: WebSocket, user_id: Optional[str] = None):
        """Handle a new WebSocket connection"""
        await self.manager.connect(websocket, user_id)
        
        try:
            # Send welcome message
            await self.send_message(websocket, {
                'type': 'connection',
                'status': 'connected',
                'timestamp': datetime.utcnow().isoformat(),
                'message': 'Connected to Brazilian Debenture Management System'
            })
            
            # Keep connection alive and handle incoming messages
            while True:
                data = await websocket.receive_text()
                await self.handle_message(websocket, data, user_id)
                
        except WebSocketDisconnect:
            self.manager.disconnect(websocket, user_id)
        except Exception as e:
            logger.error(f"WebSocket error: {e}")
            self.manager.disconnect(websocket, user_id)
    
    async def handle_message(self, websocket: WebSocket, data: str, user_id: Optional[str] = None):
        """Handle incoming WebSocket message"""
        try:
            message = json.loads(data)
            message_type = message.get('type')
            
            if message_type == 'ping':
                await self.send_message(websocket, {
                    'type': 'pong',
                    'timestamp': datetime.utcnow().isoformat()
                })
            
            elif message_type == 'subscribe':
                # Handle subscription to specific events
                topics = message.get('topics', [])
                await self.handle_subscription(websocket, topics, user_id)
            
            elif message_type == 'unsubscribe':
                # Handle unsubscription from events
                topics = message.get('topics', [])
                await self.handle_unsubscription(websocket, topics, user_id)
            
            else:
                logger.warning(f"Unknown message type: {message_type}")
                
        except json.JSONDecodeError:
            logger.error(f"Invalid JSON received: {data}")
        except Exception as e:
            logger.error(f"Error handling message: {e}")
    
    async def handle_subscription(self, websocket: WebSocket, topics: List[str], user_id: Optional[str] = None):
        """Handle subscription to event topics"""
        # Store subscription info (could be enhanced with Redis for persistence)
        await self.send_message(websocket, {
            'type': 'subscription',
            'status': 'subscribed',
            'topics': topics,
            'timestamp': datetime.utcnow().isoformat()
        })
    
    async def handle_unsubscription(self, websocket: WebSocket, topics: List[str], user_id: Optional[str] = None):
        """Handle unsubscription from event topics"""
        await self.send_message(websocket, {
            'type': 'subscription',
            'status': 'unsubscribed',
            'topics': topics,
            'timestamp': datetime.utcnow().isoformat()
        })
    
    async def send_message(self, websocket: WebSocket, message: Dict[str, Any]):
        """Send a structured message to a WebSocket"""
        try:
            await websocket.send_text(json.dumps(message))
        except Exception as e:
            logger.error(f"Error sending WebSocket message: {e}")
    
    async def broadcast_crawler_status(self, crawler_run_id: int, status: str, 
                                     agent_name: str, progress: Optional[Dict[str, Any]] = None):
        """Broadcast crawler status update to all connected clients"""
        message = {
            'type': 'crawler_status',
            'crawler_run_id': crawler_run_id,
            'status': status,
            'agent_name': agent_name,
            'progress': progress,
            'timestamp': datetime.utcnow().isoformat()
        }
        
        await self.manager.broadcast(json.dumps(message))
    
    async def broadcast_document_update(self, document_id: int, action: str, 
                                      document_info: Dict[str, Any]):
        """Broadcast document update to all connected clients"""
        message = {
            'type': 'document_update',
            'document_id': document_id,
            'action': action,  # 'created', 'updated', 'deleted'
            'document_info': document_info,
            'timestamp': datetime.utcnow().isoformat()
        }
        
        await self.manager.broadcast(json.dumps(message))
    
    async def broadcast_analysis_complete(self, analysis_id: int, document_id: int, 
                                        analysis_result: Dict[str, Any]):
        """Broadcast analysis completion to all connected clients"""
        message = {
            'type': 'analysis_complete',
            'analysis_id': analysis_id,
            'document_id': document_id,
            'analysis_result': analysis_result,
            'timestamp': datetime.utcnow().isoformat()
        }
        
        await self.manager.broadcast(json.dumps(message))
    
    async def send_notification(self, user_id: str, notification: Dict[str, Any]):
        """Send a notification to a specific user"""
        message = {
            'type': 'notification',
            'notification': notification,
            'timestamp': datetime.utcnow().isoformat()
        }
        
        await self.manager.send_to_user(json.dumps(message), user_id)
    
    async def broadcast_system_status(self, status: Dict[str, Any]):
        """Broadcast system status update"""
        message = {
            'type': 'system_status',
            'status': status,
            'timestamp': datetime.utcnow().isoformat()
        }
        
        await self.manager.broadcast(json.dumps(message))
    
    def get_connection_stats(self) -> Dict[str, Any]:
        """Get WebSocket connection statistics"""
        return {
            'total_connections': len(self.manager.active_connections),
            'user_connections': len(self.manager.user_connections),
            'users_online': list(self.manager.user_connections.keys())
        }


# Global WebSocket service instance
websocket_service = WebSocketService()

