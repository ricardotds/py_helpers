"""
Notification Service
Handles email notifications and system alerts
"""

import smtplib
import ssl
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
from typing import List, Dict, Any, Optional
from datetime import datetime
import logging
import asyncio
import os

from app.config.settings import settings
from app.services.websocket_service import websocket_service

logger = logging.getLogger(__name__)


class NotificationService:
    """Service for sending notifications via email and WebSocket"""
    
    def __init__(self):
        self.smtp_host = getattr(settings, 'SMTP_HOST', None)
        self.smtp_port = getattr(settings, 'SMTP_PORT', 587)
        self.smtp_user = getattr(settings, 'SMTP_USER', None)
        self.smtp_password = getattr(settings, 'SMTP_PASSWORD', None)
        self.from_email = getattr(settings, 'FROM_EMAIL', self.smtp_user)
        self.enabled = bool(self.smtp_host and self.smtp_user and self.smtp_password)
        
        if not self.enabled:
            logger.warning("Email notifications disabled - SMTP settings not configured")
    
    async def send_email(self, 
                        to_emails: List[str], 
                        subject: str, 
                        body: str, 
                        html_body: Optional[str] = None,
                        attachments: Optional[List[str]] = None) -> bool:
        """Send email notification"""
        if not self.enabled:
            logger.warning("Cannot send email - SMTP not configured")
            return False
        
        try:
            # Create message
            message = MIMEMultipart("alternative")
            message["Subject"] = subject
            message["From"] = self.from_email
            message["To"] = ", ".join(to_emails)
            
            # Add text part
            text_part = MIMEText(body, "plain")
            message.attach(text_part)
            
            # Add HTML part if provided
            if html_body:
                html_part = MIMEText(html_body, "html")
                message.attach(html_part)
            
            # Add attachments if provided
            if attachments:
                for file_path in attachments:
                    if os.path.exists(file_path):
                        with open(file_path, "rb") as attachment:
                            part = MIMEBase('application', 'octet-stream')
                            part.set_payload(attachment.read())
                        
                        encoders.encode_base64(part)
                        part.add_header(
                            'Content-Disposition',
                            f'attachment; filename= {os.path.basename(file_path)}'
                        )
                        message.attach(part)
            
            # Send email
            context = ssl.create_default_context()
            with smtplib.SMTP(self.smtp_host, self.smtp_port) as server:
                server.starttls(context=context)
                server.login(self.smtp_user, self.smtp_password)
                server.sendmail(self.from_email, to_emails, message.as_string())
            
            logger.info(f"Email sent successfully to {to_emails}")
            return True
            
        except Exception as e:
            logger.error(f"Error sending email: {e}")
            return False
    
    async def notify_crawler_started(self, agent_name: str, crawler_run_id: int, 
                                   user_emails: Optional[List[str]] = None):
        """Notify that a crawler has started"""
        # WebSocket notification
        await websocket_service.broadcast_crawler_status(
            crawler_run_id=crawler_run_id,
            status="started",
            agent_name=agent_name,
            progress={"message": f"Crawler started for {agent_name}"}
        )
        
        # Email notification (if configured and emails provided)
        if self.enabled and user_emails:
            subject = f"Crawler Started - {agent_name}"
            body = f"""
            The crawler for {agent_name} has been started.
            
            Crawler Run ID: {crawler_run_id}
            Started at: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC
            
            You will receive another notification when the crawling is complete.
            """
            
            await self.send_email(user_emails, subject, body)
    
    async def notify_crawler_completed(self, agent_name: str, crawler_run_id: int,
                                     documents_found: int, documents_downloaded: int,
                                     duration: float, user_emails: Optional[List[str]] = None):
        """Notify that a crawler has completed"""
        # WebSocket notification
        await websocket_service.broadcast_crawler_status(
            crawler_run_id=crawler_run_id,
            status="completed",
            agent_name=agent_name,
            progress={
                "documents_found": documents_found,
                "documents_downloaded": documents_downloaded,
                "duration": duration,
                "message": f"Crawler completed for {agent_name}"
            }
        )
        
        # Email notification
        if self.enabled and user_emails:
            subject = f"Crawler Completed - {agent_name}"
            body = f"""
            The crawler for {agent_name} has completed successfully.
            
            Crawler Run ID: {crawler_run_id}
            Documents Found: {documents_found}
            Documents Downloaded: {documents_downloaded}
            Duration: {duration:.2f} seconds
            Completed at: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC
            
            You can now view and analyze the downloaded documents in the system.
            """
            
            await self.send_email(user_emails, subject, body)
    
    async def notify_crawler_failed(self, agent_name: str, crawler_run_id: int,
                                  error_message: str, user_emails: Optional[List[str]] = None):
        """Notify that a crawler has failed"""
        # WebSocket notification
        await websocket_service.broadcast_crawler_status(
            crawler_run_id=crawler_run_id,
            status="failed",
            agent_name=agent_name,
            progress={
                "error": error_message,
                "message": f"Crawler failed for {agent_name}"
            }
        )
        
        # Email notification
        if self.enabled and user_emails:
            subject = f"Crawler Failed - {agent_name}"
            body = f"""
            The crawler for {agent_name} has failed.
            
            Crawler Run ID: {crawler_run_id}
            Error: {error_message}
            Failed at: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC
            
            Please check the system logs for more details.
            """
            
            await self.send_email(user_emails, subject, body)
    
    async def notify_document_analysis_complete(self, document_title: str, analysis_id: int,
                                              analysis_result: Dict[str, Any],
                                              user_emails: Optional[List[str]] = None):
        """Notify that document analysis is complete"""
        # WebSocket notification
        await websocket_service.broadcast_analysis_complete(
            analysis_id=analysis_id,
            document_id=analysis_result.get('document_id'),
            analysis_result=analysis_result
        )
        
        # Email notification
        if self.enabled and user_emails:
            subject = f"Document Analysis Complete - {document_title}"
            body = f"""
            The analysis for document "{document_title}" has been completed.
            
            Analysis ID: {analysis_id}
            Completed at: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC
            
            You can view the analysis results in the system.
            """
            
            await self.send_email(user_emails, subject, body)
    
    async def notify_system_alert(self, alert_type: str, message: str, 
                                severity: str = "info", user_emails: Optional[List[str]] = None):
        """Send system alert notification"""
        # WebSocket notification
        await websocket_service.broadcast_system_status({
            "alert_type": alert_type,
            "message": message,
            "severity": severity
        })
        
        # Email notification for high severity alerts
        if self.enabled and user_emails and severity in ["warning", "error", "critical"]:
            subject = f"System Alert - {alert_type.title()}"
            body = f"""
            A system alert has been triggered.
            
            Alert Type: {alert_type}
            Severity: {severity.upper()}
            Message: {message}
            Time: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC
            
            Please check the system status and take appropriate action if needed.
            """
            
            await self.send_email(user_emails, subject, body)
    
    async def send_daily_summary(self, summary_data: Dict[str, Any], 
                               user_emails: List[str]):
        """Send daily summary report"""
        if not self.enabled or not user_emails:
            return
        
        subject = f"Daily Summary - {datetime.utcnow().strftime('%Y-%m-%d')}"
        
        # Create HTML body
        html_body = f"""
        <html>
        <body>
            <h2>Brazilian Debenture Management System - Daily Summary</h2>
            <p><strong>Date:</strong> {datetime.utcnow().strftime('%Y-%m-%d')}</p>
            
            <h3>Crawler Activity</h3>
            <ul>
                <li>Crawlers Run: {summary_data.get('crawlers_run', 0)}</li>
                <li>Documents Downloaded: {summary_data.get('documents_downloaded', 0)}</li>
                <li>Total Documents: {summary_data.get('total_documents', 0)}</li>
            </ul>
            
            <h3>Analysis Activity</h3>
            <ul>
                <li>Analyses Completed: {summary_data.get('analyses_completed', 0)}</li>
                <li>Pending Analyses: {summary_data.get('pending_analyses', 0)}</li>
            </ul>
            
            <h3>System Status</h3>
            <ul>
                <li>System Health: {summary_data.get('system_health', 'Unknown')}</li>
                <li>Active Connections: {summary_data.get('active_connections', 0)}</li>
            </ul>
        </body>
        </html>
        """
        
        # Create text body
        text_body = f"""
        Brazilian Debenture Management System - Daily Summary
        Date: {datetime.utcnow().strftime('%Y-%m-%d')}
        
        Crawler Activity:
        - Crawlers Run: {summary_data.get('crawlers_run', 0)}
        - Documents Downloaded: {summary_data.get('documents_downloaded', 0)}
        - Total Documents: {summary_data.get('total_documents', 0)}
        
        Analysis Activity:
        - Analyses Completed: {summary_data.get('analyses_completed', 0)}
        - Pending Analyses: {summary_data.get('pending_analyses', 0)}
        
        System Status:
        - System Health: {summary_data.get('system_health', 'Unknown')}
        - Active Connections: {summary_data.get('active_connections', 0)}
        """
        
        await self.send_email(user_emails, subject, text_body, html_body)


# Global notification service instance
notification_service = NotificationService()

