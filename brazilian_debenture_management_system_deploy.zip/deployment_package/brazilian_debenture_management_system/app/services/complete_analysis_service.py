"""
Complete Analysis Service
Handles document analysis using LangChain with customizable prompts and structured outputs
"""

import json
import logging
from typing import Dict, Any, Optional, List
from datetime import datetime
import asyncio

from langchain_openai import ChatOpenAI
from langchain.prompts import PromptTemplate
from langchain.schema import BaseOutputParser
from langchain.output_parsers import PydanticOutputParser
from pydantic import BaseModel, Field, create_model
from sqlalchemy.orm import Session

from app.models.document import Document
from app.models.analysis import DocumentAnalysis
from app.models.prompt import SystemPrompt
from app.models.schema import OutputSchema
from app.services.websocket_service import websocket_service
from app.services.notification_service import notification_service
from app.config.settings import settings

logger = logging.getLogger(__name__)


class AnalysisResult(BaseModel):
    """Base model for analysis results"""
    success: bool = Field(description="Whether the analysis was successful")
    content: Dict[str, Any] = Field(description="Extracted content")
    confidence: float = Field(description="Confidence score of the analysis", ge=0.0, le=1.0)
    processing_time: float = Field(description="Time taken for analysis in seconds")
    model_used: str = Field(description="AI model used for analysis")


class CompleteAnalysisService:
    """Complete service for document analysis using LangChain"""
    
    def __init__(self, db: Session):
        self.db = db
        self.llm = ChatOpenAI(
            model="gpt-4-turbo-preview",
            temperature=0.1,
            max_tokens=4000
        )
        
    async def analyze_document(self, 
                             document_id: int, 
                             prompt_id: int, 
                             schema_id: Optional[int] = None,
                             user_emails: Optional[List[str]] = None) -> Optional[DocumentAnalysis]:
        """
        Analyze a document using specified prompt and optional schema
        """
        try:
            # Get document
            document = self.db.query(Document).filter(Document.id == document_id).first()
            if not document:
                logger.error(f"Document not found: {document_id}")
                return None
            
            # Get system prompt
            prompt = self.db.query(SystemPrompt).filter(SystemPrompt.id == prompt_id).first()
            if not prompt:
                logger.error(f"System prompt not found: {prompt_id}")
                return None
            
            # Get output schema if specified
            output_schema = None
            if schema_id:
                output_schema = self.db.query(OutputSchema).filter(OutputSchema.id == schema_id).first()
                if not output_schema:
                    logger.error(f"Output schema not found: {schema_id}")
                    return None
            
            # Create analysis record
            analysis = DocumentAnalysis(
                document_id=document_id,
                prompt_id=prompt_id,
                schema_id=schema_id,
                status="running",
                started_at=datetime.utcnow()
            )
            self.db.add(analysis)
            self.db.commit()
            self.db.refresh(analysis)
            
            # Send start notification
            await websocket_service.broadcast_analysis_complete(
                analysis_id=analysis.id,
                document_id=document_id,
                analysis_result={
                    "status": "started",
                    "message": f"Starting analysis of {document.title}"
                }
            )
            
            # Perform analysis
            start_time = datetime.utcnow()
            result = await self._perform_analysis(document, prompt, output_schema)
            end_time = datetime.utcnow()
            
            # Update analysis record
            analysis.status = "completed" if result.success else "failed"
            analysis.completed_at = end_time
            analysis.result = result.dict()
            analysis.processing_time = result.processing_time
            analysis.model_used = result.model_used
            
            if not result.success:
                analysis.error_message = result.content.get("error", "Analysis failed")
            
            self.db.commit()
            self.db.refresh(analysis)
            
            # Send completion notification
            await notification_service.notify_document_analysis_complete(
                document_title=document.title,
                analysis_id=analysis.id,
                analysis_result=result.dict(),
                user_emails=user_emails
            )
            
            await websocket_service.broadcast_analysis_complete(
                analysis_id=analysis.id,
                document_id=document_id,
                analysis_result=result.dict()
            )
            
            logger.info(f"Analysis completed for document {document_id}")
            return analysis
            
        except Exception as e:
            logger.error(f"Error analyzing document {document_id}: {e}")
            
            # Update analysis record with error
            if 'analysis' in locals():
                analysis.status = "failed"
                analysis.completed_at = datetime.utcnow()
                analysis.error_message = str(e)
                self.db.commit()
            
            return None
    
    async def _perform_analysis(self, 
                              document: Document, 
                              prompt: SystemPrompt, 
                              output_schema: Optional[OutputSchema] = None) -> AnalysisResult:
        """
        Perform the actual document analysis
        """
        start_time = datetime.utcnow()
        
        try:
            # Prepare document content
            content = document.content or ""
            if not content and document.file_path:
                # Try to extract content if not already available
                content = await self._extract_document_content(document.file_path)
            
            if not content:
                return AnalysisResult(
                    success=False,
                    content={"error": "No content available for analysis"},
                    confidence=0.0,
                    processing_time=0.0,
                    model_used="none"
                )
            
            # Create prompt template
            prompt_template = PromptTemplate(
                input_variables=["content"],
                template=prompt.prompt_text
            )
            
            # Set up output parser if schema is provided
            output_parser = None
            if output_schema:
                try:
                    # Create dynamic Pydantic model from schema
                    pydantic_model = self._create_pydantic_model_from_schema(output_schema.schema_json)
                    output_parser = PydanticOutputParser(pydantic_model=pydantic_model)
                    
                    # Add format instructions to prompt
                    format_instructions = output_parser.get_format_instructions()
                    enhanced_template = prompt.prompt_text + "\n\n" + format_instructions
                    prompt_template = PromptTemplate(
                        input_variables=["content"],
                        template=enhanced_template
                    )
                except Exception as e:
                    logger.warning(f"Failed to create output parser: {e}")
                    output_parser = None
            
            # Create chain
            chain = prompt_template | self.llm
            
            # Run analysis
            response = await asyncio.to_thread(
                chain.invoke,
                {"content": content[:10000]}  # Limit content to avoid token limits
            )
            
            # Parse response
            if output_parser:
                try:
                    parsed_result = output_parser.parse(response.content)
                    result_content = parsed_result.dict()
                    confidence = 0.9  # High confidence for structured output
                except Exception as e:
                    logger.warning(f"Failed to parse structured output: {e}")
                    result_content = {"raw_response": response.content}
                    confidence = 0.7
            else:
                result_content = {"analysis": response.content}
                confidence = 0.8
            
            # Calculate processing time
            processing_time = (datetime.utcnow() - start_time).total_seconds()
            
            return AnalysisResult(
                success=True,
                content=result_content,
                confidence=confidence,
                processing_time=processing_time,
                model_used=self.llm.model_name
            )
            
        except Exception as e:
            processing_time = (datetime.utcnow() - start_time).total_seconds()
            logger.error(f"Analysis failed: {e}")
            
            return AnalysisResult(
                success=False,
                content={"error": str(e)},
                confidence=0.0,
                processing_time=processing_time,
                model_used=self.llm.model_name
            )
    
    def _create_pydantic_model_from_schema(self, schema_json: Dict[str, Any]) -> BaseModel:
        """
        Create a Pydantic model from JSON schema
        """
        try:
            # Parse schema properties
            properties = schema_json.get("properties", {})
            required_fields = schema_json.get("required", [])
            
            # Create field definitions
            field_definitions = {}
            for field_name, field_def in properties.items():
                field_type = self._get_python_type_from_json_schema(field_def)
                
                # Create field with description
                if field_name in required_fields:
                    field_definitions[field_name] = (field_type, Field(description=field_def.get("description", "")))
                else:
                    field_definitions[field_name] = (Optional[field_type], Field(default=None, description=field_def.get("description", "")))
            
            # Create dynamic model
            DynamicModel = create_model("DynamicAnalysisModel", **field_definitions)
            return DynamicModel
            
        except Exception as e:
            logger.error(f"Failed to create Pydantic model from schema: {e}")
            # Fallback to basic model
            class FallbackModel(BaseModel):
                result: str = Field(description="Analysis result")
            return FallbackModel
    
    def _get_python_type_from_json_schema(self, field_def: Dict[str, Any]):
        """
        Convert JSON schema type to Python type
        """
        json_type = field_def.get("type", "string")
        
        if json_type == "string":
            return str
        elif json_type == "integer":
            return int
        elif json_type == "number":
            return float
        elif json_type == "boolean":
            return bool
        elif json_type == "array":
            item_type = self._get_python_type_from_json_schema(field_def.get("items", {"type": "string"}))
            return List[item_type]
        else:
            return str  # Default to string
    
    async def _extract_document_content(self, file_path: str) -> str:
        """
        Extract content from document file
        """
        try:
            import PyPDF2
            import pdfplumber
            
            content = ""
            
            # Try with pdfplumber first
            with pdfplumber.open(file_path) as pdf:
                for page in pdf.pages:
                    page_text = page.extract_text()
                    if page_text:
                        content += page_text + "\n"
            
            # If pdfplumber didn't work well, try PyPDF2
            if len(content.strip()) < 100:
                content = ""
                with open(file_path, 'rb') as file:
                    pdf_reader = PyPDF2.PdfReader(file)
                    for page in pdf_reader.pages:
                        page_text = page.extract_text()
                        if page_text:
                            content += page_text + "\n"
            
            return content.strip()
            
        except Exception as e:
            logger.error(f"Failed to extract content from {file_path}: {e}")
            return ""
    
    def get_analysis_by_id(self, analysis_id: int) -> Optional[DocumentAnalysis]:
        """Get analysis by ID"""
        return self.db.query(DocumentAnalysis).filter(DocumentAnalysis.id == analysis_id).first()
    
    def get_document_analyses(self, document_id: int) -> List[DocumentAnalysis]:
        """Get all analyses for a document"""
        return self.db.query(DocumentAnalysis).filter(
            DocumentAnalysis.document_id == document_id
        ).order_by(DocumentAnalysis.started_at.desc()).all()
    
    def get_recent_analyses(self, limit: int = 50) -> List[DocumentAnalysis]:
        """Get recent analyses"""
        return self.db.query(DocumentAnalysis).order_by(
            DocumentAnalysis.started_at.desc()
        ).limit(limit).all()
    
    async def batch_analyze_documents(self, 
                                    document_ids: List[int], 
                                    prompt_id: int, 
                                    schema_id: Optional[int] = None,
                                    user_emails: Optional[List[str]] = None) -> List[DocumentAnalysis]:
        """
        Analyze multiple documents in batch
        """
        analyses = []
        
        for document_id in document_ids:
            try:
                analysis = await self.analyze_document(
                    document_id=document_id,
                    prompt_id=prompt_id,
                    schema_id=schema_id,
                    user_emails=user_emails
                )
                if analysis:
                    analyses.append(analysis)
                
                # Small delay between analyses to prevent overwhelming the API
                await asyncio.sleep(1)
                
            except Exception as e:
                logger.error(f"Failed to analyze document {document_id}: {e}")
                continue
        
        return analyses
    
    def get_analysis_statistics(self) -> Dict[str, Any]:
        """Get analysis statistics"""
        total_analyses = self.db.query(DocumentAnalysis).count()
        successful_analyses = self.db.query(DocumentAnalysis).filter(
            DocumentAnalysis.status == "completed"
        ).count()
        failed_analyses = self.db.query(DocumentAnalysis).filter(
            DocumentAnalysis.status == "failed"
        ).count()
        
        # Recent analyses (last 24 hours)
        recent_cutoff = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
        recent_analyses = self.db.query(DocumentAnalysis).filter(
            DocumentAnalysis.started_at >= recent_cutoff
        ).count()
        
        return {
            "total_analyses": total_analyses,
            "successful_analyses": successful_analyses,
            "failed_analyses": failed_analyses,
            "success_rate": (successful_analyses / total_analyses * 100) if total_analyses > 0 else 0,
            "recent_analyses_today": recent_analyses
        }

