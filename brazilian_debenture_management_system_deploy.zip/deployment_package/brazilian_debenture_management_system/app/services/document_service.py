"""
Document Service
Handles document processing, text extraction, and metadata management
"""

import os
import hashlib
import mimetypes
from typing import List, Dict, Any, Optional, BinaryIO
from datetime import datetime
import logging
import asyncio
from pathlib import Path

import PyPDF2
import pdfplumber
from sqlalchemy.orm import Session

from app.models.document import Document
from app.models.fiduciary_agent import FiduciaryAgent
from app.config.settings import settings

logger = logging.getLogger(__name__)


class DocumentService:
    """Service for document processing and management"""
    
    def __init__(self, db: Session):
        self.db = db
        self.storage_path = getattr(settings, 'STORAGE_PATH', '/app/storage')
        self.documents_path = os.path.join(self.storage_path, 'documents')
        
        # Ensure storage directories exist
        os.makedirs(self.documents_path, exist_ok=True)
    
    async def process_document(self, file_path: str, metadata: Dict[str, Any]) -> Optional[Document]:
        """
        Process a document file and create database record
        """
        try:
            # Validate file exists
            if not os.path.exists(file_path):
                logger.error(f"File not found: {file_path}")
                return None
            
            # Calculate file hash
            file_hash = await self._calculate_file_hash(file_path)
            
            # Check if document already exists
            existing_doc = self.db.query(Document).filter(
                Document.file_hash == file_hash
            ).first()
            
            if existing_doc:
                logger.info(f"Document already exists: {file_hash}")
                return existing_doc
            
            # Extract text content
            content = await self._extract_text_content(file_path)
            
            # Get file metadata
            file_stats = os.stat(file_path)
            file_size = file_stats.st_size
            mime_type = mimetypes.guess_type(file_path)[0] or 'application/pdf'
            
            # Create document record
            document = Document(
                title=metadata.get('title', 'Unknown Document'),
                file_path=file_path,
                file_hash=file_hash,
                file_size=file_size,
                mime_type=mime_type,
                content=content,
                url=metadata.get('url'),
                document_type=metadata.get('document_type', 'other'),
                company_name=metadata.get('company_name'),
                emission_date=metadata.get('emission_date'),
                fiduciary_agent_id=metadata.get('fiduciary_agent_id'),
                metadata_=metadata,
                downloaded_at=metadata.get('downloaded_at', datetime.utcnow())
            )
            
            self.db.add(document)
            self.db.commit()
            self.db.refresh(document)
            
            logger.info(f"Document processed successfully: {document.id}")
            return document
            
        except Exception as e:
            logger.error(f"Error processing document {file_path}: {e}")
            self.db.rollback()
            return None
    
    async def _calculate_file_hash(self, file_path: str) -> str:
        """Calculate MD5 hash of file content"""
        hash_md5 = hashlib.md5()
        
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(4096), b""):
                hash_md5.update(chunk)
        
        return hash_md5.hexdigest()
    
    async def _extract_text_content(self, file_path: str) -> str:
        """Extract text content from PDF file"""
        content = ""
        
        try:
            # Try with pdfplumber first (better for complex layouts)
            with pdfplumber.open(file_path) as pdf:
                for page in pdf.pages:
                    page_text = page.extract_text()
                    if page_text:
                        content += page_text + "\n"
            
            # If pdfplumber didn't extract much, try PyPDF2
            if len(content.strip()) < 100:
                content = ""
                with open(file_path, 'rb') as file:
                    pdf_reader = PyPDF2.PdfReader(file)
                    for page in pdf_reader.pages:
                        page_text = page.extract_text()
                        if page_text:
                            content += page_text + "\n"
            
        except Exception as e:
            logger.error(f"Error extracting text from {file_path}: {e}")
            content = ""
        
        return content.strip()
    
    def get_documents(self, 
                     fiduciary_agent_id: Optional[int] = None,
                     document_type: Optional[str] = None,
                     company_name: Optional[str] = None,
                     start_date: Optional[datetime] = None,
                     end_date: Optional[datetime] = None,
                     search_query: Optional[str] = None,
                     limit: int = 100,
                     offset: int = 0) -> List[Document]:
        """
        Get documents with filtering options
        """
        query = self.db.query(Document)
        
        # Apply filters
        if fiduciary_agent_id:
            query = query.filter(Document.fiduciary_agent_id == fiduciary_agent_id)
        
        if document_type:
            query = query.filter(Document.document_type == document_type)
        
        if company_name:
            query = query.filter(Document.company_name.ilike(f"%{company_name}%"))
        
        if start_date:
            query = query.filter(Document.emission_date >= start_date)
        
        if end_date:
            query = query.filter(Document.emission_date <= end_date)
        
        if search_query:
            # Full-text search on title and content
            query = query.filter(
                Document.title.ilike(f"%{search_query}%") |
                Document.content.ilike(f"%{search_query}%")
            )
        
        # Order by emission date (newest first)
        query = query.order_by(Document.emission_date.desc().nullslast())
        
        # Apply pagination
        query = query.offset(offset).limit(limit)
        
        return query.all()
    
    def get_document_by_id(self, document_id: int) -> Optional[Document]:
        """Get document by ID"""
        return self.db.query(Document).filter(Document.id == document_id).first()
    
    def get_document_by_hash(self, file_hash: str) -> Optional[Document]:
        """Get document by file hash"""
        return self.db.query(Document).filter(Document.file_hash == file_hash).first()
    
    def get_document_statistics(self) -> Dict[str, Any]:
        """Get document statistics"""
        total_documents = self.db.query(Document).count()
        
        # Count by document type
        type_counts = self.db.query(
            Document.document_type,
            self.db.func.count(Document.id)
        ).group_by(Document.document_type).all()
        
        # Count by fiduciary agent
        agent_counts = self.db.query(
            FiduciaryAgent.name,
            self.db.func.count(Document.id)
        ).join(Document).group_by(FiduciaryAgent.name).all()
        
        # Recent documents (last 30 days)
        recent_date = datetime.utcnow().replace(day=1)  # First day of current month
        recent_documents = self.db.query(Document).filter(
            Document.downloaded_at >= recent_date
        ).count()
        
        return {
            'total_documents': total_documents,
            'recent_documents': recent_documents,
            'by_type': dict(type_counts),
            'by_agent': dict(agent_counts)
        }
    
    async def delete_document(self, document_id: int) -> bool:
        """Delete document and associated file"""
        try:
            document = self.get_document_by_id(document_id)
            if not document:
                return False
            
            # Delete file if it exists
            if document.file_path and os.path.exists(document.file_path):
                os.remove(document.file_path)
            
            # Delete database record
            self.db.delete(document)
            self.db.commit()
            
            logger.info(f"Document deleted: {document_id}")
            return True
            
        except Exception as e:
            logger.error(f"Error deleting document {document_id}: {e}")
            self.db.rollback()
            return False
    
    def update_document_metadata(self, document_id: int, metadata: Dict[str, Any]) -> Optional[Document]:
        """Update document metadata"""
        try:
            document = self.get_document_by_id(document_id)
            if not document:
                return None
            
            # Update fields
            for key, value in metadata.items():
                if hasattr(document, key):
                    setattr(document, key, value)
            
            # Update metadata JSON
            if document.metadata_:
                document.metadata_.update(metadata)
            else:
                document.metadata_ = metadata
            
            self.db.commit()
            self.db.refresh(document)
            
            return document
            
        except Exception as e:
            logger.error(f"Error updating document metadata {document_id}: {e}")
            self.db.rollback()
            return None
    
    async def validate_document_integrity(self, document_id: int) -> bool:
        """Validate document file integrity"""
        try:
            document = self.get_document_by_id(document_id)
            if not document:
                return False
            
            # Check if file exists
            if not os.path.exists(document.file_path):
                logger.warning(f"Document file missing: {document.file_path}")
                return False
            
            # Verify file hash
            current_hash = await self._calculate_file_hash(document.file_path)
            if current_hash != document.file_hash:
                logger.warning(f"Document hash mismatch: {document_id}")
                return False
            
            return True
            
        except Exception as e:
            logger.error(f"Error validating document integrity {document_id}: {e}")
            return False
    
    def get_duplicate_documents(self) -> List[Dict[str, Any]]:
        """Find duplicate documents based on file hash"""
        duplicates = self.db.query(
            Document.file_hash,
            self.db.func.count(Document.id).label('count'),
            self.db.func.array_agg(Document.id).label('document_ids')
        ).group_by(Document.file_hash).having(
            self.db.func.count(Document.id) > 1
        ).all()
        
        return [
            {
                'file_hash': dup.file_hash,
                'count': dup.count,
                'document_ids': dup.document_ids
            }
            for dup in duplicates
        ]

