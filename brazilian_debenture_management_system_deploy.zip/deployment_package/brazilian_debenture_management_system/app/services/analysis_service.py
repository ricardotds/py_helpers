"""
Analysis Service for LangChain integration and document processing
"""

from typing import Optional, Dict, Any, List
from datetime import datetime
import logging
import json
import time
from pathlib import Path
from sqlalchemy.orm import Session

# LangChain imports
from langchain_community.document_loaders import PyPDFLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.schema import Document as LangChainDocument
from langchain_openai import ChatOpenAI
from langchain.prompts import ChatPromptTemplate
from langchain.output_parsers import PydanticOutputParser
from langchain.schema.output_parser import OutputParserException
from pydantic import BaseModel, ValidationError

from app.models.document import Document
from app.models.analysis import DocumentAnalysis
from app.models.prompt import SystemPrompt
from app.models.schema import OutputSchema
from app.config.settings import get_settings

logger = logging.getLogger(__name__)
settings = get_settings()


class AnalysisService:
    """Service for document analysis using LangChain"""
    
    def __init__(self, db: Session):
        self.db = db
        self.text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=4000,
            chunk_overlap=200,
            length_function=len,
        )
    
    def create_llm(self, model_name: str = None, temperature: float = None, 
                   max_tokens: int = None) -> ChatOpenAI:
        """Create LangChain LLM instance"""
        return ChatOpenAI(
            model_name=model_name or settings.DEFAULT_LLM_MODEL,
            temperature=temperature or settings.TEMPERATURE,
            max_tokens=max_tokens or settings.MAX_TOKENS,
            openai_api_key=settings.OPENAI_API_KEY,
            openai_api_base=settings.OPENAI_API_BASE
        )
    
    def extract_text_from_pdf(self, file_path: str) -> str:
        """Extract text from PDF file"""
        try:
            loader = PyPDFLoader(file_path)
            pages = loader.load()
            
            # Combine all pages
            full_text = "\n\n".join([page.page_content for page in pages])
            
            logger.info(f"Extracted {len(full_text)} characters from PDF: {file_path}")
            return full_text
            
        except Exception as e:
            logger.error(f"Failed to extract text from PDF {file_path}: {str(e)}")
            raise
    
    def create_dynamic_output_parser(self, schema_definition: Dict[str, Any]) -> PydanticOutputParser:
        """Create dynamic Pydantic output parser from schema definition"""
        try:
            # Create dynamic Pydantic model from JSON schema
            model_fields = {}
            
            if 'properties' in schema_definition:
                for field_name, field_def in schema_definition['properties'].items():
                    field_type = self.json_type_to_python_type(field_def.get('type', 'string'))
                    
                    # Check if field is required
                    is_required = field_name in schema_definition.get('required', [])
                    
                    if is_required:
                        model_fields[field_name] = (field_type, ...)
                    else:
                        model_fields[field_name] = (Optional[field_type], None)
            
            # Create dynamic model
            DynamicModel = type('DynamicAnalysisModel', (BaseModel,), model_fields)
            
            return PydanticOutputParser(pydantic_object=DynamicModel)
            
        except Exception as e:
            logger.error(f"Failed to create output parser: {str(e)}")
            raise
    
    def json_type_to_python_type(self, json_type: str):
        """Convert JSON schema type to Python type"""
        type_mapping = {
            'string': str,
            'integer': int,
            'number': float,
            'boolean': bool,
            'array': List[str],  # Default to list of strings
            'object': Dict[str, Any]
        }
        return type_mapping.get(json_type, str)
    
    def analyze_document(self, document_id: int, prompt_id: int, schema_id: int,
                        model_name: str = None, temperature: float = None,
                        max_tokens: int = None, custom_prompt: str = None) -> DocumentAnalysis:
        """Analyze document using LangChain"""
        
        start_time = time.time()
        
        # Get document, prompt, and schema
        document = self.db.query(Document).filter(Document.id == document_id).first()
        if not document:
            raise ValueError(f"Document with ID {document_id} not found")
        
        prompt = self.db.query(SystemPrompt).filter(SystemPrompt.id == prompt_id).first()
        if not prompt:
            raise ValueError(f"System prompt with ID {prompt_id} not found")
        
        schema = self.db.query(OutputSchema).filter(OutputSchema.id == schema_id).first()
        if not schema:
            raise ValueError(f"Output schema with ID {schema_id} not found")
        
        # Create analysis record
        analysis = DocumentAnalysis(
            document_id=document_id,
            prompt_id=prompt_id,
            schema_id=schema_id,
            status="pending",
            model_used=model_name or settings.DEFAULT_LLM_MODEL,
            temperature=temperature or settings.TEMPERATURE,
            max_tokens=max_tokens or settings.MAX_TOKENS,
            custom_prompt=custom_prompt
        )
        
        self.db.add(analysis)
        self.db.commit()
        self.db.refresh(analysis)
        
        try:
            logger.info(f"Starting analysis for document {document.document_name}")
            
            # Extract text from PDF
            document_text = self.extract_text_from_pdf(document.file_path)
            
            # Split text if too long
            if len(document_text) > 10000:  # Arbitrary limit
                chunks = self.text_splitter.split_text(document_text)
                # For now, use first chunk. In production, might want to analyze all chunks
                document_text = chunks[0]
                logger.info(f"Using first chunk of {len(chunks)} chunks for analysis")
            
            # Create LLM
            llm = self.create_llm(model_name, temperature, max_tokens)
            
            # Create output parser
            output_parser = self.create_dynamic_output_parser(schema.schema_definition)
            
            # Create prompt template
            prompt_text = custom_prompt or prompt.prompt_text
            
            # Add format instructions to prompt
            format_instructions = output_parser.get_format_instructions()
            full_prompt = f"{prompt_text}\n\n{format_instructions}\n\nDocument text:\n{document_text}"
            
            # Create chat prompt template
            chat_prompt = ChatPromptTemplate.from_messages([
                ("system", "You are an expert financial document analyst."),
                ("human", full_prompt)
            ])
            
            # Create chain
            chain = chat_prompt | llm | output_parser
            
            # Execute analysis
            logger.info("Executing LangChain analysis...")
            result = chain.invoke({})
            
            # Convert result to dict
            if hasattr(result, 'dict'):
                analysis_result = result.dict()
            else:
                analysis_result = dict(result)
            
            # Calculate processing time
            processing_time = time.time() - start_time
            
            # Update analysis record
            analysis.status = "completed"
            analysis.analysis_result = analysis_result
            analysis.processing_time = processing_time
            analysis.validation_passed = "true"
            
            # Increment usage counters
            prompt.increment_usage()
            schema.increment_usage()
            
            # Mark document as processed
            document.is_processed = True
            
            self.db.commit()
            
            logger.info(f"Analysis completed successfully in {processing_time:.2f} seconds")
            
            return analysis
            
        except OutputParserException as e:
            # Handle parsing errors
            error_msg = f"Output parsing failed: {str(e)}"
            logger.error(error_msg)
            
            analysis.status = "failed"
            analysis.error_message = error_msg
            analysis.error_code = "PARSING_ERROR"
            analysis.processing_time = time.time() - start_time
            
            self.db.commit()
            raise
            
        except ValidationError as e:
            # Handle validation errors
            error_msg = f"Schema validation failed: {str(e)}"
            logger.error(error_msg)
            
            analysis.status = "failed"
            analysis.error_message = error_msg
            analysis.error_code = "VALIDATION_ERROR"
            analysis.processing_time = time.time() - start_time
            
            self.db.commit()
            raise
            
        except Exception as e:
            # Handle other errors
            error_msg = f"Analysis failed: {str(e)}"
            logger.error(error_msg)
            
            analysis.status = "failed"
            analysis.error_message = error_msg
            analysis.error_code = "ANALYSIS_ERROR"
            analysis.processing_time = time.time() - start_time
            
            self.db.commit()
            raise
    
    def bulk_analyze_documents(self, document_ids: List[int], prompt_id: int, 
                              schema_id: int, **kwargs) -> List[DocumentAnalysis]:
        """Analyze multiple documents"""
        results = []
        
        for doc_id in document_ids:
            try:
                analysis = self.analyze_document(doc_id, prompt_id, schema_id, **kwargs)
                results.append(analysis)
            except Exception as e:
                logger.error(f"Failed to analyze document {doc_id}: {str(e)}")
                # Create failed analysis record
                analysis = DocumentAnalysis(
                    document_id=doc_id,
                    prompt_id=prompt_id,
                    schema_id=schema_id,
                    status="failed",
                    error_message=str(e),
                    error_code="BULK_ANALYSIS_ERROR"
                )
                self.db.add(analysis)
                results.append(analysis)
        
        self.db.commit()
        return results
    
    def get_analysis_summary(self, analysis_id: int) -> Dict[str, Any]:
        """Get analysis summary"""
        analysis = self.db.query(DocumentAnalysis).filter(
            DocumentAnalysis.id == analysis_id
        ).first()
        
        if not analysis:
            raise ValueError(f"Analysis with ID {analysis_id} not found")
        
        return {
            "id": analysis.id,
            "status": analysis.status,
            "document_name": analysis.document.document_name,
            "prompt_name": analysis.prompt.name,
            "schema_name": analysis.schema.name,
            "processing_time": analysis.processing_time,
            "created_at": analysis.created_at,
            "has_errors": analysis.has_errors,
            "result_fields": len(analysis.analysis_result) if analysis.analysis_result else 0
        }
    
    def validate_analysis_result(self, analysis_id: int) -> Dict[str, Any]:
        """Validate analysis result against schema"""
        analysis = self.db.query(DocumentAnalysis).filter(
            DocumentAnalysis.id == analysis_id
        ).first()
        
        if not analysis:
            raise ValueError(f"Analysis with ID {analysis_id} not found")
        
        if not analysis.analysis_result:
            return {"is_valid": False, "errors": ["No analysis result available"]}
        
        # Validate against schema
        is_valid, errors = analysis.schema.validate_data(analysis.analysis_result)
        
        # Update analysis record
        analysis.validation_passed = "true" if is_valid else "false"
        analysis.validation_errors = "\n".join(errors) if errors else None
        
        self.db.commit()
        
        return {
            "is_valid": is_valid,
            "errors": errors,
            "analysis_id": analysis_id
        }
    
    def get_analysis_statistics(self, document_id: Optional[int] = None) -> Dict[str, Any]:
        """Get analysis statistics"""
        query = self.db.query(DocumentAnalysis)
        
        if document_id:
            query = query.filter(DocumentAnalysis.document_id == document_id)
        
        analyses = query.all()
        
        total_analyses = len(analyses)
        completed_analyses = len([a for a in analyses if a.status == "completed"])
        failed_analyses = len([a for a in analyses if a.status == "failed"])
        
        processing_times = [a.processing_time for a in analyses if a.processing_time]
        avg_processing_time = sum(processing_times) / len(processing_times) if processing_times else 0
        
        # Group by model
        models = {}
        for analysis in analyses:
            model = analysis.model_used or "unknown"
            if model not in models:
                models[model] = 0
            models[model] += 1
        
        return {
            "total_analyses": total_analyses,
            "completed_analyses": completed_analyses,
            "failed_analyses": failed_analyses,
            "success_rate": (completed_analyses / total_analyses * 100) if total_analyses > 0 else 0,
            "average_processing_time": avg_processing_time,
            "analyses_by_model": models
        }

