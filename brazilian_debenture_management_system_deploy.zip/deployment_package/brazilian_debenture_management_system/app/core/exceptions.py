"""
Custom Exception Classes
"""

from typing import Optional, Any


class CustomException(Exception):
    """Base custom exception class"""
    
    def __init__(
        self,
        message: str,
        status_code: int = 500,
        error_code: str = "INTERNAL_ERROR",
        details: Optional[Any] = None
    ):
        self.message = message
        self.status_code = status_code
        self.error_code = error_code
        self.details = details
        super().__init__(self.message)


class ValidationError(CustomException):
    """Validation error exception"""
    
    def __init__(self, message: str, details: Optional[Any] = None):
        super().__init__(
            message=message,
            status_code=422,
            error_code="VALIDATION_ERROR",
            details=details
        )


class NotFoundError(CustomException):
    """Resource not found exception"""
    
    def __init__(self, resource: str, identifier: Any):
        message = f"{resource} with identifier '{identifier}' not found"
        super().__init__(
            message=message,
            status_code=404,
            error_code="NOT_FOUND",
            details={"resource": resource, "identifier": str(identifier)}
        )


class ConflictError(CustomException):
    """Resource conflict exception"""
    
    def __init__(self, message: str, details: Optional[Any] = None):
        super().__init__(
            message=message,
            status_code=409,
            error_code="CONFLICT",
            details=details
        )


class AuthenticationError(CustomException):
    """Authentication error exception"""
    
    def __init__(self, message: str = "Authentication required"):
        super().__init__(
            message=message,
            status_code=401,
            error_code="AUTHENTICATION_ERROR"
        )


class AuthorizationError(CustomException):
    """Authorization error exception"""
    
    def __init__(self, message: str = "Insufficient permissions"):
        super().__init__(
            message=message,
            status_code=403,
            error_code="AUTHORIZATION_ERROR"
        )


class CrawlerError(CustomException):
    """Crawler-related error exception"""
    
    def __init__(self, message: str, crawler_name: str, details: Optional[Any] = None):
        super().__init__(
            message=message,
            status_code=500,
            error_code="CRAWLER_ERROR",
            details={"crawler": crawler_name, "details": details}
        )


class DocumentError(CustomException):
    """Document-related error exception"""
    
    def __init__(self, message: str, document_id: Optional[int] = None, details: Optional[Any] = None):
        super().__init__(
            message=message,
            status_code=500,
            error_code="DOCUMENT_ERROR",
            details={"document_id": document_id, "details": details}
        )


class AnalysisError(CustomException):
    """Analysis-related error exception"""
    
    def __init__(self, message: str, analysis_id: Optional[int] = None, details: Optional[Any] = None):
        super().__init__(
            message=message,
            status_code=500,
            error_code="ANALYSIS_ERROR",
            details={"analysis_id": analysis_id, "details": details}
        )


class StorageError(CustomException):
    """Storage-related error exception"""
    
    def __init__(self, message: str, file_path: Optional[str] = None, details: Optional[Any] = None):
        super().__init__(
            message=message,
            status_code=500,
            error_code="STORAGE_ERROR",
            details={"file_path": file_path, "details": details}
        )


class DatabaseError(CustomException):
    """Database-related error exception"""
    
    def __init__(self, message: str, details: Optional[Any] = None):
        super().__init__(
            message=message,
            status_code=500,
            error_code="DATABASE_ERROR",
            details=details
        )


class ExternalServiceError(CustomException):
    """External service error exception"""
    
    def __init__(self, service: str, message: str, details: Optional[Any] = None):
        super().__init__(
            message=f"{service} service error: {message}",
            status_code=502,
            error_code="EXTERNAL_SERVICE_ERROR",
            details={"service": service, "details": details}
        )


class RateLimitError(CustomException):
    """Rate limit exceeded exception"""
    
    def __init__(self, message: str = "Rate limit exceeded", retry_after: Optional[int] = None):
        super().__init__(
            message=message,
            status_code=429,
            error_code="RATE_LIMIT_EXCEEDED",
            details={"retry_after": retry_after}
        )

