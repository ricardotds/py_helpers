"""Core utilities and components for the Brazilian Debenture Management Application"""

