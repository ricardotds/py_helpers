"""
Security utilities for authentication and authorization
"""

from datetime import datetime, timedelta
from typing import Optional, Union, Any
from jose import JWTError, jwt
from passlib.context import CryptContext
from fastapi import HTTPException, status, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials

from app.config.settings import get_settings
from app.core.exceptions import AuthenticationError, AuthorizationError

settings = get_settings()

# Password hashing
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# JWT token security
security = HTTPBearer()


def create_access_token(
    subject: Union[str, Any], 
    expires_delta: Optional[timedelta] = None
) -> str:
    """
    Create JWT access token
    """
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(
            minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES
        )
    
    to_encode = {"exp": expire, "sub": str(subject)}
    encoded_jwt = jwt.encode(
        to_encode, 
        settings.SECRET_KEY, 
        algorithm=settings.ALGORITHM
    )
    return encoded_jwt


def verify_token(token: str) -> Optional[str]:
    """
    Verify JWT token and return subject
    """
    try:
        payload = jwt.decode(
            token, 
            settings.SECRET_KEY, 
            algorithms=[settings.ALGORITHM]
        )
        subject: str = payload.get("sub")
        if subject is None:
            return None
        return subject
    except JWTError:
        return None


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """
    Verify password against hash
    """
    return pwd_context.verify(plain_password, hashed_password)


def get_password_hash(password: str) -> str:
    """
    Hash password
    """
    return pwd_context.hash(password)


async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security)
) -> str:
    """
    Get current authenticated user from JWT token
    """
    token = credentials.credentials
    subject = verify_token(token)
    
    if subject is None:
        raise AuthenticationError("Invalid authentication credentials")
    
    return subject


async def get_current_user_optional(
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(security)
) -> Optional[str]:
    """
    Get current user from JWT token (optional, returns None if not authenticated)
    """
    if not credentials:
        return None
    
    token = credentials.credentials
    subject = verify_token(token)
    return subject


async def get_current_active_user(
    current_user: str = Depends(get_current_user)
) -> str:
    """
    Get current active user (placeholder for user status checking)
    """
    # In a real application, you would check if the user is active
    # For now, we'll just return the user
    return current_user


class RoleChecker:
    """
    Role-based access control checker
    """
    
    def __init__(self, allowed_roles: list):
        self.allowed_roles = allowed_roles
    
    def __call__(self, current_user: str = Depends(get_current_user)):
        # In a real application, you would check user roles from database
        # For now, we'll assume all authenticated users have access
        return current_user


# Common role checkers
require_admin = RoleChecker(["admin"])
require_user = RoleChecker(["user", "admin"])
require_analyst = RoleChecker(["analyst", "admin"])


def create_api_key() -> str:
    """
    Create API key for external integrations
    """
    import secrets
    return secrets.token_urlsafe(32)


def verify_api_key(api_key: str) -> bool:
    """
    Verify API key (placeholder implementation)
    """
    # In a real application, you would check against stored API keys
    # For now, we'll accept any non-empty key
    return bool(api_key and len(api_key) > 10)


async def get_api_key_user(
    credentials: HTTPAuthorizationCredentials = Depends(security)
) -> str:
    """
    Authenticate using API key
    """
    api_key = credentials.credentials
    
    if not verify_api_key(api_key):
        raise AuthenticationError("Invalid API key")
    
    return "api_user"


class SecurityHeaders:
    """
    Security headers middleware
    """
    
    @staticmethod
    def add_security_headers(response):
        """
        Add security headers to response
        """
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["X-XSS-Protection"] = "1; mode=block"
        response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        return response


def sanitize_input(input_string: str) -> str:
    """
    Sanitize user input to prevent injection attacks
    """
    if not isinstance(input_string, str):
        return str(input_string)
    
    # Remove potentially dangerous characters
    dangerous_chars = ["<", ">", "&", "\"", "'", "/", "\\"]
    sanitized = input_string
    
    for char in dangerous_chars:
        sanitized = sanitized.replace(char, "")
    
    return sanitized.strip()


def validate_file_type(filename: str, allowed_extensions: list = None) -> bool:
    """
    Validate file type based on extension
    """
    if allowed_extensions is None:
        allowed_extensions = [".pdf", ".doc", ".docx", ".txt"]
    
    file_extension = filename.lower().split(".")[-1]
    return f".{file_extension}" in allowed_extensions


def validate_file_size(file_size: int, max_size: int = None) -> bool:
    """
    Validate file size
    """
    if max_size is None:
        max_size = settings.MAX_FILE_SIZE
    
    return file_size <= max_size

