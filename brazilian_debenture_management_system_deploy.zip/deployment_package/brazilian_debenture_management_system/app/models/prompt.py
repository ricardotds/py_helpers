"""
System Prompt Model
"""

from sqlalchemy import Column, Integer, String, Boolean, Text, Index
from sqlalchemy.orm import relationship

from app.models.base import BaseModel


class SystemPrompt(BaseModel):
    """System prompt model for storing LangChain prompts"""
    
    __tablename__ = "system_prompts"
    
    # Basic information
    name = Column(String(255), nullable=False, unique=True, comment="Unique name for the prompt")
    description = Column(Text, comment="Description of what the prompt does")
    
    # Prompt content
    prompt_text = Column(Text, nullable=False, comment="The actual prompt text")
    
    # Configuration
    is_active = Column(Boolean, default=True, nullable=False, comment="Whether the prompt is active")
    
    # Metadata
    created_by = Column(String(100), comment="User who created the prompt")
    category = Column(String(100), comment="Category of the prompt (e.g., 'debenture', 'assembly')")
    tags = Column(String(500), comment="Comma-separated tags for organization")
    
    # Usage tracking
    usage_count = Column(Integer, default=0, comment="Number of times this prompt has been used")
    
    # Version control
    version = Column(String(20), default="1.0", comment="Version of the prompt")
    parent_prompt_id = Column(Integer, comment="ID of parent prompt if this is a version")
    
    # LangChain specific settings
    model_settings = Column(Text, comment="JSON string with model-specific settings")
    
    # Relationships
    analyses = relationship("DocumentAnalysis", back_populates="prompt")
    
    # Indexes for performance
    __table_args__ = (
        Index('idx_system_prompts_name', 'name'),
        Index('idx_system_prompts_is_active', 'is_active'),
        Index('idx_system_prompts_category', 'category'),
        Index('idx_system_prompts_created_by', 'created_by'),
    )
    
    def __repr__(self):
        return f"<SystemPrompt(id={self.id}, name='{self.name}')>"
    
    @property
    def display_name(self):
        """Get display name for UI"""
        return self.name
    
    @property
    def prompt_preview(self):
        """Get preview of prompt text"""
        max_length = 100
        if len(self.prompt_text) <= max_length:
            return self.prompt_text
        return self.prompt_text[:max_length-3] + "..."
    
    @property
    def tag_list(self):
        """Get tags as a list"""
        if self.tags:
            return [tag.strip() for tag in self.tags.split(',') if tag.strip()]
        return []
    
    def add_tag(self, tag: str):
        """Add a tag to the prompt"""
        current_tags = self.tag_list
        if tag not in current_tags:
            current_tags.append(tag)
            self.tags = ', '.join(current_tags)
    
    def remove_tag(self, tag: str):
        """Remove a tag from the prompt"""
        current_tags = self.tag_list
        if tag in current_tags:
            current_tags.remove(tag)
            self.tags = ', '.join(current_tags)
    
    def increment_usage(self):
        """Increment usage count"""
        self.usage_count = (self.usage_count or 0) + 1
    
    def get_model_settings_dict(self):
        """Get model settings as dictionary"""
        if self.model_settings:
            import json
            try:
                return json.loads(self.model_settings)
            except json.JSONDecodeError:
                return {}
        return {}
    
    def set_model_settings_dict(self, settings: dict):
        """Set model settings from dictionary"""
        import json
        self.model_settings = json.dumps(settings)

