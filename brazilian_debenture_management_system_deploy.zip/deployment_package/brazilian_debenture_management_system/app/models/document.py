"""
Document Model
"""

from sqlalchemy import Column, Integer, String, Boolean, Text, BigInteger, Date, DateTime, ForeignKey, Index
from sqlalchemy.orm import relationship

from app.models.base import BaseModel


class Document(BaseModel):
    """Document model for storing PDF documents and metadata"""
    
    __tablename__ = "documents"
    
    # Foreign key to fiduciary agent
    fiduciary_agent_id = Column(Integer, ForeignKey("fiduciary_agents.id"), nullable=False)
    
    # Company and asset information
    company_name = Column(String(255), nullable=False, comment="Name of the issuing company")
    asset_code = Column(String(50), comment="Asset code (e.g., ADAG11)")
    emission_number = Column(String(50), comment="Emission number")
    series = Column(String(50), comment="Series information")
    
    # Document information
    document_type = Column(String(100), nullable=False, comment="Type of document")
    document_name = Column(String(500), nullable=False, comment="Original document name")
    
    # File information
    file_path = Column(String(1000), nullable=False, comment="Local file path")
    file_size = Column(BigInteger, comment="File size in bytes")
    file_hash = Column(String(64), unique=True, comment="SHA-256 hash of the file")
    
    # Date information
    document_date = Column(Date, comment="Date mentioned in the document")
    download_date = Column(DateTime, nullable=False, comment="When the document was downloaded")
    last_modified = Column(DateTime, comment="Last modification time of the source file")
    
    # Processing status
    is_processed = Column(Boolean, default=False, nullable=False, comment="Whether the document has been processed")
    
    # Additional metadata
    source_url = Column(String(1000), comment="Original URL where the document was found")
    description = Column(Text, comment="Additional description or notes")
    
    # Relationships
    fiduciary_agent = relationship("FiduciaryAgent", back_populates="documents")
    analyses = relationship("DocumentAnalysis", back_populates="document", cascade="all, delete-orphan")
    
    # Indexes for performance
    __table_args__ = (
        Index('idx_documents_fiduciary_agent', 'fiduciary_agent_id'),
        Index('idx_documents_company_name', 'company_name'),
        Index('idx_documents_asset_code', 'asset_code'),
        Index('idx_documents_document_type', 'document_type'),
        Index('idx_documents_download_date', 'download_date'),
        Index('idx_documents_file_hash', 'file_hash'),
        Index('idx_documents_is_processed', 'is_processed'),
    )
    
    def __repr__(self):
        return f"<Document(id={self.id}, name='{self.document_name[:50]}...')>"
    
    @property
    def file_extension(self):
        """Get file extension"""
        if self.document_name:
            return self.document_name.split('.')[-1].lower()
        return None
    
    @property
    def is_pdf(self):
        """Check if document is a PDF"""
        return self.file_extension == 'pdf'
    
    @property
    def display_name(self):
        """Get display name for UI"""
        max_length = 80
        if len(self.document_name) <= max_length:
            return self.document_name
        return self.document_name[:max_length-3] + "..."
    
    def get_file_size_mb(self):
        """Get file size in MB"""
        if self.file_size:
            return round(self.file_size / (1024 * 1024), 2)
        return None

