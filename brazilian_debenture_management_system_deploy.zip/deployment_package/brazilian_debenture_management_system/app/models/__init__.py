"""Database models for the Brazilian Debenture Management Application"""

from app.models.base import Base
from app.models.fiduciary_agent import FiduciaryAgent
from app.models.document import Document
from app.models.crawler import CrawlerRun
from app.models.analysis import DocumentAnalysis
from app.models.prompt import SystemPrompt
from app.models.schema import OutputSchema

__all__ = [
    "Base",
    "FiduciaryAgent",
    "Document",
    "CrawlerRun",
    "DocumentAnalysis",
    "SystemPrompt",
    "OutputSchema"
]

