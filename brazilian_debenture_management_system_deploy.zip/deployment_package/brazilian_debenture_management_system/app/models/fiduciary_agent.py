"""
Fiduciary Agent Model
"""

from sqlalchemy import Column, Integer, String, Boolean, Text
from sqlalchemy.orm import relationship

from app.models.base import BaseModel


class FiduciaryAgent(BaseModel):
    """Fiduciary Agent model"""
    
    __tablename__ = "fiduciary_agents"
    
    # Basic information
    name = Column(String(255), nullable=False, comment="Full name of the fiduciary agent")
    short_name = Column(String(50), nullable=False, unique=True, comment="Short name for display")
    website_url = Column(String(500), nullable=False, comment="Main website URL")
    
    # Crawler configuration
    crawler_class = Column(String(100), nullable=False, comment="Python class name for the crawler")
    
    # Status
    is_active = Column(Boolean, default=True, nullable=False, comment="Whether the agent is active")
    
    # Additional information
    description = Column(Text, comment="Description of the fiduciary agent")
    contact_email = Column(String(255), comment="Contact email")
    contact_phone = Column(String(50), comment="Contact phone")
    
    # Relationships
    documents = relationship("Document", back_populates="fiduciary_agent", cascade="all, delete-orphan")
    crawler_runs = relationship("CrawlerRun", back_populates="fiduciary_agent", cascade="all, delete-orphan")
    
    def __repr__(self):
        return f"<FiduciaryAgent(id={self.id}, short_name='{self.short_name}')>"
    
    @property
    def display_name(self):
        """Get display name for UI"""
        return self.short_name or self.name

