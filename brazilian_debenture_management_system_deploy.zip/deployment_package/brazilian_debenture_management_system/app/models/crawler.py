"""
Crawler Run Model
"""

from sqlalchemy import Column, Integer, String, DateTime, Text, ForeignKey, Index
from sqlalchemy.orm import relationship

from app.models.base import BaseModel


class CrawlerRun(BaseModel):
    """Crawler run model for tracking crawler executions"""
    
    __tablename__ = "crawler_runs"
    
    # Foreign key to fiduciary agent
    fiduciary_agent_id = Column(Integer, ForeignKey("fiduciary_agents.id"), nullable=False)
    
    # Execution information
    status = Column(String(50), nullable=False, comment="Status: running, completed, failed, stopped")
    start_time = Column(DateTime, nullable=False, comment="When the crawler started")
    end_time = Column(DateTime, comment="When the crawler finished")
    
    # Results
    documents_found = Column(Integer, default=0, comment="Number of documents found")
    documents_downloaded = Column(Integer, default=0, comment="Number of documents downloaded")
    documents_skipped = Column(Integer, default=0, comment="Number of documents skipped")
    errors_count = Column(Integer, default=0, comment="Number of errors encountered")
    
    # Error details
    error_details = Column(Text, comment="Detailed error information")
    
    # Configuration used
    force_full_crawl = Column(String(10), comment="Whether full crawl was forced (true/false)")
    date_range_from = Column(DateTime, comment="Date range start for the crawl")
    date_range_to = Column(DateTime, comment="Date range end for the crawl")
    
    # Performance metrics
    execution_time_seconds = Column(Integer, comment="Total execution time in seconds")
    pages_processed = Column(Integer, comment="Number of pages processed")
    last_page_processed = Column(Integer, comment="Last page number processed")
    
    # Additional metadata
    crawler_version = Column(String(50), comment="Version of the crawler used")
    user_agent = Column(String(500), comment="User agent string used")
    notes = Column(Text, comment="Additional notes about the run")
    
    # Relationships
    fiduciary_agent = relationship("FiduciaryAgent", back_populates="crawler_runs")
    
    # Indexes for performance
    __table_args__ = (
        Index('idx_crawler_runs_agent_status', 'fiduciary_agent_id', 'status'),
        Index('idx_crawler_runs_start_time', 'start_time'),
        Index('idx_crawler_runs_status', 'status'),
    )
    
    def __repr__(self):
        return f"<CrawlerRun(id={self.id}, agent_id={self.fiduciary_agent_id}, status='{self.status}')>"
    
    @property
    def duration_seconds(self):
        """Get duration in seconds"""
        if self.start_time and self.end_time:
            return (self.end_time - self.start_time).total_seconds()
        return None
    
    @property
    def duration_formatted(self):
        """Get formatted duration string"""
        duration = self.duration_seconds
        if duration is None:
            return "N/A"
        
        hours = int(duration // 3600)
        minutes = int((duration % 3600) // 60)
        seconds = int(duration % 60)
        
        if hours > 0:
            return f"{hours}h {minutes}m {seconds}s"
        elif minutes > 0:
            return f"{minutes}m {seconds}s"
        else:
            return f"{seconds}s"
    
    @property
    def success_rate(self):
        """Get success rate as percentage"""
        if self.documents_found > 0:
            return round((self.documents_downloaded / self.documents_found) * 100, 2)
        return 0.0
    
    @property
    def is_running(self):
        """Check if crawler is currently running"""
        return self.status == "running"
    
    @property
    def is_completed(self):
        """Check if crawler completed successfully"""
        return self.status == "completed"
    
    @property
    def has_errors(self):
        """Check if crawler had errors"""
        return self.errors_count > 0 or self.status == "failed"

