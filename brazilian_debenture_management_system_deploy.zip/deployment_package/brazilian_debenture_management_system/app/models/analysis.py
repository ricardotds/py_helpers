"""
Document Analysis Model
"""

from sqlalchemy import Column, Integer, String, Text, JSON, Float, ForeignKey, Index
from sqlalchemy.orm import relationship

from app.models.base import BaseModel


class DocumentAnalysis(BaseModel):
    """Document analysis model for storing LangChain analysis results"""
    
    __tablename__ = "document_analyses"
    
    # Foreign keys
    document_id = Column(Integer, ForeignKey("documents.id"), nullable=False)
    prompt_id = Column(Integer, ForeignKey("system_prompts.id"), nullable=False)
    schema_id = Column(Integer, ForeignKey("output_schemas.id"), nullable=False)
    
    # Analysis results
    analysis_result = Column(JSON, comment="Structured analysis result")
    raw_response = Column(Text, comment="Raw response from the LLM")
    
    # Model information
    model_used = Column(String(100), comment="LLM model used for analysis")
    model_version = Column(String(50), comment="Version of the model")
    
    # Performance metrics
    processing_time = Column(Float, comment="Processing time in seconds")
    token_count_input = Column(Integer, comment="Number of input tokens")
    token_count_output = Column(Integer, comment="Number of output tokens")
    cost_estimate = Column(Float, comment="Estimated cost in USD")
    
    # Status and error handling
    status = Column(String(50), nullable=False, comment="Status: pending, completed, failed")
    error_message = Column(Text, comment="Error message if analysis failed")
    error_code = Column(String(50), comment="Error code for categorization")
    
    # Configuration used
    temperature = Column(Float, comment="Temperature setting used")
    max_tokens = Column(Integer, comment="Max tokens setting used")
    custom_prompt = Column(Text, comment="Custom prompt if different from system prompt")
    
    # Quality metrics
    confidence_score = Column(Float, comment="Confidence score of the analysis")
    validation_passed = Column(String(10), comment="Whether output validation passed (true/false)")
    validation_errors = Column(Text, comment="Validation errors if any")
    
    # Metadata
    analysis_version = Column(String(20), default="1.0", comment="Version of the analysis")
    notes = Column(Text, comment="Additional notes about the analysis")
    reviewed_by = Column(String(100), comment="User who reviewed the analysis")
    review_status = Column(String(50), comment="Review status: pending, approved, rejected")
    
    # Relationships
    document = relationship("Document", back_populates="analyses")
    prompt = relationship("SystemPrompt", back_populates="analyses")
    schema = relationship("OutputSchema", back_populates="analyses")
    
    # Indexes for performance
    __table_args__ = (
        Index('idx_document_analyses_document', 'document_id'),
        Index('idx_document_analyses_status', 'status'),
        Index('idx_document_analyses_prompt', 'prompt_id'),
        Index('idx_document_analyses_schema', 'schema_id'),
        Index('idx_document_analyses_model', 'model_used'),
        Index('idx_document_analyses_review_status', 'review_status'),
    )
    
    def __repr__(self):
        return f"<DocumentAnalysis(id={self.id}, document_id={self.document_id}, status='{self.status}')>"
    
    @property
    def is_completed(self):
        """Check if analysis is completed"""
        return self.status == "completed"
    
    @property
    def is_pending(self):
        """Check if analysis is pending"""
        return self.status == "pending"
    
    @property
    def is_failed(self):
        """Check if analysis failed"""
        return self.status == "failed"
    
    @property
    def has_errors(self):
        """Check if analysis has errors"""
        return bool(self.error_message) or self.status == "failed"
    
    @property
    def processing_time_formatted(self):
        """Get formatted processing time"""
        if self.processing_time is None:
            return "N/A"
        
        if self.processing_time < 1:
            return f"{int(self.processing_time * 1000)}ms"
        elif self.processing_time < 60:
            return f"{self.processing_time:.1f}s"
        else:
            minutes = int(self.processing_time // 60)
            seconds = int(self.processing_time % 60)
            return f"{minutes}m {seconds}s"
    
    @property
    def cost_formatted(self):
        """Get formatted cost estimate"""
        if self.cost_estimate is None:
            return "N/A"
        return f"${self.cost_estimate:.4f}"
    
    @property
    def total_tokens(self):
        """Get total token count"""
        input_tokens = self.token_count_input or 0
        output_tokens = self.token_count_output or 0
        return input_tokens + output_tokens
    
    def get_analysis_summary(self) -> dict:
        """Get summary of analysis results"""
        summary = {
            "status": self.status,
            "model": self.model_used,
            "processing_time": self.processing_time_formatted,
            "total_tokens": self.total_tokens,
            "cost": self.cost_formatted,
            "has_errors": self.has_errors,
            "validation_passed": self.validation_passed == "true"
        }
        
        if self.analysis_result:
            summary["fields_extracted"] = len(self.analysis_result) if isinstance(self.analysis_result, dict) else 0
        
        return summary
    
    def get_extracted_fields(self) -> list:
        """Get list of extracted field names"""
        if isinstance(self.analysis_result, dict):
            return list(self.analysis_result.keys())
        return []
    
    def get_field_value(self, field_name: str):
        """Get value of a specific extracted field"""
        if isinstance(self.analysis_result, dict):
            return self.analysis_result.get(field_name)
        return None
    
    def validate_against_schema(self) -> tuple[bool, list]:
        """Validate analysis result against the schema"""
        if not self.schema or not self.analysis_result:
            return False, ["No schema or analysis result available"]
        
        return self.schema.validate_data(self.analysis_result)
    
    def calculate_completeness_score(self) -> float:
        """Calculate completeness score based on required fields"""
        if not self.schema or not isinstance(self.analysis_result, dict):
            return 0.0
        
        required_fields = self.schema.required_fields
        if not required_fields:
            return 1.0
        
        filled_required = sum(1 for field in required_fields 
                            if field in self.analysis_result and self.analysis_result[field] is not None)
        
        return filled_required / len(required_fields)

