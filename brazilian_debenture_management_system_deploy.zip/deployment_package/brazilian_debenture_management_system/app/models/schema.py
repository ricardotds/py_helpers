"""
Output Schema Model
"""

from sqlalchemy import Column, Integer, String, Boolean, Text, JSON, Index
from sqlalchemy.orm import relationship

from app.models.base import BaseModel


class OutputSchema(BaseModel):
    """Output schema model for storing structured output schemas"""
    
    __tablename__ = "output_schemas"
    
    # Basic information
    name = Column(String(255), nullable=False, unique=True, comment="Unique name for the schema")
    description = Column(Text, comment="Description of what the schema defines")
    
    # Schema definition
    schema_definition = Column(JSON, nullable=False, comment="JSON schema definition")
    
    # Configuration
    is_active = Column(Boolean, default=True, nullable=False, comment="Whether the schema is active")
    
    # Metadata
    created_by = Column(String(100), comment="User who created the schema")
    category = Column(String(100), comment="Category of the schema (e.g., 'debenture', 'assembly')")
    tags = Column(String(500), comment="Comma-separated tags for organization")
    
    # Usage tracking
    usage_count = Column(Integer, default=0, comment="Number of times this schema has been used")
    
    # Version control
    version = Column(String(20), default="1.0", comment="Version of the schema")
    parent_schema_id = Column(Integer, comment="ID of parent schema if this is a version")
    
    # Validation settings
    strict_validation = Column(Boolean, default=True, comment="Whether to enforce strict validation")
    allow_additional_properties = Column(Boolean, default=False, comment="Whether to allow additional properties")
    
    # Relationships
    analyses = relationship("DocumentAnalysis", back_populates="schema")
    
    # Indexes for performance
    __table_args__ = (
        Index('idx_output_schemas_name', 'name'),
        Index('idx_output_schemas_is_active', 'is_active'),
        Index('idx_output_schemas_category', 'category'),
        Index('idx_output_schemas_created_by', 'created_by'),
    )
    
    def __repr__(self):
        return f"<OutputSchema(id={self.id}, name='{self.name}')>"
    
    @property
    def display_name(self):
        """Get display name for UI"""
        return self.name
    
    @property
    def schema_preview(self):
        """Get preview of schema definition"""
        import json
        try:
            schema_str = json.dumps(self.schema_definition, indent=2)
            max_length = 200
            if len(schema_str) <= max_length:
                return schema_str
            return schema_str[:max_length-3] + "..."
        except (TypeError, ValueError):
            return "Invalid JSON schema"
    
    @property
    def tag_list(self):
        """Get tags as a list"""
        if self.tags:
            return [tag.strip() for tag in self.tags.split(',') if tag.strip()]
        return []
    
    @property
    def required_fields(self):
        """Get list of required fields from schema"""
        if isinstance(self.schema_definition, dict):
            return self.schema_definition.get('required', [])
        return []
    
    @property
    def properties(self):
        """Get properties from schema"""
        if isinstance(self.schema_definition, dict):
            return self.schema_definition.get('properties', {})
        return {}
    
    @property
    def field_count(self):
        """Get number of fields in schema"""
        return len(self.properties)
    
    def add_tag(self, tag: str):
        """Add a tag to the schema"""
        current_tags = self.tag_list
        if tag not in current_tags:
            current_tags.append(tag)
            self.tags = ', '.join(current_tags)
    
    def remove_tag(self, tag: str):
        """Remove a tag from the schema"""
        current_tags = self.tag_list
        if tag in current_tags:
            current_tags.remove(tag)
            self.tags = ', '.join(current_tags)
    
    def increment_usage(self):
        """Increment usage count"""
        self.usage_count = (self.usage_count or 0) + 1
    
    def validate_data(self, data: dict) -> tuple[bool, list]:
        """Validate data against schema"""
        try:
            import jsonschema
            jsonschema.validate(data, self.schema_definition)
            return True, []
        except jsonschema.ValidationError as e:
            return False, [str(e)]
        except Exception as e:
            return False, [f"Schema validation error: {str(e)}"]
    
    def get_field_info(self, field_name: str) -> dict:
        """Get information about a specific field"""
        properties = self.properties
        if field_name in properties:
            field_info = properties[field_name].copy()
            field_info['required'] = field_name in self.required_fields
            return field_info
        return {}
    
    def get_example_data(self) -> dict:
        """Generate example data based on schema"""
        example = {}
        properties = self.properties
        
        for field_name, field_def in properties.items():
            field_type = field_def.get('type', 'string')
            
            if field_type == 'string':
                if field_def.get('format') == 'date':
                    example[field_name] = "2025-01-01"
                elif 'enum' in field_def:
                    example[field_name] = field_def['enum'][0]
                else:
                    example[field_name] = f"example_{field_name}"
            elif field_type == 'number':
                example[field_name] = 100.0
            elif field_type == 'integer':
                example[field_name] = 1
            elif field_type == 'boolean':
                example[field_name] = True
            elif field_type == 'array':
                example[field_name] = []
            elif field_type == 'object':
                example[field_name] = {}
        
        return example

