"""
Brazilian Debenture Management Application
FastAPI Backend Main Application
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from fastapi.responses import JSONResponse
import uvicorn
import logging
from contextlib import asynccontextmanager

from app.config.settings import get_settings
from app.config.database import engine, create_tables
from app.api.v1.api import api_router
from app.core.exceptions import CustomException


# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan events"""
    # Startup
    logger.info("Starting Brazilian Debenture Management Application")
    
    # Create database tables
    await create_tables()
    logger.info("Database tables created/verified")
    
    yield
    
    # Shutdown
    logger.info("Shutting down application")


# Create FastAPI application
app = FastAPI(
    title="Brazilian Debenture Management API",
    description="""
    A comprehensive management engine for executing web crawlers that retrieve 
    PDF files regarding debentures from Brazilian Fiduciary Agents, with 
    document analysis capabilities using LangChain and customizable prompts.
    
    ## Features
    
    * **Crawler Management**: Individual crawlers for each Brazilian fiduciary agent
    * **Document Management**: Comprehensive document storage and retrieval
    * **AI Analysis**: LangChain integration for document analysis with customizable prompts
    * **Structured Output**: Configurable schemas for analysis results
    * **Databricks Integration**: Ready for enterprise data integration
    
    ## Fiduciary Agents Supported
    
    * Pentágono S.A. DTVM
    * Vórtx DTVM Ltda.
    * Oliveira Trust DTVM S.A.
    * Planner Trustee DTVM Ltda
    * BTG Pactual Serviços Financeiros S.A. DTVM
    * BRL Trust DTVM S.A.
    * XP Investimentos CCTVM S.A.
    * Banco do Brasil S.A.
    * Itaú DTVM S.A.
    """,
    version="1.0.0",
    contact={
        "name": "Debenture Management Team",
        "email": "support@debenture-management.com",
    },
    license_info={
        "name": "MIT License",
        "url": "https://opensource.org/licenses/MIT",
    },
    lifespan=lifespan
)

# Get settings
settings = get_settings()

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allow all origins for development
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Add trusted host middleware for security
app.add_middleware(
    TrustedHostMiddleware,
    allowed_hosts=["*"]  # Allow all hosts for development
)

# Include API router
app.include_router(api_router, prefix="/api/v1")


# Global exception handler
@app.exception_handler(CustomException)
async def custom_exception_handler(request, exc: CustomException):
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "error": {
                "code": exc.error_code,
                "message": exc.message,
                "details": exc.details
            }
        }
    )


@app.exception_handler(HTTPException)
async def http_exception_handler(request, exc: HTTPException):
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "error": {
                "code": "HTTP_ERROR",
                "message": exc.detail,
                "details": None
            }
        }
    )


@app.exception_handler(Exception)
async def general_exception_handler(request, exc: Exception):
    logger.error(f"Unhandled exception: {str(exc)}", exc_info=True)
    return JSONResponse(
        status_code=500,
        content={
            "error": {
                "code": "INTERNAL_SERVER_ERROR",
                "message": "An internal server error occurred",
                "details": None
            }
        }
    )


# Health check endpoint
@app.get("/health", tags=["Health"])
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "service": "Brazilian Debenture Management API",
        "version": "1.0.0"
    }


# Root endpoint
@app.get("/", tags=["Root"])
async def root():
    """Root endpoint with API information"""
    return {
        "message": "Brazilian Debenture Management API",
        "version": "1.0.0",
        "docs": "/docs",
        "redoc": "/redoc",
        "health": "/health"
    }


if __name__ == "__main__":
    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )

