"""
Crawler Pydantic Schemas
"""

from typing import Optional, List, Dict, Any
from datetime import datetime, date
from pydantic import BaseModel, validator


class DateRange(BaseModel):
    """Date range for crawler configuration"""
    start_date: Optional[date] = None
    end_date: Optional[date] = None
    
    @validator('end_date')
    def validate_date_range(cls, v, values):
        if v and 'start_date' in values and values['start_date']:
            if v < values['start_date']:
                raise ValueError('end_date cannot be before start_date')
        return v


class CrawlerRunCreate(BaseModel):
    """Schema for creating a crawler run"""
    force_full_crawl: bool = False
    date_range: Optional[DateRange] = None


class CrawlerStatus(BaseModel):
    """Schema for crawler status"""
    fiduciary_agent_id: int
    agent_name: str
    status: str  # idle, running, completed, failed
    last_run: Optional[datetime] = None
    next_scheduled_run: Optional[datetime] = None
    documents_found_last_run: int = 0
    documents_downloaded_last_run: int = 0
    errors_last_run: int = 0


class CrawlerRun(BaseModel):
    """Schema for crawler run"""
    id: int
    status: str
    start_time: datetime
    end_time: Optional[datetime] = None
    documents_found: int = 0
    documents_downloaded: int = 0
    errors_count: int = 0
    error_details: Optional[str] = None
    
    class Config:
        from_attributes = True


class CrawlerRunDetail(CrawlerRun):
    """Detailed schema for crawler run"""
    fiduciary_agent_id: int
    agent_name: str
    documents_skipped: int = 0
    force_full_crawl: Optional[str] = None
    date_range_from: Optional[datetime] = None
    date_range_to: Optional[datetime] = None
    execution_time_seconds: Optional[int] = None
    pages_processed: Optional[int] = None
    last_page_processed: Optional[int] = None
    crawler_version: Optional[str] = None
    user_agent: Optional[str] = None
    notes: Optional[str] = None
    created_at: datetime
    
    class Config:
        from_attributes = True


class CrawlerLog(BaseModel):
    """Schema for crawler log entry"""
    timestamp: datetime
    level: str  # INFO, WARNING, ERROR, DEBUG
    message: str
    details: Dict[str, Any] = {}


class CrawlerRunLogs(BaseModel):
    """Schema for crawler run logs"""
    run_id: int
    logs: List[CrawlerLog]


class CrawlerConfiguration(BaseModel):
    """Schema for crawler configuration"""
    user_agent: Optional[str] = None
    timeout: Optional[int] = 30
    retry_attempts: Optional[int] = 3
    delay_between_requests: Optional[float] = 1.0
    max_pages: Optional[int] = None
    custom_headers: Optional[Dict[str, str]] = None


class CrawlerStats(BaseModel):
    """Schema for crawler statistics"""
    total_runs: int
    successful_runs: int
    failed_runs: int
    total_documents_found: int
    total_documents_downloaded: int
    average_execution_time: Optional[float] = None
    last_successful_run: Optional[datetime] = None
    last_failed_run: Optional[datetime] = None

