"""
Document Analysis Pydantic Schemas
"""

from typing import Optional, Dict, Any
from datetime import datetime
from pydantic import BaseModel, validator
from app.schemas.document import DocumentSummary
from app.schemas.prompt import SystemPromptSummary
from app.schemas.schema import OutputSchemaSummary


class DocumentAnalysisBase(BaseModel):
    """Base schema for document analysis"""
    model_used: Optional[str] = None
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None
    custom_prompt: Optional[str] = None


class DocumentAnalysisCreate(DocumentAnalysisBase):
    """Schema for creating a document analysis"""
    document_id: int
    prompt_id: int
    schema_id: int
    
    @validator('document_id', 'prompt_id', 'schema_id')
    def validate_ids(cls, v):
        if v <= 0:
            raise ValueError('ID must be a positive integer')
        return v


class DocumentAnalysisUpdate(BaseModel):
    """Schema for updating a document analysis"""
    status: Optional[str] = None
    analysis_result: Optional[Dict[str, Any]] = None
    error_message: Optional[str] = None
    confidence_score: Optional[float] = None
    notes: Optional[str] = None
    reviewed_by: Optional[str] = None
    review_status: Optional[str] = None


class DocumentAnalysis(DocumentAnalysisBase):
    """Schema for document analysis response"""
    id: int
    document_id: int
    prompt_id: int
    schema_id: int
    analysis_result: Optional[Dict[str, Any]] = None
    raw_response: Optional[str] = None
    model_version: Optional[str] = None
    processing_time: Optional[float] = None
    token_count_input: Optional[int] = None
    token_count_output: Optional[int] = None
    cost_estimate: Optional[float] = None
    status: str
    error_message: Optional[str] = None
    error_code: Optional[str] = None
    confidence_score: Optional[float] = None
    validation_passed: Optional[str] = None
    validation_errors: Optional[str] = None
    analysis_version: str = "1.0"
    notes: Optional[str] = None
    reviewed_by: Optional[str] = None
    review_status: Optional[str] = None
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True


class DocumentAnalysisDetail(DocumentAnalysis):
    """Detailed schema for document analysis with related objects"""
    document: DocumentSummary
    prompt: SystemPromptSummary
    schema: OutputSchemaSummary
    
    class Config:
        from_attributes = True


class DocumentAnalysisSummary(BaseModel):
    """Summary schema for document analysis"""
    id: int
    document_id: int
    status: str
    model_used: Optional[str] = None
    processing_time: Optional[float] = None
    confidence_score: Optional[float] = None
    created_at: datetime
    
    class Config:
        from_attributes = True


class AnalysisStats(BaseModel):
    """Schema for analysis statistics"""
    total_analyses: int
    completed_analyses: int
    pending_analyses: int
    failed_analyses: int
    average_processing_time: Optional[float] = None
    total_cost: Optional[float] = None
    analyses_by_model: Dict[str, int]
    analyses_by_status: Dict[str, int]


class AnalysisResult(BaseModel):
    """Schema for analysis result"""
    analysis_id: int
    status: str
    result: Optional[Dict[str, Any]] = None
    error_message: Optional[str] = None
    processing_time: Optional[float] = None
    confidence_score: Optional[float] = None


class BulkAnalysisRequest(BaseModel):
    """Schema for bulk analysis request"""
    document_ids: list[int]
    prompt_id: int
    schema_id: int
    model_used: Optional[str] = None
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None
    
    @validator('document_ids')
    def validate_document_ids(cls, v):
        if not v:
            raise ValueError('At least one document ID is required')
        if len(v) > 100:
            raise ValueError('Maximum 100 documents can be analyzed at once')
        return v

