"""
Document Pydantic Schemas
"""

from typing import Optional, List
from datetime import datetime, date
from pydantic import BaseModel, validator
from app.schemas.fiduciary_agent import FiduciaryAgentSummary


class DocumentBase(BaseModel):
    """Base schema for document"""
    company_name: str
    asset_code: Optional[str] = None
    emission_number: Optional[str] = None
    series: Optional[str] = None
    document_type: str
    document_name: str
    document_date: Optional[date] = None
    description: Optional[str] = None


class DocumentCreate(DocumentBase):
    """Schema for creating a document"""
    fiduciary_agent_id: int
    file_path: str
    file_size: Optional[int] = None
    file_hash: Optional[str] = None
    source_url: Optional[str] = None
    last_modified: Optional[datetime] = None
    
    @validator('company_name', 'document_type', 'document_name')
    def validate_required_fields(cls, v):
        if not v or len(v.strip()) == 0:
            raise ValueError('Field cannot be empty')
        return v.strip()


class DocumentUpdate(BaseModel):
    """Schema for updating a document"""
    company_name: Optional[str] = None
    asset_code: Optional[str] = None
    emission_number: Optional[str] = None
    series: Optional[str] = None
    document_type: Optional[str] = None
    document_name: Optional[str] = None
    document_date: Optional[date] = None
    description: Optional[str] = None
    is_processed: Optional[bool] = None


class Document(DocumentBase):
    """Schema for document response"""
    id: int
    fiduciary_agent_id: int
    file_path: str
    file_size: Optional[int] = None
    file_hash: Optional[str] = None
    download_date: datetime
    last_modified: Optional[datetime] = None
    is_processed: bool = False
    source_url: Optional[str] = None
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True


class DocumentWithAgent(Document):
    """Schema for document with fiduciary agent information"""
    fiduciary_agent: FiduciaryAgentSummary
    analysis_count: int = 0
    
    class Config:
        from_attributes = True


class DocumentSummary(BaseModel):
    """Summary schema for document"""
    id: int
    document_name: str
    company_name: str
    asset_code: Optional[str] = None
    document_type: str
    file_size: Optional[int] = None
    download_date: datetime
    is_processed: bool = False
    
    class Config:
        from_attributes = True


class DocumentFilter(BaseModel):
    """Schema for document filtering"""
    fiduciary_agent_id: Optional[int] = None
    company_name: Optional[str] = None
    asset_code: Optional[str] = None
    document_type: Optional[str] = None
    date_from: Optional[date] = None
    date_to: Optional[date] = None
    search: Optional[str] = None
    is_processed: Optional[bool] = None


class DocumentStats(BaseModel):
    """Schema for document statistics"""
    total_documents: int
    processed_documents: int
    unprocessed_documents: int
    total_size_mb: float
    documents_by_type: dict
    documents_by_agent: dict
    recent_downloads: List[DocumentSummary]


class DocumentAnalysisSummary(BaseModel):
    """Summary schema for document analysis"""
    id: int
    status: str
    model_used: Optional[str] = None
    processing_time: Optional[float] = None
    created_at: datetime
    
    class Config:
        from_attributes = True


class DocumentWithAnalyses(DocumentWithAgent):
    """Schema for document with analysis information"""
    analyses: List[DocumentAnalysisSummary] = []
    
    class Config:
        from_attributes = True

