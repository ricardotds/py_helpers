"""
Output Schema Pydantic Schemas
"""

from typing import Optional, List, Dict, Any
from datetime import datetime
from pydantic import BaseModel, validator


class OutputSchemaBase(BaseModel):
    """Base schema for output schema"""
    name: str
    description: Optional[str] = None
    schema_definition: Dict[str, Any]
    is_active: bool = True
    category: Optional[str] = None
    tags: Optional[str] = None
    strict_validation: bool = True
    allow_additional_properties: bool = False


class OutputSchemaCreate(OutputSchemaBase):
    """Schema for creating an output schema"""
    created_by: Optional[str] = None
    version: str = "1.0"
    parent_schema_id: Optional[int] = None
    
    @validator('name')
    def validate_name(cls, v):
        if not v or len(v.strip()) == 0:
            raise ValueError('Name cannot be empty')
        return v.strip()
    
    @validator('schema_definition')
    def validate_schema_definition(cls, v):
        if not v:
            raise ValueError('Schema definition cannot be empty')
        
        # Basic JSON schema validation
        if not isinstance(v, dict):
            raise ValueError('Schema definition must be a valid JSON object')
        
        # Check for required JSON schema fields
        if 'type' not in v:
            raise ValueError('Schema definition must have a "type" field')
        
        return v


class OutputSchemaUpdate(BaseModel):
    """Schema for updating an output schema"""
    name: Optional[str] = None
    description: Optional[str] = None
    schema_definition: Optional[Dict[str, Any]] = None
    is_active: Optional[bool] = None
    category: Optional[str] = None
    tags: Optional[str] = None
    strict_validation: Optional[bool] = None
    allow_additional_properties: Optional[bool] = None


class OutputSchema(OutputSchemaBase):
    """Schema for output schema response"""
    id: int
    created_by: Optional[str] = None
    usage_count: int = 0
    version: str = "1.0"
    parent_schema_id: Optional[int] = None
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True


class OutputSchemaSummary(BaseModel):
    """Summary schema for output schema"""
    id: int
    name: str
    description: Optional[str] = None
    is_active: bool
    category: Optional[str] = None
    usage_count: int = 0
    field_count: int = 0
    created_at: datetime
    
    class Config:
        from_attributes = True


class OutputSchemaWithUsage(OutputSchema):
    """Schema for output schema with usage statistics"""
    recent_analyses_count: int = 0
    average_processing_time: Optional[float] = None
    validation_success_rate: Optional[float] = None
    
    class Config:
        from_attributes = True


class SchemaValidationResult(BaseModel):
    """Schema for validation result"""
    is_valid: bool
    errors: List[str] = []


class SchemaFieldInfo(BaseModel):
    """Schema for field information"""
    name: str
    type: str
    description: Optional[str] = None
    required: bool = False
    enum_values: Optional[List[str]] = None
    format: Optional[str] = None
    example: Optional[Any] = None

