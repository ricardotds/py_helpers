"""
Fiduciary Agent Pydantic Schemas
"""

from typing import Optional
from datetime import datetime
from pydantic import BaseModel, HttpUrl, validator


class FiduciaryAgentBase(BaseModel):
    """Base schema for fiduciary agent"""
    name: str
    short_name: str
    website_url: str
    crawler_class: str
    is_active: bool = True
    description: Optional[str] = None
    contact_email: Optional[str] = None
    contact_phone: Optional[str] = None


class FiduciaryAgentCreate(FiduciaryAgentBase):
    """Schema for creating a fiduciary agent"""
    
    @validator('short_name')
    def validate_short_name(cls, v):
        if not v or len(v.strip()) == 0:
            raise ValueError('Short name cannot be empty')
        return v.strip()
    
    @validator('crawler_class')
    def validate_crawler_class(cls, v):
        if not v or len(v.strip()) == 0:
            raise ValueError('Crawler class cannot be empty')
        return v.strip()


class FiduciaryAgentUpdate(BaseModel):
    """Schema for updating a fiduciary agent"""
    name: Optional[str] = None
    short_name: Optional[str] = None
    website_url: Optional[str] = None
    crawler_class: Optional[str] = None
    is_active: Optional[bool] = None
    description: Optional[str] = None
    contact_email: Optional[str] = None
    contact_phone: Optional[str] = None


class FiduciaryAgent(FiduciaryAgentBase):
    """Schema for fiduciary agent response"""
    id: int
    document_count: Optional[int] = 0
    last_crawl: Optional[datetime] = None
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True


class FiduciaryAgentSummary(BaseModel):
    """Summary schema for fiduciary agent"""
    id: int
    name: str
    short_name: str
    is_active: bool
    document_count: Optional[int] = 0
    last_crawl: Optional[datetime] = None
    
    class Config:
        from_attributes = True

