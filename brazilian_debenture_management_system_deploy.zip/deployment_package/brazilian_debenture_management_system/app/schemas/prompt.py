"""
System Prompt Pydantic Schemas
"""

from typing import Optional, List, Dict, Any
from datetime import datetime
from pydantic import BaseModel, validator


class SystemPromptBase(BaseModel):
    """Base schema for system prompt"""
    name: str
    description: Optional[str] = None
    prompt_text: str
    is_active: bool = True
    category: Optional[str] = None
    tags: Optional[str] = None


class SystemPromptCreate(SystemPromptBase):
    """Schema for creating a system prompt"""
    created_by: Optional[str] = None
    version: str = "1.0"
    parent_prompt_id: Optional[int] = None
    model_settings: Optional[Dict[str, Any]] = None
    
    @validator('name')
    def validate_name(cls, v):
        if not v or len(v.strip()) == 0:
            raise ValueError('Name cannot be empty')
        return v.strip()
    
    @validator('prompt_text')
    def validate_prompt_text(cls, v):
        if not v or len(v.strip()) == 0:
            raise ValueError('Prompt text cannot be empty')
        return v.strip()


class SystemPromptUpdate(BaseModel):
    """Schema for updating a system prompt"""
    name: Optional[str] = None
    description: Optional[str] = None
    prompt_text: Optional[str] = None
    is_active: Optional[bool] = None
    category: Optional[str] = None
    tags: Optional[str] = None
    model_settings: Optional[Dict[str, Any]] = None


class SystemPrompt(SystemPromptBase):
    """Schema for system prompt response"""
    id: int
    created_by: Optional[str] = None
    usage_count: int = 0
    version: str = "1.0"
    parent_prompt_id: Optional[int] = None
    model_settings: Optional[str] = None
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True


class SystemPromptSummary(BaseModel):
    """Summary schema for system prompt"""
    id: int
    name: str
    description: Optional[str] = None
    is_active: bool
    category: Optional[str] = None
    usage_count: int = 0
    created_at: datetime
    
    class Config:
        from_attributes = True


class SystemPromptWithUsage(SystemPrompt):
    """Schema for system prompt with usage statistics"""
    recent_analyses_count: int = 0
    average_processing_time: Optional[float] = None
    success_rate: Optional[float] = None
    
    class Config:
        from_attributes = True

