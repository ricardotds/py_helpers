"""Pydantic schemas for API request/response validation"""

from app.schemas.fiduciary_agent import FiduciaryAgent, FiduciaryAgentCreate, FiduciaryAgentUpdate
from app.schemas.document import Document, DocumentCreate, DocumentUpdate, DocumentFilter
from app.schemas.crawler import CrawlerStatus, CrawlerRun, CrawlerRunCreate, CrawlerRunDetail, CrawlerLog
from app.schemas.analysis import DocumentAnalysis, DocumentAnalysisCreate, DocumentAnalysisUpdate
from app.schemas.prompt import SystemPrompt, SystemPromptCreate, SystemPromptUpdate
from app.schemas.schema import OutputSchema, OutputSchemaCreate, OutputSchemaUpdate

__all__ = [
    "FiduciaryAgent", "FiduciaryAgentCreate", "FiduciaryAgentUpdate",
    "Document", "DocumentCreate", "DocumentUpdate", "DocumentFilter",
    "CrawlerStatus", "CrawlerRun", "CrawlerRunCreate", "CrawlerRunDetail", "CrawlerLog",
    "DocumentAnalysis", "DocumentAnalysisCreate", "DocumentAnalysisUpdate",
    "SystemPrompt", "SystemPromptCreate", "SystemPromptUpdate",
    "OutputSchema", "OutputSchemaCreate", "OutputSchemaUpdate"
]

