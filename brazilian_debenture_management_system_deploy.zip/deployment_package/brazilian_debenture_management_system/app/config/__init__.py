"""Configuration package for the Brazilian Debenture Management Application"""

