"""
Database Configuration
"""

from sqlalchemy import create_engine, MetaData
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy.pool import StaticPool
from typing import Generator
import logging

from app.config.settings import get_settings

logger = logging.getLogger(__name__)

# Get settings
settings = get_settings()

# Create database engine
if settings.USE_SQLITE:
    # SQLite configuration for development
    engine = create_engine(
        settings.database_url,
        connect_args={
            "check_same_thread": False,
        },
        poolclass=StaticPool,
        echo=settings.DATABASE_ECHO
    )
else:
    # PostgreSQL configuration for production
    engine = create_engine(
        settings.database_url,
        echo=settings.DATABASE_ECHO,
        pool_pre_ping=True,
        pool_recycle=300,
    )

# Create session factory
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Create base class for models
Base = declarative_base()

# Metadata for migrations
metadata = MetaData()


def get_db() -> Generator[Session, None, None]:
    """
    Dependency to get database session
    """
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


async def create_tables():
    """
    Create all database tables
    """
    try:
        # Import all models to ensure they are registered
        from app.models import (
            fiduciary_agent,
            document,
            crawler,
            analysis,
            prompt,
            schema
        )
        
        # Create all tables
        Base.metadata.create_all(bind=engine)
        logger.info("Database tables created successfully")
        
    except Exception as e:
        logger.error(f"Error creating database tables: {str(e)}")
        raise


async def drop_tables():
    """
    Drop all database tables (for testing/development)
    """
    try:
        Base.metadata.drop_all(bind=engine)
        logger.info("Database tables dropped successfully")
        
    except Exception as e:
        logger.error(f"Error dropping database tables: {str(e)}")
        raise


def init_db():
    """
    Initialize database with default data
    """
    from app.models.fiduciary_agent import FiduciaryAgent
    from app.models.prompt import SystemPrompt
    from app.models.schema import OutputSchema
    
    db = SessionLocal()
    try:
        # Create default fiduciary agents
        default_agents = [
            {
                "name": "Pentágono S.A. Distribuidora de Títulos e Valores Mobiliários",
                "short_name": "Pentágono",
                "website_url": "https://www.pentagonotrustee.com.br/",
                "crawler_class": "PentagonoCrawler"
            },
            {
                "name": "Vórtx DTVM Ltda.",
                "short_name": "Vórtx",
                "website_url": "https://www.vortx.com.br/",
                "crawler_class": "VortxCrawler"
            },
            {
                "name": "Oliveira Trust DTVM S.A.",
                "short_name": "Oliveira Trust",
                "website_url": "https://www.oliveiratrust.com.br/",
                "crawler_class": "OliveiraTrustCrawler"
            },
            {
                "name": "Planner Trustee DTVM Ltda",
                "short_name": "Planner",
                "website_url": "https://www.trusteedtvm.com.br/",
                "crawler_class": "PlannerCrawler"
            },
            {
                "name": "BTG Pactual Serviços Financeiros S.A. DTVM",
                "short_name": "BTG Pactual",
                "website_url": "https://www.btgpactual.com/",
                "crawler_class": "BTGPactualCrawler"
            },
            {
                "name": "BRL Trust DTVM S.A.",
                "short_name": "BRL Trust",
                "website_url": "https://www.internal.brltrust.com.br/",
                "crawler_class": "BRLTrustCrawler"
            },
            {
                "name": "XP Investimentos CCTVM S.A.",
                "short_name": "XP Investimentos",
                "website_url": "https://www.xpi.com.br/",
                "crawler_class": "XPCrawler"
            },
            {
                "name": "Banco do Brasil S.A.",
                "short_name": "Banco do Brasil",
                "website_url": "https://www.bancodobrasilsecurities.com/",
                "crawler_class": "BancoBrasilCrawler"
            },
            {
                "name": "Itaú DTVM S.A.",
                "short_name": "Itaú",
                "website_url": "https://www.itau.com.br/investmentservices-en/",
                "crawler_class": "ItauCrawler"
            }
        ]
        
        for agent_data in default_agents:
            # Check if agent already exists
            existing = db.query(FiduciaryAgent).filter_by(
                short_name=agent_data["short_name"]
            ).first()
            
            if not existing:
                agent = FiduciaryAgent(**agent_data)
                db.add(agent)
        
        # Create default system prompts
        default_prompts = [
            {
                "name": "Debenture Analysis",
                "description": "Extract key information from debenture documents",
                "prompt_text": """You are an expert financial analyst specializing in Brazilian debentures. 
                Analyze the following debenture document and extract the key information according to the provided schema.
                
                Focus on:
                - Company information
                - Emission details (value, date, maturity)
                - Interest rate and indexation
                - Guarantee type and details
                - Series and emission number
                - Any special conditions or covenants
                
                Provide accurate information based only on what is explicitly stated in the document.
                If information is not available, indicate as null or not specified.
                
                Document content:
                {document_content}
                
                Please extract the information according to the provided schema.""",
                "is_active": True,
                "created_by": "system"
            },
            {
                "name": "Assembly Analysis",
                "description": "Extract information from assembly documents",
                "prompt_text": """You are an expert in corporate governance and Brazilian securities law.
                Analyze the following assembly document (AGT/AGD) and extract relevant information.
                
                Focus on:
                - Assembly type and date
                - Decisions made
                - Voting results
                - Changes to terms and conditions
                - Participant information
                - Resolutions passed
                
                Document content:
                {document_content}
                
                Please extract the information according to the provided schema.""",
                "is_active": True,
                "created_by": "system"
            }
        ]
        
        for prompt_data in default_prompts:
            existing = db.query(SystemPrompt).filter_by(
                name=prompt_data["name"]
            ).first()
            
            if not existing:
                prompt = SystemPrompt(**prompt_data)
                db.add(prompt)
        
        # Create default output schemas
        default_schemas = [
            {
                "name": "Debenture Schema",
                "description": "Structured output for debenture information",
                "schema_definition": {
                    "type": "object",
                    "properties": {
                        "company_name": {
                            "type": "string",
                            "description": "Name of the issuing company"
                        },
                        "emission_value": {
                            "type": "number",
                            "description": "Total emission value in BRL"
                        },
                        "emission_date": {
                            "type": "string",
                            "format": "date",
                            "description": "Date of emission"
                        },
                        "maturity_date": {
                            "type": "string",
                            "format": "date",
                            "description": "Maturity date of the debenture"
                        },
                        "interest_rate": {
                            "type": "string",
                            "description": "Interest rate description (e.g., 'IPCA + 4.24% a.a.')"
                        },
                        "guarantee_type": {
                            "type": "string",
                            "enum": ["Real", "Flutuante", "Subordinada", "Quirografária"],
                            "description": "Type of guarantee"
                        },
                        "emission_number": {
                            "type": "string",
                            "description": "Emission number"
                        },
                        "series": {
                            "type": "string",
                            "description": "Series information"
                        },
                        "asset_code": {
                            "type": "string",
                            "description": "Asset code (e.g., ADAG11)"
                        },
                        "quantity": {
                            "type": "integer",
                            "description": "Number of debentures issued"
                        },
                        "nominal_value": {
                            "type": "number",
                            "description": "Nominal value per debenture"
                        }
                    },
                    "required": ["company_name", "emission_value", "maturity_date"]
                },
                "is_active": True,
                "created_by": "system"
            },
            {
                "name": "Assembly Schema",
                "description": "Structured output for assembly documents",
                "schema_definition": {
                    "type": "object",
                    "properties": {
                        "assembly_type": {
                            "type": "string",
                            "enum": ["AGT", "AGD", "AGE"],
                            "description": "Type of assembly"
                        },
                        "assembly_date": {
                            "type": "string",
                            "format": "date",
                            "description": "Date of the assembly"
                        },
                        "company_name": {
                            "type": "string",
                            "description": "Name of the company"
                        },
                        "asset_code": {
                            "type": "string",
                            "description": "Related asset code"
                        },
                        "decisions": {
                            "type": "array",
                            "items": {
                                "type": "object",
                                "properties": {
                                    "decision": {"type": "string"},
                                    "approved": {"type": "boolean"},
                                    "votes_for": {"type": "integer"},
                                    "votes_against": {"type": "integer"}
                                }
                            },
                            "description": "Decisions made in the assembly"
                        },
                        "purpose": {
                            "type": "string",
                            "description": "Main purpose of the assembly"
                        }
                    },
                    "required": ["assembly_type", "assembly_date", "company_name"]
                },
                "is_active": True,
                "created_by": "system"
            }
        ]
        
        for schema_data in default_schemas:
            existing = db.query(OutputSchema).filter_by(
                name=schema_data["name"]
            ).first()
            
            if not existing:
                schema = OutputSchema(**schema_data)
                db.add(schema)
        
        db.commit()
        logger.info("Database initialized with default data")
        
    except Exception as e:
        logger.error(f"Error initializing database: {str(e)}")
        db.rollback()
        raise
    finally:
        db.close()

