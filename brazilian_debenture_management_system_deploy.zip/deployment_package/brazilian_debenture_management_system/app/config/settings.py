"""
Application Settings Configuration
"""

from functools import lru_cache
from typing import Optional, List
from pydantic_settings import BaseSettings
from pydantic import validator
import os
from pathlib import Path


class Settings(BaseSettings):
    """Application settings"""
    
    # Application settings
    APP_NAME: str = "Brazilian Debenture Management API"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = False
    
    # Server settings
    HOST: str = "0.0.0.0"
    PORT: int = 8000
    
    # Database settings
    DATABASE_URL: str = "postgresql://postgres:password@localhost:5432/debenture_management"
    DATABASE_ECHO: bool = False
    
    # Alternative database for development (SQLite)
    USE_SQLITE: bool = True
    SQLITE_DATABASE_URL: str = "sqlite:///./debenture_management.db"
    
    # Redis settings for caching and task queue
    REDIS_URL: str = "redis://localhost:6379/0"
    
    # Storage settings
    STORAGE_PATH: str = "./storage"
    DOCUMENTS_PATH: str = "./storage/documents"
    LOGS_PATH: str = "./storage/logs"
    MAX_FILE_SIZE: int = 100 * 1024 * 1024  # 100MB
    
    # Security settings
    SECRET_KEY: str = "your-secret-key-change-in-production"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    ALGORITHM: str = "HS256"
    
    # CORS settings
    ALLOWED_ORIGINS: List[str] = ["*"]
    ALLOWED_METHODS: List[str] = ["*"]
    ALLOWED_HEADERS: List[str] = ["*"]
    
    # LangChain and OpenAI settings
    OPENAI_API_KEY: Optional[str] = None
    OPENAI_API_BASE: Optional[str] = None
    DEFAULT_LLM_MODEL: str = "gpt-3.5-turbo"
    MAX_TOKENS: int = 4000
    TEMPERATURE: float = 0.1
    
    # Crawler settings
    CRAWLER_USER_AGENT: str = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
    CRAWLER_TIMEOUT: int = 30
    CRAWLER_RETRY_ATTEMPTS: int = 3
    CRAWLER_DELAY_BETWEEN_REQUESTS: float = 1.0
    MAX_CONCURRENT_CRAWLERS: int = 3
    
    # Databricks settings
    DATABRICKS_SERVER_HOSTNAME: Optional[str] = None
    DATABRICKS_HTTP_PATH: Optional[str] = None
    DATABRICKS_ACCESS_TOKEN: Optional[str] = None
    DATABRICKS_CATALOG: str = "main"
    DATABRICKS_SCHEMA: str = "debenture_management"
    
    # Logging settings
    LOG_LEVEL: str = "INFO"
    LOG_FORMAT: str = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    
    # Rate limiting
    RATE_LIMIT_REQUESTS: int = 1000
    RATE_LIMIT_WINDOW: int = 3600  # 1 hour
    
    # Background task settings
    CELERY_BROKER_URL: str = "redis://localhost:6379/1"
    CELERY_RESULT_BACKEND: str = "redis://localhost:6379/2"
    
    @validator("STORAGE_PATH", "DOCUMENTS_PATH", "LOGS_PATH")
    def create_directories(cls, v):
        """Create directories if they don't exist"""
        Path(v).mkdir(parents=True, exist_ok=True)
        return v
    
    @validator("OPENAI_API_KEY", pre=True)
    def get_openai_api_key(cls, v):
        """Get OpenAI API key from environment if not provided"""
        return v or os.getenv("OPENAI_API_KEY")
    
    @validator("OPENAI_API_BASE", pre=True)
    def get_openai_api_base(cls, v):
        """Get OpenAI API base from environment if not provided"""
        return v or os.getenv("OPENAI_API_BASE")
    
    @property
    def database_url(self) -> str:
        """Get the appropriate database URL"""
        if self.USE_SQLITE:
            return self.SQLITE_DATABASE_URL
        return self.DATABASE_URL
    
    @property
    def storage_path_obj(self) -> Path:
        """Get storage path as Path object"""
        return Path(self.STORAGE_PATH)
    
    @property
    def documents_path_obj(self) -> Path:
        """Get documents path as Path object"""
        return Path(self.DOCUMENTS_PATH)
    
    @property
    def logs_path_obj(self) -> Path:
        """Get logs path as Path object"""
        return Path(self.LOGS_PATH)
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = True


@lru_cache()
def get_settings() -> Settings:
    """Get cached settings instance"""
    return Settings()

