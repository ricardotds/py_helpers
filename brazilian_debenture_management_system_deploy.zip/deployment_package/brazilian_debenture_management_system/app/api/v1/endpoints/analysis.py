"""
Document Analysis Endpoints
"""

from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status, BackgroundTasks
from sqlalchemy.orm import Session

from app.config.database import get_db
from app.api.deps import (
    get_current_user,
    get_pagination_params,
    PaginationParams
)
from app.schemas.analysis import (
    DocumentAnalysis,
    DocumentAnalysisCreate,
    DocumentAnalysisDetail,
    AnalysisResult,
    BulkAnalysisRequest,
    AnalysisStats
)
from app.models.analysis import DocumentAnalysis as AnalysisModel
from app.models.document import Document
from app.models.prompt import SystemPrompt
from app.models.schema import OutputSchema
from app.services.analysis_service import AnalysisService
from app.core.exceptions import NotFoundError, ValidationError

router = APIRouter()


@router.post("/", response_model=AnalysisResult)
async def create_analysis(
    analysis_request: DocumentAnalysisCreate,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    """
    Create new document analysis
    """
    # Validate that document, prompt, and schema exist
    document = db.query(Document).filter(Document.id == analysis_request.document_id).first()
    if not document:
        raise NotFoundError("Document", analysis_request.document_id)
    
    prompt = db.query(SystemPrompt).filter(SystemPrompt.id == analysis_request.prompt_id).first()
    if not prompt:
        raise NotFoundError("System Prompt", analysis_request.prompt_id)
    
    schema = db.query(OutputSchema).filter(OutputSchema.id == analysis_request.schema_id).first()
    if not schema:
        raise NotFoundError("Output Schema", analysis_request.schema_id)
    
    # Check if analysis already exists for this combination
    existing_analysis = db.query(AnalysisModel).filter(
        AnalysisModel.document_id == analysis_request.document_id,
        AnalysisModel.prompt_id == analysis_request.prompt_id,
        AnalysisModel.schema_id == analysis_request.schema_id
    ).first()
    
    if existing_analysis:
        return AnalysisResult(
            analysis_id=existing_analysis.id,
            status=existing_analysis.status,
            result=existing_analysis.analysis_result,
            error_message=existing_analysis.error_message,
            processing_time=existing_analysis.processing_time,
            confidence_score=existing_analysis.confidence_score
        )
    
    # Create analysis service
    analysis_service = AnalysisService(db)
    
    # Start analysis in background
    background_tasks.add_task(
        analysis_service.analyze_document,
        document_id=analysis_request.document_id,
        prompt_id=analysis_request.prompt_id,
        schema_id=analysis_request.schema_id,
        model_name=analysis_request.model_used,
        temperature=analysis_request.temperature,
        max_tokens=analysis_request.max_tokens,
        custom_prompt=analysis_request.custom_prompt
    )
    
    return AnalysisResult(
        analysis_id=0,  # Will be updated when analysis completes
        status="pending",
        result=None,
        error_message=None,
        processing_time=None,
        confidence_score=None
    )


@router.post("/bulk", response_model=List[AnalysisResult])
async def create_bulk_analysis(
    bulk_request: BulkAnalysisRequest,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    """
    Create bulk document analysis
    """
    # Validate prompt and schema exist
    prompt = db.query(SystemPrompt).filter(SystemPrompt.id == bulk_request.prompt_id).first()
    if not prompt:
        raise NotFoundError("System Prompt", bulk_request.prompt_id)
    
    schema = db.query(OutputSchema).filter(OutputSchema.id == bulk_request.schema_id).first()
    if not schema:
        raise NotFoundError("Output Schema", bulk_request.schema_id)
    
    # Validate all documents exist
    documents = db.query(Document).filter(Document.id.in_(bulk_request.document_ids)).all()
    if len(documents) != len(bulk_request.document_ids):
        found_ids = {doc.id for doc in documents}
        missing_ids = set(bulk_request.document_ids) - found_ids
        raise ValidationError(f"Documents not found: {list(missing_ids)}")
    
    # Create analysis service
    analysis_service = AnalysisService(db)
    
    # Start bulk analysis in background
    background_tasks.add_task(
        analysis_service.bulk_analyze_documents,
        document_ids=bulk_request.document_ids,
        prompt_id=bulk_request.prompt_id,
        schema_id=bulk_request.schema_id,
        model_name=bulk_request.model_used,
        temperature=bulk_request.temperature,
        max_tokens=bulk_request.max_tokens
    )
    
    # Return pending results
    results = []
    for doc_id in bulk_request.document_ids:
        results.append(AnalysisResult(
            analysis_id=0,
            status="pending",
            result=None,
            error_message=None,
            processing_time=None,
            confidence_score=None
        ))
    
    return results


@router.get("/", response_model=dict)
async def get_analyses(
    pagination: PaginationParams = Depends(get_pagination_params),
    document_id: Optional[int] = None,
    prompt_id: Optional[int] = None,
    schema_id: Optional[int] = None,
    status: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    """
    Get paginated list of analyses with filtering
    """
    query = db.query(AnalysisModel)
    
    # Apply filters
    if document_id:
        query = query.filter(AnalysisModel.document_id == document_id)
    
    if prompt_id:
        query = query.filter(AnalysisModel.prompt_id == prompt_id)
    
    if schema_id:
        query = query.filter(AnalysisModel.schema_id == schema_id)
    
    if status:
        query = query.filter(AnalysisModel.status == status)
    
    # Get total count
    total = query.count()
    
    # Apply pagination and ordering
    analyses = query.order_by(AnalysisModel.created_at.desc()).offset(
        pagination.offset
    ).limit(pagination.limit).all()
    
    # Convert to response models
    analysis_items = []
    for analysis in analyses:
        analysis_item = DocumentAnalysis(
            **analysis.__dict__
        )
        analysis_items.append(analysis_item)
    
    return {
        "total": total,
        "items": analysis_items,
        "limit": pagination.limit,
        "offset": pagination.offset,
        "has_next": pagination.offset + pagination.limit < total,
        "has_prev": pagination.offset > 0
    }


@router.get("/{analysis_id}", response_model=DocumentAnalysisDetail)
async def get_analysis_detail(
    analysis_id: int,
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    """
    Get detailed information about a specific analysis
    """
    analysis = db.query(AnalysisModel).filter(AnalysisModel.id == analysis_id).first()
    
    if not analysis:
        raise NotFoundError("Analysis", analysis_id)
    
    return DocumentAnalysisDetail(
        **analysis.__dict__,
        document={
            "id": analysis.document.id,
            "document_name": analysis.document.document_name,
            "company_name": analysis.document.company_name,
            "asset_code": analysis.document.asset_code,
            "document_type": analysis.document.document_type,
            "file_size": analysis.document.file_size,
            "download_date": analysis.document.download_date,
            "is_processed": analysis.document.is_processed
        },
        prompt={
            "id": analysis.prompt.id,
            "name": analysis.prompt.name,
            "description": analysis.prompt.description,
            "is_active": analysis.prompt.is_active,
            "category": analysis.prompt.category,
            "usage_count": analysis.prompt.usage_count,
            "created_at": analysis.prompt.created_at
        },
        schema={
            "id": analysis.schema.id,
            "name": analysis.schema.name,
            "description": analysis.schema.description,
            "is_active": analysis.schema.is_active,
            "category": analysis.schema.category,
            "usage_count": analysis.schema.usage_count,
            "field_count": analysis.schema.field_count,
            "created_at": analysis.schema.created_at
        }
    )


@router.delete("/{analysis_id}")
async def delete_analysis(
    analysis_id: int,
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    """
    Delete analysis
    """
    analysis = db.query(AnalysisModel).filter(AnalysisModel.id == analysis_id).first()
    
    if not analysis:
        raise NotFoundError("Analysis", analysis_id)
    
    db.delete(analysis)
    db.commit()
    
    return {"message": f"Analysis {analysis_id} deleted successfully"}


@router.post("/{analysis_id}/validate")
async def validate_analysis(
    analysis_id: int,
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    """
    Validate analysis result against schema
    """
    analysis_service = AnalysisService(db)
    
    try:
        result = analysis_service.validate_analysis_result(analysis_id)
        return result
    except ValueError as e:
        raise NotFoundError("Analysis", analysis_id)


@router.get("/stats/overview", response_model=AnalysisStats)
async def get_analysis_statistics(
    document_id: Optional[int] = None,
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    """
    Get analysis statistics overview
    """
    analysis_service = AnalysisService(db)
    stats = analysis_service.get_analysis_statistics(document_id)
    
    # Get additional stats
    query = db.query(AnalysisModel)
    if document_id:
        query = query.filter(AnalysisModel.document_id == document_id)
    
    analyses = query.all()
    
    # Group by status
    status_stats = {}
    for analysis in analyses:
        status = analysis.status
        if status not in status_stats:
            status_stats[status] = 0
        status_stats[status] += 1
    
    return AnalysisStats(
        total_analyses=stats["total_analyses"],
        completed_analyses=stats["completed_analyses"],
        pending_analyses=status_stats.get("pending", 0),
        failed_analyses=stats["failed_analyses"],
        average_processing_time=stats["average_processing_time"],
        total_cost=None,  # TODO: Implement cost tracking
        analyses_by_model=stats["analyses_by_model"],
        analyses_by_status=status_stats
    )


@router.get("/document/{document_id}/analyses", response_model=List[DocumentAnalysis])
async def get_document_analyses(
    document_id: int,
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    """
    Get all analyses for a specific document
    """
    # Verify document exists
    document = db.query(Document).filter(Document.id == document_id).first()
    if not document:
        raise NotFoundError("Document", document_id)
    
    analyses = db.query(AnalysisModel).filter(
        AnalysisModel.document_id == document_id
    ).order_by(AnalysisModel.created_at.desc()).all()
    
    return [DocumentAnalysis(**analysis.__dict__) for analysis in analyses]


@router.post("/{analysis_id}/rerun")
async def rerun_analysis(
    analysis_id: int,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    """
    Rerun an existing analysis
    """
    analysis = db.query(AnalysisModel).filter(AnalysisModel.id == analysis_id).first()
    
    if not analysis:
        raise NotFoundError("Analysis", analysis_id)
    
    # Reset analysis status
    analysis.status = "pending"
    analysis.analysis_result = None
    analysis.error_message = None
    analysis.processing_time = None
    
    db.commit()
    
    # Create analysis service and rerun
    analysis_service = AnalysisService(db)
    
    background_tasks.add_task(
        analysis_service.analyze_document,
        document_id=analysis.document_id,
        prompt_id=analysis.prompt_id,
        schema_id=analysis.schema_id,
        model_name=analysis.model_used,
        temperature=analysis.temperature,
        max_tokens=analysis.max_tokens,
        custom_prompt=analysis.custom_prompt
    )
    
    return {"message": f"Analysis {analysis_id} queued for rerun"}

