"""
Crawler Management Endpoints
"""

from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status, BackgroundTasks
from sqlalchemy.orm import Session
from datetime import date

from app.config.database import get_db
from app.api.deps import (
    get_current_user,
    get_pagination_params,
    get_crawler_filters,
    get_fiduciary_agent,
    PaginationParams,
    CrawlerFilters,
    PaginatedResponse
)
from app.schemas.crawler import (
    CrawlerStatus,
    CrawlerRun,
    CrawlerRunCreate,
    CrawlerRunDetail,
    CrawlerLog
)
from app.schemas.fiduciary_agent import FiduciaryAgent
from app.models.fiduciary_agent import FiduciaryAgent as FiduciaryAgentModel
from app.models.crawler import CrawlerRun as CrawlerRunModel
from app.services.crawler_service import CrawlerService
from app.core.exceptions import NotFoundError, ValidationError

router = APIRouter()


@router.get("/status", response_model=List[CrawlerStatus])
async def get_crawlers_status(
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    """
    Get status of all crawlers
    """
    # Get all fiduciary agents
    agents = db.query(FiduciaryAgentModel).filter(
        FiduciaryAgentModel.is_active == True
    ).all()
    
    crawler_statuses = []
    
    for agent in agents:
        # Get latest crawler run
        latest_run = db.query(CrawlerRunModel).filter(
            CrawlerRunModel.fiduciary_agent_id == agent.id
        ).order_by(CrawlerRunModel.start_time.desc()).first()
        
        # Get running crawler
        running_crawler = db.query(CrawlerRunModel).filter(
            CrawlerRunModel.fiduciary_agent_id == agent.id,
            CrawlerRunModel.status == "running"
        ).first()
        
        status = "idle"
        if running_crawler:
            status = "running"
        elif latest_run and latest_run.status == "failed":
            status = "failed"
        elif latest_run and latest_run.status == "completed":
            status = "completed"
        
        crawler_status = CrawlerStatus(
            fiduciary_agent_id=agent.id,
            agent_name=agent.short_name,
            status=status,
            last_run=latest_run.start_time if latest_run else None,
            next_scheduled_run=None,  # TODO: Implement scheduling
            documents_found_last_run=latest_run.documents_found if latest_run else 0,
            documents_downloaded_last_run=latest_run.documents_downloaded if latest_run else 0,
            errors_last_run=latest_run.errors_count if latest_run else 0
        )
        
        crawler_statuses.append(crawler_status)
    
    return crawler_statuses


@router.post("/{agent_id}/start", response_model=dict)
async def start_crawler(
    agent_id: int,
    crawler_config: CrawlerRunCreate,
    background_tasks: BackgroundTasks,
    agent: FiduciaryAgentModel = Depends(get_fiduciary_agent),
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    """
    Start crawler for specific fiduciary agent
    """
    # Check if crawler is already running
    running_crawler = db.query(CrawlerRunModel).filter(
        CrawlerRunModel.fiduciary_agent_id == agent_id,
        CrawlerRunModel.status == "running"
    ).first()
    
    if running_crawler:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Crawler for {agent.short_name} is already running"
        )
    
    # Create crawler service
    crawler_service = CrawlerService(db)
    
    # Start crawler in background
    background_tasks.add_task(
        crawler_service.execute_crawler,
        agent_id=agent_id,
        date_from=crawler_config.date_range.start_date if crawler_config.date_range else None,
        date_to=crawler_config.date_range.end_date if crawler_config.date_range else None,
        force_full_crawl=crawler_config.force_full_crawl
    )
    
    return {
        "message": f"Crawler for {agent.short_name} started successfully",
        "agent_id": agent_id,
        "estimated_duration": "15-30 minutes"
    }


@router.post("/{agent_id}/stop", response_model=dict)
async def stop_crawler(
    agent_id: int,
    agent: FiduciaryAgentModel = Depends(get_fiduciary_agent),
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    """
    Stop running crawler
    """
    # Find running crawler
    running_crawler = db.query(CrawlerRunModel).filter(
        CrawlerRunModel.fiduciary_agent_id == agent_id,
        CrawlerRunModel.status == "running"
    ).first()
    
    if not running_crawler:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"No running crawler found for {agent.short_name}"
        )
    
    # Update status to stopped
    running_crawler.status = "stopped"
    running_crawler.end_time = db.func.now()
    db.commit()
    
    return {
        "message": f"Crawler for {agent.short_name} stopped successfully",
        "run_id": running_crawler.id
    }


@router.get("/{agent_id}/runs", response_model=dict)
async def get_crawler_runs(
    agent_id: int,
    pagination: PaginationParams = Depends(get_pagination_params),
    filters: CrawlerFilters = Depends(get_crawler_filters),
    agent: FiduciaryAgentModel = Depends(get_fiduciary_agent),
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    """
    Get crawler run history for specific agent
    """
    query = db.query(CrawlerRunModel).filter(
        CrawlerRunModel.fiduciary_agent_id == agent_id
    )
    
    # Apply filters
    if filters.status:
        query = query.filter(CrawlerRunModel.status == filters.status)
    
    if filters.date_from:
        query = query.filter(CrawlerRunModel.start_time >= filters.date_from)
    
    if filters.date_to:
        query = query.filter(CrawlerRunModel.start_time <= filters.date_to)
    
    # Get total count
    total = query.count()
    
    # Apply pagination and ordering
    runs = query.order_by(CrawlerRunModel.start_time.desc()).offset(
        pagination.offset
    ).limit(pagination.limit).all()
    
    # Convert to response models
    run_items = []
    for run in runs:
        run_item = CrawlerRun(
            id=run.id,
            status=run.status,
            start_time=run.start_time,
            end_time=run.end_time,
            documents_found=run.documents_found,
            documents_downloaded=run.documents_downloaded,
            errors_count=run.errors_count,
            error_details=run.error_details
        )
        run_items.append(run_item)
    
    return {
        "total": total,
        "items": run_items,
        "limit": pagination.limit,
        "offset": pagination.offset,
        "has_next": pagination.offset + pagination.limit < total,
        "has_prev": pagination.offset > 0
    }


@router.get("/{agent_id}/runs/{run_id}", response_model=CrawlerRunDetail)
async def get_crawler_run_detail(
    agent_id: int,
    run_id: int,
    agent: FiduciaryAgentModel = Depends(get_fiduciary_agent),
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    """
    Get detailed information about a specific crawler run
    """
    run = db.query(CrawlerRunModel).filter(
        CrawlerRunModel.id == run_id,
        CrawlerRunModel.fiduciary_agent_id == agent_id
    ).first()
    
    if not run:
        raise NotFoundError("Crawler Run", run_id)
    
    return CrawlerRunDetail(
        id=run.id,
        fiduciary_agent_id=run.fiduciary_agent_id,
        agent_name=agent.short_name,
        status=run.status,
        start_time=run.start_time,
        end_time=run.end_time,
        documents_found=run.documents_found,
        documents_downloaded=run.documents_downloaded,
        errors_count=run.errors_count,
        error_details=run.error_details,
        created_at=run.created_at
    )


@router.get("/{agent_id}/runs/{run_id}/logs", response_model=dict)
async def get_crawler_run_logs(
    agent_id: int,
    run_id: int,
    agent: FiduciaryAgentModel = Depends(get_fiduciary_agent),
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    """
    Get detailed logs for specific crawler run
    """
    run = db.query(CrawlerRunModel).filter(
        CrawlerRunModel.id == run_id,
        CrawlerRunModel.fiduciary_agent_id == agent_id
    ).first()
    
    if not run:
        raise NotFoundError("Crawler Run", run_id)
    
    # TODO: Implement actual log retrieval from log files
    # For now, return basic information
    logs = [
        CrawlerLog(
            timestamp=run.start_time,
            level="INFO",
            message=f"Starting crawler for {agent.short_name}",
            details={}
        )
    ]
    
    if run.end_time:
        logs.append(
            CrawlerLog(
                timestamp=run.end_time,
                level="INFO" if run.status == "completed" else "ERROR",
                message=f"Crawler finished with status: {run.status}",
                details={
                    "documents_found": run.documents_found,
                    "documents_downloaded": run.documents_downloaded,
                    "errors_count": run.errors_count
                }
            )
        )
    
    if run.error_details:
        logs.append(
            CrawlerLog(
                timestamp=run.end_time or run.start_time,
                level="ERROR",
                message="Crawler errors occurred",
                details={"error_details": run.error_details}
            )
        )
    
    return {
        "run_id": run_id,
        "logs": logs
    }


@router.get("/agents", response_model=List[FiduciaryAgent])
async def get_fiduciary_agents(
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    """
    Get list of all fiduciary agents
    """
    agents = db.query(FiduciaryAgentModel).filter(
        FiduciaryAgentModel.is_active == True
    ).all()
    
    agent_list = []
    for agent in agents:
        # Get document count
        document_count = db.query(db.func.count(db.text("documents.id"))).filter(
            db.text("documents.fiduciary_agent_id") == agent.id
        ).scalar() or 0
        
        # Get last crawl time
        last_run = db.query(CrawlerRunModel).filter(
            CrawlerRunModel.fiduciary_agent_id == agent.id
        ).order_by(CrawlerRunModel.start_time.desc()).first()
        
        agent_item = FiduciaryAgent(
            id=agent.id,
            name=agent.name,
            short_name=agent.short_name,
            website_url=agent.website_url,
            crawler_class=agent.crawler_class,
            is_active=agent.is_active,
            document_count=document_count,
            last_crawl=last_run.start_time if last_run else None,
            created_at=agent.created_at,
            updated_at=agent.updated_at
        )
        agent_list.append(agent_item)
    
    return agent_list


@router.get("/agents/{agent_id}", response_model=FiduciaryAgent)
async def get_fiduciary_agent_detail(
    agent_id: int,
    agent: FiduciaryAgentModel = Depends(get_fiduciary_agent),
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    """
    Get specific fiduciary agent details
    """
    # Get document count
    document_count = db.query(db.func.count(db.text("documents.id"))).filter(
        db.text("documents.fiduciary_agent_id") == agent.id
    ).scalar() or 0
    
    # Get last crawl time
    last_run = db.query(CrawlerRunModel).filter(
        CrawlerRunModel.fiduciary_agent_id == agent.id
    ).order_by(CrawlerRunModel.start_time.desc()).first()
    
    return FiduciaryAgent(
        id=agent.id,
        name=agent.name,
        short_name=agent.short_name,
        website_url=agent.website_url,
        crawler_class=agent.crawler_class,
        is_active=agent.is_active,
        document_count=document_count,
        last_crawl=last_run.start_time if last_run else None,
        created_at=agent.created_at,
        updated_at=agent.updated_at
    )

