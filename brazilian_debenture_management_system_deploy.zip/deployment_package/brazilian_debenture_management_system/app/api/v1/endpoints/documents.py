"""
Document Management Endpoints
"""

from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_

from app.config.database import get_db
from app.api.deps import (
    get_current_user,
    get_pagination_params,
    PaginationParams
)
from app.schemas.document import (
    Document,
    DocumentWithAgent,
    DocumentWithAnalyses,
    DocumentSummary,
    DocumentFilter,
    DocumentStats
)
from app.models.document import Document as DocumentModel
from app.models.fiduciary_agent import FiduciaryAgent
from app.models.analysis import DocumentAnalysis
from app.core.exceptions import NotFoundError

router = APIRouter()


@router.get("/", response_model=dict)
async def get_documents(
    pagination: PaginationParams = Depends(get_pagination_params),
    fiduciary_agent_id: Optional[int] = Query(None),
    company_name: Optional[str] = Query(None),
    asset_code: Optional[str] = Query(None),
    document_type: Optional[str] = Query(None),
    search: Optional[str] = Query(None),
    is_processed: Optional[bool] = Query(None),
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    """
    Get paginated list of documents with filtering
    """
    query = db.query(DocumentModel).join(FiduciaryAgent)
    
    # Apply filters
    if fiduciary_agent_id:
        query = query.filter(DocumentModel.fiduciary_agent_id == fiduciary_agent_id)
    
    if company_name:
        query = query.filter(DocumentModel.company_name.ilike(f"%{company_name}%"))
    
    if asset_code:
        query = query.filter(DocumentModel.asset_code.ilike(f"%{asset_code}%"))
    
    if document_type:
        query = query.filter(DocumentModel.document_type.ilike(f"%{document_type}%"))
    
    if is_processed is not None:
        query = query.filter(DocumentModel.is_processed == is_processed)
    
    if search:
        search_filter = or_(
            DocumentModel.document_name.ilike(f"%{search}%"),
            DocumentModel.company_name.ilike(f"%{search}%"),
            DocumentModel.asset_code.ilike(f"%{search}%"),
            DocumentModel.document_type.ilike(f"%{search}%")
        )
        query = query.filter(search_filter)
    
    # Get total count
    total = query.count()
    
    # Apply pagination and ordering
    documents = query.order_by(DocumentModel.download_date.desc()).offset(
        pagination.offset
    ).limit(pagination.limit).all()
    
    # Convert to response models
    document_items = []
    for doc in documents:
        # Get analysis count
        analysis_count = db.query(DocumentAnalysis).filter(
            DocumentAnalysis.document_id == doc.id
        ).count()
        
        doc_item = DocumentWithAgent(
            **doc.__dict__,
            fiduciary_agent={
                "id": doc.fiduciary_agent.id,
                "name": doc.fiduciary_agent.name,
                "short_name": doc.fiduciary_agent.short_name,
                "is_active": doc.fiduciary_agent.is_active,
                "document_count": 0,  # Not needed here
                "last_crawl": None,   # Not needed here
            },
            analysis_count=analysis_count
        )
        document_items.append(doc_item)
    
    return {
        "total": total,
        "items": document_items,
        "limit": pagination.limit,
        "offset": pagination.offset,
        "has_next": pagination.offset + pagination.limit < total,
        "has_prev": pagination.offset > 0
    }


@router.get("/{document_id}", response_model=DocumentWithAnalyses)
async def get_document_detail(
    document_id: int,
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    """
    Get detailed information about a specific document
    """
    document = db.query(DocumentModel).filter(DocumentModel.id == document_id).first()
    
    if not document:
        raise NotFoundError("Document", document_id)
    
    # Get analyses
    analyses = db.query(DocumentAnalysis).filter(
        DocumentAnalysis.document_id == document_id
    ).order_by(DocumentAnalysis.created_at.desc()).all()
    
    analysis_summaries = []
    for analysis in analyses:
        analysis_summaries.append({
            "id": analysis.id,
            "status": analysis.status,
            "model_used": analysis.model_used,
            "processing_time": analysis.processing_time,
            "created_at": analysis.created_at
        })
    
    return DocumentWithAnalyses(
        **document.__dict__,
        fiduciary_agent={
            "id": document.fiduciary_agent.id,
            "name": document.fiduciary_agent.name,
            "short_name": document.fiduciary_agent.short_name,
            "is_active": document.fiduciary_agent.is_active,
            "document_count": 0,
            "last_crawl": None,
        },
        analysis_count=len(analyses),
        analyses=analysis_summaries
    )


@router.get("/{document_id}/download")
async def download_document(
    document_id: int,
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    """
    Download document file
    """
    from fastapi.responses import FileResponse
    import os
    
    document = db.query(DocumentModel).filter(DocumentModel.id == document_id).first()
    
    if not document:
        raise NotFoundError("Document", document_id)
    
    if not os.path.exists(document.file_path):
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Document file not found on disk"
        )
    
    return FileResponse(
        path=document.file_path,
        filename=document.document_name,
        media_type='application/pdf'
    )


@router.delete("/{document_id}")
async def delete_document(
    document_id: int,
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    """
    Delete document and its file
    """
    import os
    
    document = db.query(DocumentModel).filter(DocumentModel.id == document_id).first()
    
    if not document:
        raise NotFoundError("Document", document_id)
    
    # Delete file if exists
    if os.path.exists(document.file_path):
        try:
            os.remove(document.file_path)
        except Exception as e:
            logger.warning(f"Failed to delete file {document.file_path}: {str(e)}")
    
    # Delete database record
    db.delete(document)
    db.commit()
    
    return {"message": f"Document {document.document_name} deleted successfully"}


@router.get("/stats/overview", response_model=DocumentStats)
async def get_document_statistics(
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    """
    Get document statistics overview
    """
    # Total documents
    total_documents = db.query(DocumentModel).count()
    
    # Processed vs unprocessed
    processed_documents = db.query(DocumentModel).filter(
        DocumentModel.is_processed == True
    ).count()
    unprocessed_documents = total_documents - processed_documents
    
    # Total size
    total_size_bytes = db.query(db.func.sum(DocumentModel.file_size)).scalar() or 0
    total_size_mb = round(total_size_bytes / (1024 * 1024), 2)
    
    # Documents by type
    type_stats = db.query(
        DocumentModel.document_type,
        db.func.count(DocumentModel.id)
    ).group_by(DocumentModel.document_type).all()
    
    documents_by_type = {doc_type: count for doc_type, count in type_stats}
    
    # Documents by agent
    agent_stats = db.query(
        FiduciaryAgent.short_name,
        db.func.count(DocumentModel.id)
    ).join(DocumentModel).group_by(FiduciaryAgent.short_name).all()
    
    documents_by_agent = {agent_name: count for agent_name, count in agent_stats}
    
    # Recent downloads
    recent_docs = db.query(DocumentModel).order_by(
        DocumentModel.download_date.desc()
    ).limit(10).all()
    
    recent_downloads = []
    for doc in recent_docs:
        recent_downloads.append(DocumentSummary(
            id=doc.id,
            document_name=doc.document_name,
            company_name=doc.company_name,
            asset_code=doc.asset_code,
            document_type=doc.document_type,
            file_size=doc.file_size,
            download_date=doc.download_date,
            is_processed=doc.is_processed
        ))
    
    return DocumentStats(
        total_documents=total_documents,
        processed_documents=processed_documents,
        unprocessed_documents=unprocessed_documents,
        total_size_mb=total_size_mb,
        documents_by_type=documents_by_type,
        documents_by_agent=documents_by_agent,
        recent_downloads=recent_downloads
    )


@router.get("/types/list")
async def get_document_types(
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    """
    Get list of all document types
    """
    types = db.query(DocumentModel.document_type).distinct().all()
    return {"document_types": [doc_type[0] for doc_type in types if doc_type[0]]}


@router.get("/companies/list")
async def get_companies(
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    """
    Get list of all companies
    """
    companies = db.query(DocumentModel.company_name).distinct().all()
    return {"companies": [company[0] for company in companies if company[0]]}


@router.get("/assets/list")
async def get_asset_codes(
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    """
    Get list of all asset codes
    """
    assets = db.query(DocumentModel.asset_code).distinct().all()
    return {"asset_codes": [asset[0] for asset in assets if asset[0]]}


@router.post("/{document_id}/mark-processed")
async def mark_document_processed(
    document_id: int,
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    """
    Mark document as processed
    """
    document = db.query(DocumentModel).filter(DocumentModel.id == document_id).first()
    
    if not document:
        raise NotFoundError("Document", document_id)
    
    document.is_processed = True
    db.commit()
    
    return {"message": f"Document {document.document_name} marked as processed"}


@router.post("/{document_id}/mark-unprocessed")
async def mark_document_unprocessed(
    document_id: int,
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    """
    Mark document as unprocessed
    """
    document = db.query(DocumentModel).filter(DocumentModel.id == document_id).first()
    
    if not document:
        raise NotFoundError("Document", document_id)
    
    document.is_processed = False
    db.commit()
    
    return {"message": f"Document {document.document_name} marked as unprocessed"}

