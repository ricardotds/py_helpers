"""
Output Schemas Management Endpoints
"""

from typing import List, Optional, Dict, Any
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session

from app.config.database import get_db
from app.api.deps import (
    get_current_user,
    get_pagination_params,
    PaginationParams
)
from app.schemas.schema import (
    OutputSchema,
    OutputSchemaCreate,
    OutputSchemaUpdate,
    OutputSchemaSummary,
    OutputSchemaWithUsage,
    SchemaValidationResult,
    SchemaFieldInfo
)
from app.models.schema import OutputSchema as SchemaModel
from app.models.analysis import DocumentAnalysis
from app.core.exceptions import NotFoundError, ValidationError

router = APIRouter()


@router.post("/", response_model=OutputSchema)
async def create_schema(
    schema_data: OutputSchemaCreate,
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    """
    Create new output schema
    """
    # Check if schema with same name already exists
    existing_schema = db.query(SchemaModel).filter(
        SchemaModel.name == schema_data.name
    ).first()
    
    if existing_schema:
        raise ValidationError(f"Schema with name '{schema_data.name}' already exists")
    
    # Create new schema
    schema = SchemaModel(
        name=schema_data.name,
        description=schema_data.description,
        schema_definition=schema_data.schema_definition,
        is_active=schema_data.is_active,
        category=schema_data.category,
        tags=schema_data.tags,
        strict_validation=schema_data.strict_validation,
        allow_additional_properties=schema_data.allow_additional_properties,
        created_by=schema_data.created_by or current_user,
        version=schema_data.version,
        parent_schema_id=schema_data.parent_schema_id
    )
    
    db.add(schema)
    db.commit()
    db.refresh(schema)
    
    return OutputSchema(**schema.__dict__)


@router.get("/", response_model=dict)
async def get_schemas(
    pagination: PaginationParams = Depends(get_pagination_params),
    category: Optional[str] = Query(None),
    is_active: Optional[bool] = Query(None),
    search: Optional[str] = Query(None),
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    """
    Get paginated list of output schemas with filtering
    """
    query = db.query(SchemaModel)
    
    # Apply filters
    if category:
        query = query.filter(SchemaModel.category == category)
    
    if is_active is not None:
        query = query.filter(SchemaModel.is_active == is_active)
    
    if search:
        query = query.filter(
            SchemaModel.name.ilike(f"%{search}%") |
            SchemaModel.description.ilike(f"%{search}%")
        )
    
    # Get total count
    total = query.count()
    
    # Apply pagination and ordering
    schemas = query.order_by(SchemaModel.created_at.desc()).offset(
        pagination.offset
    ).limit(pagination.limit).all()
    
    # Convert to response models
    schema_items = []
    for schema in schemas:
        schema_item = OutputSchema(**schema.__dict__)
        schema_items.append(schema_item)
    
    return {
        "total": total,
        "items": schema_items,
        "limit": pagination.limit,
        "offset": pagination.offset,
        "has_next": pagination.offset + pagination.limit < total,
        "has_prev": pagination.offset > 0
    }


@router.get("/{schema_id}", response_model=OutputSchemaWithUsage)
async def get_schema_detail(
    schema_id: int,
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    """
    Get detailed information about a specific schema
    """
    schema = db.query(SchemaModel).filter(SchemaModel.id == schema_id).first()
    
    if not schema:
        raise NotFoundError("Output Schema", schema_id)
    
    # Get usage statistics
    recent_analyses = db.query(DocumentAnalysis).filter(
        DocumentAnalysis.schema_id == schema_id
    ).order_by(DocumentAnalysis.created_at.desc()).limit(30).all()
    
    recent_analyses_count = len(recent_analyses)
    
    # Calculate average processing time
    processing_times = [a.processing_time for a in recent_analyses if a.processing_time]
    average_processing_time = sum(processing_times) / len(processing_times) if processing_times else None
    
    # Calculate validation success rate
    validation_successes = [a for a in recent_analyses if a.validation_passed == "true"]
    validation_success_rate = (len(validation_successes) / len(recent_analyses) * 100) if recent_analyses else None
    
    return OutputSchemaWithUsage(
        **schema.__dict__,
        recent_analyses_count=recent_analyses_count,
        average_processing_time=average_processing_time,
        validation_success_rate=validation_success_rate
    )


@router.put("/{schema_id}", response_model=OutputSchema)
async def update_schema(
    schema_id: int,
    schema_data: OutputSchemaUpdate,
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    """
    Update output schema
    """
    schema = db.query(SchemaModel).filter(SchemaModel.id == schema_id).first()
    
    if not schema:
        raise NotFoundError("Output Schema", schema_id)
    
    # Check if name is being changed and if it conflicts
    if schema_data.name and schema_data.name != schema.name:
        existing_schema = db.query(SchemaModel).filter(
            SchemaModel.name == schema_data.name,
            SchemaModel.id != schema_id
        ).first()
        
        if existing_schema:
            raise ValidationError(f"Schema with name '{schema_data.name}' already exists")
    
    # Update fields
    update_data = schema_data.dict(exclude_unset=True)
    for field, value in update_data.items():
        setattr(schema, field, value)
    
    db.commit()
    db.refresh(schema)
    
    return OutputSchema(**schema.__dict__)


@router.delete("/{schema_id}")
async def delete_schema(
    schema_id: int,
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    """
    Delete output schema
    """
    schema = db.query(SchemaModel).filter(SchemaModel.id == schema_id).first()
    
    if not schema:
        raise NotFoundError("Output Schema", schema_id)
    
    # Check if schema is being used in analyses
    analyses_count = db.query(DocumentAnalysis).filter(
        DocumentAnalysis.schema_id == schema_id
    ).count()
    
    if analyses_count > 0:
        raise ValidationError(
            f"Cannot delete schema '{schema.name}' because it is used in {analyses_count} analyses"
        )
    
    db.delete(schema)
    db.commit()
    
    return {"message": f"Schema '{schema.name}' deleted successfully"}


@router.post("/{schema_id}/duplicate", response_model=OutputSchema)
async def duplicate_schema(
    schema_id: int,
    new_name: str,
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    """
    Duplicate an existing schema
    """
    original_schema = db.query(SchemaModel).filter(SchemaModel.id == schema_id).first()
    
    if not original_schema:
        raise NotFoundError("Output Schema", schema_id)
    
    # Check if new name already exists
    existing_schema = db.query(SchemaModel).filter(
        SchemaModel.name == new_name
    ).first()
    
    if existing_schema:
        raise ValidationError(f"Schema with name '{new_name}' already exists")
    
    # Create duplicate
    new_schema = SchemaModel(
        name=new_name,
        description=f"Copy of {original_schema.name}",
        schema_definition=original_schema.schema_definition,
        is_active=original_schema.is_active,
        category=original_schema.category,
        tags=original_schema.tags,
        strict_validation=original_schema.strict_validation,
        allow_additional_properties=original_schema.allow_additional_properties,
        created_by=current_user,
        version="1.0",
        parent_schema_id=original_schema.id
    )
    
    db.add(new_schema)
    db.commit()
    db.refresh(new_schema)
    
    return OutputSchema(**new_schema.__dict__)


@router.post("/{schema_id}/validate", response_model=SchemaValidationResult)
async def validate_data_against_schema(
    schema_id: int,
    data: Dict[str, Any],
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    """
    Validate data against schema
    """
    schema = db.query(SchemaModel).filter(SchemaModel.id == schema_id).first()
    
    if not schema:
        raise NotFoundError("Output Schema", schema_id)
    
    is_valid, errors = schema.validate_data(data)
    
    return SchemaValidationResult(
        is_valid=is_valid,
        errors=errors
    )


@router.get("/{schema_id}/fields", response_model=List[SchemaFieldInfo])
async def get_schema_fields(
    schema_id: int,
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    """
    Get detailed information about schema fields
    """
    schema = db.query(SchemaModel).filter(SchemaModel.id == schema_id).first()
    
    if not schema:
        raise NotFoundError("Output Schema", schema_id)
    
    fields = []
    properties = schema.properties
    required_fields = schema.required_fields
    
    for field_name, field_def in properties.items():
        field_info = SchemaFieldInfo(
            name=field_name,
            type=field_def.get('type', 'string'),
            description=field_def.get('description'),
            required=field_name in required_fields,
            enum_values=field_def.get('enum'),
            format=field_def.get('format'),
            example=field_def.get('example')
        )
        fields.append(field_info)
    
    return fields


@router.get("/{schema_id}/example", response_model=Dict[str, Any])
async def get_schema_example(
    schema_id: int,
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    """
    Get example data for schema
    """
    schema = db.query(SchemaModel).filter(SchemaModel.id == schema_id).first()
    
    if not schema:
        raise NotFoundError("Output Schema", schema_id)
    
    example_data = schema.get_example_data()
    
    return {
        "schema_id": schema_id,
        "schema_name": schema.name,
        "example_data": example_data
    }


@router.get("/categories/list")
async def get_schema_categories(
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    """
    Get list of all schema categories
    """
    categories = db.query(SchemaModel.category).distinct().all()
    return {"categories": [cat[0] for cat in categories if cat[0]]}


@router.get("/tags/list")
async def get_schema_tags(
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    """
    Get list of all schema tags
    """
    schemas = db.query(SchemaModel).filter(SchemaModel.tags.isnot(None)).all()
    
    all_tags = set()
    for schema in schemas:
        tags = schema.tag_list
        all_tags.update(tags)
    
    return {"tags": sorted(list(all_tags))}


@router.get("/{schema_id}/versions", response_model=List[OutputSchemaSummary])
async def get_schema_versions(
    schema_id: int,
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    """
    Get all versions of a schema
    """
    # Get the main schema
    main_schema = db.query(SchemaModel).filter(SchemaModel.id == schema_id).first()
    
    if not main_schema:
        raise NotFoundError("Output Schema", schema_id)
    
    # Get all versions (children of this schema)
    versions = db.query(SchemaModel).filter(
        SchemaModel.parent_schema_id == schema_id
    ).order_by(SchemaModel.created_at.desc()).all()
    
    # Include the main schema in the list
    all_versions = [main_schema] + versions
    
    return [OutputSchemaSummary(**schema.__dict__) for schema in all_versions]


@router.post("/templates/debenture", response_model=OutputSchema)
async def create_debenture_template(
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    """
    Create a template schema for debenture documents
    """
    template_name = "Debenture Analysis Template"
    
    # Check if template already exists
    existing_template = db.query(SchemaModel).filter(
        SchemaModel.name == template_name
    ).first()
    
    if existing_template:
        return OutputSchema(**existing_template.__dict__)
    
    # Create debenture template schema
    debenture_schema = {
        "type": "object",
        "properties": {
            "company_name": {
                "type": "string",
                "description": "Name of the issuing company"
            },
            "asset_code": {
                "type": "string",
                "description": "Asset code (e.g., ADAG11)"
            },
            "emission_number": {
                "type": "string",
                "description": "Emission number"
            },
            "series": {
                "type": "string",
                "description": "Series information"
            },
            "total_value": {
                "type": "number",
                "description": "Total emission value in BRL"
            },
            "unit_value": {
                "type": "number",
                "description": "Unit value of each debenture"
            },
            "maturity_date": {
                "type": "string",
                "format": "date",
                "description": "Maturity date of the debenture"
            },
            "interest_rate": {
                "type": "number",
                "description": "Interest rate percentage"
            },
            "indexer": {
                "type": "string",
                "description": "Indexer (e.g., CDI, IPCA)",
                "enum": ["CDI", "IPCA", "SELIC", "PRE", "IGP-M"]
            },
            "guarantee_type": {
                "type": "string",
                "description": "Type of guarantee"
            },
            "rating": {
                "type": "string",
                "description": "Credit rating"
            },
            "purpose": {
                "type": "string",
                "description": "Purpose of the emission"
            }
        },
        "required": ["company_name", "asset_code", "total_value", "maturity_date"]
    }
    
    template = SchemaModel(
        name=template_name,
        description="Template for analyzing debenture emission documents",
        schema_definition=debenture_schema,
        is_active=True,
        category="debenture",
        tags="template, debenture, emission",
        created_by=current_user,
        version="1.0"
    )
    
    db.add(template)
    db.commit()
    db.refresh(template)
    
    return OutputSchema(**template.__dict__)

