"""
Health check endpoints for monitoring and load balancer health checks.
"""

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import text
import os
from datetime import datetime

from app.api.deps import get_db
from app.config.settings import get_settings

router = APIRouter()

settings = get_settings()


@router.get("/health")
async def health_check():
    """
    Basic health check endpoint.
    Returns 200 OK if the service is running.
    """
    return {
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat(),
        "service": "Brazilian Debenture Management System",
        "version": "1.0.0"
    }


@router.get("/health/detailed")
async def detailed_health_check(db: Session = Depends(get_db)):
    """
    Detailed health check that verifies all system components.
    """
    health_status = {
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat(),
        "service": "Brazilian Debenture Management System",
        "version": "1.0.0",
        "components": {}
    }
    
    overall_healthy = True
    
    # Check database connection
    try:
        db.execute(text("SELECT 1"))
        health_status["components"]["database"] = {
            "status": "healthy",
            "message": "Database connection successful"
        }
    except Exception as e:
        health_status["components"]["database"] = {
            "status": "unhealthy",
            "message": f"Database connection failed: {str(e)}"
        }
        overall_healthy = False
    
    # Check Redis connection (if configured)
    health_status["components"]["redis"] = {
        "status": "not_configured",
        "message": "Redis not configured (optional component)"
    }
    
    # Check storage directory
    try:
        storage_path = getattr(settings, 'STORAGE_PATH', '/app/storage')
        if os.path.exists(storage_path) and os.access(storage_path, os.W_OK):
            health_status["components"]["storage"] = {
                "status": "healthy",
                "message": "Storage directory accessible"
            }
        else:
            health_status["components"]["storage"] = {
                "status": "unhealthy",
                "message": "Storage directory not accessible"
            }
            overall_healthy = False
    except Exception as e:
        health_status["components"]["storage"] = {
            "status": "unhealthy",
            "message": f"Storage check failed: {str(e)}"
        }
        overall_healthy = False
    
    # Check OpenAI API key
    try:
        if os.getenv('OPENAI_API_KEY'):
            health_status["components"]["openai"] = {
                "status": "configured",
                "message": "OpenAI API key configured"
            }
        else:
            health_status["components"]["openai"] = {
                "status": "not_configured",
                "message": "OpenAI API key not configured"
            }
    except Exception as e:
        health_status["components"]["openai"] = {
            "status": "error",
            "message": f"OpenAI check failed: {str(e)}"
        }
    
    # Set overall status
    if not overall_healthy:
        health_status["status"] = "unhealthy"
        raise HTTPException(status_code=503, detail=health_status)
    
    return health_status


@router.get("/health/ready")
async def readiness_check(db: Session = Depends(get_db)):
    """
    Readiness check for Kubernetes/container orchestration.
    Returns 200 when the service is ready to accept traffic.
    """
    try:
        # Check if database is ready
        db.execute(text("SELECT 1"))
        
        # Check if required tables exist
        result = db.execute(text("""
            SELECT COUNT(*) FROM information_schema.tables 
            WHERE table_schema = 'public' 
            AND table_name IN ('fiduciary_agents', 'documents', 'crawler_runs')
        """))
        table_count = result.scalar()
        
        if table_count < 3:
            raise HTTPException(
                status_code=503, 
                detail="Database not fully initialized"
            )
        
        return {
            "status": "ready",
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=503,
            detail=f"Service not ready: {str(e)}"
        )


@router.get("/health/live")
async def liveness_check():
    """
    Liveness check for Kubernetes/container orchestration.
    Returns 200 if the service is alive (basic functionality).
    """
    return {
        "status": "alive",
        "timestamp": datetime.utcnow().isoformat()
    }

