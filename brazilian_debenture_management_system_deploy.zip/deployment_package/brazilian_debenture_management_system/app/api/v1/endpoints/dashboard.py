"""
Dashboard Overview Endpoints
"""

from typing import Dict, Any, List
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import func, desc
from datetime import datetime, timedelta

from app.config.database import get_db
from app.api.deps import get_current_user
from app.models.document import Document
from app.models.crawler import CrawlerRun
from app.models.analysis import DocumentAnalysis
from app.models.fiduciary_agent import FiduciaryAgent
from app.models.prompt import SystemPrompt
from app.models.schema import OutputSchema

router = APIRouter()


@router.get("/overview")
async def get_dashboard_overview(
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
) -> Dict[str, Any]:
    """
    Get dashboard overview statistics
    """
    # Total counts
    total_documents = db.query(Document).count()
    total_agents = db.query(FiduciaryAgent).filter(FiduciaryAgent.is_active == True).count()
    total_analyses = db.query(DocumentAnalysis).count()
    total_prompts = db.query(SystemPrompt).filter(SystemPrompt.is_active == True).count()
    total_schemas = db.query(OutputSchema).filter(OutputSchema.is_active == True).count()
    
    # Document processing stats
    processed_documents = db.query(Document).filter(Document.is_processed == True).count()
    unprocessed_documents = total_documents - processed_documents
    processing_rate = (processed_documents / total_documents * 100) if total_documents > 0 else 0
    
    # Recent activity (last 7 days)
    week_ago = datetime.now() - timedelta(days=7)
    
    recent_documents = db.query(Document).filter(
        Document.download_date >= week_ago
    ).count()
    
    recent_analyses = db.query(DocumentAnalysis).filter(
        DocumentAnalysis.created_at >= week_ago
    ).count()
    
    recent_crawler_runs = db.query(CrawlerRun).filter(
        CrawlerRun.start_time >= week_ago
    ).count()
    
    # Crawler status summary
    running_crawlers = db.query(CrawlerRun).filter(
        CrawlerRun.status == "running"
    ).count()
    
    # Analysis status summary
    pending_analyses = db.query(DocumentAnalysis).filter(
        DocumentAnalysis.status == "pending"
    ).count()
    
    completed_analyses = db.query(DocumentAnalysis).filter(
        DocumentAnalysis.status == "completed"
    ).count()
    
    failed_analyses = db.query(DocumentAnalysis).filter(
        DocumentAnalysis.status == "failed"
    ).count()
    
    # Storage statistics
    total_size_bytes = db.query(func.sum(Document.file_size)).scalar() or 0
    total_size_mb = round(total_size_bytes / (1024 * 1024), 2)
    
    return {
        "totals": {
            "documents": total_documents,
            "agents": total_agents,
            "analyses": total_analyses,
            "prompts": total_prompts,
            "schemas": total_schemas
        },
        "processing": {
            "processed_documents": processed_documents,
            "unprocessed_documents": unprocessed_documents,
            "processing_rate": round(processing_rate, 1)
        },
        "recent_activity": {
            "documents_downloaded": recent_documents,
            "analyses_created": recent_analyses,
            "crawler_runs": recent_crawler_runs
        },
        "status": {
            "running_crawlers": running_crawlers,
            "pending_analyses": pending_analyses,
            "completed_analyses": completed_analyses,
            "failed_analyses": failed_analyses
        },
        "storage": {
            "total_size_mb": total_size_mb,
            "average_file_size_mb": round(total_size_mb / total_documents, 2) if total_documents > 0 else 0
        }
    }


@router.get("/activity-chart")
async def get_activity_chart_data(
    days: int = 30,
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
) -> Dict[str, Any]:
    """
    Get activity chart data for the last N days
    """
    start_date = datetime.now() - timedelta(days=days)
    
    # Documents downloaded per day
    document_activity = db.query(
        func.date(Document.download_date).label('date'),
        func.count(Document.id).label('count')
    ).filter(
        Document.download_date >= start_date
    ).group_by(
        func.date(Document.download_date)
    ).order_by('date').all()
    
    # Analyses created per day
    analysis_activity = db.query(
        func.date(DocumentAnalysis.created_at).label('date'),
        func.count(DocumentAnalysis.id).label('count')
    ).filter(
        DocumentAnalysis.created_at >= start_date
    ).group_by(
        func.date(DocumentAnalysis.created_at)
    ).order_by('date').all()
    
    # Crawler runs per day
    crawler_activity = db.query(
        func.date(CrawlerRun.start_time).label('date'),
        func.count(CrawlerRun.id).label('count')
    ).filter(
        CrawlerRun.start_time >= start_date
    ).group_by(
        func.date(CrawlerRun.start_time)
    ).order_by('date').all()
    
    return {
        "documents": [{"date": str(item.date), "count": item.count} for item in document_activity],
        "analyses": [{"date": str(item.date), "count": item.count} for item in analysis_activity],
        "crawler_runs": [{"date": str(item.date), "count": item.count} for item in crawler_activity]
    }


@router.get("/agents-summary")
async def get_agents_summary(
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
) -> List[Dict[str, Any]]:
    """
    Get summary of all fiduciary agents
    """
    agents = db.query(FiduciaryAgent).filter(FiduciaryAgent.is_active == True).all()
    
    agent_summaries = []
    for agent in agents:
        # Document count
        document_count = db.query(Document).filter(
            Document.fiduciary_agent_id == agent.id
        ).count()
        
        # Last crawler run
        last_run = db.query(CrawlerRun).filter(
            CrawlerRun.fiduciary_agent_id == agent.id
        ).order_by(desc(CrawlerRun.start_time)).first()
        
        # Running crawler
        running_crawler = db.query(CrawlerRun).filter(
            CrawlerRun.fiduciary_agent_id == agent.id,
            CrawlerRun.status == "running"
        ).first()
        
        status = "idle"
        if running_crawler:
            status = "running"
        elif last_run:
            status = last_run.status
        
        agent_summaries.append({
            "id": agent.id,
            "name": agent.short_name,
            "status": status,
            "document_count": document_count,
            "last_run": last_run.start_time if last_run else None,
            "last_run_documents": last_run.documents_downloaded if last_run else 0,
            "last_run_errors": last_run.errors_count if last_run else 0
        })
    
    return agent_summaries


@router.get("/document-types-chart")
async def get_document_types_chart(
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
) -> Dict[str, Any]:
    """
    Get document types distribution for chart
    """
    type_stats = db.query(
        Document.document_type,
        func.count(Document.id).label('count')
    ).group_by(
        Document.document_type
    ).order_by(desc('count')).all()
    
    return {
        "labels": [item.document_type for item in type_stats],
        "data": [item.count for item in type_stats]
    }


@router.get("/analysis-performance")
async def get_analysis_performance(
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
) -> Dict[str, Any]:
    """
    Get analysis performance metrics
    """
    # Recent analyses (last 30 days)
    month_ago = datetime.now() - timedelta(days=30)
    
    recent_analyses = db.query(DocumentAnalysis).filter(
        DocumentAnalysis.created_at >= month_ago
    ).all()
    
    if not recent_analyses:
        return {
            "total_analyses": 0,
            "average_processing_time": 0,
            "success_rate": 0,
            "model_performance": {},
            "processing_time_trend": []
        }
    
    # Calculate metrics
    total_analyses = len(recent_analyses)
    completed_analyses = [a for a in recent_analyses if a.status == "completed"]
    success_rate = (len(completed_analyses) / total_analyses * 100) if total_analyses > 0 else 0
    
    # Average processing time
    processing_times = [a.processing_time for a in completed_analyses if a.processing_time]
    avg_processing_time = sum(processing_times) / len(processing_times) if processing_times else 0
    
    # Model performance
    model_stats = {}
    for analysis in recent_analyses:
        model = analysis.model_used or "unknown"
        if model not in model_stats:
            model_stats[model] = {"total": 0, "completed": 0, "processing_times": []}
        
        model_stats[model]["total"] += 1
        if analysis.status == "completed":
            model_stats[model]["completed"] += 1
            if analysis.processing_time:
                model_stats[model]["processing_times"].append(analysis.processing_time)
    
    model_performance = {}
    for model, stats in model_stats.items():
        success_rate_model = (stats["completed"] / stats["total"] * 100) if stats["total"] > 0 else 0
        avg_time_model = sum(stats["processing_times"]) / len(stats["processing_times"]) if stats["processing_times"] else 0
        
        model_performance[model] = {
            "total_analyses": stats["total"],
            "success_rate": round(success_rate_model, 1),
            "average_processing_time": round(avg_time_model, 2)
        }
    
    # Processing time trend (last 7 days)
    week_ago = datetime.now() - timedelta(days=7)
    daily_performance = db.query(
        func.date(DocumentAnalysis.created_at).label('date'),
        func.avg(DocumentAnalysis.processing_time).label('avg_time'),
        func.count(DocumentAnalysis.id).label('count')
    ).filter(
        DocumentAnalysis.created_at >= week_ago,
        DocumentAnalysis.status == "completed",
        DocumentAnalysis.processing_time.isnot(None)
    ).group_by(
        func.date(DocumentAnalysis.created_at)
    ).order_by('date').all()
    
    processing_time_trend = [
        {
            "date": str(item.date),
            "average_time": round(float(item.avg_time), 2) if item.avg_time else 0,
            "count": item.count
        }
        for item in daily_performance
    ]
    
    return {
        "total_analyses": total_analyses,
        "average_processing_time": round(avg_processing_time, 2),
        "success_rate": round(success_rate, 1),
        "model_performance": model_performance,
        "processing_time_trend": processing_time_trend
    }


@router.get("/recent-activity")
async def get_recent_activity(
    limit: int = 20,
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
) -> List[Dict[str, Any]]:
    """
    Get recent activity feed
    """
    activities = []
    
    # Recent documents
    recent_docs = db.query(Document).order_by(
        desc(Document.download_date)
    ).limit(limit // 3).all()
    
    for doc in recent_docs:
        activities.append({
            "type": "document_downloaded",
            "timestamp": doc.download_date,
            "description": f"Downloaded document: {doc.document_name}",
            "details": {
                "document_id": doc.id,
                "company": doc.company_name,
                "agent": doc.fiduciary_agent.short_name
            }
        })
    
    # Recent analyses
    recent_analyses = db.query(DocumentAnalysis).order_by(
        desc(DocumentAnalysis.created_at)
    ).limit(limit // 3).all()
    
    for analysis in recent_analyses:
        activities.append({
            "type": "analysis_completed" if analysis.status == "completed" else "analysis_failed",
            "timestamp": analysis.created_at,
            "description": f"Analysis {analysis.status}: {analysis.document.document_name}",
            "details": {
                "analysis_id": analysis.id,
                "document_id": analysis.document_id,
                "status": analysis.status
            }
        })
    
    # Recent crawler runs
    recent_runs = db.query(CrawlerRun).order_by(
        desc(CrawlerRun.start_time)
    ).limit(limit // 3).all()
    
    for run in recent_runs:
        activities.append({
            "type": "crawler_completed" if run.status == "completed" else "crawler_failed",
            "timestamp": run.start_time,
            "description": f"Crawler {run.status} for {run.fiduciary_agent.short_name}",
            "details": {
                "run_id": run.id,
                "agent": run.fiduciary_agent.short_name,
                "documents_found": run.documents_found,
                "status": run.status
            }
        })
    
    # Sort by timestamp and limit
    activities.sort(key=lambda x: x["timestamp"], reverse=True)
    
    return activities[:limit]


@router.get("/system-health")
async def get_system_health(
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
) -> Dict[str, Any]:
    """
    Get system health indicators
    """
    # Check for stuck crawlers (running for more than 2 hours)
    two_hours_ago = datetime.now() - timedelta(hours=2)
    stuck_crawlers = db.query(CrawlerRun).filter(
        CrawlerRun.status == "running",
        CrawlerRun.start_time < two_hours_ago
    ).count()
    
    # Check for failed analyses in last 24 hours
    day_ago = datetime.now() - timedelta(days=1)
    recent_failed_analyses = db.query(DocumentAnalysis).filter(
        DocumentAnalysis.status == "failed",
        DocumentAnalysis.created_at >= day_ago
    ).count()
    
    # Check for inactive agents
    inactive_agents = db.query(FiduciaryAgent).filter(
        FiduciaryAgent.is_active == False
    ).count()
    
    # Overall health score
    health_issues = 0
    if stuck_crawlers > 0:
        health_issues += 1
    if recent_failed_analyses > 5:  # More than 5 failures in 24h
        health_issues += 1
    if inactive_agents > 0:
        health_issues += 1
    
    health_score = max(0, 100 - (health_issues * 25))
    
    return {
        "health_score": health_score,
        "status": "healthy" if health_score >= 80 else "warning" if health_score >= 60 else "critical",
        "issues": {
            "stuck_crawlers": stuck_crawlers,
            "recent_failed_analyses": recent_failed_analyses,
            "inactive_agents": inactive_agents
        },
        "recommendations": [
            "Check stuck crawlers and restart if necessary" if stuck_crawlers > 0 else None,
            "Review failed analyses and check system configuration" if recent_failed_analyses > 5 else None,
            "Activate or configure inactive agents" if inactive_agents > 0 else None
        ]
    }

