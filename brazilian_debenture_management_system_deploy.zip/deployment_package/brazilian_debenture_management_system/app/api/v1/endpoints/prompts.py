"""
System Prompts Management Endpoints
"""

from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session

from app.config.database import get_db
from app.api.deps import (
    get_current_user,
    get_pagination_params,
    PaginationParams
)
from app.schemas.prompt import (
    SystemPrompt,
    SystemPromptCreate,
    SystemPromptUpdate,
    SystemPromptSummary,
    SystemPromptWithUsage
)
from app.models.prompt import SystemPrompt as PromptModel
from app.models.analysis import DocumentAnalysis
from app.core.exceptions import NotFoundError, ValidationError

router = APIRouter()


@router.post("/", response_model=SystemPrompt)
async def create_prompt(
    prompt_data: SystemPromptCreate,
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    """
    Create new system prompt
    """
    # Check if prompt with same name already exists
    existing_prompt = db.query(PromptModel).filter(
        PromptModel.name == prompt_data.name
    ).first()
    
    if existing_prompt:
        raise ValidationError(f"Prompt with name '{prompt_data.name}' already exists")
    
    # Create new prompt
    prompt = PromptModel(
        name=prompt_data.name,
        description=prompt_data.description,
        prompt_text=prompt_data.prompt_text,
        is_active=prompt_data.is_active,
        category=prompt_data.category,
        tags=prompt_data.tags,
        created_by=prompt_data.created_by or current_user,
        version=prompt_data.version,
        parent_prompt_id=prompt_data.parent_prompt_id
    )
    
    # Set model settings if provided
    if prompt_data.model_settings:
        prompt.set_model_settings_dict(prompt_data.model_settings)
    
    db.add(prompt)
    db.commit()
    db.refresh(prompt)
    
    return SystemPrompt(**prompt.__dict__)


@router.get("/", response_model=dict)
async def get_prompts(
    pagination: PaginationParams = Depends(get_pagination_params),
    category: Optional[str] = Query(None),
    is_active: Optional[bool] = Query(None),
    search: Optional[str] = Query(None),
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    """
    Get paginated list of system prompts with filtering
    """
    query = db.query(PromptModel)
    
    # Apply filters
    if category:
        query = query.filter(PromptModel.category == category)
    
    if is_active is not None:
        query = query.filter(PromptModel.is_active == is_active)
    
    if search:
        query = query.filter(
            PromptModel.name.ilike(f"%{search}%") |
            PromptModel.description.ilike(f"%{search}%") |
            PromptModel.prompt_text.ilike(f"%{search}%")
        )
    
    # Get total count
    total = query.count()
    
    # Apply pagination and ordering
    prompts = query.order_by(PromptModel.created_at.desc()).offset(
        pagination.offset
    ).limit(pagination.limit).all()
    
    # Convert to response models
    prompt_items = []
    for prompt in prompts:
        prompt_item = SystemPrompt(**prompt.__dict__)
        prompt_items.append(prompt_item)
    
    return {
        "total": total,
        "items": prompt_items,
        "limit": pagination.limit,
        "offset": pagination.offset,
        "has_next": pagination.offset + pagination.limit < total,
        "has_prev": pagination.offset > 0
    }


@router.get("/{prompt_id}", response_model=SystemPromptWithUsage)
async def get_prompt_detail(
    prompt_id: int,
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    """
    Get detailed information about a specific prompt
    """
    prompt = db.query(PromptModel).filter(PromptModel.id == prompt_id).first()
    
    if not prompt:
        raise NotFoundError("System Prompt", prompt_id)
    
    # Get usage statistics
    recent_analyses = db.query(DocumentAnalysis).filter(
        DocumentAnalysis.prompt_id == prompt_id
    ).order_by(DocumentAnalysis.created_at.desc()).limit(30).all()
    
    recent_analyses_count = len(recent_analyses)
    
    # Calculate average processing time
    processing_times = [a.processing_time for a in recent_analyses if a.processing_time]
    average_processing_time = sum(processing_times) / len(processing_times) if processing_times else None
    
    # Calculate success rate
    completed_analyses = [a for a in recent_analyses if a.status == "completed"]
    success_rate = (len(completed_analyses) / len(recent_analyses) * 100) if recent_analyses else None
    
    return SystemPromptWithUsage(
        **prompt.__dict__,
        recent_analyses_count=recent_analyses_count,
        average_processing_time=average_processing_time,
        success_rate=success_rate
    )


@router.put("/{prompt_id}", response_model=SystemPrompt)
async def update_prompt(
    prompt_id: int,
    prompt_data: SystemPromptUpdate,
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    """
    Update system prompt
    """
    prompt = db.query(PromptModel).filter(PromptModel.id == prompt_id).first()
    
    if not prompt:
        raise NotFoundError("System Prompt", prompt_id)
    
    # Check if name is being changed and if it conflicts
    if prompt_data.name and prompt_data.name != prompt.name:
        existing_prompt = db.query(PromptModel).filter(
            PromptModel.name == prompt_data.name,
            PromptModel.id != prompt_id
        ).first()
        
        if existing_prompt:
            raise ValidationError(f"Prompt with name '{prompt_data.name}' already exists")
    
    # Update fields
    update_data = prompt_data.dict(exclude_unset=True)
    
    # Handle model settings separately
    if 'model_settings' in update_data:
        model_settings = update_data.pop('model_settings')
        if model_settings:
            prompt.set_model_settings_dict(model_settings)
    
    # Update other fields
    for field, value in update_data.items():
        setattr(prompt, field, value)
    
    db.commit()
    db.refresh(prompt)
    
    return SystemPrompt(**prompt.__dict__)


@router.delete("/{prompt_id}")
async def delete_prompt(
    prompt_id: int,
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    """
    Delete system prompt
    """
    prompt = db.query(PromptModel).filter(PromptModel.id == prompt_id).first()
    
    if not prompt:
        raise NotFoundError("System Prompt", prompt_id)
    
    # Check if prompt is being used in analyses
    analyses_count = db.query(DocumentAnalysis).filter(
        DocumentAnalysis.prompt_id == prompt_id
    ).count()
    
    if analyses_count > 0:
        raise ValidationError(
            f"Cannot delete prompt '{prompt.name}' because it is used in {analyses_count} analyses"
        )
    
    db.delete(prompt)
    db.commit()
    
    return {"message": f"Prompt '{prompt.name}' deleted successfully"}


@router.post("/{prompt_id}/duplicate", response_model=SystemPrompt)
async def duplicate_prompt(
    prompt_id: int,
    new_name: str,
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    """
    Duplicate an existing prompt
    """
    original_prompt = db.query(PromptModel).filter(PromptModel.id == prompt_id).first()
    
    if not original_prompt:
        raise NotFoundError("System Prompt", prompt_id)
    
    # Check if new name already exists
    existing_prompt = db.query(PromptModel).filter(
        PromptModel.name == new_name
    ).first()
    
    if existing_prompt:
        raise ValidationError(f"Prompt with name '{new_name}' already exists")
    
    # Create duplicate
    new_prompt = PromptModel(
        name=new_name,
        description=f"Copy of {original_prompt.name}",
        prompt_text=original_prompt.prompt_text,
        is_active=original_prompt.is_active,
        category=original_prompt.category,
        tags=original_prompt.tags,
        created_by=current_user,
        version="1.0",
        parent_prompt_id=original_prompt.id,
        model_settings=original_prompt.model_settings
    )
    
    db.add(new_prompt)
    db.commit()
    db.refresh(new_prompt)
    
    return SystemPrompt(**new_prompt.__dict__)


@router.get("/categories/list")
async def get_prompt_categories(
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    """
    Get list of all prompt categories
    """
    categories = db.query(PromptModel.category).distinct().all()
    return {"categories": [cat[0] for cat in categories if cat[0]]}


@router.get("/tags/list")
async def get_prompt_tags(
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    """
    Get list of all prompt tags
    """
    prompts = db.query(PromptModel).filter(PromptModel.tags.isnot(None)).all()
    
    all_tags = set()
    for prompt in prompts:
        tags = prompt.tag_list
        all_tags.update(tags)
    
    return {"tags": sorted(list(all_tags))}


@router.post("/{prompt_id}/test")
async def test_prompt(
    prompt_id: int,
    test_text: str,
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    """
    Test prompt with sample text
    """
    prompt = db.query(PromptModel).filter(PromptModel.id == prompt_id).first()
    
    if not prompt:
        raise NotFoundError("System Prompt", prompt_id)
    
    # For testing, we'll just return the formatted prompt
    # In a real implementation, you might want to run it through the LLM
    formatted_prompt = prompt.prompt_text.replace("{document_text}", test_text)
    
    return {
        "prompt_id": prompt_id,
        "formatted_prompt": formatted_prompt,
        "test_text_length": len(test_text),
        "prompt_length": len(formatted_prompt)
    }


@router.get("/{prompt_id}/versions", response_model=List[SystemPromptSummary])
async def get_prompt_versions(
    prompt_id: int,
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    """
    Get all versions of a prompt
    """
    # Get the main prompt
    main_prompt = db.query(PromptModel).filter(PromptModel.id == prompt_id).first()
    
    if not main_prompt:
        raise NotFoundError("System Prompt", prompt_id)
    
    # Get all versions (children of this prompt)
    versions = db.query(PromptModel).filter(
        PromptModel.parent_prompt_id == prompt_id
    ).order_by(PromptModel.created_at.desc()).all()
    
    # Include the main prompt in the list
    all_versions = [main_prompt] + versions
    
    return [SystemPromptSummary(**prompt.__dict__) for prompt in all_versions]

