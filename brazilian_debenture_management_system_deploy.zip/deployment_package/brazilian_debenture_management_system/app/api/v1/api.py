"""
Main API Router
"""

from fastapi import APIRouter

from app.api.v1.endpoints import (
    crawlers,
    documents,
    analysis,
    prompts,
    schemas,
    dashboard,
    health,
    websocket
)

# Create main API router
api_router = APIRouter()

# Include endpoint routers
api_router.include_router(
    crawlers.router,
    prefix="/crawlers",
    tags=["Crawlers"]
)

api_router.include_router(
    documents.router,
    prefix="/documents",
    tags=["Documents"]
)

api_router.include_router(
    analysis.router,
    prefix="/analysis",
    tags=["Analysis"]
)

api_router.include_router(
    prompts.router,
    prefix="/prompts",
    tags=["System Prompts"]
)

api_router.include_router(
    schemas.router,
    prefix="/schemas",
    tags=["Output Schemas"]
)

api_router.include_router(
    dashboard.router,
    prefix="/dashboard",
    tags=["Dashboard"]
)

# Health check endpoints (no prefix for standard health checks)
api_router.include_router(
    health.router,
    tags=["Health"]
)

# WebSocket endpoints
api_router.include_router(
    websocket.router,
    tags=["WebSocket"]
)

