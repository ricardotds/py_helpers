"""
API Dependencies
"""

from typing import Generator, Optional
from fastapi import Depends, HTTPException, status, Query
from sqlalchemy.orm import Session

from app.config.database import get_db
from app.core.security import get_current_user, get_current_active_user
from app.models.fiduciary_agent import FiduciaryAgent
from app.models.document import Document
from app.models.prompt import SystemPrompt
from app.models.schema import OutputSchema
from app.core.exceptions import NotFoundError


# Database dependency
def get_database() -> Generator[Session, None, None]:
    """Get database session"""
    return get_db()


# Authentication dependencies
def get_current_user_dep() -> str:
    """Get current authenticated user"""
    return Depends(get_current_user)


def get_current_active_user_dep() -> str:
    """Get current active user"""
    return Depends(get_current_active_user)


# Pagination dependencies
class PaginationParams:
    """Pagination parameters"""
    
    def __init__(
        self,
        limit: int = Query(50, ge=1, le=100, description="Number of items to return"),
        offset: int = Query(0, ge=0, description="Number of items to skip")
    ):
        self.limit = limit
        self.offset = offset


def get_pagination_params() -> PaginationParams:
    """Get pagination parameters"""
    return Depends(PaginationParams)


# Resource dependencies
def get_fiduciary_agent(
    agent_id: int,
    db: Session = Depends(get_db)
) -> FiduciaryAgent:
    """Get fiduciary agent by ID"""
    agent = db.query(FiduciaryAgent).filter(FiduciaryAgent.id == agent_id).first()
    if not agent:
        raise NotFoundError("Fiduciary Agent", agent_id)
    return agent


def get_document(
    document_id: int,
    db: Session = Depends(get_db)
) -> Document:
    """Get document by ID"""
    document = db.query(Document).filter(Document.id == document_id).first()
    if not document:
        raise NotFoundError("Document", document_id)
    return document


def get_system_prompt(
    prompt_id: int,
    db: Session = Depends(get_db)
) -> SystemPrompt:
    """Get system prompt by ID"""
    prompt = db.query(SystemPrompt).filter(SystemPrompt.id == prompt_id).first()
    if not prompt:
        raise NotFoundError("System Prompt", prompt_id)
    return prompt


def get_output_schema(
    schema_id: int,
    db: Session = Depends(get_db)
) -> OutputSchema:
    """Get output schema by ID"""
    schema = db.query(OutputSchema).filter(OutputSchema.id == schema_id).first()
    if not schema:
        raise NotFoundError("Output Schema", schema_id)
    return schema


# Filter dependencies
class DocumentFilters:
    """Document filtering parameters"""
    
    def __init__(
        self,
        fiduciary_agent_id: Optional[int] = Query(None, description="Filter by fiduciary agent ID"),
        company_name: Optional[str] = Query(None, description="Filter by company name"),
        asset_code: Optional[str] = Query(None, description="Filter by asset code"),
        document_type: Optional[str] = Query(None, description="Filter by document type"),
        date_from: Optional[str] = Query(None, description="Filter by date from (YYYY-MM-DD)"),
        date_to: Optional[str] = Query(None, description="Filter by date to (YYYY-MM-DD)"),
        search: Optional[str] = Query(None, description="Search in document names and company names"),
        is_processed: Optional[bool] = Query(None, description="Filter by processing status")
    ):
        self.fiduciary_agent_id = fiduciary_agent_id
        self.company_name = company_name
        self.asset_code = asset_code
        self.document_type = document_type
        self.date_from = date_from
        self.date_to = date_to
        self.search = search
        self.is_processed = is_processed


def get_document_filters() -> DocumentFilters:
    """Get document filtering parameters"""
    return Depends(DocumentFilters)


class CrawlerFilters:
    """Crawler filtering parameters"""
    
    def __init__(
        self,
        status: Optional[str] = Query(None, description="Filter by crawler status"),
        agent_id: Optional[int] = Query(None, description="Filter by fiduciary agent ID"),
        date_from: Optional[str] = Query(None, description="Filter by start date from (YYYY-MM-DD)"),
        date_to: Optional[str] = Query(None, description="Filter by start date to (YYYY-MM-DD)")
    ):
        self.status = status
        self.agent_id = agent_id
        self.date_from = date_from
        self.date_to = date_to


def get_crawler_filters() -> CrawlerFilters:
    """Get crawler filtering parameters"""
    return Depends(CrawlerFilters)


class AnalysisFilters:
    """Analysis filtering parameters"""
    
    def __init__(
        self,
        status: Optional[str] = Query(None, description="Filter by analysis status"),
        document_id: Optional[int] = Query(None, description="Filter by document ID"),
        prompt_id: Optional[int] = Query(None, description="Filter by prompt ID"),
        schema_id: Optional[int] = Query(None, description="Filter by schema ID"),
        model_used: Optional[str] = Query(None, description="Filter by model used")
    ):
        self.status = status
        self.document_id = document_id
        self.prompt_id = prompt_id
        self.schema_id = schema_id
        self.model_used = model_used


def get_analysis_filters() -> AnalysisFilters:
    """Get analysis filtering parameters"""
    return Depends(AnalysisFilters)


# Validation dependencies
def validate_date_range(date_from: Optional[str], date_to: Optional[str]) -> tuple:
    """Validate date range parameters"""
    from datetime import datetime
    
    parsed_from = None
    parsed_to = None
    
    if date_from:
        try:
            parsed_from = datetime.strptime(date_from, "%Y-%m-%d").date()
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid date_from format. Use YYYY-MM-DD"
            )
    
    if date_to:
        try:
            parsed_to = datetime.strptime(date_to, "%Y-%m-%d").date()
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid date_to format. Use YYYY-MM-DD"
            )
    
    if parsed_from and parsed_to and parsed_from > parsed_to:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="date_from cannot be greater than date_to"
        )
    
    return parsed_from, parsed_to


# Rate limiting dependency (placeholder)
def rate_limit_check():
    """Rate limiting check (placeholder implementation)"""
    # In a real application, you would implement rate limiting logic here
    # using Redis or another caching solution
    pass


# Common response models
class PaginatedResponse:
    """Paginated response model"""
    
    def __init__(self, items: list, total: int, limit: int, offset: int):
        self.items = items
        self.total = total
        self.limit = limit
        self.offset = offset
        self.has_next = offset + limit < total
        self.has_prev = offset > 0

