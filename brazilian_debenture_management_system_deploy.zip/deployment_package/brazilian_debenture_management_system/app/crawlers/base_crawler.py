"""
Base Crawler Class for Brazilian Fiduciary Agents
"""

from abc import ABC, abstractmethod
from typing import List, Dict, Optional, Tuple, Set
from dataclasses import dataclass
from datetime import datetime, date
import hashlib
import requests
from pathlib import Path
import time
import logging
import re
from urllib.parse import urljoin, urlparse
from bs4 import BeautifulSoup

from app.config.settings import get_settings

# Configure logging
logger = logging.getLogger(__name__)

# Get settings
settings = get_settings()


@dataclass
class DocumentInfo:
    """Information about a discovered document"""
    company_name: str
    asset_code: Optional[str]
    emission_number: Optional[str]
    series: Optional[str]
    document_type: str
    document_name: str
    download_url: str
    document_date: Optional[date]
    file_size: Optional[int]
    last_modified: Optional[datetime]
    source_url: Optional[str] = None  # URL where the document was found


@dataclass
class CrawlerResult:
    """Result of a crawler execution"""
    documents_found: int
    documents_downloaded: int
    documents_skipped: int
    errors: List[str]
    execution_time: float
    last_page_processed: Optional[int]
    total_pages: Optional[int]


class BaseCrawler(ABC):
    """Abstract base class for all fiduciary agent crawlers"""
    
    def __init__(self, agent_id: int, storage_path: Path, session: requests.Session = None):
        self.agent_id = agent_id
        self.storage_path = Path(storage_path)
        self.session = session or self._create_session()
        self.errors = []
        self.documents_found = []
        self.documents_downloaded = []
        self.documents_skipped = []
        self.downloaded_urls: Set[str] = set()  # Track downloaded URLs to avoid duplicates
        self.last_page_processed = None
        self.total_pages = None
        
        # Create storage directory
        self.agent_storage_path = self.storage_path / self.get_agent_name().lower().replace(' ', '_')
        self.agent_storage_path.mkdir(parents=True, exist_ok=True)
    
    def _create_session(self) -> requests.Session:
        """Create a configured requests session"""
        session = requests.Session()
        session.headers.update({
            'User-Agent': settings.CRAWLER_USER_AGENT,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'pt-BR,pt;q=0.9,en;q=0.8',
            'Accept-Encoding': 'gzip, deflate, br',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
        })
        return session
    
    @abstractmethod
    def get_agent_name(self) -> str:
        """Return the name of the fiduciary agent"""
        pass
    
    @abstractmethod
    def get_base_url(self) -> str:
        """Return the base URL for the fiduciary agent"""
        pass
    
    @abstractmethod
    def discover_documents(self, date_from: Optional[date] = None, 
                          date_to: Optional[date] = None) -> List[DocumentInfo]:
        """Discover all available documents"""
        pass
    
    def should_download(self, doc_info: DocumentInfo, existing_hashes: Set[str] = None) -> bool:
        """Determine if a document should be downloaded"""
        # Check if URL already processed in this session
        if doc_info.download_url in self.downloaded_urls:
            return False
        
        # Check if file already exists with same hash (if provided)
        if existing_hashes:
            # For now, we'll download and check hash later
            # In a real implementation, you might want to do a HEAD request to get file info
            pass
        
        return True
    
    def download_document(self, doc_info: DocumentInfo) -> Tuple[bool, Optional[str], Optional[str]]:
        """Download a document and return (success, file_path, file_hash)"""
        try:
            logger.info(f"Downloading document: {doc_info.document_name}")
            
            # Add delay between requests
            time.sleep(settings.CRAWLER_DELAY_BETWEEN_REQUESTS)
            
            # Download with retries
            for attempt in range(settings.CRAWLER_RETRY_ATTEMPTS):
                try:
                    response = self.session.get(
                        doc_info.download_url, 
                        timeout=settings.CRAWLER_TIMEOUT,
                        stream=True
                    )
                    response.raise_for_status()
                    break
                except requests.RequestException as e:
                    if attempt == settings.CRAWLER_RETRY_ATTEMPTS - 1:
                        raise e
                    logger.warning(f"Download attempt {attempt + 1} failed, retrying...")
                    time.sleep(2 ** attempt)  # Exponential backoff
            
            # Check content type
            content_type = response.headers.get('content-type', '').lower()
            if 'pdf' not in content_type and not doc_info.document_name.lower().endswith('.pdf'):
                logger.warning(f"Document may not be PDF: {content_type}")
            
            # Generate file path
            file_path = self.generate_file_path(doc_info)
            file_path.parent.mkdir(parents=True, exist_ok=True)
            
            # Save file
            with open(file_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)
            
            # Calculate hash
            file_hash = self.calculate_file_hash(file_path)
            
            # Get file size
            file_size = file_path.stat().st_size
            
            # Update document info with actual file size
            doc_info.file_size = file_size
            
            # Mark URL as downloaded
            self.downloaded_urls.add(doc_info.download_url)
            
            logger.info(f"Successfully downloaded: {doc_info.document_name} ({file_size} bytes)")
            
            return True, str(file_path), file_hash
            
        except Exception as e:
            error_msg = f"Failed to download {doc_info.document_name}: {str(e)}"
            self.errors.append(error_msg)
            logger.error(error_msg)
            return False, None, None
    
    def generate_file_path(self, doc_info: DocumentInfo) -> Path:
        """Generate standardized file path for document"""
        # Sanitize filename
        safe_name = self.sanitize_filename(doc_info.document_name)
        
        # Create directory structure: agent/company/asset_code/
        dir_path = self.agent_storage_path
        
        if doc_info.company_name:
            company_dir = self.sanitize_filename(doc_info.company_name)
            dir_path = dir_path / company_dir
        
        if doc_info.asset_code:
            dir_path = dir_path / doc_info.asset_code
        
        # Add document type subdirectory
        if doc_info.document_type:
            type_dir = self.sanitize_filename(doc_info.document_type)
            dir_path = dir_path / type_dir
        
        return dir_path / safe_name
    
    def sanitize_filename(self, filename: str) -> str:
        """Sanitize filename for filesystem"""
        if not filename:
            return "unknown"
        
        # Remove or replace invalid characters
        filename = re.sub(r'[<>:"/\\|?*]', '_', filename)
        filename = re.sub(r'\s+', '_', filename)
        filename = filename.strip('._')
        
        # Limit length
        if len(filename) > 200:
            name, ext = filename.rsplit('.', 1) if '.' in filename else (filename, '')
            filename = name[:200-len(ext)-1] + ('.' + ext if ext else '')
        
        return filename or "unknown"
    
    def calculate_file_hash(self, file_path: Path) -> str:
        """Calculate SHA-256 hash of file"""
        hash_sha256 = hashlib.sha256()
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(4096), b""):
                hash_sha256.update(chunk)
        return hash_sha256.hexdigest()
    
    def get_remote_file_hash(self, doc_info: DocumentInfo) -> Optional[str]:
        """Get hash of remote file without downloading (if possible)"""
        # Default implementation - can be overridden by specific crawlers
        return None
    
    def make_request(self, url: str, method: str = 'GET', **kwargs) -> requests.Response:
        """Make HTTP request with error handling"""
        try:
            response = self.session.request(method, url, timeout=settings.CRAWLER_TIMEOUT, **kwargs)
            response.raise_for_status()
            return response
        except requests.RequestException as e:
            error_msg = f"Request failed for {url}: {str(e)}"
            self.errors.append(error_msg)
            logger.error(error_msg)
            raise
    
    def parse_html(self, html: str) -> BeautifulSoup:
        """Parse HTML content"""
        return BeautifulSoup(html, 'html.parser')
    
    def extract_date_from_text(self, text: str) -> Optional[date]:
        """Extract date from text using common Brazilian date formats"""
        if not text:
            return None
        
        # Common date patterns
        patterns = [
            r'(\d{4})\.(\d{2})\.(\d{2})',  # YYYY.MM.DD
            r'(\d{2})\.(\d{2})\.(\d{4})',  # DD.MM.YYYY
            r'(\d{4})-(\d{2})-(\d{2})',   # YYYY-MM-DD
            r'(\d{2})-(\d{2})-(\d{4})',   # DD-MM-YYYY
            r'(\d{2})/(\d{2})/(\d{4})',   # DD/MM/YYYY
            r'(\d{4})/(\d{2})/(\d{2})',   # YYYY/MM/DD
        ]
        
        for pattern in patterns:
            match = re.search(pattern, text)
            if match:
                try:
                    groups = match.groups()
                    if len(groups[0]) == 4:  # Year first
                        year, month, day = int(groups[0]), int(groups[1]), int(groups[2])
                    else:  # Day first
                        day, month, year = int(groups[0]), int(groups[1]), int(groups[2])
                    
                    return date(year, month, day)
                except (ValueError, IndexError):
                    continue
        
        return None
    
    def classify_document_type(self, doc_name: str, context: str = "") -> str:
        """Classify document type based on name and context"""
        doc_name_lower = doc_name.lower()
        context_lower = context.lower()
        
        # Document type classification
        if any(term in doc_name_lower for term in ['escritura', 'emissão']):
            return 'Escritura de Emissão'
        elif any(term in doc_name_lower for term in ['cessão', 'fiduciária']):
            return 'Contrato de Cessão Fiduciária'
        elif 'aditamento' in doc_name_lower:
            return 'Aditamento'
        elif any(term in doc_name_lower for term in ['relatório', 'relatorio']):
            return 'Relatório'
        elif any(term in doc_name_lower for term in ['assembleia', 'agt', 'agd']):
            return 'Assembleia'
        elif 'covenant' in doc_name_lower:
            return 'Covenants'
        elif any(term in doc_name_lower for term in ['notificação', 'notificacao']):
            return 'Notificação'
        elif 'dfp' in doc_name_lower:
            return 'Demonstrações Financeiras'
        else:
            return 'Documento'
    
    def build_absolute_url(self, url: str, base_url: str = None) -> str:
        """Build absolute URL from relative URL"""
        if url.startswith('http'):
            return url
        
        base = base_url or self.get_base_url()
        return urljoin(base, url)
    
    def is_valid_pdf_url(self, url: str) -> bool:
        """Check if URL is likely a PDF"""
        if not url:
            return False
        
        url_lower = url.lower()
        return (url_lower.endswith('.pdf') or 
                'pdf' in url_lower or 
                'download' in url_lower or
                'arquivo' in url_lower)
    
    def execute(self, date_from: Optional[date] = None, 
                date_to: Optional[date] = None,
                force_full_crawl: bool = False,
                existing_hashes: Set[str] = None) -> CrawlerResult:
        """Execute the crawler"""
        start_time = datetime.now()
        
        try:
            logger.info(f"Starting crawler for {self.get_agent_name()}")
            
            # Discover documents
            documents = self.discover_documents(date_from, date_to)
            self.documents_found = documents
            
            logger.info(f"Found {len(documents)} documents")
            
            # Download documents
            for i, doc_info in enumerate(documents):
                try:
                    if not force_full_crawl and not self.should_download(doc_info, existing_hashes):
                        self.documents_skipped.append(doc_info)
                        logger.info(f"Skipping document {i+1}/{len(documents)}: {doc_info.document_name}")
                        continue
                    
                    logger.info(f"Processing document {i+1}/{len(documents)}: {doc_info.document_name}")
                    
                    success, file_path, file_hash = self.download_document(doc_info)
                    if success:
                        self.documents_downloaded.append((doc_info, file_path, file_hash))
                    
                except Exception as e:
                    error_msg = f"Error processing document {doc_info.document_name}: {str(e)}"
                    self.errors.append(error_msg)
                    logger.error(error_msg)
                
        except Exception as e:
            error_msg = f"Crawler execution failed: {str(e)}"
            self.errors.append(error_msg)
            logger.error(error_msg)
        
        execution_time = (datetime.now() - start_time).total_seconds()
        
        result = CrawlerResult(
            documents_found=len(self.documents_found),
            documents_downloaded=len(self.documents_downloaded),
            documents_skipped=len(self.documents_skipped),
            errors=self.errors,
            execution_time=execution_time,
            last_page_processed=self.last_page_processed,
            total_pages=self.total_pages
        )
        
        logger.info(f"Crawler completed: {result.documents_downloaded}/{result.documents_found} documents downloaded")
        
        return result

