"""Web crawler modules for Brazilian Fiduciary Agents"""

from app.crawlers.base_crawler import BaseCrawler, DocumentInfo, CrawlerResult
from app.crawlers.pentagono_crawler import PentagonoCrawler
from app.crawlers.vortx_crawler import VortxCrawler
from app.crawlers.oliveira_trust_crawler import OliveiraTrustCrawler

__all__ = [
    "BaseCrawler",
    "DocumentInfo", 
    "CrawlerResult",
    "PentagonoCrawler",
    "VortxCrawler", 
    "OliveiraTrustCrawler"
]

