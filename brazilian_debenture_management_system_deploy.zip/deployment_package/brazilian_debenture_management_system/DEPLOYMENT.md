# Deployment Guide - Brazilian Debenture Management System

This guide provides step-by-step instructions for deploying the Brazilian Debenture Management System in different environments.

## Quick Start (Development)

### Prerequisites
- Python 3.11+
- Node.js 20+
- Git

### 1. Clone and Setup Backend

```bash
# Navigate to the application directory
cd debenture_management_app

# Install Python dependencies
pip install -r requirements.txt

# Initialize database with default data
python run.py --init-db

# Start the backend server
python run.py --no-init
```

The backend will be available at `http://localhost:8000`
API documentation: `http://localhost:8000/docs`

### 2. Setup Frontend

```bash
# Navigate to frontend directory
cd frontend

# Install dependencies
pnpm install

# Start development server
pnpm run dev --host
```

The frontend will be available at `http://localhost:5173`

## Production Deployment

### Option 1: Traditional Server Deployment

#### Backend Deployment

1. **Prepare the server:**
```bash
# Update system packages
sudo apt update && sudo apt upgrade -y

# Install Python 3.11
sudo apt install python3.11 python3.11-pip python3.11-venv -y

# Install Node.js 20
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

# Install pnpm
npm install -g pnpm
```

2. **Deploy backend:**
```bash
# Create application directory
sudo mkdir -p /opt/debenture-management
sudo chown $USER:$USER /opt/debenture-management

# Copy application files
cp -r debenture_management_app/* /opt/debenture-management/

# Navigate to application directory
cd /opt/debenture-management

# Create virtual environment
python3.11 -m venv venv
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Set environment variables
export DATABASE_URL="postgresql://user:password@localhost:5432/debenture_management"
export OPENAI_API_KEY="your-openai-api-key"
export SECRET_KEY="your-production-secret-key"

# Initialize database
python run.py --init-db

# Install and configure systemd service
sudo cp deployment/debenture-backend.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable debenture-backend
sudo systemctl start debenture-backend
```

3. **Deploy frontend:**
```bash
# Navigate to frontend directory
cd /opt/debenture-management/frontend

# Install dependencies
pnpm install

# Build for production
pnpm run build

# Copy built files to web server
sudo cp -r dist/* /var/www/html/debenture-management/

# Configure nginx
sudo cp deployment/nginx.conf /etc/nginx/sites-available/debenture-management
sudo ln -s /etc/nginx/sites-available/debenture-management /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx
```

### Option 2: Docker Deployment

#### 1. Create Docker files

**Backend Dockerfile:**
```dockerfile
FROM python:3.11-slim

WORKDIR /app

# Install system dependencies
RUN apt-get update && apt-get install -y \
    gcc \
    && rm -rf /var/lib/apt/lists/*

# Copy requirements and install Python dependencies
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy application code
COPY . .

# Create storage directories
RUN mkdir -p storage/documents storage/logs

# Expose port
EXPOSE 8000

# Run application
CMD ["python", "run.py", "--no-init"]
```

**Frontend Dockerfile:**
```dockerfile
FROM node:20-alpine as builder

WORKDIR /app
COPY frontend/package*.json ./
COPY frontend/pnpm-lock.yaml ./
RUN npm install -g pnpm && pnpm install

COPY frontend/ .
RUN pnpm run build

FROM nginx:alpine
COPY --from=builder /app/dist /usr/share/nginx/html
COPY deployment/nginx.conf /etc/nginx/conf.d/default.conf
EXPOSE 80
```

**Docker Compose:**
```yaml
version: '3.8'

services:
  postgres:
    image: postgres:15
    environment:
      POSTGRES_DB: debenture_management
      POSTGRES_USER: postgres
      POSTGRES_PASSWORD: password
    volumes:
      - postgres_data:/var/lib/postgresql/data
    ports:
      - "5432:5432"

  backend:
    build: .
    environment:
      DATABASE_URL: postgresql://postgres:password@postgres:5432/debenture_management
      OPENAI_API_KEY: ${OPENAI_API_KEY}
      SECRET_KEY: ${SECRET_KEY}
    ports:
      - "8000:8000"
    depends_on:
      - postgres
    volumes:
      - ./storage:/app/storage

  frontend:
    build:
      context: .
      dockerfile: frontend/Dockerfile
    ports:
      - "80:80"
    depends_on:
      - backend

volumes:
  postgres_data:
```

#### 2. Deploy with Docker

```bash
# Create environment file
cat > .env << EOF
OPENAI_API_KEY=your-openai-api-key
SECRET_KEY=your-production-secret-key
EOF

# Build and start services
docker-compose up -d

# Initialize database
docker-compose exec backend python run.py --init-db
```

### Option 3: Cloud Deployment (AWS/GCP/Azure)

#### AWS Deployment with ECS

1. **Create ECR repositories:**
```bash
# Create repositories for backend and frontend
aws ecr create-repository --repository-name debenture-backend
aws ecr create-repository --repository-name debenture-frontend

# Build and push images
docker build -t debenture-backend .
docker build -t debenture-frontend -f frontend/Dockerfile .

# Tag and push to ECR
docker tag debenture-backend:latest <account-id>.dkr.ecr.<region>.amazonaws.com/debenture-backend:latest
docker tag debenture-frontend:latest <account-id>.dkr.ecr.<region>.amazonaws.com/debenture-frontend:latest

docker push <account-id>.dkr.ecr.<region>.amazonaws.com/debenture-backend:latest
docker push <account-id>.dkr.ecr.<region>.amazonaws.com/debenture-frontend:latest
```

2. **Create ECS task definitions and services:**
```json
{
  "family": "debenture-backend",
  "networkMode": "awsvpc",
  "requiresCompatibilities": ["FARGATE"],
  "cpu": "512",
  "memory": "1024",
  "executionRoleArn": "arn:aws:iam::<account-id>:role/ecsTaskExecutionRole",
  "containerDefinitions": [
    {
      "name": "backend",
      "image": "<account-id>.dkr.ecr.<region>.amazonaws.com/debenture-backend:latest",
      "portMappings": [
        {
          "containerPort": 8000,
          "protocol": "tcp"
        }
      ],
      "environment": [
        {
          "name": "DATABASE_URL",
          "value": "postgresql://user:password@rds-endpoint:5432/debenture_management"
        }
      ],
      "secrets": [
        {
          "name": "OPENAI_API_KEY",
          "valueFrom": "arn:aws:secretsmanager:<region>:<account-id>:secret:openai-api-key"
        }
      ]
    }
  ]
}
```

## Environment Configuration

### Required Environment Variables

```bash
# Database
DATABASE_URL=postgresql://user:password@localhost:5432/debenture_management

# OpenAI (for LangChain)
OPENAI_API_KEY=your-openai-api-key
OPENAI_API_BASE=https://api.openai.com/v1

# Application Security
SECRET_KEY=your-secret-key-change-in-production

# Application Settings
DEBUG=false
CORS_ORIGINS=["https://yourdomain.com"]

# Crawler Settings
CRAWLER_DELAY=1.0
MAX_CONCURRENT_CRAWLERS=3
DOWNLOAD_TIMEOUT=30

# Storage
STORAGE_PATH=/opt/debenture-management/storage
DOCUMENTS_PATH=/opt/debenture-management/storage/documents
LOGS_PATH=/opt/debenture-management/storage/logs
```

### Database Setup

#### PostgreSQL (Recommended for Production)

```bash
# Install PostgreSQL
sudo apt install postgresql postgresql-contrib -y

# Create database and user
sudo -u postgres psql << EOF
CREATE DATABASE debenture_management;
CREATE USER debenture_user WITH PASSWORD 'secure_password';
GRANT ALL PRIVILEGES ON DATABASE debenture_management TO debenture_user;
\q
EOF

# Update connection string
export DATABASE_URL="postgresql://debenture_user:secure_password@localhost:5432/debenture_management"
```

#### SQLite (Development Only)

```bash
# SQLite is used by default for development
export DATABASE_URL="sqlite:///./debenture_management.db"
```

## Security Considerations

### 1. API Security
- Change default SECRET_KEY in production
- Use HTTPS in production
- Implement rate limiting
- Configure CORS properly

### 2. Database Security
- Use strong passwords
- Enable SSL connections
- Regular backups
- Access control

### 3. File Storage Security
- Secure file permissions
- Virus scanning for uploaded files
- Storage encryption

### 4. Network Security
- Firewall configuration
- VPN access for admin functions
- Load balancer with SSL termination

## Monitoring and Maintenance

### 1. Application Monitoring

```bash
# Check application status
systemctl status debenture-backend

# View logs
journalctl -u debenture-backend -f

# Monitor resource usage
htop
df -h
```

### 2. Database Maintenance

```bash
# Backup database
pg_dump debenture_management > backup_$(date +%Y%m%d_%H%M%S).sql

# Restore database
psql debenture_management < backup_file.sql

# Vacuum and analyze
psql debenture_management -c "VACUUM ANALYZE;"
```

### 3. Log Management

```bash
# Rotate logs
sudo logrotate /etc/logrotate.d/debenture-management

# Clean old documents (if needed)
find /opt/debenture-management/storage/documents -type f -mtime +365 -delete
```

## Troubleshooting

### Common Issues

1. **Database Connection Errors**
   - Check DATABASE_URL format
   - Verify database server is running
   - Check network connectivity

2. **OpenAI API Errors**
   - Verify OPENAI_API_KEY is set
   - Check API quota and billing
   - Validate API key permissions

3. **Crawler Failures**
   - Check website accessibility
   - Verify crawler configuration
   - Review error logs

4. **Frontend Build Errors**
   - Clear node_modules and reinstall
   - Check Node.js version compatibility
   - Verify environment variables

### Performance Optimization

1. **Database Optimization**
   - Add indexes for frequently queried fields
   - Optimize query performance
   - Configure connection pooling

2. **Application Optimization**
   - Enable caching
   - Optimize crawler concurrency
   - Configure load balancing

3. **Storage Optimization**
   - Implement file compression
   - Archive old documents
   - Use CDN for static files

## Backup and Recovery

### 1. Database Backup

```bash
# Automated backup script
#!/bin/bash
BACKUP_DIR="/opt/backups/database"
DATE=$(date +%Y%m%d_%H%M%S)
mkdir -p $BACKUP_DIR

pg_dump debenture_management | gzip > $BACKUP_DIR/debenture_backup_$DATE.sql.gz

# Keep only last 30 days of backups
find $BACKUP_DIR -name "*.sql.gz" -mtime +30 -delete
```

### 2. File Backup

```bash
# Backup documents and configuration
tar -czf /opt/backups/files/debenture_files_$(date +%Y%m%d).tar.gz \
  /opt/debenture-management/storage \
  /opt/debenture-management/.env \
  /opt/debenture-management/deployment
```

### 3. Recovery Procedures

```bash
# Restore database
gunzip -c backup_file.sql.gz | psql debenture_management

# Restore files
tar -xzf debenture_files_backup.tar.gz -C /

# Restart services
systemctl restart debenture-backend
systemctl restart nginx
```

## Scaling Considerations

### Horizontal Scaling

1. **Load Balancer Configuration**
   - Multiple backend instances
   - Session affinity if needed
   - Health checks

2. **Database Scaling**
   - Read replicas
   - Connection pooling
   - Query optimization

3. **File Storage Scaling**
   - Distributed file systems
   - Object storage (S3, GCS)
   - CDN integration

### Vertical Scaling

1. **Resource Allocation**
   - CPU and memory optimization
   - Storage performance
   - Network bandwidth

2. **Application Tuning**
   - Worker process configuration
   - Connection limits
   - Cache sizing

## Support and Maintenance

### Regular Maintenance Tasks

1. **Weekly Tasks**
   - Review system logs
   - Check disk usage
   - Verify backup integrity

2. **Monthly Tasks**
   - Update dependencies
   - Security patches
   - Performance review

3. **Quarterly Tasks**
   - Capacity planning
   - Security audit
   - Disaster recovery testing

### Getting Help

- Check application logs first
- Review this deployment guide
- Consult the main README.md
- Check API documentation at `/docs`

For additional support, ensure you have:
- Application version information
- Error logs and stack traces
- Environment configuration details
- Steps to reproduce issues

