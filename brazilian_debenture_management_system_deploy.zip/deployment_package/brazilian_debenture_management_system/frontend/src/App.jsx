import React, { useState } from 'react';
import {
  Box,
  CssBaseline,
  AppBar,
  Toolbar,
  Typography,
  Drawer,
  List,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  IconButton,
  useTheme,
  ThemeProvider,
  createTheme,
  Container
} from '@mui/material';
import {
  Menu as MenuIcon,
  Dashboard,
  Settings,
  Description,
  Analytics,
  Psychology,
  Schema,
  BugReport
} from '@mui/icons-material';

// Import components
import DashboardInterface from './components/Dashboard/DashboardInterface';
import CrawlerInterface from './components/Crawlers/CrawlerInterface';
import DocumentsInterface from './components/Documents/DocumentsInterface';
import AnalysisInterface from './components/Analysis/AnalysisInterface';
import PromptsInterface from './components/Prompts/PromptsInterface';
import SchemasInterface from './components/Schemas/SchemasInterface';

const theme = createTheme({
  palette: {
    primary: {
      main: '#1976d2',
    },
    secondary: {
      main: '#dc004e',
    },
  },
});

const drawerWidth = 280;

const menuItems = [
  { id: 'dashboard', label: 'Dashboard', icon: <Dashboard />, component: DashboardInterface },
  { id: 'crawlers', label: 'Controle de Crawlers', icon: <BugReport />, component: CrawlerInterface },
  { id: 'documents', label: 'Documentos', icon: <Description />, component: DocumentsInterface },
  { id: 'analysis', label: 'Análises', icon: <Analytics />, component: AnalysisInterface },
  { id: 'prompts', label: 'Prompts', icon: <Psychology />, component: PromptsInterface },
  { id: 'schemas', label: 'Esquemas', icon: <Schema />, component: SchemasInterface },
];

function App() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [selectedTab, setSelectedTab] = useState('dashboard');

  const handleDrawerToggle = () => {
    setMobileOpen(!mobileOpen);
  };

  const handleTabChange = (tabId) => {
    setSelectedTab(tabId);
    setMobileOpen(false); // Close mobile drawer when item is selected
  };

  const drawer = (
    <div>
      <Toolbar>
        <Typography variant="h6" noWrap component="div">
          Debenture Manager
        </Typography>
      </Toolbar>
      <List>
        {menuItems.map((item) => (
          <ListItem key={item.id} disablePadding>
            <ListItemButton
              selected={selectedTab === item.id}
              onClick={() => handleTabChange(item.id)}
            >
              <ListItemIcon>
                {item.icon}
              </ListItemIcon>
              <ListItemText primary={item.label} />
            </ListItemButton>
          </ListItem>
        ))}
      </List>
    </div>
  );

  const currentComponent = menuItems.find(item => item.id === selectedTab)?.component;
  const CurrentComponent = currentComponent || DashboardInterface;

  return (
    <ThemeProvider theme={theme}>
      <Box sx={{ display: 'flex' }}>
        <CssBaseline />
        <AppBar
          position="fixed"
          sx={{
            width: { sm: `calc(100% - ${drawerWidth}px)` },
            ml: { sm: `${drawerWidth}px` },
          }}
        >
          <Toolbar>
            <IconButton
              color="inherit"
              aria-label="open drawer"
              edge="start"
              onClick={handleDrawerToggle}
              sx={{ mr: 2, display: { sm: 'none' } }}
            >
              <MenuIcon />
            </IconButton>
            <Typography variant="h6" noWrap component="div">
              Sistema de Gestão de Debêntures Brasileiras
            </Typography>
          </Toolbar>
        </AppBar>
        <Box
          component="nav"
          sx={{ width: { sm: drawerWidth }, flexShrink: { sm: 0 } }}
          aria-label="mailbox folders"
        >
          <Drawer
            variant="temporary"
            open={mobileOpen}
            onClose={handleDrawerToggle}
            ModalProps={{
              keepMounted: true, // Better open performance on mobile.
            }}
            sx={{
              display: { xs: 'block', sm: 'none' },
              '& .MuiDrawer-paper': { boxSizing: 'border-box', width: drawerWidth },
            }}
          >
            {drawer}
          </Drawer>
          <Drawer
            variant="permanent"
            sx={{
              display: { xs: 'none', sm: 'block' },
              '& .MuiDrawer-paper': { boxSizing: 'border-box', width: drawerWidth },
            }}
            open
          >
            {drawer}
          </Drawer>
        </Box>
        <Box
          component="main"
          sx={{
            flexGrow: 1,
            width: { sm: `calc(100% - ${drawerWidth}px)` },
            minHeight: '100vh',
            backgroundColor: '#f5f5f5'
          }}
        >
          <Toolbar />
          <Container maxWidth={false} sx={{ py: 2 }}>
            <CurrentComponent />
          </Container>
        </Box>
      </Box>
    </ThemeProvider>
  );
}

export default App;

