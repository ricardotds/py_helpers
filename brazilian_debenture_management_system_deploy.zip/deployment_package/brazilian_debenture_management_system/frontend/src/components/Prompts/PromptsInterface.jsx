import React, { useState, useEffect } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  IconButton,
  Tooltip,
  Alert,
  Grid,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Chip
} from '@mui/material';
import {
  Add,
  Edit,
  Delete,
  Visibility,
  Psychology,
  Save,
  Cancel
} from '@mui/icons-material';

const PromptsInterface = () => {
  const [prompts, setPrompts] = useState([]);
  const [editDialog, setEditDialog] = useState(false);
  const [viewDialog, setViewDialog] = useState(false);
  const [selectedPrompt, setSelectedPrompt] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    prompt_text: '',
    category: 'general',
    model_type: 'gpt-4',
    temperature: 0.1,
    max_tokens: 2000,
    is_active: true
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [isEditing, setIsEditing] = useState(false);

  const categories = [
    'general',
    'financial_analysis',
    'legal_analysis',
    'risk_assessment',
    'compliance',
    'data_extraction',
    'summarization'
  ];

  const modelTypes = [
    'gpt-4',
    'gpt-4-turbo-preview',
    'gpt-3.5-turbo',
    'gpt-3.5-turbo-16k'
  ];

  useEffect(() => {
    fetchPrompts();
  }, []);

  const fetchPrompts = async () => {
    try {
      const response = await fetch('/api/v1/prompts/');
      const data = await response.json();
      setPrompts(data);
    } catch (error) {
      console.error('Error fetching prompts:', error);
      setError('Failed to fetch prompts');
    }
  };

  const handleOpenDialog = (prompt = null) => {
    if (prompt) {
      setFormData({
        name: prompt.name,
        description: prompt.description,
        prompt_text: prompt.prompt_text,
        category: prompt.category || 'general',
        model_type: prompt.model_type || 'gpt-4',
        temperature: prompt.temperature || 0.1,
        max_tokens: prompt.max_tokens || 2000,
        is_active: prompt.is_active !== false
      });
      setSelectedPrompt(prompt);
      setIsEditing(true);
    } else {
      setFormData({
        name: '',
        description: '',
        prompt_text: '',
        category: 'general',
        model_type: 'gpt-4',
        temperature: 0.1,
        max_tokens: 2000,
        is_active: true
      });
      setSelectedPrompt(null);
      setIsEditing(false);
    }
    setEditDialog(true);
    setError('');
  };

  const handleCloseDialog = () => {
    setEditDialog(false);
    setSelectedPrompt(null);
    setError('');
  };

  const handleSave = async () => {
    if (!formData.name || !formData.prompt_text) {
      setError('Name and prompt text are required');
      return;
    }

    setLoading(true);
    setError('');

    try {
      const url = isEditing ? `/api/v1/prompts/${selectedPrompt.id}` : '/api/v1/prompts/';
      const method = isEditing ? 'PUT' : 'POST';

      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        handleCloseDialog();
        fetchPrompts();
      } else {
        const errorData = await response.json();
        setError(errorData.detail || 'Failed to save prompt');
      }
    } catch (error) {
      setError('Network error occurred');
      console.error('Error saving prompt:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (promptId) => {
    if (!window.confirm('Are you sure you want to delete this prompt?')) {
      return;
    }

    try {
      const response = await fetch(`/api/v1/prompts/${promptId}`, {
        method: 'DELETE',
      });

      if (response.ok) {
        fetchPrompts();
      } else {
        setError('Failed to delete prompt');
      }
    } catch (error) {
      setError('Network error occurred');
      console.error('Error deleting prompt:', error);
    }
  };

  const handleView = (prompt) => {
    setSelectedPrompt(prompt);
    setViewDialog(true);
  };

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h4" gutterBottom>
        System Prompts Management
      </Typography>

      {error && (
        <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError('')}>
          {error}
        </Alert>
      )}

      <Grid container spacing={3}>
        {/* Controls */}
        <Grid item xs={12}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                <Psychology sx={{ mr: 1, verticalAlign: 'middle' }} />
                Prompt Management
              </Typography>
              <Button
                variant="contained"
                color="primary"
                onClick={() => handleOpenDialog()}
                startIcon={<Add />}
              >
                Create New Prompt
              </Button>
            </CardContent>
          </Card>
        </Grid>

        {/* Prompts Table */}
        <Grid item xs={12}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Available Prompts ({prompts.length})
              </Typography>
              <TableContainer component={Paper}>
                <Table>
                  <TableHead>
                    <TableRow>
                      <TableCell>Name</TableCell>
                      <TableCell>Description</TableCell>
                      <TableCell>Category</TableCell>
                      <TableCell>Model</TableCell>
                      <TableCell>Status</TableCell>
                      <TableCell>Created</TableCell>
                      <TableCell>Actions</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {prompts.map((prompt) => (
                      <TableRow key={prompt.id}>
                        <TableCell>
                          <Typography variant="subtitle2">{prompt.name}</Typography>
                        </TableCell>
                        <TableCell>
                          <Typography variant="body2" color="text.secondary">
                            {prompt.description || 'No description'}
                          </Typography>
                        </TableCell>
                        <TableCell>
                          <Chip 
                            label={prompt.category || 'general'} 
                            size="small" 
                            variant="outlined"
                          />
                        </TableCell>
                        <TableCell>
                          <Typography variant="body2">
                            {prompt.model_type || 'gpt-4'}
                          </Typography>
                        </TableCell>
                        <TableCell>
                          <Chip
                            label={prompt.is_active !== false ? 'Active' : 'Inactive'}
                            color={prompt.is_active !== false ? 'success' : 'default'}
                            size="small"
                          />
                        </TableCell>
                        <TableCell>
                          {new Date(prompt.created_at).toLocaleDateString()}
                        </TableCell>
                        <TableCell>
                          <Tooltip title="View">
                            <IconButton
                              onClick={() => handleView(prompt)}
                              size="small"
                            >
                              <Visibility />
                            </IconButton>
                          </Tooltip>
                          <Tooltip title="Edit">
                            <IconButton
                              onClick={() => handleOpenDialog(prompt)}
                              size="small"
                            >
                              <Edit />
                            </IconButton>
                          </Tooltip>
                          <Tooltip title="Delete">
                            <IconButton
                              onClick={() => handleDelete(prompt.id)}
                              size="small"
                              color="error"
                            >
                              <Delete />
                            </IconButton>
                          </Tooltip>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Edit/Create Dialog */}
      <Dialog open={editDialog} onClose={handleCloseDialog} maxWidth="lg" fullWidth>
        <DialogTitle>
          <Psychology sx={{ mr: 1, verticalAlign: 'middle' }} />
          {isEditing ? 'Edit Prompt' : 'Create New Prompt'}
        </DialogTitle>
        <DialogContent>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, mt: 2 }}>
            <Grid container spacing={2}>
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="Name"
                  value={formData.name}
                  onChange={(e) => handleInputChange('name', e.target.value)}
                  required
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <FormControl fullWidth>
                  <InputLabel>Category</InputLabel>
                  <Select
                    value={formData.category}
                    label="Category"
                    onChange={(e) => handleInputChange('category', e.target.value)}
                  >
                    {categories.map((category) => (
                      <MenuItem key={category} value={category}>
                        {category.replace('_', ' ').toUpperCase()}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Description"
                  value={formData.description}
                  onChange={(e) => handleInputChange('description', e.target.value)}
                  multiline
                  rows={2}
                />
              </Grid>
              <Grid item xs={12} md={4}>
                <FormControl fullWidth>
                  <InputLabel>Model Type</InputLabel>
                  <Select
                    value={formData.model_type}
                    label="Model Type"
                    onChange={(e) => handleInputChange('model_type', e.target.value)}
                  >
                    {modelTypes.map((model) => (
                      <MenuItem key={model} value={model}>
                        {model}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12} md={4}>
                <TextField
                  fullWidth
                  label="Temperature"
                  type="number"
                  value={formData.temperature}
                  onChange={(e) => handleInputChange('temperature', parseFloat(e.target.value))}
                  inputProps={{ min: 0, max: 2, step: 0.1 }}
                />
              </Grid>
              <Grid item xs={12} md={4}>
                <TextField
                  fullWidth
                  label="Max Tokens"
                  type="number"
                  value={formData.max_tokens}
                  onChange={(e) => handleInputChange('max_tokens', parseInt(e.target.value))}
                  inputProps={{ min: 100, max: 8000 }}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Prompt Text"
                  value={formData.prompt_text}
                  onChange={(e) => handleInputChange('prompt_text', e.target.value)}
                  multiline
                  rows={10}
                  required
                  placeholder="Enter your prompt text here. Use {content} as a placeholder for document content."
                />
              </Grid>
            </Grid>
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog} startIcon={<Cancel />}>
            Cancel
          </Button>
          <Button
            onClick={handleSave}
            variant="contained"
            disabled={loading || !formData.name || !formData.prompt_text}
            startIcon={<Save />}
          >
            {loading ? 'Saving...' : 'Save'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* View Dialog */}
      <Dialog open={viewDialog} onClose={() => setViewDialog(false)} maxWidth="lg" fullWidth>
        <DialogTitle>
          View Prompt: {selectedPrompt?.name}
        </DialogTitle>
        <DialogContent>
          {selectedPrompt && (
            <Box sx={{ mt: 2 }}>
              <Grid container spacing={2}>
                <Grid item xs={12} md={6}>
                  <Typography variant="h6" gutterBottom>Details</Typography>
                  <Typography><strong>Name:</strong> {selectedPrompt.name}</Typography>
                  <Typography><strong>Description:</strong> {selectedPrompt.description || 'No description'}</Typography>
                  <Typography><strong>Category:</strong> {selectedPrompt.category || 'general'}</Typography>
                  <Typography><strong>Model Type:</strong> {selectedPrompt.model_type || 'gpt-4'}</Typography>
                  <Typography><strong>Temperature:</strong> {selectedPrompt.temperature || 0.1}</Typography>
                  <Typography><strong>Max Tokens:</strong> {selectedPrompt.max_tokens || 2000}</Typography>
                  <Typography><strong>Status:</strong> 
                    <Chip 
                      label={selectedPrompt.is_active !== false ? 'Active' : 'Inactive'} 
                      color={selectedPrompt.is_active !== false ? 'success' : 'default'} 
                      size="small" 
                      sx={{ ml: 1 }}
                    />
                  </Typography>
                  <Typography><strong>Created:</strong> {new Date(selectedPrompt.created_at).toLocaleString()}</Typography>
                </Grid>
                <Grid item xs={12}>
                  <Typography variant="h6" gutterBottom>Prompt Text</Typography>
                  <TextField
                    multiline
                    rows={12}
                    fullWidth
                    value={selectedPrompt.prompt_text}
                    variant="outlined"
                    InputProps={{
                      readOnly: true,
                      style: { fontFamily: 'monospace', fontSize: '0.875rem' }
                    }}
                  />
                </Grid>
              </Grid>
            </Box>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setViewDialog(false)}>Close</Button>
          <Button
            onClick={() => {
              setViewDialog(false);
              handleOpenDialog(selectedPrompt);
            }}
            variant="contained"
            startIcon={<Edit />}
          >
            Edit
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default PromptsInterface;

