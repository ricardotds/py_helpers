import React, { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Button,
  TextField,
  Grid,
  Chip,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  CircularProgress,
  Alert
} from '@mui/material';
import {
  Search,
  Download,
  Visibility,
  Analytics,
  Delete
} from '@mui/icons-material';

const DocumentsInterface = () => {
  const [documents, setDocuments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDocument, setSelectedDocument] = useState(null);
  const [dialogOpen, setDialogOpen] = useState(false);

  useEffect(() => {
    fetchDocuments();
  }, []);

  const fetchDocuments = async () => {
    try {
      setLoading(true);
      const response = await fetch('http://localhost:8000/api/v1/documents/');
      if (response.ok) {
        const data = await response.json();
        setDocuments(data.items || []);
      } else {
        setError('Failed to fetch documents');
      }
    } catch (err) {
      setError('Error connecting to server');
    } finally {
      setLoading(false);
    }
  };

  const handleAnalyzeDocument = async (documentId) => {
    try {
      const response = await fetch('http://localhost:8000/api/v1/analysis/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          document_id: documentId,
          prompt_id: 1, // Default prompt
          schema_id: 1, // Default schema
          model_used: 'gpt-4-turbo-preview',
          temperature: 0.1,
          max_tokens: 4000
        }),
      });
      
      if (response.ok) {
        alert('Análise iniciada com sucesso!');
      } else {
        alert('Erro ao iniciar análise');
      }
    } catch (err) {
      alert('Erro ao conectar com o servidor');
    }
  };

  const handleDownloadDocument = async (documentId, filename) => {
    try {
      const response = await fetch(`http://localhost:8000/api/v1/documents/${documentId}/download`);
      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
      }
    } catch (err) {
      alert('Erro ao baixar documento');
    }
  };

  const filteredDocuments = documents.filter(doc =>
    doc.filename?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    doc.company_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    doc.document_type?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="400px">
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box p={3}>
      <Typography variant="h4" gutterBottom>
        Gestão de Documentos
      </Typography>
      
      {error && (
        <Alert severity="error" sx={{ mb: 3 }}>
          {error}
        </Alert>
      )}

      <Grid container spacing={2} sx={{ mb: 3 }}>
        <Grid item xs={12} md={6}>
          <TextField
            fullWidth
            variant="outlined"
            placeholder="Buscar documentos..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            InputProps={{
              startAdornment: <Search sx={{ mr: 1, color: 'text.secondary' }} />
            }}
          />
        </Grid>
        <Grid item xs={12} md={6}>
          <Button
            variant="contained"
            onClick={fetchDocuments}
            sx={{ height: '56px' }}
          >
            Atualizar Lista
          </Button>
        </Grid>
      </Grid>

      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Nome do Arquivo</TableCell>
              <TableCell>Empresa</TableCell>
              <TableCell>Tipo</TableCell>
              <TableCell>Data</TableCell>
              <TableCell>Status</TableCell>
              <TableCell>Ações</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {filteredDocuments.map((doc) => (
              <TableRow key={doc.id}>
                <TableCell>{doc.filename}</TableCell>
                <TableCell>{doc.company_name || 'N/A'}</TableCell>
                <TableCell>
                  <Chip 
                    label={doc.document_type || 'Documento'} 
                    size="small" 
                    color="primary"
                  />
                </TableCell>
                <TableCell>
                  {doc.created_at ? new Date(doc.created_at).toLocaleDateString('pt-BR') : 'N/A'}
                </TableCell>
                <TableCell>
                  <Chip 
                    label={doc.processed ? 'Processado' : 'Pendente'} 
                    size="small" 
                    color={doc.processed ? 'success' : 'warning'}
                  />
                </TableCell>
                <TableCell>
                  <IconButton
                    size="small"
                    onClick={() => {
                      setSelectedDocument(doc);
                      setDialogOpen(true);
                    }}
                    title="Visualizar"
                  >
                    <Visibility />
                  </IconButton>
                  <IconButton
                    size="small"
                    onClick={() => handleDownloadDocument(doc.id, doc.filename)}
                    title="Download"
                  >
                    <Download />
                  </IconButton>
                  <IconButton
                    size="small"
                    onClick={() => handleAnalyzeDocument(doc.id)}
                    title="Analisar com IA"
                  >
                    <Analytics />
                  </IconButton>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)} maxWidth="md" fullWidth>
        <DialogTitle>Detalhes do Documento</DialogTitle>
        <DialogContent>
          {selectedDocument && (
            <Box>
              <Typography variant="h6" gutterBottom>
                {selectedDocument.filename}
              </Typography>
              <Typography variant="body2" color="textSecondary" gutterBottom>
                <strong>Empresa:</strong> {selectedDocument.company_name || 'N/A'}
              </Typography>
              <Typography variant="body2" color="textSecondary" gutterBottom>
                <strong>Tipo:</strong> {selectedDocument.document_type || 'N/A'}
              </Typography>
              <Typography variant="body2" color="textSecondary" gutterBottom>
                <strong>URL:</strong> {selectedDocument.url || 'N/A'}
              </Typography>
              <Typography variant="body2" color="textSecondary" gutterBottom>
                <strong>Tamanho:</strong> {selectedDocument.file_size ? `${Math.round(selectedDocument.file_size / 1024)} KB` : 'N/A'}
              </Typography>
              <Typography variant="body2" color="textSecondary">
                <strong>Data de Criação:</strong> {selectedDocument.created_at ? new Date(selectedDocument.created_at).toLocaleString('pt-BR') : 'N/A'}
              </Typography>
            </Box>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDialogOpen(false)}>Fechar</Button>
          {selectedDocument && (
            <>
              <Button 
                onClick={() => handleDownloadDocument(selectedDocument.id, selectedDocument.filename)}
                variant="outlined"
              >
                Download
              </Button>
              <Button 
                onClick={() => handleAnalyzeDocument(selectedDocument.id)}
                variant="contained"
              >
                Analisar com IA
              </Button>
            </>
          )}
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default DocumentsInterface;

