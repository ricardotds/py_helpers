import React, { useState, useEffect } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  IconButton,
  Tooltip,
  Alert,
  Grid,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Chip,
  Accordion,
  AccordionSummary,
  AccordionDetails
} from '@mui/material';
import {
  Add,
  Edit,
  Delete,
  Visibility,
  Schema,
  Save,
  Cancel,
  ExpandMore,
  Code
} from '@mui/icons-material';

const SchemasInterface = () => {
  const [schemas, setSchemas] = useState([]);
  const [editDialog, setEditDialog] = useState(false);
  const [viewDialog, setViewDialog] = useState(false);
  const [selectedSchema, setSelectedSchema] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    schema_json: {},
    category: 'general',
    version: '1.0',
    is_active: true
  });
  const [schemaText, setSchemaText] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [isEditing, setIsEditing] = useState(false);

  const categories = [
    'general',
    'financial_data',
    'legal_document',
    'risk_metrics',
    'compliance_check',
    'entity_extraction',
    'summary_data'
  ];

  const defaultSchema = {
    type: "object",
    properties: {
      summary: {
        type: "string",
        description: "Brief summary of the document"
      },
      key_points: {
        type: "array",
        items: {
          type: "string"
        },
        description: "List of key points extracted from the document"
      },
      confidence: {
        type: "number",
        minimum: 0,
        maximum: 1,
        description: "Confidence score of the analysis"
      }
    },
    required: ["summary"]
  };

  useEffect(() => {
    fetchSchemas();
  }, []);

  const fetchSchemas = async () => {
    try {
      const response = await fetch('/api/v1/schemas/');
      const data = await response.json();
      setSchemas(data);
    } catch (error) {
      console.error('Error fetching schemas:', error);
      setError('Failed to fetch schemas');
    }
  };

  const handleOpenDialog = (schema = null) => {
    if (schema) {
      setFormData({
        name: schema.name,
        description: schema.description,
        schema_json: schema.schema_json,
        category: schema.category || 'general',
        version: schema.version || '1.0',
        is_active: schema.is_active !== false
      });
      setSchemaText(JSON.stringify(schema.schema_json, null, 2));
      setSelectedSchema(schema);
      setIsEditing(true);
    } else {
      setFormData({
        name: '',
        description: '',
        schema_json: defaultSchema,
        category: 'general',
        version: '1.0',
        is_active: true
      });
      setSchemaText(JSON.stringify(defaultSchema, null, 2));
      setSelectedSchema(null);
      setIsEditing(false);
    }
    setEditDialog(true);
    setError('');
  };

  const handleCloseDialog = () => {
    setEditDialog(false);
    setSelectedSchema(null);
    setError('');
  };

  const handleSchemaTextChange = (value) => {
    setSchemaText(value);
    try {
      const parsedSchema = JSON.parse(value);
      setFormData(prev => ({
        ...prev,
        schema_json: parsedSchema
      }));
      setError('');
    } catch (e) {
      // Don't update formData if JSON is invalid, but don't show error yet
    }
  };

  const validateSchema = () => {
    try {
      const parsedSchema = JSON.parse(schemaText);
      
      // Basic validation
      if (!parsedSchema.type) {
        throw new Error('Schema must have a "type" property');
      }
      
      if (parsedSchema.type === 'object' && !parsedSchema.properties) {
        throw new Error('Object schema must have "properties"');
      }
      
      return parsedSchema;
    } catch (e) {
      throw new Error(`Invalid JSON Schema: ${e.message}`);
    }
  };

  const handleSave = async () => {
    if (!formData.name) {
      setError('Name is required');
      return;
    }

    try {
      const validatedSchema = validateSchema();
      const dataToSave = {
        ...formData,
        schema_json: validatedSchema
      };

      setLoading(true);
      setError('');

      const url = isEditing ? `/api/v1/schemas/${selectedSchema.id}` : '/api/v1/schemas/';
      const method = isEditing ? 'PUT' : 'POST';

      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(dataToSave),
      });

      if (response.ok) {
        handleCloseDialog();
        fetchSchemas();
      } else {
        const errorData = await response.json();
        setError(errorData.detail || 'Failed to save schema');
      }
    } catch (error) {
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (schemaId) => {
    if (!window.confirm('Are you sure you want to delete this schema?')) {
      return;
    }

    try {
      const response = await fetch(`/api/v1/schemas/${schemaId}`, {
        method: 'DELETE',
      });

      if (response.ok) {
        fetchSchemas();
      } else {
        setError('Failed to delete schema');
      }
    } catch (error) {
      setError('Network error occurred');
      console.error('Error deleting schema:', error);
    }
  };

  const handleView = (schema) => {
    setSelectedSchema(schema);
    setViewDialog(true);
  };

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const insertTemplate = (template) => {
    let templateSchema;
    
    switch (template) {
      case 'financial':
        templateSchema = {
          type: "object",
          properties: {
            company_name: { type: "string", description: "Name of the company" },
            emission_value: { type: "number", description: "Total emission value" },
            interest_rate: { type: "number", description: "Interest rate percentage" },
            maturity_date: { type: "string", format: "date", description: "Maturity date" },
            risk_rating: { type: "string", description: "Risk rating" },
            guarantees: { 
              type: "array", 
              items: { type: "string" },
              description: "List of guarantees"
            }
          },
          required: ["company_name", "emission_value"]
        };
        break;
      case 'legal':
        templateSchema = {
          type: "object",
          properties: {
            document_type: { type: "string", description: "Type of legal document" },
            parties: {
              type: "array",
              items: { type: "string" },
              description: "Parties involved"
            },
            key_clauses: {
              type: "array",
              items: { type: "string" },
              description: "Important clauses"
            },
            obligations: {
              type: "array",
              items: { type: "string" },
              description: "Legal obligations"
            },
            compliance_status: { type: "string", description: "Compliance status" }
          },
          required: ["document_type", "parties"]
        };
        break;
      case 'extraction':
        templateSchema = {
          type: "object",
          properties: {
            entities: {
              type: "object",
              properties: {
                persons: { type: "array", items: { type: "string" } },
                organizations: { type: "array", items: { type: "string" } },
                locations: { type: "array", items: { type: "string" } },
                dates: { type: "array", items: { type: "string" } },
                amounts: { type: "array", items: { type: "number" } }
              }
            },
            relationships: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  subject: { type: "string" },
                  predicate: { type: "string" },
                  object: { type: "string" }
                }
              }
            }
          },
          required: ["entities"]
        };
        break;
      default:
        templateSchema = defaultSchema;
    }
    
    setSchemaText(JSON.stringify(templateSchema, null, 2));
    handleSchemaTextChange(JSON.stringify(templateSchema, null, 2));
  };

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h4" gutterBottom>
        Output Schemas Management
      </Typography>

      {error && (
        <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError('')}>
          {error}
        </Alert>
      )}

      <Grid container spacing={3}>
        {/* Controls */}
        <Grid item xs={12}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                <Schema sx={{ mr: 1, verticalAlign: 'middle' }} />
                Schema Management
              </Typography>
              <Button
                variant="contained"
                color="primary"
                onClick={() => handleOpenDialog()}
                startIcon={<Add />}
              >
                Create New Schema
              </Button>
            </CardContent>
          </Card>
        </Grid>

        {/* Schemas Table */}
        <Grid item xs={12}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Available Schemas ({schemas.length})
              </Typography>
              <TableContainer component={Paper}>
                <Table>
                  <TableHead>
                    <TableRow>
                      <TableCell>Name</TableCell>
                      <TableCell>Description</TableCell>
                      <TableCell>Category</TableCell>
                      <TableCell>Version</TableCell>
                      <TableCell>Status</TableCell>
                      <TableCell>Created</TableCell>
                      <TableCell>Actions</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {schemas.map((schema) => (
                      <TableRow key={schema.id}>
                        <TableCell>
                          <Typography variant="subtitle2">{schema.name}</Typography>
                        </TableCell>
                        <TableCell>
                          <Typography variant="body2" color="text.secondary">
                            {schema.description || 'No description'}
                          </Typography>
                        </TableCell>
                        <TableCell>
                          <Chip 
                            label={schema.category || 'general'} 
                            size="small" 
                            variant="outlined"
                          />
                        </TableCell>
                        <TableCell>
                          <Typography variant="body2">
                            {schema.version || '1.0'}
                          </Typography>
                        </TableCell>
                        <TableCell>
                          <Chip
                            label={schema.is_active !== false ? 'Active' : 'Inactive'}
                            color={schema.is_active !== false ? 'success' : 'default'}
                            size="small"
                          />
                        </TableCell>
                        <TableCell>
                          {new Date(schema.created_at).toLocaleDateString()}
                        </TableCell>
                        <TableCell>
                          <Tooltip title="View">
                            <IconButton
                              onClick={() => handleView(schema)}
                              size="small"
                            >
                              <Visibility />
                            </IconButton>
                          </Tooltip>
                          <Tooltip title="Edit">
                            <IconButton
                              onClick={() => handleOpenDialog(schema)}
                              size="small"
                            >
                              <Edit />
                            </IconButton>
                          </Tooltip>
                          <Tooltip title="Delete">
                            <IconButton
                              onClick={() => handleDelete(schema.id)}
                              size="small"
                              color="error"
                            >
                              <Delete />
                            </IconButton>
                          </Tooltip>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Edit/Create Dialog */}
      <Dialog open={editDialog} onClose={handleCloseDialog} maxWidth="lg" fullWidth>
        <DialogTitle>
          <Schema sx={{ mr: 1, verticalAlign: 'middle' }} />
          {isEditing ? 'Edit Schema' : 'Create New Schema'}
        </DialogTitle>
        <DialogContent>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, mt: 2 }}>
            <Grid container spacing={2}>
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="Name"
                  value={formData.name}
                  onChange={(e) => handleInputChange('name', e.target.value)}
                  required
                />
              </Grid>
              <Grid item xs={12} md={3}>
                <FormControl fullWidth>
                  <InputLabel>Category</InputLabel>
                  <Select
                    value={formData.category}
                    label="Category"
                    onChange={(e) => handleInputChange('category', e.target.value)}
                  >
                    {categories.map((category) => (
                      <MenuItem key={category} value={category}>
                        {category.replace('_', ' ').toUpperCase()}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12} md={3}>
                <TextField
                  fullWidth
                  label="Version"
                  value={formData.version}
                  onChange={(e) => handleInputChange('version', e.target.value)}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Description"
                  value={formData.description}
                  onChange={(e) => handleInputChange('description', e.target.value)}
                  multiline
                  rows={2}
                />
              </Grid>
              <Grid item xs={12}>
                <Box sx={{ mb: 2 }}>
                  <Typography variant="h6" gutterBottom>
                    <Code sx={{ mr: 1, verticalAlign: 'middle' }} />
                    JSON Schema
                  </Typography>
                  <Box sx={{ mb: 1 }}>
                    <Button
                      size="small"
                      onClick={() => insertTemplate('financial')}
                      sx={{ mr: 1 }}
                    >
                      Financial Template
                    </Button>
                    <Button
                      size="small"
                      onClick={() => insertTemplate('legal')}
                      sx={{ mr: 1 }}
                    >
                      Legal Template
                    </Button>
                    <Button
                      size="small"
                      onClick={() => insertTemplate('extraction')}
                      sx={{ mr: 1 }}
                    >
                      Entity Extraction
                    </Button>
                    <Button
                      size="small"
                      onClick={() => insertTemplate('default')}
                    >
                      Basic Template
                    </Button>
                  </Box>
                </Box>
                <TextField
                  fullWidth
                  label="Schema Definition (JSON)"
                  value={schemaText}
                  onChange={(e) => handleSchemaTextChange(e.target.value)}
                  multiline
                  rows={15}
                  required
                  InputProps={{
                    style: { fontFamily: 'monospace', fontSize: '0.875rem' }
                  }}
                  placeholder="Enter JSON schema definition..."
                />
              </Grid>
            </Grid>
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog} startIcon={<Cancel />}>
            Cancel
          </Button>
          <Button
            onClick={handleSave}
            variant="contained"
            disabled={loading || !formData.name}
            startIcon={<Save />}
          >
            {loading ? 'Saving...' : 'Save'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* View Dialog */}
      <Dialog open={viewDialog} onClose={() => setViewDialog(false)} maxWidth="lg" fullWidth>
        <DialogTitle>
          View Schema: {selectedSchema?.name}
        </DialogTitle>
        <DialogContent>
          {selectedSchema && (
            <Box sx={{ mt: 2 }}>
              <Grid container spacing={2}>
                <Grid item xs={12} md={6}>
                  <Typography variant="h6" gutterBottom>Details</Typography>
                  <Typography><strong>Name:</strong> {selectedSchema.name}</Typography>
                  <Typography><strong>Description:</strong> {selectedSchema.description || 'No description'}</Typography>
                  <Typography><strong>Category:</strong> {selectedSchema.category || 'general'}</Typography>
                  <Typography><strong>Version:</strong> {selectedSchema.version || '1.0'}</Typography>
                  <Typography><strong>Status:</strong> 
                    <Chip 
                      label={selectedSchema.is_active !== false ? 'Active' : 'Inactive'} 
                      color={selectedSchema.is_active !== false ? 'success' : 'default'} 
                      size="small" 
                      sx={{ ml: 1 }}
                    />
                  </Typography>
                  <Typography><strong>Created:</strong> {new Date(selectedSchema.created_at).toLocaleString()}</Typography>
                </Grid>
                <Grid item xs={12}>
                  <Accordion>
                    <AccordionSummary expandIcon={<ExpandMore />}>
                      <Typography variant="h6">Schema Definition</Typography>
                    </AccordionSummary>
                    <AccordionDetails>
                      <TextField
                        multiline
                        rows={15}
                        fullWidth
                        value={JSON.stringify(selectedSchema.schema_json, null, 2)}
                        variant="outlined"
                        InputProps={{
                          readOnly: true,
                          style: { fontFamily: 'monospace', fontSize: '0.875rem' }
                        }}
                      />
                    </AccordionDetails>
                  </Accordion>
                </Grid>
              </Grid>
            </Box>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setViewDialog(false)}>Close</Button>
          <Button
            onClick={() => {
              setViewDialog(false);
              handleOpenDialog(selectedSchema);
            }}
            variant="contained"
            startIcon={<Edit />}
          >
            Edit
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default SchemasInterface;

