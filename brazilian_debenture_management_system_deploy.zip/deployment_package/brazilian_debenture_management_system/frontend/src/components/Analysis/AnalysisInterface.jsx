import React, { useState, useEffect } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  TextField,
  Chip,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  IconButton,
  Tooltip,
  CircularProgress,
  Alert,
  Grid,
  Accordion,
  AccordionSummary,
  AccordionDetails
} from '@mui/material';
import {
  PlayArrow,
  Stop,
  Visibility,
  Delete,
  ExpandMore,
  Analytics,
  Description,
  Schema,
  Psychology
} from '@mui/icons-material';

const AnalysisInterface = () => {
  const [documents, setDocuments] = useState([]);
  const [prompts, setPrompts] = useState([]);
  const [schemas, setSchemas] = useState([]);
  const [analyses, setAnalyses] = useState([]);
  const [selectedDocument, setSelectedDocument] = useState('');
  const [selectedPrompt, setSelectedPrompt] = useState('');
  const [selectedSchema, setSelectedSchema] = useState('');
  const [analysisDialog, setAnalysisDialog] = useState(false);
  const [viewDialog, setViewDialog] = useState(false);
  const [selectedAnalysis, setSelectedAnalysis] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchDocuments();
    fetchPrompts();
    fetchSchemas();
    fetchAnalyses();
  }, []);

  const fetchDocuments = async () => {
    try {
      const response = await fetch('/api/v1/documents/');
      const data = await response.json();
      setDocuments(data);
    } catch (error) {
      console.error('Error fetching documents:', error);
    }
  };

  const fetchPrompts = async () => {
    try {
      const response = await fetch('/api/v1/prompts/');
      const data = await response.json();
      setPrompts(data);
    } catch (error) {
      console.error('Error fetching prompts:', error);
    }
  };

  const fetchSchemas = async () => {
    try {
      const response = await fetch('/api/v1/schemas/');
      const data = await response.json();
      setSchemas(data);
    } catch (error) {
      console.error('Error fetching schemas:', error);
    }
  };

  const fetchAnalyses = async () => {
    try {
      const response = await fetch('/api/v1/analysis/');
      const data = await response.json();
      setAnalyses(data);
    } catch (error) {
      console.error('Error fetching analyses:', error);
    }
  };

  const handleStartAnalysis = async () => {
    if (!selectedDocument || !selectedPrompt) {
      setError('Please select both a document and a prompt');
      return;
    }

    setLoading(true);
    setError('');

    try {
      const response = await fetch('/api/v1/analysis/analyze', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          document_id: parseInt(selectedDocument),
          prompt_id: parseInt(selectedPrompt),
          schema_id: selectedSchema ? parseInt(selectedSchema) : null,
        }),
      });

      if (response.ok) {
        setAnalysisDialog(false);
        setSelectedDocument('');
        setSelectedPrompt('');
        setSelectedSchema('');
        fetchAnalyses();
      } else {
        const errorData = await response.json();
        setError(errorData.detail || 'Failed to start analysis');
      }
    } catch (error) {
      setError('Network error occurred');
      console.error('Error starting analysis:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleViewAnalysis = (analysis) => {
    setSelectedAnalysis(analysis);
    setViewDialog(true);
  };

  const handleDeleteAnalysis = async (analysisId) => {
    if (!window.confirm('Are you sure you want to delete this analysis?')) {
      return;
    }

    try {
      const response = await fetch(`/api/v1/analysis/${analysisId}`, {
        method: 'DELETE',
      });

      if (response.ok) {
        fetchAnalyses();
      } else {
        setError('Failed to delete analysis');
      }
    } catch (error) {
      setError('Network error occurred');
      console.error('Error deleting analysis:', error);
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'completed':
        return 'success';
      case 'running':
        return 'warning';
      case 'failed':
        return 'error';
      default:
        return 'default';
    }
  };

  const formatAnalysisResult = (result) => {
    if (!result) return 'No result available';
    
    if (typeof result === 'string') {
      return result;
    }
    
    if (result.content) {
      return JSON.stringify(result.content, null, 2);
    }
    
    return JSON.stringify(result, null, 2);
  };

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h4" gutterBottom>
        Document Analysis
      </Typography>

      {error && (
        <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError('')}>
          {error}
        </Alert>
      )}

      <Grid container spacing={3}>
        {/* Analysis Controls */}
        <Grid item xs={12}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                <Analytics sx={{ mr: 1, verticalAlign: 'middle' }} />
                Start New Analysis
              </Typography>
              <Button
                variant="contained"
                color="primary"
                onClick={() => setAnalysisDialog(true)}
                startIcon={<PlayArrow />}
                disabled={loading}
              >
                New Analysis
              </Button>
            </CardContent>
          </Card>
        </Grid>

        {/* Recent Analyses */}
        <Grid item xs={12}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                <Description sx={{ mr: 1, verticalAlign: 'middle' }} />
                Recent Analyses
              </Typography>
              <TableContainer component={Paper}>
                <Table>
                  <TableHead>
                    <TableRow>
                      <TableCell>Document</TableCell>
                      <TableCell>Prompt</TableCell>
                      <TableCell>Schema</TableCell>
                      <TableCell>Status</TableCell>
                      <TableCell>Started</TableCell>
                      <TableCell>Duration</TableCell>
                      <TableCell>Actions</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {analyses.map((analysis) => (
                      <TableRow key={analysis.id}>
                        <TableCell>
                          {analysis.document?.title || `Document ${analysis.document_id}`}
                        </TableCell>
                        <TableCell>
                          {analysis.prompt?.name || `Prompt ${analysis.prompt_id}`}
                        </TableCell>
                        <TableCell>
                          {analysis.schema?.name || (analysis.schema_id ? `Schema ${analysis.schema_id}` : 'None')}
                        </TableCell>
                        <TableCell>
                          <Chip
                            label={analysis.status}
                            color={getStatusColor(analysis.status)}
                            size="small"
                          />
                        </TableCell>
                        <TableCell>
                          {new Date(analysis.started_at).toLocaleString()}
                        </TableCell>
                        <TableCell>
                          {analysis.processing_time ? `${analysis.processing_time.toFixed(2)}s` : '-'}
                        </TableCell>
                        <TableCell>
                          <Tooltip title="View Results">
                            <IconButton
                              onClick={() => handleViewAnalysis(analysis)}
                              size="small"
                            >
                              <Visibility />
                            </IconButton>
                          </Tooltip>
                          <Tooltip title="Delete">
                            <IconButton
                              onClick={() => handleDeleteAnalysis(analysis.id)}
                              size="small"
                              color="error"
                            >
                              <Delete />
                            </IconButton>
                          </Tooltip>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* New Analysis Dialog */}
      <Dialog open={analysisDialog} onClose={() => setAnalysisDialog(false)} maxWidth="md" fullWidth>
        <DialogTitle>
          <Psychology sx={{ mr: 1, verticalAlign: 'middle' }} />
          Start New Analysis
        </DialogTitle>
        <DialogContent>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, mt: 2 }}>
            <FormControl fullWidth>
              <InputLabel>Document</InputLabel>
              <Select
                value={selectedDocument}
                label="Document"
                onChange={(e) => setSelectedDocument(e.target.value)}
              >
                {documents.map((doc) => (
                  <MenuItem key={doc.id} value={doc.id}>
                    {doc.title} ({doc.document_type})
                  </MenuItem>
                ))}
              </Select>
            </FormControl>

            <FormControl fullWidth>
              <InputLabel>System Prompt</InputLabel>
              <Select
                value={selectedPrompt}
                label="System Prompt"
                onChange={(e) => setSelectedPrompt(e.target.value)}
              >
                {prompts.map((prompt) => (
                  <MenuItem key={prompt.id} value={prompt.id}>
                    {prompt.name} - {prompt.description}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>

            <FormControl fullWidth>
              <InputLabel>Output Schema (Optional)</InputLabel>
              <Select
                value={selectedSchema}
                label="Output Schema (Optional)"
                onChange={(e) => setSelectedSchema(e.target.value)}
              >
                <MenuItem value="">None</MenuItem>
                {schemas.map((schema) => (
                  <MenuItem key={schema.id} value={schema.id}>
                    {schema.name} - {schema.description}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setAnalysisDialog(false)}>Cancel</Button>
          <Button
            onClick={handleStartAnalysis}
            variant="contained"
            disabled={loading || !selectedDocument || !selectedPrompt}
            startIcon={loading ? <CircularProgress size={20} /> : <PlayArrow />}
          >
            {loading ? 'Starting...' : 'Start Analysis'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* View Analysis Results Dialog */}
      <Dialog open={viewDialog} onClose={() => setViewDialog(false)} maxWidth="lg" fullWidth>
        <DialogTitle>
          Analysis Results
        </DialogTitle>
        <DialogContent>
          {selectedAnalysis && (
            <Box sx={{ mt: 2 }}>
              <Grid container spacing={2}>
                <Grid item xs={12} md={6}>
                  <Typography variant="h6" gutterBottom>Analysis Details</Typography>
                  <Typography><strong>Document:</strong> {selectedAnalysis.document?.title}</Typography>
                  <Typography><strong>Prompt:</strong> {selectedAnalysis.prompt?.name}</Typography>
                  <Typography><strong>Schema:</strong> {selectedAnalysis.schema?.name || 'None'}</Typography>
                  <Typography><strong>Status:</strong> 
                    <Chip 
                      label={selectedAnalysis.status} 
                      color={getStatusColor(selectedAnalysis.status)} 
                      size="small" 
                      sx={{ ml: 1 }}
                    />
                  </Typography>
                  <Typography><strong>Started:</strong> {new Date(selectedAnalysis.started_at).toLocaleString()}</Typography>
                  {selectedAnalysis.completed_at && (
                    <Typography><strong>Completed:</strong> {new Date(selectedAnalysis.completed_at).toLocaleString()}</Typography>
                  )}
                  {selectedAnalysis.processing_time && (
                    <Typography><strong>Processing Time:</strong> {selectedAnalysis.processing_time.toFixed(2)}s</Typography>
                  )}
                  {selectedAnalysis.model_used && (
                    <Typography><strong>Model Used:</strong> {selectedAnalysis.model_used}</Typography>
                  )}
                </Grid>
                <Grid item xs={12}>
                  <Accordion>
                    <AccordionSummary expandIcon={<ExpandMore />}>
                      <Typography variant="h6">Analysis Results</Typography>
                    </AccordionSummary>
                    <AccordionDetails>
                      <TextField
                        multiline
                        rows={15}
                        fullWidth
                        value={formatAnalysisResult(selectedAnalysis.result)}
                        variant="outlined"
                        InputProps={{
                          readOnly: true,
                          style: { fontFamily: 'monospace', fontSize: '0.875rem' }
                        }}
                      />
                    </AccordionDetails>
                  </Accordion>
                </Grid>
                {selectedAnalysis.error_message && (
                  <Grid item xs={12}>
                    <Alert severity="error">
                      <strong>Error:</strong> {selectedAnalysis.error_message}
                    </Alert>
                  </Grid>
                )}
              </Grid>
            </Box>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setViewDialog(false)}>Close</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default AnalysisInterface;

