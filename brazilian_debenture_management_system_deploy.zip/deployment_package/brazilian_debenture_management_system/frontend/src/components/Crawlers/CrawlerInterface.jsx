import React, { useState, useEffect } from 'react';
import {
  Box,
  Grid,
  Card,
  CardContent,
  Typography,
  Button,
  CircularProgress,
  Alert,
  Chip,
  LinearProgress
} from '@mui/material';
import {
  PlayArrow,
  Stop,
  BugReport
} from '@mui/icons-material';

const CrawlerInterface = () => {
  const [agents, setAgents] = useState([]);
  const [crawlerStatus, setCrawlerStatus] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchAgents();
    fetchCrawlerStatus();
  }, []);

  const fetchAgents = async () => {
    try {
      const response = await fetch('http://localhost:8000/api/v1/crawlers/agents');
      if (response.ok) {
        const data = await response.json();
        setAgents(data);
      }
    } catch (err) {
      setError('Error fetching agents');
    }
  };

  const fetchCrawlerStatus = async () => {
    try {
      const response = await fetch('http://localhost:8000/api/v1/crawlers/status');
      if (response.ok) {
        const data = await response.json();
        setCrawlerStatus(data);
      }
    } catch (err) {
      setError('Error fetching crawler status');
    } finally {
      setLoading(false);
    }
  };

  const startCrawler = async (agentId) => {
    try {
      const response = await fetch(`http://localhost:8000/api/v1/crawlers/${agentId}/start`, {
        method: 'POST'
      });
      if (response.ok) {
        fetchCrawlerStatus();
      }
    } catch (err) {
      setError('Error starting crawler');
    }
  };

  const stopCrawler = async (agentId) => {
    try {
      const response = await fetch(`http://localhost:8000/api/v1/crawlers/${agentId}/stop`, {
        method: 'POST'
      });
      if (response.ok) {
        fetchCrawlerStatus();
      }
    } catch (err) {
      setError('Error stopping crawler');
    }
  };

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="400px">
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box p={3}>
      <Typography variant="h4" gutterBottom>
        Controle de Crawlers
      </Typography>
      
      {error && (
        <Alert severity="error" sx={{ mb: 3 }}>
          {error}
        </Alert>
      )}

      <Grid container spacing={3}>
        {agents.map((agent) => {
          const status = crawlerStatus[agent.id] || { status: 'stopped', progress: 0 };
          const isRunning = status.status === 'running';
          
          return (
            <Grid item xs={12} sm={6} md={4} key={agent.id}>
              <Card>
                <CardContent>
                  <Box display="flex" alignItems="center" mb={2}>
                    <BugReport color="primary" sx={{ mr: 1 }} />
                    <Typography variant="h6" component="div">
                      {agent.name}
                    </Typography>
                  </Box>
                  
                  <Typography variant="body2" color="textSecondary" gutterBottom>
                    {agent.description || 'Agente Fiduciário Brasileiro'}
                  </Typography>
                  
                  <Box mb={2}>
                    <Chip 
                      label={status.status === 'running' ? 'Executando' : 'Parado'}
                      color={status.status === 'running' ? 'success' : 'default'}
                      size="small"
                    />
                  </Box>
                  
                  {isRunning && (
                    <Box mb={2}>
                      <Typography variant="body2" gutterBottom>
                        Progresso: {Math.round(status.progress || 0)}%
                      </Typography>
                      <LinearProgress 
                        variant="determinate" 
                        value={status.progress || 0} 
                      />
                    </Box>
                  )}
                  
                  <Box display="flex" gap={1}>
                    <Button
                      variant="contained"
                      color="primary"
                      size="small"
                      startIcon={<PlayArrow />}
                      onClick={() => startCrawler(agent.id)}
                      disabled={isRunning}
                    >
                      Iniciar
                    </Button>
                    <Button
                      variant="outlined"
                      color="secondary"
                      size="small"
                      startIcon={<Stop />}
                      onClick={() => stopCrawler(agent.id)}
                      disabled={!isRunning}
                    >
                      Parar
                    </Button>
                  </Box>
                </CardContent>
              </Card>
            </Grid>
          );
        })}
      </Grid>
    </Box>
  );
};

export default CrawlerInterface;

