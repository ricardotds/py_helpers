# Brazilian Debenture Management System - Deployment Guide

This guide provides comprehensive instructions for deploying the Brazilian Debenture Management System in both development and production environments.

## 📋 Prerequisites

### System Requirements
- **Operating System:** Linux (Ubuntu 20.04+ recommended), macOS, or Windows with WSL2
- **Memory:** Minimum 4GB RAM (8GB+ recommended for production)
- **Storage:** Minimum 20GB free space (100GB+ recommended for production)
- **Network:** Internet connection for downloading dependencies and accessing fiduciary agent websites

### Required Software
- **Docker:** Version 20.10+
- **Docker Compose:** Version 2.0+
- **Git:** For version control (optional but recommended)

### Installation Commands

#### Ubuntu/Debian
```bash
# Update package index
sudo apt update

# Install Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh
sudo usermod -aG docker $USER

# Install Docker Compose
sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose

# Logout and login again to apply group changes
```

#### macOS
```bash
# Install Docker Desktop from https://www.docker.com/products/docker-desktop
# Docker Compose is included with Docker Desktop
```

#### Windows
```bash
# Install Docker Desktop from https://www.docker.com/products/docker-desktop
# Enable WSL2 integration
```

## 🚀 Quick Start (Development)

### 1. Clone or Extract the Application
```bash
# If using the provided archive
tar -xzf brazilian_debenture_management_system.tar.gz
cd debenture_management_app

# Or if using git
git clone <repository-url>
cd debenture_management_app
```

### 2. Configure Environment
```bash
# Copy environment template
cp .env.example .env

# Edit configuration (required)
nano .env
```

**Required Environment Variables:**
```env
# OpenAI API Key (required for document analysis)
OPENAI_API_KEY=your-openai-api-key-here

# Database password (change from default)
POSTGRES_PASSWORD=your_secure_password_here

# Application secret key (change from default)
SECRET_KEY=your-super-secret-key-change-in-production
```

### 3. Deploy Development Environment
```bash
# Make scripts executable
chmod +x scripts/*.sh

# Deploy development environment
./scripts/deploy.sh development
```

### 4. Access the Application
- **Frontend:** http://localhost
- **Backend API:** http://localhost:8000
- **API Documentation:** http://localhost:8000/docs

## 🏭 Production Deployment

### 1. Prepare Production Environment

#### Server Setup
```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install required packages
sudo apt install -y curl wget git htop

# Configure firewall
sudo ufw allow 22    # SSH
sudo ufw allow 80    # HTTP
sudo ufw allow 443   # HTTPS
sudo ufw enable
```

#### SSL Certificates
```bash
# Create SSL directory
mkdir -p nginx/ssl

# Option 1: Self-signed certificates (for testing)
openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
  -keyout nginx/ssl/key.pem \
  -out nginx/ssl/cert.pem

# Option 2: Let's Encrypt (recommended for production)
# Install certbot and obtain certificates
sudo apt install certbot
sudo certbot certonly --standalone -d yourdomain.com
sudo cp /etc/letsencrypt/live/yourdomain.com/fullchain.pem nginx/ssl/cert.pem
sudo cp /etc/letsencrypt/live/yourdomain.com/privkey.pem nginx/ssl/key.pem
```

### 2. Configure Production Environment
```bash
# Copy and edit production environment
cp .env.example .env
nano .env
```

**Production Environment Variables:**
```env
# Database (use strong passwords)
POSTGRES_PASSWORD=very_secure_production_password
POSTGRES_USER=debenture_user
POSTGRES_DB=debenture_production

# Application security
SECRET_KEY=very-long-random-secret-key-for-production
DEBUG=false
CORS_ORIGINS=["https://yourdomain.com"]

# OpenAI
OPENAI_API_KEY=your-production-openai-api-key

# Email notifications (optional)
SMTP_HOST=smtp.yourdomain.com
SMTP_USER=noreply@yourdomain.com
SMTP_PASSWORD=your-smtp-password

# Monitoring (optional)
SENTRY_DSN=your-sentry-dsn-for-error-tracking
```

### 3. Deploy Production Environment
```bash
# Deploy production environment
./scripts/deploy.sh production

# Enable monitoring (optional)
docker-compose -f docker-compose.prod.yml --profile monitoring up -d
```

### 4. Configure Domain and DNS
```bash
# Update nginx configuration with your domain
sed -i 's/server_name _;/server_name yourdomain.com;/g' nginx/nginx.prod.conf

# Restart nginx
docker-compose -f docker-compose.prod.yml restart nginx
```

## 🔧 Configuration Options

### Database Configuration
```env
# PostgreSQL settings
POSTGRES_DB=debenture_management
POSTGRES_USER=postgres
POSTGRES_PASSWORD=secure_password
POSTGRES_PORT=5432
```

### Crawler Configuration
```env
# Crawler behavior
CRAWLER_DELAY=1.0                    # Delay between requests (seconds)
MAX_CONCURRENT_CRAWLERS=3            # Maximum concurrent crawlers
DOWNLOAD_TIMEOUT=30                  # Download timeout (seconds)
```

### Storage Configuration
```env
# File storage paths
STORAGE_PATH=/app/storage
DOCUMENTS_PATH=/app/storage/documents
LOGS_PATH=/app/logs
```

### Security Configuration
```env
# Application security
SECRET_KEY=your-secret-key
DEBUG=false
CORS_ORIGINS=["https://yourdomain.com"]

# Rate limiting (requests per second)
API_RATE_LIMIT=10
LOGIN_RATE_LIMIT=1
```

## 📊 Monitoring and Maintenance

### Health Checks
```bash
# Check service status
docker-compose ps

# Check service health
curl http://localhost:8000/health
curl http://localhost/health

# View logs
docker-compose logs -f backend
docker-compose logs -f frontend
```

### Backup and Restore
```bash
# Create backup
./scripts/backup.sh

# List available backups
ls -la backups/

# Restore from backup
./scripts/restore.sh 20241221_143000
```

### Updates
```bash
# Update to latest version
./scripts/update.sh production

# View update logs
docker-compose logs -f
```

### Performance Monitoring
```bash
# Enable monitoring stack
docker-compose -f docker-compose.prod.yml --profile monitoring up -d

# Access monitoring dashboards
# Prometheus: http://localhost:9090
# Grafana: http://localhost:3000 (admin/admin)
```

## 🔒 Security Best Practices

### 1. Environment Security
- Use strong, unique passwords for all services
- Keep environment variables secure and never commit them to version control
- Regularly rotate API keys and passwords
- Use HTTPS in production with valid SSL certificates

### 2. Network Security
- Configure firewall to only allow necessary ports
- Use VPN or private networks for database access
- Implement rate limiting and DDoS protection
- Monitor access logs for suspicious activity

### 3. Application Security
- Keep all dependencies updated
- Regularly scan for vulnerabilities
- Implement proper authentication and authorization
- Use secure headers and CORS policies

### 4. Data Security
- Encrypt sensitive data at rest and in transit
- Implement regular backups with encryption
- Use secure file storage with proper permissions
- Implement data retention policies

## 🚨 Troubleshooting

### Common Issues

#### 1. Services Won't Start
```bash
# Check Docker daemon
sudo systemctl status docker

# Check logs
docker-compose logs

# Restart services
docker-compose restart
```

#### 2. Database Connection Issues
```bash
# Check database status
docker-compose exec postgres pg_isready

# Reset database
docker-compose down -v
docker-compose up -d
```

#### 3. Permission Issues
```bash
# Fix file permissions
sudo chown -R $USER:$USER storage/ logs/
chmod -R 755 storage/ logs/
```

#### 4. SSL Certificate Issues
```bash
# Check certificate validity
openssl x509 -in nginx/ssl/cert.pem -text -noout

# Regenerate self-signed certificate
openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
  -keyout nginx/ssl/key.pem -out nginx/ssl/cert.pem
```

### Performance Issues

#### 1. High Memory Usage
```bash
# Check memory usage
docker stats

# Adjust resource limits in docker-compose.prod.yml
# Restart services
docker-compose -f docker-compose.prod.yml restart
```

#### 2. Slow Database Queries
```bash
# Check database performance
docker-compose exec postgres psql -U postgres -d debenture_management -c "SELECT * FROM pg_stat_activity;"

# Optimize database
docker-compose exec postgres psql -U postgres -d debenture_management -c "VACUUM ANALYZE;"
```

#### 3. Crawler Performance
```bash
# Adjust crawler settings in .env
CRAWLER_DELAY=2.0
MAX_CONCURRENT_CRAWLERS=2

# Restart backend
docker-compose restart backend
```

## 📞 Support and Maintenance

### Log Locations
- **Application Logs:** `logs/`
- **Nginx Logs:** `logs/nginx/`
- **Database Logs:** Available via `docker-compose logs postgres`

### Backup Schedule
- **Automatic Backups:** Configured via cron in production
- **Manual Backups:** Use `./scripts/backup.sh`
- **Retention:** 30 days by default

### Update Schedule
- **Security Updates:** Apply immediately
- **Feature Updates:** Test in development first
- **Dependencies:** Update monthly

### Contact Information
For technical support and questions:
- **Documentation:** Check README.md and API documentation
- **Issues:** Create detailed issue reports with logs
- **Updates:** Monitor for new releases and security patches

## 🎯 Next Steps

After successful deployment:

1. **Configure Crawlers:** Set up individual crawler schedules
2. **Create Users:** Set up user accounts and permissions
3. **Configure Analysis:** Create custom prompts and schemas
4. **Monitor Performance:** Set up alerts and monitoring
5. **Schedule Backups:** Implement automated backup strategy
6. **Plan Updates:** Establish update and maintenance schedule

The Brazilian Debenture Management System is now ready for production use!

