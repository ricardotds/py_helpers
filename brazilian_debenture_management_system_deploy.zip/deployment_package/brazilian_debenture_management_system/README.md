# Brazilian Debenture Management System

A comprehensive Python application for managing web crawlers that retrieve PDF files from Brazilian Fiduciary Agents, with document analysis capabilities using LangChain and customizable prompts.

## Features

### Core Functionality
- **Web Crawlers**: Automated crawlers for 9 major Brazilian Fiduciary Agents
- **Document Management**: Comprehensive PDF document storage and organization
- **LangChain Integration**: AI-powered document analysis with customizable prompts
- **Structured Output**: Configurable schemas for consistent data extraction
- **Real-time Dashboard**: Live monitoring of crawler status and system metrics

### Supported Fiduciary Agents
1. Pentágono S.A. Distribuidora de Títulos e Valores Mobiliários (DTVM)
2. Vórtx DTVM Ltda.
3. Oliveira Trust DTVM S.A.
4. Planner Trustee DTVM Ltda
5. BTG Pactual Serviços Financeiros S.A. DTVM
6. BRL Trust DTVM S.A.
7. XP Investimentos CCTVM S.A.
8. Banco do Brasil S.A.
9. Itaú DTVM S.A.

### Document Types
- Debenture Emissions (Escrituras de Emissão)
- Corporate Events (Eventos Societários)
- Shareholder Meetings (Assembleias)
- Financial Reports (Relatórios Financeiros)
- Covenants and Compliance Documents
- Investor Relations Materials

## Architecture

### Backend (FastAPI)
```
app/
├── api/v1/endpoints/     # API endpoints
├── config/               # Configuration files
├── core/                 # Core utilities and security
├── crawlers/             # Web crawler modules
├── db/                   # Database initialization
├── models/               # SQLAlchemy models
├── schemas/              # Pydantic schemas
└── services/             # Business logic services
```

### Frontend (React TypeScript)
```
frontend/
├── src/
│   ├── components/       # React components
│   ├── hooks/           # Custom React hooks
│   ├── lib/             # Utility functions
│   └── assets/          # Static assets
```

### Database Schema
- **FiduciaryAgent**: Agent information and configuration
- **Document**: PDF file metadata and storage
- **CrawlerRun**: Crawler execution history
- **SystemPrompt**: LangChain prompts for analysis
- **OutputSchema**: Structured output definitions
- **DocumentAnalysis**: Analysis results and metadata

## Installation

### Prerequisites
- Python 3.11+
- Node.js 20+
- SQLite (default) or PostgreSQL
- OpenAI API key (for LangChain features)

### Backend Setup

1. **Clone and navigate to the project**:
```bash
cd debenture_management_app
```

2. **Install Python dependencies**:
```bash
pip install -r requirements.txt
```

3. **Set environment variables**:
```bash
# Create .env file
cp .env.example .env

# Edit .env with your configuration
export OPENAI_API_KEY="your-openai-api-key"
export DATABASE_URL="sqlite:///./debenture_management.db"
```

4. **Initialize database and run server**:
```bash
python run.py
```

The backend will be available at `http://localhost:8000`

### Frontend Setup

1. **Navigate to frontend directory**:
```bash
cd frontend
```

2. **Install dependencies**:
```bash
pnpm install
```

3. **Start development server**:
```bash
pnpm run dev --host
```

The frontend will be available at `http://localhost:5173`

## Usage

### Starting Crawlers

1. **Access the Dashboard**: Navigate to the main dashboard to see system overview
2. **Crawler Control**: Go to "Controle de Crawlers" section
3. **Start Individual Crawlers**: Click "Iniciar" button for each fiduciary agent
4. **Monitor Progress**: Watch real-time status updates and document counts

### Document Management

1. **View Documents**: Access "Documentos" section to browse all downloaded files
2. **Filter and Search**: Use filters to find specific documents by:
   - Company name
   - Asset code
   - Document type
   - Processing status
   - Fiduciary agent
3. **Download Files**: Click download button to access original PDF files

### Document Analysis

1. **Select Documents**: Choose documents for analysis
2. **Configure Analysis**: Select or create:
   - System prompts for analysis instructions
   - Output schemas for structured data extraction
3. **Run Analysis**: Execute LangChain-powered analysis
4. **Review Results**: View structured analysis results and validation status

### Prompt Management

1. **Create Prompts**: Design custom analysis prompts for different document types
2. **Version Control**: Manage prompt versions and track usage
3. **Categories**: Organize prompts by category (debenture, covenant, financial)
4. **Testing**: Test prompts with sample text before deployment

### Schema Management

1. **Define Schemas**: Create JSON schemas for structured output
2. **Validation**: Ensure analysis results conform to defined schemas
3. **Templates**: Use pre-built templates for common document types
4. **Field Mapping**: Define required and optional fields for extraction

## API Documentation

### Crawler Endpoints
- `POST /api/v1/crawlers/{agent_id}/start` - Start crawler for specific agent
- `POST /api/v1/crawlers/{agent_id}/stop` - Stop running crawler
- `GET /api/v1/crawlers/status` - Get status of all crawlers
- `GET /api/v1/crawlers/{agent_id}/runs` - Get crawler run history

### Document Endpoints
- `GET /api/v1/documents/` - List documents with filtering
- `GET /api/v1/documents/{id}` - Get document details
- `GET /api/v1/documents/{id}/download` - Download PDF file
- `GET /api/v1/documents/stats/overview` - Get document statistics

### Analysis Endpoints
- `POST /api/v1/analysis/` - Create new analysis
- `POST /api/v1/analysis/bulk` - Bulk analysis creation
- `GET /api/v1/analysis/{id}` - Get analysis results
- `POST /api/v1/analysis/{id}/validate` - Validate analysis results

### Prompt Management
- `GET /api/v1/prompts/` - List system prompts
- `POST /api/v1/prompts/` - Create new prompt
- `PUT /api/v1/prompts/{id}` - Update prompt
- `DELETE /api/v1/prompts/{id}` - Delete prompt

### Schema Management
- `GET /api/v1/schemas/` - List output schemas
- `POST /api/v1/schemas/` - Create new schema
- `PUT /api/v1/schemas/{id}` - Update schema
- `POST /api/v1/schemas/{id}/validate` - Validate data against schema

## Configuration

### Environment Variables

```bash
# Database
DATABASE_URL=sqlite:///./debenture_management.db

# OpenAI (for LangChain)
OPENAI_API_KEY=your-openai-api-key
OPENAI_API_BASE=https://api.openai.com/v1

# Application
SECRET_KEY=your-secret-key
DEBUG=false
CORS_ORIGINS=["http://localhost:3000", "http://localhost:5173"]

# Crawler Settings
CRAWLER_DELAY=1.0
MAX_CONCURRENT_CRAWLERS=3
DOWNLOAD_TIMEOUT=30
```

### Crawler Configuration

Each crawler can be configured with:
- **Delay between requests**: Respect rate limits
- **Retry logic**: Handle temporary failures
- **File filters**: Specify document types to download
- **Date ranges**: Control historical data retrieval

### LangChain Configuration

- **Model Selection**: Choose OpenAI models (GPT-3.5, GPT-4)
- **Temperature**: Control response creativity
- **Max Tokens**: Limit response length
- **Custom Prompts**: Tailor analysis for specific needs

## Deployment

### Production Deployment

1. **Backend Deployment**:
```bash
# Build and deploy backend
pip install -r requirements.txt
python run.py --no-init
```

2. **Frontend Deployment**:
```bash
# Build frontend
cd frontend
pnpm run build

# Deploy static files
cp -r dist/* /var/www/html/
```

3. **Database Migration**:
```bash
# For production database
python -c "from app.db.init_db import init_db; init_db()"
```

### Docker Deployment

```dockerfile
# Dockerfile example
FROM python:3.11-slim

WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt

COPY . .
EXPOSE 8000

CMD ["python", "run.py"]
```

## Monitoring and Maintenance

### System Health
- **Dashboard Monitoring**: Real-time system status
- **Crawler Health**: Monitor for stuck or failed crawlers
- **Storage Usage**: Track document storage growth
- **Analysis Performance**: Monitor processing times and success rates

### Maintenance Tasks
- **Database Cleanup**: Remove old crawler logs and failed analyses
- **File Management**: Archive or compress old documents
- **Performance Optimization**: Monitor and optimize slow queries
- **Security Updates**: Keep dependencies updated

## Troubleshooting

### Common Issues

1. **Crawler Failures**:
   - Check website accessibility
   - Verify crawler configuration
   - Review error logs

2. **Analysis Errors**:
   - Validate OpenAI API key
   - Check prompt and schema compatibility
   - Review document text extraction

3. **Database Issues**:
   - Check database connectivity
   - Verify table creation
   - Review migration status

### Logging

Logs are available in:
- **Application logs**: Console output with structured logging
- **Crawler logs**: Detailed crawler execution logs
- **Analysis logs**: LangChain processing logs
- **Error logs**: Exception tracking and debugging

## Contributing

### Development Setup
1. Fork the repository
2. Create feature branch
3. Install development dependencies
4. Run tests
5. Submit pull request

### Code Standards
- **Python**: Follow PEP 8 style guide
- **TypeScript**: Use ESLint and Prettier
- **Documentation**: Update README and API docs
- **Testing**: Add tests for new features

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

For support and questions:
- **Documentation**: Check this README and API documentation
- **Issues**: Create GitHub issues for bugs and feature requests
- **Discussions**: Use GitHub discussions for questions

## Acknowledgments

- **FastAPI**: Modern Python web framework
- **React**: Frontend user interface library
- **LangChain**: AI/ML integration framework
- **Material-UI**: React component library
- **Brazilian Financial Market**: Data sources and regulations

