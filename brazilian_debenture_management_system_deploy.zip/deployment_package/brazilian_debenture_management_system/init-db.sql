-- Brazilian Debenture Management System - Database Initialization
-- This script creates the initial database structure and default data

-- Create database if it doesn't exist
SELECT 'CREATE DATABASE debenture_management'
WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = 'debenture_management');

-- Connect to the database
\c debenture_management;

-- Create extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_documents_agent_id ON documents(fiduciary_agent_id);
CREATE INDEX IF NOT EXISTS idx_documents_created_at ON documents(created_at);
CREATE INDEX IF NOT EXISTS idx_documents_file_hash ON documents(file_hash);
CREATE INDEX IF NOT EXISTS idx_crawler_runs_agent_id ON crawler_runs(fiduciary_agent_id);
CREATE INDEX IF NOT EXISTS idx_crawler_runs_status ON crawler_runs(status);
CREATE INDEX IF NOT EXISTS idx_document_analyses_document_id ON document_analyses(document_id);

-- Create full-text search indexes
CREATE INDEX IF NOT EXISTS idx_documents_title_fts ON documents USING gin(to_tsvector('portuguese', title));
CREATE INDEX IF NOT EXISTS idx_documents_content_fts ON documents USING gin(to_tsvector('portuguese', content));

-- Insert default system prompts
INSERT INTO system_prompts (name, description, prompt_text, is_active) VALUES
('default_analysis', 'Default document analysis prompt', 
'Analyze the following debenture document and extract key information including:
- Emission details (amount, interest rate, maturity)
- Company information (name, CNPJ, sector)
- Guarantees and collateral
- Payment terms and conditions
- Risk factors
- Use of proceeds

Document content: {content}', true),

('financial_summary', 'Financial information extraction', 
'Extract financial information from this debenture document:
- Total emission value
- Interest rate (CDI + spread or fixed rate)
- Maturity date
- Payment frequency
- Early redemption conditions
- Credit rating (if available)

Document content: {content}', true),

('risk_assessment', 'Risk factors identification', 
'Identify and categorize risk factors mentioned in this debenture document:
- Credit risk
- Market risk
- Liquidity risk
- Operational risk
- Regulatory risk
- Company-specific risks

Document content: {content}', true)
ON CONFLICT (name) DO NOTHING;

-- Insert default output schemas
INSERT INTO output_schemas (name, description, schema_json, is_active) VALUES
('debenture_basic', 'Basic debenture information schema',
'{
  "type": "object",
  "properties": {
    "company_name": {"type": "string", "description": "Name of the issuing company"},
    "cnpj": {"type": "string", "description": "Company CNPJ number"},
    "emission_value": {"type": "number", "description": "Total emission value in BRL"},
    "interest_rate": {"type": "string", "description": "Interest rate description"},
    "maturity_date": {"type": "string", "format": "date", "description": "Maturity date"},
    "guarantees": {"type": "array", "items": {"type": "string"}, "description": "List of guarantees"},
    "use_of_proceeds": {"type": "string", "description": "Intended use of proceeds"}
  },
  "required": ["company_name", "emission_value", "interest_rate", "maturity_date"]
}', true),

('financial_details', 'Detailed financial information schema',
'{
  "type": "object",
  "properties": {
    "emission_value": {"type": "number", "description": "Total emission value in BRL"},
    "unit_value": {"type": "number", "description": "Value per debenture unit"},
    "quantity": {"type": "integer", "description": "Number of debentures issued"},
    "interest_rate_type": {"type": "string", "enum": ["fixed", "floating"], "description": "Type of interest rate"},
    "interest_rate": {"type": "number", "description": "Interest rate percentage"},
    "spread": {"type": "number", "description": "Spread over CDI if applicable"},
    "payment_frequency": {"type": "string", "description": "Payment frequency"},
    "maturity_date": {"type": "string", "format": "date", "description": "Maturity date"},
    "early_redemption": {"type": "boolean", "description": "Early redemption allowed"},
    "credit_rating": {"type": "string", "description": "Credit rating if available"}
  },
  "required": ["emission_value", "interest_rate_type", "maturity_date"]
}', true),

('risk_factors', 'Risk factors schema',
'{
  "type": "object",
  "properties": {
    "credit_risk": {"type": "string", "description": "Credit risk description"},
    "market_risk": {"type": "string", "description": "Market risk description"},
    "liquidity_risk": {"type": "string", "description": "Liquidity risk description"},
    "operational_risk": {"type": "string", "description": "Operational risk description"},
    "regulatory_risk": {"type": "string", "description": "Regulatory risk description"},
    "company_risks": {"type": "array", "items": {"type": "string"}, "description": "Company-specific risks"},
    "risk_level": {"type": "string", "enum": ["low", "medium", "high"], "description": "Overall risk assessment"}
  }
}', true)
ON CONFLICT (name) DO NOTHING;

-- Create a function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Create triggers for updated_at columns
CREATE TRIGGER update_fiduciary_agents_updated_at BEFORE UPDATE ON fiduciary_agents FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_documents_updated_at BEFORE UPDATE ON documents FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_crawler_runs_updated_at BEFORE UPDATE ON crawler_runs FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_system_prompts_updated_at BEFORE UPDATE ON system_prompts FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_output_schemas_updated_at BEFORE UPDATE ON output_schemas FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_document_analyses_updated_at BEFORE UPDATE ON document_analyses FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Grant permissions
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO postgres;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO postgres;

