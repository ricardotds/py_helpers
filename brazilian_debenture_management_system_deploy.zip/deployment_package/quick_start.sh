#!/bin/bash

# Brazilian Debenture Management System - Quick Start Script

echo "🚀 Brazilian Debenture Management System - Quick Start"
echo "======================================================"

# Check if we're in the right directory
if [ ! -f "brazilian_debenture_management_system/run.py" ]; then
    echo "❌ Error: Please run this script from the deployment package root directory"
    exit 1
fi

cd brazilian_debenture_management_system

# Check Python version
echo "🐍 Checking Python version..."
python_version=$(python3 --version 2>&1 | grep -oP '\d+\.\d+')
if [ "$(echo "$python_version >= 3.11" | bc -l)" -eq 0 ]; then
    echo "❌ Error: Python 3.11+ required. Found: $python_version"
    exit 1
fi
echo "✅ Python version OK: $python_version"

# Check Node.js version
echo "📦 Checking Node.js version..."
if ! command -v node &> /dev/null; then
    echo "❌ Error: Node.js not found. Please install Node.js 18+"
    exit 1
fi
node_version=$(node --version | grep -oP '\d+')
if [ "$node_version" -lt 18 ]; then
    echo "❌ Error: Node.js 18+ required. Found: $(node --version)"
    exit 1
fi
echo "✅ Node.js version OK: $(node --version)"

# Setup environment file
echo "⚙️  Setting up environment..."
if [ ! -f ".env" ]; then
    cp .env.example .env
    echo "📝 Created .env file. Please edit it and add your OpenAI API key:"
    echo "   OPENAI_API_KEY=your_openai_api_key_here"
    echo ""
    read -p "Press Enter after you've added your OpenAI API key to .env..."
fi

# Install Python dependencies
echo "📦 Installing Python dependencies..."
pip3 install -r requirements_enhanced.txt

# Initialize database
echo "🗄️  Initializing database..."
python3 run.py --init-db

# Install frontend dependencies
echo "🎨 Installing frontend dependencies..."
cd frontend
if command -v pnpm &> /dev/null; then
    pnpm install
else
    npm install
fi
cd ..

echo ""
echo "✅ Setup complete!"
echo ""
echo "🚀 To start the application:"
echo ""
echo "1. Start the backend (in one terminal):"
echo "   cd brazilian_debenture_management_system"
echo "   python3 run.py --no-init"
echo ""
echo "2. Start the frontend (in another terminal):"
echo "   cd brazilian_debenture_management_system/frontend"
echo "   pnpm run dev --host  # or: npm run dev -- --host"
echo ""
echo "3. Access the application:"
echo "   Frontend: http://localhost:5173"
echo "   Backend API: http://localhost:8000"
echo "   API Docs: http://localhost:8000/docs"
echo ""
echo "🎉 Enjoy using the Brazilian Debenture Management System!"

