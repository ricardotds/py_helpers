# Crawler Analysis for Fiduciary Agents

## Pentágono S.A. DTVM Analysis

### Website Structure
- Main URL: https://www.pentagonotrustee.com.br/
- Investor Information: https://www.pentagonotrustee.com.br/Site/Investidores
- Debentures Filter: https://www.pentagonotrustee.com.br/Site/Investidores?tipo=1&emissor=&ativo=

### Data Structure
1. **Main Listing Page**: Shows all debentures with:
   - Razão Social (Company Name)
   - Série/Emissão (Series/Issuance)
   - Ativo (Asset Code)

2. **Individual Debenture Page**: Detailed information including:
   - Características (Characteristics): Asset code, series, volume, remuneration, ISIN, guarantee type, etc.
   - Documentos (Documents): PDF files including:
     - Escritura de Emissão (Issuance Deed)
     - Contratos de Cessão Fiduciária (Fiduciary Assignment Contracts)
     - Aditamentos (Amendments)
   - Other tabs: Publicações, Preços Unitários, Pagamentos, Saldo Devedor, Rating

### Example Data Found
- Asset: ADAG11
- Issuer: Adecoagro Vale do Ivinema S.A.
- Series: Única/1
- Remuneration: IPCA + 4,24% a.a.
- Volume: R$ 400.000.000,00
- Issue Date: 15/11/2020
- Maturity Date: 15/12/2026
- Guarantee: Real
- ISIN: BRADAGDBS008

### PDF Documents Available
- 2023.03.31 - 1º Aditamento da Cessão Fiduciária
- Contrato de Cessão Fiduciária - 2020.11.24
- Escritura de Emissão - 2020.11.24

## Implementation Strategy

### 1. Web Scraping Approach
- Use requests + BeautifulSoup for HTTP requests and HTML parsing
- Implement pagination handling for large lists
- Extract both debenture characteristics and PDF links
- Handle dynamic content loading if needed

### 2. Data Extraction Points
- Main listing: Extract all asset codes and issuer names
- Individual pages: Extract detailed characteristics and PDF links
- PDF metadata: Extract document titles, dates, and URLs

### 3. Error Handling
- Implement retry logic for failed requests
- Handle rate limiting and respectful crawling
- Validate data before insertion into database
- Log errors and failed extractions

## Next Steps
1. Implement Pentágono crawler
2. Research and analyze other fiduciary agents' websites
3. Create unified crawler interface
4. Test and validate data extraction
5. Deploy updated application



## Vórtx DTVM Analysis

### Website Structure
- Main URL: https://www.vortx.com.br/
- Debentures Page: https://www.vortx.com.br/investidor/debenture
- Individual Debenture: https://www.vortx.com.br/investidor/operacao?operacaoDataId=11132&agFiduciario=Vortx

### Data Structure
1. **Main Listing Page**: Table format with columns:
   - Ag. Fiduciário (Fiduciary Agent)
   - Emissor (Issuer)
   - Emissão (Issuance)
   - Série (Series)
   - Código If (Code)
   - PU Diário (Daily Unit Price)
   - Apelido (Nickname)

2. **Individual Debenture Page**: Comprehensive tabs including:
   - Dashboard: Main characteristics and price chart
   - Documentos: PDF documents organized by categories
   - Relatórios de Garantias: Guarantee reports
   - Assembleias: Assemblies
   - Fatos Relevantes: Relevant facts
   - Relatório do Ag. Fiduciário: Fiduciary agent reports
   - Detalhes: Details
   - Outras operações: Other operations
   - Obrigações: Obligations

### Example Data Found
- Asset: ENTV12
- Issuer: ENTREVIAS CONCESSIONARIA DE RODOVIAS S.A.
- Series: 2ª emissão - ÚNICAª série
- Remuneration: IPCA + 7,7500%
- Issue Date: 2/15/2018
- Maturity Date: 12/15/2030
- Volume: R$ 1.000.000.000,00
- ISIN: BRENTVDBS008
- Rating: AA+(bra) - Fitch Ratings

### Document Categories
- EMISSÃO DEBÊNTURES: Issuance documents
- AF AÇÕES: Fiduciary agent actions
- CESSÃO FIDUCIÁRIA: Fiduciary assignments
- COVENANTS: Covenant documents
- NOTIFICAÇÃO: Notifications
- RATING: Rating documents

### PDF Documents Available
- DEB - 2EUS - ENTREVIAS - EMISSÃO DEBÊNTURES (V JUCESP)
- DEB - 2EUS - ENTREVIAS - EMISSÃO DEBÊNTURES - 1 ADITAMENTO
- DEB - 2EUS - ENTREVIAS - EMISSÃO DEBÊNTURES (VASSINADA)
- DEB - 2EUS - ENTREVIAS - EMISSÃO DEBÊNTURES - 1 ADITAMENTO (JUCESP).PDF


## Oliveira Trust DTVM Analysis

### Website Structure
- Main URL: https://www.oliveiratrust.com.br/
- Assets Page: https://www.oliveiratrust.com.br/investidor/ativos
- Debentures Filter: https://www.oliveiratrust.com.br/investidor/ativos?tipo=debentures
- Individual Asset: https://www.oliveiratrust.com.br/investidor/ativo?id=44411&tipo=debentures&typo=debentures

### Data Structure
1. **Main Listing Page**: Card-based layout with:
   - Asset type filters (Debênture, CRI, CRA, Fundos, NC, LF, NP)
   - Search functionality
   - Asset cards showing: Series/Emission, Issuer name, Current value, Date

2. **Individual Asset Page**: Comprehensive tabs including:
   - Características do Ativo: Main characteristics
   - Índices: Indices
   - Avisos: Notices
   - Documentos: Documents organized by categories

### Example Data Found
- Asset: EBEC14
- Issuer: LET'S RENT A CAR S.A.
- Series: 1ª Série 6ª Emissão
- ISIN: BREBECDBS039
- Issue Date: 27/07/2023
- Maturity Date: 27/07/2029
- Volume: R$ 200.000.000,00
- Remuneration: CDI + 2,60000000% a.a.
- Custodian: B3 S.A. - Brasil, Bolsa, Balcão
- Registrar: OLIVEIRA TRUST DTVM S.A.

### Document Categories
- Assembleias: Assembly documents
- Contratos: Contract documents
- Relatórios: Report documents

### PDF Documents Available
- AGD 2024.01.30 (Assembly document)

## Implementation Summary

Based on the analysis of the three main fiduciary agents, I can see that:

1. **Pentágono**: Well-structured with clear navigation and comprehensive document access
2. **Vórtx**: Modern interface with detailed categorization of documents
3. **Oliveira Trust**: Card-based layout with expandable document categories

All three have similar data structures but different UI implementations. The key data points to extract are:
- Asset codes and ISIN
- Issuer information
- Series and emission details
- Dates (issue, maturity)
- Financial details (volume, remuneration)
- PDF document links and metadata

Next step: Implement real web crawlers for each fiduciary agent.

