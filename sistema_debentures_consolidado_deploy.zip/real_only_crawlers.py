"""
Real-Only Web Crawlers System for Brazilian Fiduciary Agents
NO MOCK DATA - Only real data from official websites
Version 4.0 - Real data only, no fallback
"""

import requests
from bs4 import BeautifulSoup
import time
import random
import re
from datetime import datetime, timedelta
from urllib.parse import urljoin, urlparse
import logging
import json

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class RealOnlyWebCrawler:
    """Base class for real-only web crawlers - NO MOCK DATA"""
    
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'pt-BR,pt;q=0.9,en;q=0.8',
            'Accept-Encoding': 'gzip, deflate, br',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1'
        })
        
    def safe_request(self, url, max_retries=3):
        """Make a safe HTTP request with retry logic"""
        for attempt in range(max_retries):
            try:
                logger.info(f"Requesting: {url} (attempt {attempt + 1})")
                response = self.session.get(url, timeout=30)
                response.raise_for_status()
                return response
            except requests.RequestException as e:
                logger.warning(f"Request failed (attempt {attempt + 1}): {e}")
                if attempt < max_retries - 1:
                    self.delay(2, 5)
                else:
                    logger.error(f"All attempts failed for {url}")
                    return None
        return None
        
    def delay(self, min_seconds=1, max_seconds=3):
        """Random delay to be respectful to servers"""
        delay_time = random.uniform(min_seconds, max_seconds)
        logger.info(f"Waiting {delay_time:.2f} seconds...")
        time.sleep(delay_time)
        
    def crawl(self):
        """Override in subclasses - MUST return real data only"""
        raise NotImplementedError

class PentagonoRealCrawler(RealOnlyWebCrawler):
    """Real web crawler for Pentágono S.A. DTVM - REAL DATA ONLY"""
    
    def __init__(self):
        super().__init__()
        self.base_url = "https://www.pentagonotrustee.com.br"
        
    def crawl(self):
        """Crawl Pentágono for REAL debenture data from official website"""
        logger.info("Starting Pentágono S.A. DTVM real crawler...")
        
        try:
            # Access the main page
            response = self.safe_request(self.base_url)
            if not response:
                logger.error("Failed to access Pentágono website")
                return [], []
            
            # Try to find debentures section
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # Look for investor relations or debentures links
            debentures_links = []
            for link in soup.find_all('a', href=True):
                href = link['href'].lower()
                text = link.get_text().lower()
                if any(keyword in href or keyword in text for keyword in ['debenture', 'investidor', 'investor']):
                    full_url = urljoin(self.base_url, link['href'])
                    debentures_links.append(full_url)
            
            if not debentures_links:
                logger.warning("No debentures links found on Pentágono website")
                return [], []
            
            # Try to access debentures pages and extract real data
            emissoes = []
            documentos = []
            
            for link in debentures_links[:3]:  # Limit to first 3 links
                self.delay(2, 4)
                response = self.safe_request(link)
                if response:
                    soup = BeautifulSoup(response.content, 'html.parser')
                    
                    # Extract any debenture codes found
                    text_content = soup.get_text()
                    debenture_codes = re.findall(r'[A-Z]{4}[0-9]{2}', text_content)
                    
                    for code in debenture_codes[:5]:  # Limit to 5 codes per page
                        # Only add if we can extract real information
                        emissao_data = self.extract_real_emission_data(soup, code)
                        if emissao_data:
                            emissoes.append(emissao_data)
                            
                        # Extract real documents
                        docs = self.extract_real_documents(soup, code)
                        documentos.extend(docs)
            
            logger.info(f"Pentágono crawler found {len(emissoes)} real emissions and {len(documentos)} real documents")
            return emissoes, documentos
            
        except Exception as e:
            logger.error(f"Error in Pentágono crawler: {e}")
            return [], []
    
    def extract_real_emission_data(self, soup, code):
        """Extract real emission data from webpage"""
        try:
            # Look for emission information in the page
            text_content = soup.get_text()
            
            # Try to find issuer name near the code
            lines = text_content.split('\n')
            issuer = None
            for i, line in enumerate(lines):
                if code in line:
                    # Look for company name in nearby lines
                    for j in range(max(0, i-3), min(len(lines), i+4)):
                        if 'S.A.' in lines[j] or 'LTDA' in lines[j]:
                            issuer = lines[j].strip()
                            break
                    break
            
            if not issuer:
                return None
                
            return {
                'codigo': code,
                'emissor': issuer,
                'agente_fiduciario': 'Pentágono S.A. DTVM',
                'data_coleta': datetime.now().isoformat()
            }
        except Exception as e:
            logger.error(f"Error extracting emission data: {e}")
            return None
    
    def extract_real_documents(self, soup, code):
        """Extract real document links from webpage"""
        documents = []
        try:
            # Look for PDF links
            for link in soup.find_all('a', href=True):
                href = link['href']
                if href.endswith('.pdf'):
                    title = link.get_text().strip() or f"Documento {code}"
                    full_url = urljoin(self.base_url, href)
                    
                    documents.append({
                        'titulo': title,
                        'url': full_url,
                        'codigo': code,
                        'agente_fiduciario': 'Pentágono S.A. DTVM',
                        'data_coleta': datetime.now().isoformat()
                    })
        except Exception as e:
            logger.error(f"Error extracting documents: {e}")
        
        return documents

class VortxRealCrawler(RealOnlyWebCrawler):
    """Real web crawler for Vórtx DTVM - REAL DATA ONLY"""
    
    def __init__(self):
        super().__init__()
        self.base_url = "https://www.vortx.com.br"
        
    def crawl(self):
        """Crawl Vórtx for REAL debenture data from official website"""
        logger.info("Starting Vórtx DTVM real crawler...")
        
        try:
            # Access debentures page directly
            debentures_url = f"{self.base_url}/investidor/debenture"
            response = self.safe_request(debentures_url)
            if not response:
                logger.error("Failed to access Vórtx debentures page")
                return [], []
            
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # Extract real debenture data from the page
            emissoes = []
            documentos = []
            
            # Look for debenture codes in the page
            text_content = soup.get_text()
            debenture_codes = re.findall(r'[A-Z]{4}[0-9]{2}', text_content)
            
            for code in set(debenture_codes):  # Remove duplicates
                emissao_data = self.extract_real_emission_data(soup, code)
                if emissao_data:
                    emissoes.append(emissao_data)
                    
                docs = self.extract_real_documents(soup, code)
                documentos.extend(docs)
            
            logger.info(f"Vórtx crawler found {len(emissoes)} real emissions and {len(documentos)} real documents")
            return emissoes, documentos
            
        except Exception as e:
            logger.error(f"Error in Vórtx crawler: {e}")
            return [], []
    
    def extract_real_emission_data(self, soup, code):
        """Extract real emission data from Vórtx webpage"""
        try:
            # Look for emission information
            text_content = soup.get_text()
            lines = text_content.split('\n')
            
            issuer = None
            for i, line in enumerate(lines):
                if code in line:
                    # Look for company name
                    for j in range(max(0, i-2), min(len(lines), i+3)):
                        if any(suffix in lines[j] for suffix in ['S.A.', 'LTDA', 'S/A']):
                            issuer = lines[j].strip()
                            break
                    break
            
            if issuer:
                return {
                    'codigo': code,
                    'emissor': issuer,
                    'agente_fiduciario': 'Vórtx DTVM',
                    'data_coleta': datetime.now().isoformat()
                }
        except Exception as e:
            logger.error(f"Error extracting Vórtx emission data: {e}")
        
        return None
    
    def extract_real_documents(self, soup, code):
        """Extract real document links from Vórtx webpage"""
        documents = []
        try:
            for link in soup.find_all('a', href=True):
                href = link['href']
                if href.endswith('.pdf'):
                    title = link.get_text().strip() or f"Documento {code}"
                    full_url = urljoin(self.base_url, href)
                    
                    documents.append({
                        'titulo': title,
                        'url': full_url,
                        'codigo': code,
                        'agente_fiduciario': 'Vórtx DTVM',
                        'data_coleta': datetime.now().isoformat()
                    })
        except Exception as e:
            logger.error(f"Error extracting Vórtx documents: {e}")
        
        return documents

class OliveiraTrustRealCrawler(RealOnlyWebCrawler):
    """Real web crawler for Oliveira Trust DTVM - REAL DATA ONLY"""
    
    def __init__(self):
        super().__init__()
        self.base_url = "https://www.oliveiratrust.com.br"
        
    def crawl(self):
        """Crawl Oliveira Trust for REAL debenture data from official website"""
        logger.info("Starting Oliveira Trust DTVM real crawler...")
        
        try:
            # Access debentures page
            debentures_url = f"{self.base_url}/fiduciario/pus_dt.php?ativo=Debentures"
            response = self.safe_request(debentures_url)
            if not response:
                logger.error("Failed to access Oliveira Trust debentures page")
                return [], []
            
            soup = BeautifulSoup(response.content, 'html.parser')
            
            emissoes = []
            documentos = []
            
            # Look for debenture table or list
            tables = soup.find_all('table')
            for table in tables:
                rows = table.find_all('tr')
                for row in rows:
                    cells = row.find_all(['td', 'th'])
                    if len(cells) >= 2:
                        # Look for debenture codes in cells
                        for cell in cells:
                            text = cell.get_text().strip()
                            if re.match(r'[A-Z]{4}[0-9]{2}', text):
                                # Found a debenture code
                                emissao_data = self.extract_real_emission_from_row(row, text)
                                if emissao_data:
                                    emissoes.append(emissao_data)
                                    
                                docs = self.extract_real_documents_from_row(row, text)
                                documentos.extend(docs)
            
            logger.info(f"Oliveira Trust crawler found {len(emissoes)} real emissions and {len(documentos)} real documents")
            return emissoes, documentos
            
        except Exception as e:
            logger.error(f"Error in Oliveira Trust crawler: {e}")
            return [], []
    
    def extract_real_emission_from_row(self, row, code):
        """Extract real emission data from table row"""
        try:
            cells = row.find_all(['td', 'th'])
            if len(cells) >= 2:
                # Try to find issuer in adjacent cells
                issuer = None
                for cell in cells:
                    text = cell.get_text().strip()
                    if any(suffix in text for suffix in ['S.A.', 'LTDA', 'S/A']) and code not in text:
                        issuer = text
                        break
                
                if issuer:
                    return {
                        'codigo': code,
                        'emissor': issuer,
                        'agente_fiduciario': 'Oliveira Trust DTVM',
                        'data_coleta': datetime.now().isoformat()
                    }
        except Exception as e:
            logger.error(f"Error extracting emission from row: {e}")
        
        return None
    
    def extract_real_documents_from_row(self, row, code):
        """Extract real document links from table row"""
        documents = []
        try:
            for link in row.find_all('a', href=True):
                href = link['href']
                if href.endswith('.pdf'):
                    title = link.get_text().strip() or f"Documento {code}"
                    full_url = urljoin(self.base_url, href)
                    
                    documents.append({
                        'titulo': title,
                        'url': full_url,
                        'codigo': code,
                        'agente_fiduciario': 'Oliveira Trust DTVM',
                        'data_coleta': datetime.now().isoformat()
                    })
        except Exception as e:
            logger.error(f"Error extracting documents from row: {e}")
        
        return documents

class RealOnlyCrawlerManager:
    """Manager for real-only crawlers - NO MOCK DATA"""
    
    def __init__(self):
        self.crawlers = {
            'pentagono': PentagonoRealCrawler(),
            'vortx': VortxRealCrawler(),
            'oliveira_trust': OliveiraTrustRealCrawler(),
            # Other agents will only return empty data until real crawlers are implemented
        }
    
    def run_crawler(self, agent_key):
        """Run crawler for specific agent - REAL DATA ONLY"""
        logger.info(f"Running real-only crawler for {agent_key}")
        
        if agent_key in self.crawlers:
            try:
                emissoes, documentos = self.crawlers[agent_key].crawl()
                logger.info(f"Crawler {agent_key} completed: {len(emissoes)} emissions, {len(documentos)} documents")
                return emissoes, documentos
            except Exception as e:
                logger.error(f"Error running crawler {agent_key}: {e}")
                return [], []
        else:
            logger.warning(f"Real crawler not implemented for {agent_key} - returning empty data")
            return [], []
    
    def run_all_crawlers(self):
        """Run all available real crawlers"""
        all_emissoes = []
        all_documentos = []
        
        for agent_key in self.crawlers.keys():
            emissoes, documentos = self.run_crawler(agent_key)
            all_emissoes.extend(emissoes)
            all_documentos.extend(documentos)
            
            # Respectful delay between agents
            time.sleep(random.uniform(3, 6))
        
        return all_emissoes, all_documentos

# Test the real-only system
if __name__ == "__main__":
    manager = RealOnlyCrawlerManager()
    
    # Test individual crawler
    print("Testing Pentágono real crawler...")
    emissoes, docs = manager.run_crawler('pentagono')
    print(f"Found {len(emissoes)} real emissions and {len(docs)} real documents")
    
    if emissoes:
        print("Sample emission:", emissoes[0])
    if docs:
        print("Sample document:", docs[0])

