#!/usr/bin/env python3
"""
Real Web Crawlers for Fiduciary Agents
This module implements actual web scraping for debenture information
from Brazilian fiduciary agents' websites.
"""

import requests
from bs4 import BeautifulSoup
import time
import random
from datetime import datetime
from urllib.parse import urljoin, urlparse
import re
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class BaseCrawler:
    """Base class for all fiduciary agent crawlers"""
    
    def __init__(self, agent_name):
        self.agent_name = agent_name
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        })
        
    def get_page(self, url, max_retries=3):
        """Get page content with retry logic"""
        for attempt in range(max_retries):
            try:
                response = self.session.get(url, timeout=30)
                response.raise_for_status()
                return response
            except Exception as e:
                logger.warning(f"Attempt {attempt + 1} failed for {url}: {e}")
                if attempt < max_retries - 1:
                    time.sleep(random.uniform(1, 3))
                else:
                    raise
    
    def extract_debentures(self):
        """Extract debenture information - to be implemented by subclasses"""
        raise NotImplementedError
    
    def extract_pdf_links(self, debenture_url):
        """Extract PDF links from debenture detail page - to be implemented by subclasses"""
        raise NotImplementedError

class PentagonoCrawler(BaseCrawler):
    """Crawler for Pentágono S.A. DTVM"""
    
    def __init__(self):
        super().__init__("Pentágono S.A. DTVM")
        self.base_url = "https://www.pentagonotrustee.com.br"
        self.debentures_url = f"{self.base_url}/Site/Investidores?tipo=1&emissor=&ativo="
    
    def extract_debentures(self):
        """Extract debenture information from Pentágono website"""
        debentures = []
        pdf_links = []
        
        try:
            logger.info(f"Crawling {self.agent_name} debentures...")
            response = self.get_page(self.debentures_url)
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # Find debenture table rows
            debenture_rows = soup.find_all('tr')
            
            for row in debenture_rows:
                cells = row.find_all('td')
                if len(cells) >= 3:
                    try:
                        # Extract basic information
                        issuer = cells[0].get_text(strip=True) if cells[0] else ""
                        series_emission = cells[1].get_text(strip=True) if cells[1] else ""
                        asset_code = cells[2].get_text(strip=True) if cells[2] else ""
                        
                        if asset_code and issuer:
                            # Get detailed information
                            detail_link = cells[2].find('a')
                            if detail_link and detail_link.get('href'):
                                detail_url = urljoin(self.base_url, detail_link.get('href'))
                                debenture_details, debenture_pdfs = self.extract_debenture_details(detail_url, asset_code)
                                
                                if debenture_details:
                                    debentures.append(debenture_details)
                                    pdf_links.extend(debenture_pdfs)
                    
                    except Exception as e:
                        logger.warning(f"Error processing row in {self.agent_name}: {e}")
                        continue
            
            logger.info(f"Found {len(debentures)} debentures and {len(pdf_links)} PDFs from {self.agent_name}")
            
        except Exception as e:
            logger.error(f"Error crawling {self.agent_name}: {e}")
        
        return debentures, pdf_links
    
    def extract_debenture_details(self, detail_url, asset_code):
        """Extract detailed debenture information from individual page"""
        try:
            response = self.get_page(detail_url)
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # Extract characteristics
            debenture = {
                'codigo': asset_code,
                'emissor': '',
                'agente_fiduciario': self.agent_name,
                'data_emissao': '',
                'data_vencimento': '',
                'valor_nominal': 0.0,
                'taxa': '',
                'indexador': '',
                'rating': '',
                'garantia': '',
                'conversibilidade': 'Não conversível'
            }
            
            # Extract from characteristics table
            char_table = soup.find('table') or soup.find('div', class_='characteristics')
            if char_table:
                rows = char_table.find_all('tr')
                for row in rows:
                    cells = row.find_all(['td', 'th'])
                    if len(cells) >= 2:
                        key = cells[0].get_text(strip=True).lower()
                        value = cells[1].get_text(strip=True)
                        
                        if 'emissor' in key or 'razão social' in key:
                            debenture['emissor'] = value
                        elif 'emissão' in key and 'data' in key:
                            debenture['data_emissao'] = self.parse_date(value)
                        elif 'vencimento' in key and 'data' in key:
                            debenture['data_vencimento'] = self.parse_date(value)
                        elif 'valor nominal' in key:
                            debenture['valor_nominal'] = self.parse_currency(value)
                        elif 'remuneração' in key or 'taxa' in key:
                            debenture['taxa'] = value
                        elif 'indexador' in key:
                            debenture['indexador'] = value
                        elif 'rating' in key:
                            debenture['rating'] = value
                        elif 'garantia' in key or 'espécie' in key:
                            debenture['garantia'] = value
            
            # Extract PDF links
            pdf_links = self.extract_pdf_links_from_page(soup, asset_code, debenture['emissor'])
            
            return debenture, pdf_links
            
        except Exception as e:
            logger.error(f"Error extracting details for {asset_code}: {e}")
            return None, []
    
    def extract_pdf_links_from_page(self, soup, asset_code, issuer):
        """Extract PDF links from the page"""
        pdf_links = []
        
        # Look for document links
        doc_links = soup.find_all('a', href=re.compile(r'\.pdf$', re.I))
        
        for link in doc_links:
            href = link.get('href')
            title = link.get_text(strip=True) or link.get('title', '')
            
            if href:
                pdf_url = urljoin(self.base_url, href)
                pdf_links.append({
                    'codigo': asset_code,
                    'emissor': issuer,
                    'agente_fiduciario': self.agent_name,
                    'titulo_documento': title,
                    'url_pdf': pdf_url,
                    'data_coleta': datetime.utcnow().isoformat()
                })
        
        return pdf_links
    
    def parse_date(self, date_str):
        """Parse date string to YYYY-MM-DD format"""
        try:
            # Try different date formats
            formats = ['%d/%m/%Y', '%d-%m-%Y', '%Y-%m-%d']
            for fmt in formats:
                try:
                    date_obj = datetime.strptime(date_str.strip(), fmt)
                    return date_obj.strftime('%Y-%m-%d')
                except ValueError:
                    continue
            return date_str
        except:
            return date_str
    
    def parse_currency(self, currency_str):
        """Parse currency string to float"""
        try:
            # Remove currency symbols and convert to float
            clean_str = re.sub(r'[^\d,.]', '', currency_str)
            clean_str = clean_str.replace(',', '.')
            return float(clean_str)
        except:
            return 0.0

class VortxCrawler(BaseCrawler):
    """Crawler for Vórtx DTVM"""
    
    def __init__(self):
        super().__init__("Vórtx DTVM")
        self.base_url = "https://www.vortx.com.br"
        self.debentures_url = f"{self.base_url}/investidor/debenture"
    
    def extract_debentures(self):
        """Extract debenture information from Vórtx website"""
        debentures = []
        pdf_links = []
        
        try:
            logger.info(f"Crawling {self.agent_name} debentures...")
            response = self.get_page(self.debentures_url)
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # Find debenture table rows
            table_rows = soup.find_all('tr')
            
            for row in table_rows[1:]:  # Skip header row
                cells = row.find_all('td')
                if len(cells) >= 7:
                    try:
                        issuer = cells[1].get_text(strip=True) if cells[1] else ""
                        emission = cells[2].get_text(strip=True) if cells[2] else ""
                        series = cells[3].get_text(strip=True) if cells[3] else ""
                        asset_code = cells[4].get_text(strip=True) if cells[4] else ""
                        
                        if asset_code and issuer:
                            # Get detail link
                            detail_link = cells[4].find('a')
                            if detail_link and detail_link.get('href'):
                                detail_url = urljoin(self.base_url, detail_link.get('href'))
                                debenture_details, debenture_pdfs = self.extract_debenture_details(detail_url, asset_code)
                                
                                if debenture_details:
                                    debentures.append(debenture_details)
                                    pdf_links.extend(debenture_pdfs)
                    
                    except Exception as e:
                        logger.warning(f"Error processing row in {self.agent_name}: {e}")
                        continue
            
            logger.info(f"Found {len(debentures)} debentures and {len(pdf_links)} PDFs from {self.agent_name}")
            
        except Exception as e:
            logger.error(f"Error crawling {self.agent_name}: {e}")
        
        return debentures, pdf_links
    
    def extract_debenture_details(self, detail_url, asset_code):
        """Extract detailed debenture information from individual page"""
        try:
            response = self.get_page(detail_url)
            soup = BeautifulSoup(response.content, 'html.parser')
            
            debenture = {
                'codigo': asset_code,
                'emissor': '',
                'agente_fiduciario': self.agent_name,
                'data_emissao': '',
                'data_vencimento': '',
                'valor_nominal': 0.0,
                'taxa': '',
                'indexador': '',
                'rating': '',
                'garantia': '',
                'conversibilidade': 'Não conversível'
            }
            
            # Extract information from the page structure
            # Look for specific elements based on Vórtx structure
            title_element = soup.find('h2')
            if title_element:
                debenture['emissor'] = title_element.get_text(strip=True)
            
            # Extract characteristics from the dashboard
            char_elements = soup.find_all(['div', 'span', 'p'])
            for element in char_elements:
                text = element.get_text(strip=True)
                if 'IPCA' in text or 'CDI' in text or '%' in text:
                    debenture['taxa'] = text
                    if 'IPCA' in text:
                        debenture['indexador'] = 'IPCA'
                    elif 'CDI' in text:
                        debenture['indexador'] = 'CDI'
            
            # Extract PDF links
            pdf_links = self.extract_pdf_links_from_page(soup, asset_code, debenture['emissor'])
            
            return debenture, pdf_links
            
        except Exception as e:
            logger.error(f"Error extracting details for {asset_code}: {e}")
            return None, []
    
    def extract_pdf_links_from_page(self, soup, asset_code, issuer):
        """Extract PDF links from the page"""
        pdf_links = []
        
        # Look for document links in the documents tab
        doc_links = soup.find_all('a', href=re.compile(r'\.pdf$', re.I))
        
        for link in doc_links:
            href = link.get('href')
            title = link.get_text(strip=True) or link.get('title', '')
            
            if href:
                pdf_url = urljoin(self.base_url, href)
                pdf_links.append({
                    'codigo': asset_code,
                    'emissor': issuer,
                    'agente_fiduciario': self.agent_name,
                    'titulo_documento': title,
                    'url_pdf': pdf_url,
                    'data_coleta': datetime.utcnow().isoformat()
                })
        
        return pdf_links

class OliveiraTrustCrawler(BaseCrawler):
    """Crawler for Oliveira Trust DTVM"""
    
    def __init__(self):
        super().__init__("Oliveira Trust DTVM S.A.")
        self.base_url = "https://www.oliveiratrust.com.br"
        self.debentures_url = f"{self.base_url}/investidor/ativos?tipo=debentures"
    
    def extract_debentures(self):
        """Extract debenture information from Oliveira Trust website"""
        debentures = []
        pdf_links = []
        
        try:
            logger.info(f"Crawling {self.agent_name} debentures...")
            response = self.get_page(self.debentures_url)
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # Find debenture cards
            debenture_cards = soup.find_all('a', href=re.compile(r'/investidor/ativo\?id='))
            
            for card in debenture_cards:
                try:
                    href = card.get('href')
                    if href:
                        detail_url = urljoin(self.base_url, href)
                        
                        # Extract asset ID from URL
                        asset_id_match = re.search(r'id=(\d+)', href)
                        if asset_id_match:
                            asset_id = asset_id_match.group(1)
                            
                            debenture_details, debenture_pdfs = self.extract_debenture_details(detail_url, asset_id)
                            
                            if debenture_details:
                                debentures.append(debenture_details)
                                pdf_links.extend(debenture_pdfs)
                
                except Exception as e:
                    logger.warning(f"Error processing card in {self.agent_name}: {e}")
                    continue
            
            logger.info(f"Found {len(debentures)} debentures and {len(pdf_links)} PDFs from {self.agent_name}")
            
        except Exception as e:
            logger.error(f"Error crawling {self.agent_name}: {e}")
        
        return debentures, pdf_links
    
    def extract_debenture_details(self, detail_url, asset_id):
        """Extract detailed debenture information from individual page"""
        try:
            response = self.get_page(detail_url)
            soup = BeautifulSoup(response.content, 'html.parser')
            
            debenture = {
                'codigo': asset_id,
                'emissor': '',
                'agente_fiduciario': self.agent_name,
                'data_emissao': '',
                'data_vencimento': '',
                'valor_nominal': 0.0,
                'taxa': '',
                'indexador': '',
                'rating': '',
                'garantia': '',
                'conversibilidade': 'Não conversível'
            }
            
            # Extract information from the characteristics table
            char_rows = soup.find_all('tr')
            for row in char_rows:
                cells = row.find_all(['td', 'th'])
                if len(cells) >= 2:
                    key = cells[0].get_text(strip=True).lower()
                    value = cells[1].get_text(strip=True)
                    
                    if 'emissor' in key:
                        debenture['emissor'] = value
                    elif 'emissão' in key:
                        debenture['data_emissao'] = self.parse_date(value)
                    elif 'vencimento' in key:
                        debenture['data_vencimento'] = self.parse_date(value)
                    elif 'código' in key and 'ativo' in key:
                        debenture['codigo'] = value
                    elif 'remuneração' in key or 'taxa' in key:
                        debenture['taxa'] = value
                        if 'CDI' in value:
                            debenture['indexador'] = 'CDI'
                        elif 'IPCA' in value:
                            debenture['indexador'] = 'IPCA'
                    elif 'volume' in key:
                        debenture['valor_nominal'] = self.parse_currency(value)
                    elif 'rating' in key:
                        debenture['rating'] = value
                    elif 'garantia' in key:
                        debenture['garantia'] = value
            
            # Extract PDF links
            pdf_links = self.extract_pdf_links_from_page(soup, debenture['codigo'], debenture['emissor'])
            
            return debenture, pdf_links
            
        except Exception as e:
            logger.error(f"Error extracting details for {asset_id}: {e}")
            return None, []
    
    def extract_pdf_links_from_page(self, soup, asset_code, issuer):
        """Extract PDF links from the page"""
        pdf_links = []
        
        # Look for document links
        doc_links = soup.find_all('a', href=re.compile(r'\.pdf$', re.I))
        
        for link in doc_links:
            href = link.get('href')
            title = link.get_text(strip=True) or link.get('title', '')
            
            if href:
                pdf_url = urljoin(self.base_url, href)
                pdf_links.append({
                    'codigo': asset_code,
                    'emissor': issuer,
                    'agente_fiduciario': self.agent_name,
                    'titulo_documento': title,
                    'url_pdf': pdf_url,
                    'data_coleta': datetime.utcnow().isoformat()
                })
        
        return pdf_links
    
    def parse_date(self, date_str):
        """Parse date string to YYYY-MM-DD format"""
        try:
            # Try different date formats
            formats = ['%d/%m/%Y', '%d-%m-%Y', '%Y-%m-%d']
            for fmt in formats:
                try:
                    date_obj = datetime.strptime(date_str.strip(), fmt)
                    return date_obj.strftime('%Y-%m-%d')
                except ValueError:
                    continue
            return date_str
        except:
            return date_str
    
    def parse_currency(self, currency_str):
        """Parse currency string to float"""
        try:
            # Remove currency symbols and convert to float
            clean_str = re.sub(r'[^\d,.]', '', currency_str)
            clean_str = clean_str.replace(',', '.')
            return float(clean_str)
        except:
            return 0.0

def run_crawler(agent_name):
    """Run crawler for specific agent"""
    crawlers = {
        'pentagono': PentagonoCrawler,
        'vortx': VortxCrawler,
        'oliveira_trust': OliveiraTrustCrawler,
    }
    
    if agent_name.lower() in crawlers:
        crawler = crawlers[agent_name.lower()]()
        return crawler.extract_debentures()
    else:
        logger.error(f"Unknown agent: {agent_name}")
        return [], []

if __name__ == "__main__":
    # Test the crawlers
    for agent in ['pentagono', 'vortx', 'oliveira_trust']:
        print(f"\n=== Testing {agent} crawler ===")
        debentures, pdfs = run_crawler(agent)
        print(f"Found {len(debentures)} debentures and {len(pdfs)} PDFs")

