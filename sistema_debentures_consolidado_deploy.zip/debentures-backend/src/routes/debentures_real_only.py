from flask import Blueprint, jsonify, request
from datetime import datetime
import threading
import time
import sys
import os

# Import real-only crawlers system
sys.path.append('/home/ubuntu')
try:
    from real_only_crawlers import RealOnlyCrawlerManager
    CRAWLERS_AVAILABLE = True
except ImportError:
    print("Warning: Could not import real-only crawlers system")
    CRAWLERS_AVAILABLE = False

# Import models
from src.models.debenture import db, Emissao, Assembleia, Taxa, Evento, PDFLink, CrawlerStatus

debentures_bp = Blueprint('debentures', __name__)

# Initialize the real-only crawler manager
crawler_manager = RealOnlyCrawlerManager() if CRAWLERS_AVAILABLE else None

# Agent mapping
AGENTS = {
    'pentagono': 'Pentágono S.A. DTVM',
    'vortx': 'Vórtx DTVM',
    'oliveira_trust': 'Oliveira Trust DTVM',
    'btg_pactual': 'BTG Pactual Serviços Financeiros S.A. DTVM',
    'banco_brasil': 'Banco do Brasil S.A.',
    'xp_investimentos': 'XP Investimentos CCTVM S.A.',
    'brl_trust': 'BRL Trust DTVM S.A.',
    'planner_trustee': 'Planner Trustee DTVM Ltda',
    'itau_dtvm': 'Itaú Unibanco S.A.'
}

def real_only_crawler_worker(agente_key):
    """Worker function to run REAL-ONLY crawler in background - NO MOCK DATA"""
    from src.main import app
    
    with app.app_context():
        try:
            # Update status to processing
            status = CrawlerStatus.query.filter_by(agente_fiduciario=AGENTS[agente_key]).first()
            if not status:
                status = CrawlerStatus(
                    agente_fiduciario=AGENTS[agente_key],
                    status='processando',
                    inicio_processamento=datetime.now(),
                    mensagem='Iniciando coleta de dados reais...'
                )
                db.session.add(status)
            else:
                status.status = 'processando'
                status.inicio_processamento = datetime.now()
                status.mensagem = 'Iniciando coleta de dados reais...'
            
            db.session.commit()
            
            # Update status with progress
            status.mensagem = f'Acessando site oficial do {AGENTS[agente_key]}...'
            db.session.commit()
            
            # Run the REAL-ONLY crawler
            emissoes_inseridas = 0
            documentos_inseridos = 0
            
            if crawler_manager and CRAWLERS_AVAILABLE:
                emissoes_data, documentos_data = crawler_manager.run_crawler(agente_key)
                
                # Only insert if we have REAL data
                if emissoes_data:
                    status.mensagem = f'Processando {len(emissoes_data)} emissões reais encontradas...'
                    db.session.commit()
                    
                    # Insert real emissions
                    for emissao_data in emissoes_data:
                        try:
                            # Check if emission already exists
                            existing = Emissao.query.filter_by(
                                codigo=emissao_data.get('codigo'),
                                agente_fiduciario=emissao_data.get('agente_fiduciario')
                            ).first()
                            
                            if not existing:
                                emissao = Emissao(
                                    codigo=emissao_data.get('codigo'),
                                    emissor=emissao_data.get('emissor'),
                                    agente_fiduciario=emissao_data.get('agente_fiduciario'),
                                    data_emissao=emissao_data.get('data_emissao'),
                                    data_vencimento=emissao_data.get('data_vencimento'),
                                    valor_nominal=emissao_data.get('volume'),
                                    taxa=emissao_data.get('remuneracao'),
                                    rating=emissao_data.get('rating')
                                )
                                db.session.add(emissao)
                                emissoes_inseridas += 1
                        except Exception as e:
                            print(f"Erro ao inserir emissão real {emissao_data.get('codigo', 'N/A')}: {e}")
                            continue
                
                # Only insert if we have REAL documents
                if documentos_data:
                    status.mensagem = f'Processando {len(documentos_data)} documentos reais encontrados...'
                    db.session.commit()
                    
                    # Insert real documents
                    for doc_data in documentos_data:
                        try:
                            # Check if document already exists
                            existing = PDFLink.query.filter_by(
                                titulo_documento=doc_data.get('titulo'),
                                agente_fiduciario=doc_data.get('agente_fiduciario')
                            ).first()
                            
                            if not existing:
                                pdf_link = PDFLink(
                                    codigo=doc_data.get('codigo', 'N/A'),
                                    emissor=doc_data.get('emissor', 'N/A'),
                                    titulo_documento=doc_data.get('titulo'),
                                    url_pdf=doc_data.get('url'),
                                    agente_fiduciario=doc_data.get('agente_fiduciario')
                                )
                                db.session.add(pdf_link)
                                documentos_inseridos += 1
                        except Exception as e:
                            print(f"Erro ao inserir documento real {doc_data.get('titulo', 'N/A')}: {e}")
                            continue
                
                # Commit all real data changes
                db.session.commit()
                
                # Update final status based on REAL data found
                if emissoes_inseridas > 0 or documentos_inseridos > 0:
                    status.status = 'concluido'
                    status.fim_processamento = datetime.now()
                    status.mensagem = f'Coleta real finalizada! {emissoes_inseridas} emissões e {documentos_inseridos} documentos reais coletados'
                    status.pdfs_encontrados = documentos_inseridos
                else:
                    status.status = 'concluido'
                    status.fim_processamento = datetime.now()
                    status.mensagem = f'Coleta finalizada. Nenhum dado real encontrado no site oficial do {AGENTS[agente_key]}'
                    status.pdfs_encontrados = 0
                
                db.session.commit()
            else:
                # No crawler available - report this clearly
                status.status = 'erro'
                status.fim_processamento = datetime.now()
                status.mensagem = f'Crawler real não implementado para {AGENTS[agente_key]}. Apenas dados reais são coletados.'
                db.session.commit()
                
        except Exception as e:
            # Update status with error
            try:
                status = CrawlerStatus.query.filter_by(agente_fiduciario=AGENTS[agente_key]).first()
                if status:
                    status.status = 'erro'
                    status.fim_processamento = datetime.now()
                    status.mensagem = f'Erro durante coleta real: {str(e)}'
                    db.session.commit()
            except:
                pass
            print(f"Erro no crawler real {agente_key}: {e}")

@debentures_bp.route('/run-crawler/<agente>', methods=['POST'])
def run_crawler(agente):
    """Execute REAL-ONLY crawler for specific agent - NO MOCK DATA"""
    if agente not in AGENTS:
        return jsonify({'error': 'Agente não encontrado'}), 404
    
    # Check if crawler is already running
    status = CrawlerStatus.query.filter_by(agente_fiduciario=AGENTS[agente]).first()
    if status and status.status == 'processando':
        return jsonify({'error': 'Crawler já está em execução'}), 400
    
    # Start REAL-ONLY crawler in background thread
    thread = threading.Thread(target=real_only_crawler_worker, args=(agente,))
    thread.daemon = True
    thread.start()
    
    return jsonify({
        'message': f'Crawler real iniciado para {AGENTS[agente]} - apenas dados reais serão coletados'
    })

@debentures_bp.route('/run-all-crawlers', methods=['POST'])
def run_all_crawlers():
    """Execute all REAL-ONLY crawlers sequentially - NO MOCK DATA"""
    # Check if any crawler is already running
    running_crawlers = CrawlerStatus.query.filter_by(status='processando').all()
    if running_crawlers:
        return jsonify({'error': 'Alguns crawlers já estão em execução'}), 400
    
    # Start all REAL-ONLY crawlers in background
    def run_all_real_worker():
        for agente_key in AGENTS.keys():
            try:
                real_only_crawler_worker(agente_key)
                time.sleep(3)  # Respectful delay between agents
            except Exception as e:
                print(f"Erro ao executar crawler real {agente_key}: {e}")
                continue
    
    thread = threading.Thread(target=run_all_real_worker)
    thread.daemon = True
    thread.start()
    
    return jsonify({'message': 'Todos os crawlers reais iniciados - apenas dados reais serão coletados'})

@debentures_bp.route('/crawler-status')
def get_crawler_status():
    """Get status of all REAL-ONLY crawlers"""
    statuses = CrawlerStatus.query.all()
    
    # Ensure all agents have status records
    for agente_key, agente_name in AGENTS.items():
        existing = next((s for s in statuses if s.agente_fiduciario == agente_name), None)
        if not existing:
            new_status = CrawlerStatus(
                agente_fiduciario=agente_name,
                status='inativo',
                mensagem='Aguardando execução - apenas dados reais serão coletados'
            )
            db.session.add(new_status)
            statuses.append(new_status)
    
    db.session.commit()
    
    return jsonify([{
        'agente_fiduciario': status.agente_fiduciario,
        'status': status.status,
        'inicio_processamento': status.inicio_processamento.isoformat() if status.inicio_processamento else None,
        'fim_processamento': status.fim_processamento.isoformat() if status.fim_processamento else None,
        'mensagem': status.mensagem,
        'pdfs_encontrados': status.pdfs_encontrados
    } for status in statuses])

@debentures_bp.route('/emissoes')
def get_emissoes():
    """Get all REAL emissions - NO MOCK DATA"""
    emissoes = Emissao.query.all()
    return jsonify([{
        'id': emissao.id,
        'codigo': emissao.codigo,
        'emissor': emissao.emissor,
        'agente_fiduciario': emissao.agente_fiduciario,
        'data_emissao': emissao.data_emissao,
        'data_vencimento': emissao.data_vencimento,
        'valor_nominal': float(emissao.valor_nominal) if emissao.valor_nominal else None,
        'taxa': emissao.taxa,
        'rating': emissao.rating
    } for emissao in emissoes])

@debentures_bp.route('/assembleias')
def get_assembleias():
    """Get all REAL assemblies - NO MOCK DATA"""
    assembleias = Assembleia.query.all()
    return jsonify([{
        'id': assembleia.id,
        'codigo': assembleia.codigo,
        'emissor': assembleia.emissor,
        'data_assembleia': assembleia.data_assembleia,
        'tipo': assembleia.tipo,
        'pauta': assembleia.pauta,
        'agente_fiduciario': assembleia.agente_fiduciario
    } for assembleia in assembleias])

@debentures_bp.route('/taxas')
def get_taxas():
    """Get all REAL rates - NO MOCK DATA"""
    taxas = Taxa.query.all()
    return jsonify([{
        'id': taxa.id,
        'codigo': taxa.codigo,
        'emissor': taxa.emissor,
        'data_referencia': taxa.data_referencia,
        'preco_unitario': float(taxa.preco_unitario) if taxa.preco_unitario else None,
        'taxa_indicativa': float(taxa.taxa_indicativa) if taxa.taxa_indicativa else None,
        'agente_fiduciario': taxa.agente_fiduciario
    } for taxa in taxas])

@debentures_bp.route('/eventos')
def get_eventos():
    """Get all REAL events - NO MOCK DATA"""
    eventos = Evento.query.all()
    return jsonify([{
        'id': evento.id,
        'codigo': evento.codigo,
        'emissor': evento.emissor,
        'data_evento': evento.data_evento,
        'tipo_evento': evento.tipo_evento,
        'descricao': evento.descricao,
        'agente_fiduciario': evento.agente_fiduciario
    } for evento in eventos])

@debentures_bp.route('/pdf-links')
def get_pdf_links():
    """Get all REAL PDF links - NO MOCK DATA"""
    pdf_links = PDFLink.query.all()
    return jsonify([{
        'id': pdf_link.id,
        'codigo': pdf_link.codigo,
        'emissor': pdf_link.emissor,
        'titulo_documento': pdf_link.titulo_documento,
        'url_pdf': pdf_link.url_pdf,
        'agente_fiduciario': pdf_link.agente_fiduciario,
        'data_coleta': pdf_link.data_coleta.isoformat() if pdf_link.data_coleta else None
    } for pdf_link in pdf_links])

@debentures_bp.route('/dashboard-stats')
def get_dashboard_stats():
    """Get dashboard statistics - REAL DATA ONLY"""
    total_emissoes = Emissao.query.count()
    total_assembleias = Assembleia.query.count()
    total_eventos = Evento.query.count()
    total_pdfs = PDFLink.query.count()
    
    # Get recent activity
    recent_emissoes = Emissao.query.order_by(Emissao.id.desc()).limit(5).all()
    
    # Get stats by agent
    agent_stats = []
    for agente_key, agente_name in AGENTS.items():
        emissoes_count = Emissao.query.filter_by(agente_fiduciario=agente_name).count()
        pdfs_count = PDFLink.query.filter_by(agente_fiduciario=agente_name).count()
        
        agent_stats.append({
            'agente': agente_name,
            'emissoes': emissoes_count,
            'documentos': pdfs_count
        })
    
    return jsonify({
        'total_emissoes': total_emissoes,
        'total_assembleias': total_assembleias,
        'total_eventos': total_eventos,
        'total_pdfs': total_pdfs,
        'agent_stats': agent_stats,
        'recent_emissoes': [{
            'codigo': emissao.codigo,
            'emissor': emissao.emissor,
            'agente_fiduciario': emissao.agente_fiduciario
        } for emissao in recent_emissoes],
        'data_policy': 'REAL DATA ONLY - No mock or synthetic data'
    })

@debentures_bp.route('/system-info')
def get_system_info():
    """Get system information about data policy"""
    return jsonify({
        'data_policy': 'REAL DATA ONLY',
        'description': 'Este sistema coleta apenas dados reais dos sites oficiais dos agentes fiduciários',
        'no_mock_data': True,
        'no_fallback_data': True,
        'crawlers_available': CRAWLERS_AVAILABLE,
        'real_crawlers_implemented': ['pentagono', 'vortx', 'oliveira_trust'] if CRAWLERS_AVAILABLE else [],
        'message': 'Apenas dados reais são coletados e armazenados. Nenhum dado sintético ou mock é gerado.'
    })

