from flask import Blueprint, jsonify, request
from datetime import datetime
import threading
import time
import sys
import os
import random

# Import complete crawlers system
sys.path.append('/home/ubuntu')
try:
    from complete_crawlers_system import CompleteCrawlerManager
except ImportError:
    print("Warning: Could not import complete crawlers system, using fallback")
    CompleteCrawlerManager = None

# Import models
from src.models.debenture import db, Emissao, Assembleia, Taxa, Evento, PDFLink, CrawlerStatus

debentures_bp = Blueprint('debentures', __name__)

# Initialize the complete crawler manager
crawler_manager = CompleteCrawlerManager() if CompleteCrawlerManager else None

# Agent mapping
AGENTS = {
    'pentagono': 'Pentágono S.A. DTVM',
    'vortx': 'Vórtx DTVM',
    'oliveira_trust': 'Oliveira Trust DTVM',
    'btg_pactual': 'BTG Pactual Serviços Financeiros S.A. DTVM',
    'banco_brasil': 'Banco do Brasil S.A.',
    'xp_investimentos': 'XP Investimentos CCTVM S.A.',
    'brl_trust': 'BRL Trust DTVM S.A.',
    'planner_trustee': 'Planner Trustee DTVM Ltda',
    'itau_dtvm': 'Itaú Unibanco S.A.'
}

def simple_crawler_worker(agente_key):
    """Simplified worker function to run crawler in background"""
    from src.main import app
    
    with app.app_context():
        try:
            # Update status to processing
            status = CrawlerStatus.query.filter_by(agente_fiduciario=AGENTS[agente_key]).first()
            if not status:
                status = CrawlerStatus(
                    agente_fiduciario=AGENTS[agente_key],
                    status='processando',
                    inicio_processamento=datetime.now(),
                    mensagem='Iniciando coleta de dados...'
                )
                db.session.add(status)
            else:
                status.status = 'processando'
                status.inicio_processamento = datetime.now()
                status.mensagem = 'Iniciando coleta de dados...'
            
            db.session.commit()
            
            # Simulate processing time
            time.sleep(2)
            
            # Update status with progress
            status.mensagem = f'Coletando dados do {AGENTS[agente_key]}...'
            db.session.commit()
            
            # Run the actual crawler
            if crawler_manager:
                emissoes_data, documentos_data = crawler_manager.run_crawler(agente_key)
                
                # Insert emissions
                emissoes_inseridas = 0
                for emissao_data in emissoes_data:
                    try:
                        # Check if emission already exists
                        existing = Emissao.query.filter_by(
                            codigo=emissao_data.get('codigo'),
                            agente_fiduciario=emissao_data.get('agente_fiduciario')
                        ).first()
                        
                        if not existing:
                            emissao = Emissao(
                                codigo=emissao_data.get('codigo'),
                                emissor=emissao_data.get('emissor'),
                                agente_fiduciario=emissao_data.get('agente_fiduciario'),
                                data_emissao=emissao_data.get('data_emissao'),
                                data_vencimento=emissao_data.get('data_vencimento'),
                                valor_nominal=emissao_data.get('volume'),
                                taxa=emissao_data.get('remuneracao'),
                                rating=emissao_data.get('rating')
                            )
                            db.session.add(emissao)
                            emissoes_inseridas += 1
                    except Exception as e:
                        print(f"Erro ao inserir emissão {emissao_data.get('codigo', 'N/A')}: {e}")
                        continue
                
                # Insert documents
                documentos_inseridos = 0
                for doc_data in documentos_data:
                    try:
                        # Check if document already exists
                        existing = PDFLink.query.filter_by(
                            titulo_documento=doc_data.get('titulo'),
                            agente_fiduciario=doc_data.get('agente_fiduciario')
                        ).first()
                        
                        if not existing:
                            pdf_link = PDFLink(
                                codigo=doc_data.get('codigo', 'N/A'),
                                emissor=doc_data.get('emissor', 'N/A'),
                                titulo_documento=doc_data.get('titulo'),
                                url_pdf=doc_data.get('url'),
                                agente_fiduciario=doc_data.get('agente_fiduciario')
                            )
                            db.session.add(pdf_link)
                            documentos_inseridos += 1
                    except Exception as e:
                        print(f"Erro ao inserir documento {doc_data.get('titulo', 'N/A')}: {e}")
                        continue
                
                # Commit all changes
                db.session.commit()
                
                # Update final status
                status.status = 'concluido'
                status.fim_processamento = datetime.now()
                status.mensagem = f'Coleta finalizada! {emissoes_inseridas} emissões e {documentos_inseridos} documentos coletados'
                status.pdfs_encontrados = documentos_inseridos
                db.session.commit()
            else:
                # Fallback if crawler manager not available
                status.status = 'erro'
                status.mensagem = 'Sistema de crawlers não disponível'
                db.session.commit()
                
        except Exception as e:
            # Update status with error
            try:
                status = CrawlerStatus.query.filter_by(agente_fiduciario=AGENTS[agente_key]).first()
                if status:
                    status.status = 'erro'
                    status.mensagem = f'Erro durante a coleta: {str(e)}'
                    db.session.commit()
            except:
                pass
            print(f"Erro no crawler {agente_key}: {e}")

@debentures_bp.route('/run-crawler/<agente>', methods=['POST'])
def run_crawler(agente):
    """Execute crawler for specific agent"""
    if agente not in AGENTS:
        return jsonify({'error': 'Agente não encontrado'}), 404
    
    # Check if crawler is already running
    status = CrawlerStatus.query.filter_by(agente_fiduciario=AGENTS[agente]).first()
    if status and status.status == 'processando':
        return jsonify({'error': 'Crawler já está em execução'}), 400
    
    # Start crawler in background thread
    thread = threading.Thread(target=simple_crawler_worker, args=(agente,))
    thread.daemon = True
    thread.start()
    
    return jsonify({
        'message': f'Crawler {AGENTS[agente]} iniciado com sucesso'
    })

@debentures_bp.route('/run-all-crawlers', methods=['POST'])
def run_all_crawlers():
    """Execute all crawlers sequentially"""
    # Check if any crawler is already running
    running_crawlers = CrawlerStatus.query.filter_by(status='processando').all()
    if running_crawlers:
        return jsonify({'error': 'Alguns crawlers já estão em execução'}), 400
    
    # Start all crawlers in background
    def run_all_worker():
        for agente_key in AGENTS.keys():
            try:
                simple_crawler_worker(agente_key)
                time.sleep(2)  # Brief delay between agents
            except Exception as e:
                print(f"Erro ao executar crawler {agente_key}: {e}")
                continue
    
    thread = threading.Thread(target=run_all_worker)
    thread.daemon = True
    thread.start()
    
    return jsonify({'message': 'Todos os crawlers iniciados com sucesso'})

@debentures_bp.route('/crawler-status')
def get_crawler_status():
    """Get status of all crawlers"""
    statuses = CrawlerStatus.query.all()
    
    # Ensure all agents have status records
    for agente_key, agente_name in AGENTS.items():
        existing = next((s for s in statuses if s.agente_fiduciario == agente_name), None)
        if not existing:
            new_status = CrawlerStatus(
                agente_fiduciario=agente_name,
                status='inativo',
                mensagem='Aguardando execução'
            )
            db.session.add(new_status)
            statuses.append(new_status)
    
    db.session.commit()
    
    return jsonify([{
        'agente_fiduciario': status.agente_fiduciario,
        'status': status.status,
        'inicio_processamento': status.inicio_processamento.isoformat() if status.inicio_processamento else None,
        'fim_processamento': status.fim_processamento.isoformat() if status.fim_processamento else None,
        'mensagem': status.mensagem,
        'pdfs_encontrados': status.pdfs_encontrados
    } for status in statuses])

@debentures_bp.route('/emissoes')
def get_emissoes():
    """Get all emissions"""
    emissoes = Emissao.query.all()
    return jsonify([{
        'id': emissao.id,
        'codigo': emissao.codigo,
        'emissor': emissao.emissor,
        'agente_fiduciario': emissao.agente_fiduciario,
        'data_emissao': emissao.data_emissao,
        'data_vencimento': emissao.data_vencimento,
        'valor_nominal': float(emissao.valor_nominal) if emissao.valor_nominal else None,
        'taxa': emissao.taxa,
        'rating': emissao.rating
    } for emissao in emissoes])

@debentures_bp.route('/assembleias')
def get_assembleias():
    """Get all assemblies"""
    assembleias = Assembleia.query.all()
    return jsonify([{
        'id': assembleia.id,
        'codigo': assembleia.codigo,
        'emissor': assembleia.emissor,
        'data_assembleia': assembleia.data_assembleia,
        'tipo': assembleia.tipo,
        'pauta': assembleia.pauta,
        'agente_fiduciario': assembleia.agente_fiduciario
    } for assembleia in assembleias])

@debentures_bp.route('/taxas')
def get_taxas():
    """Get all rates"""
    taxas = Taxa.query.all()
    return jsonify([{
        'id': taxa.id,
        'codigo': taxa.codigo,
        'emissor': taxa.emissor,
        'data_referencia': taxa.data_referencia,
        'preco_unitario': float(taxa.preco_unitario) if taxa.preco_unitario else None,
        'taxa_indicativa': float(taxa.taxa_indicativa) if taxa.taxa_indicativa else None,
        'agente_fiduciario': taxa.agente_fiduciario
    } for taxa in taxas])

@debentures_bp.route('/eventos')
def get_eventos():
    """Get all events"""
    eventos = Evento.query.all()
    return jsonify([{
        'id': evento.id,
        'codigo': evento.codigo,
        'emissor': evento.emissor,
        'data_evento': evento.data_evento,
        'tipo_evento': evento.tipo_evento,
        'descricao': evento.descricao,
        'agente_fiduciario': evento.agente_fiduciario
    } for evento in eventos])

@debentures_bp.route('/pdf-links')
def get_pdf_links():
    """Get all PDF links"""
    pdf_links = PDFLink.query.all()
    return jsonify([{
        'id': pdf_link.id,
        'codigo': pdf_link.codigo,
        'emissor': pdf_link.emissor,
        'titulo_documento': pdf_link.titulo_documento,
        'url_pdf': pdf_link.url_pdf,
        'agente_fiduciario': pdf_link.agente_fiduciario,
        'data_coleta': pdf_link.data_coleta.isoformat() if pdf_link.data_coleta else None
    } for pdf_link in pdf_links])

@debentures_bp.route('/dashboard-stats')
def get_dashboard_stats():
    """Get dashboard statistics"""
    total_emissoes = Emissao.query.count()
    total_assembleias = Assembleia.query.count()
    total_eventos = Evento.query.count()
    total_pdfs = PDFLink.query.count()
    
    # Get recent activity
    recent_emissoes = Emissao.query.order_by(Emissao.id.desc()).limit(5).all()
    
    # Get stats by agent
    agent_stats = []
    for agente_key, agente_name in AGENTS.items():
        emissoes_count = Emissao.query.filter_by(agente_fiduciario=agente_name).count()
        pdfs_count = PDFLink.query.filter_by(agente_fiduciario=agente_name).count()
        
        agent_stats.append({
            'agente': agente_name,
            'emissoes': emissoes_count,
            'documentos': pdfs_count
        })
    
    return jsonify({
        'total_emissoes': total_emissoes,
        'total_assembleias': total_assembleias,
        'total_eventos': total_eventos,
        'total_pdfs': total_pdfs,
        'agent_stats': agent_stats,
        'recent_emissoes': [{
            'codigo': emissao.codigo,
            'emissor': emissao.emissor,
            'agente_fiduciario': emissao.agente_fiduciario
        } for emissao in recent_emissoes]
    })

