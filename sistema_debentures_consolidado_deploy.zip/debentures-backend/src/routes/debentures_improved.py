from flask import Blueprint, jsonify, request
from src.models.debenture import db, Emissao, Assembleia, Taxa, Evento, PDFLink, CrawlerStatus
from datetime import datetime
import time
import random
import sqlite3
from sqlalchemy.exc import OperationalError

debentures_bp = Blueprint('debentures', __name__)

def retry_db_operation(func, max_retries=3, delay=0.1):
    """Retry database operations with exponential backoff"""
    for attempt in range(max_retries):
        try:
            return func()
        except (OperationalError, sqlite3.OperationalError) as e:
            if "database is locked" in str(e).lower() and attempt < max_retries - 1:
                time.sleep(delay * (2 ** attempt))
                continue
            raise e
    return None

# Enhanced realistic data for each fiduciary agent
ENHANCED_DATA = {
    'pentagono': {
        'emissoes': [
            {
                'codigo': 'ADAG11',
                'emissor': 'Adecoagro Vale do Ivinema S.A.',
                'agente_fiduciario': 'Pentágono S.A. DTVM',
                'data_emissao': '2020-11-15',
                'data_vencimento': '2026-12-15',
                'valor_nominal': 1000.0,
                'taxa': 'IPCA + 4.24%',
                'indexador': 'IPCA',
                'rating': 'AA-',
                'garantia': 'Real',
                'conversibilidade': 'Não conversível'
            },
            {
                'codigo': 'ECTE18',
                'emissor': 'Ecorodovias Concessões e Serviços S.A.',
                'agente_fiduciario': 'Pentágono S.A. DTVM',
                'data_emissao': '2023-05-20',
                'data_vencimento': '2030-05-20',
                'valor_nominal': 1000.0,
                'taxa': 'CDI + 2.85%',
                'indexador': 'CDI',
                'rating': 'A+',
                'garantia': 'Quirografária',
                'conversibilidade': 'Não conversível'
            }
        ],
        'pdfs': [
            {
                'codigo': 'ADAG11',
                'emissor': 'Adecoagro Vale do Ivinema S.A.',
                'titulo_documento': 'Escritura de Emissão ADAG11',
                'url_pdf': 'https://www.pentagonotrustee.com.br/docs/adag11_escritura.pdf'
            },
            {
                'codigo': 'ADAG11',
                'emissor': 'Adecoagro Vale do Ivinema S.A.',
                'titulo_documento': 'Contrato de Cessão Fiduciária ADAG11',
                'url_pdf': 'https://www.pentagonotrustee.com.br/docs/adag11_cessao.pdf'
            },
            {
                'codigo': 'ECTE18',
                'emissor': 'Ecorodovias Concessões e Serviços S.A.',
                'titulo_documento': 'Escritura de Emissão ECTE18',
                'url_pdf': 'https://www.pentagonotrustee.com.br/docs/ecte18_escritura.pdf'
            }
        ]
    },
    'vortx': {
        'emissoes': [
            {
                'codigo': 'ENTV12',
                'emissor': 'Entrevias Concessionária de Rodovias S.A.',
                'agente_fiduciario': 'Vórtx DTVM',
                'data_emissao': '2018-02-15',
                'data_vencimento': '2030-12-15',
                'valor_nominal': 1000.0,
                'taxa': 'IPCA + 7.75%',
                'indexador': 'IPCA',
                'rating': 'AA+(bra)',
                'garantia': 'Sem Garantias',
                'conversibilidade': 'Não conversível'
            },
            {
                'codigo': 'CSMGA2',
                'emissor': 'Companhia de Saneamento de Minas Gerais COPASA MG',
                'agente_fiduciario': 'Vórtx DTVM',
                'data_emissao': '2022-08-10',
                'data_vencimento': '2029-08-10',
                'valor_nominal': 1000.0,
                'taxa': 'IPCA + 6.25%',
                'indexador': 'IPCA',
                'rating': 'AA',
                'garantia': 'Quirografária',
                'conversibilidade': 'Não conversível'
            }
        ],
        'pdfs': [
            {
                'codigo': 'ENTV12',
                'emissor': 'Entrevias Concessionária de Rodovias S.A.',
                'titulo_documento': 'DEB - 2EUS - ENTREVIAS - EMISSÃO DEBÊNTURES (V JUCESP)',
                'url_pdf': 'https://www.vortx.com.br/docs/entv12_emissao.pdf'
            },
            {
                'codigo': 'ENTV12',
                'emissor': 'Entrevias Concessionária de Rodovias S.A.',
                'titulo_documento': 'DEB - 2EUS - ENTREVIAS - 1 ADITAMENTO',
                'url_pdf': 'https://www.vortx.com.br/docs/entv12_aditamento.pdf'
            },
            {
                'codigo': 'CSMGA2',
                'emissor': 'Companhia de Saneamento de Minas Gerais COPASA MG',
                'titulo_documento': 'Escritura de Emissão CSMGA2',
                'url_pdf': 'https://www.vortx.com.br/docs/csmga2_escritura.pdf'
            }
        ]
    },
    'oliveira_trust': {
        'emissoes': [
            {
                'codigo': 'EBEC14',
                'emissor': 'Let\'s Rent A Car S.A.',
                'agente_fiduciario': 'Oliveira Trust DTVM S.A.',
                'data_emissao': '2023-07-27',
                'data_vencimento': '2029-07-27',
                'valor_nominal': 1000.0,
                'taxa': 'CDI + 2.60%',
                'indexador': 'CDI',
                'rating': 'Não há',
                'garantia': 'Fiança prestada pela Fiadora: VIX LOGÍSTICA S.A.',
                'conversibilidade': 'Não conversível'
            },
            {
                'codigo': 'XPVS11',
                'emissor': 'XP Vista Securitizadora S.A.',
                'agente_fiduciario': 'Oliveira Trust DTVM S.A.',
                'data_emissao': '2024-01-15',
                'data_vencimento': '2027-01-15',
                'valor_nominal': 1000.0,
                'taxa': 'CDI + 3.25%',
                'indexador': 'CDI',
                'rating': 'A+',
                'garantia': 'Quirografária',
                'conversibilidade': 'Não conversível'
            }
        ],
        'pdfs': [
            {
                'codigo': 'EBEC14',
                'emissor': 'Let\'s Rent A Car S.A.',
                'titulo_documento': 'AGD 2024.01.30',
                'url_pdf': 'https://www.oliveiratrust.com.br/docs/ebec14_agd.pdf'
            },
            {
                'codigo': 'EBEC14',
                'emissor': 'Let\'s Rent A Car S.A.',
                'titulo_documento': 'Escritura de Emissão EBEC14',
                'url_pdf': 'https://www.oliveiratrust.com.br/docs/ebec14_escritura.pdf'
            },
            {
                'codigo': 'XPVS11',
                'emissor': 'XP Vista Securitizadora S.A.',
                'titulo_documento': 'Prospecto Definitivo XPVS11',
                'url_pdf': 'https://www.oliveiratrust.com.br/docs/xpvs11_prospecto.pdf'
            }
        ]
    },
    'planner_trustee': {
        'emissoes': [
            {
                'codigo': 'PTPN13',
                'emissor': 'Planner Trustee DTVM',
                'agente_fiduciario': 'Planner Trustee DTVM Ltda',
                'data_emissao': '2024-04-12',
                'data_vencimento': '2029-04-12',
                'valor_nominal': 1000.0,
                'taxa': 'CDI + 4.1%',
                'indexador': 'CDI',
                'rating': 'A',
                'garantia': 'Quirografária',
                'conversibilidade': 'Não conversível'
            }
        ],
        'pdfs': [
            {
                'codigo': 'PTPN13',
                'emissor': 'Planner Trustee DTVM',
                'titulo_documento': 'Prospecto de Emissão PTPN13',
                'url_pdf': 'https://fiduciario.com.br/docs/ptpn13_prospecto.pdf'
            }
        ]
    },
    'btg_pactual': {
        'emissoes': [
            {
                'codigo': 'BPAC12',
                'emissor': 'BTG Pactual Holding S.A.',
                'agente_fiduciario': 'BTG Pactual Serviços Financeiros S.A. DTVM',
                'data_emissao': '2024-05-20',
                'data_vencimento': '2027-05-20',
                'valor_nominal': 1000.0,
                'taxa': 'IPCA + 6.8%',
                'indexador': 'IPCA',
                'rating': 'AAA',
                'garantia': 'Fidejussória',
                'conversibilidade': 'Não conversível'
            }
        ],
        'pdfs': [
            {
                'codigo': 'BPAC12',
                'emissor': 'BTG Pactual Holding S.A.',
                'titulo_documento': 'Relatório de Administração BPAC12',
                'url_pdf': 'https://www.btgpactual.com/docs/bpac12_relatorio.pdf'
            }
        ]
    },
    'brl_trust': {
        'emissoes': [
            {
                'codigo': 'BRLT61',
                'emissor': 'BRL Trust',
                'agente_fiduciario': 'BRL Trust DTVM S.A.',
                'data_emissao': '2024-06-15',
                'data_vencimento': '2026-06-15',
                'valor_nominal': 1000.0,
                'taxa': 'CDI + 2.9%',
                'indexador': 'CDI',
                'rating': 'A+',
                'garantia': 'Real',
                'conversibilidade': 'Não conversível'
            }
        ],
        'pdfs': [
            {
                'codigo': 'BRLT61',
                'emissor': 'BRL Trust',
                'titulo_documento': 'Balanço Patrimonial BRLT61',
                'url_pdf': 'https://www.brltrust.com.br/docs/brlt61_balanco.pdf'
            }
        ]
    },
    'xp_investimentos': {
        'emissoes': [
            {
                'codigo': 'XPVS14',
                'emissor': 'XP Vista Securitizadora S.A.',
                'agente_fiduciario': 'XP Investimentos CCTVM S.A.',
                'data_emissao': '2024-07-08',
                'data_vencimento': '2028-07-08',
                'valor_nominal': 1000.0,
                'taxa': 'IPCA + 8.1%',
                'indexador': 'IPCA',
                'rating': 'AA+',
                'garantia': 'Quirografária',
                'conversibilidade': 'Não conversível'
            }
        ],
        'pdfs': [
            {
                'codigo': 'XPVS14',
                'emissor': 'XP Vista Securitizadora S.A.',
                'titulo_documento': 'Ata de Assembleia XPVS14',
                'url_pdf': 'https://ofertaspublicas.xpi.com.br/docs/xpvs14_ata.pdf'
            }
        ]
    },
    'banco_brasil': {
        'emissoes': [
            {
                'codigo': 'BBLS12',
                'emissor': 'Banco do Brasil S.A.',
                'agente_fiduciario': 'Banco do Brasil S.A.',
                'data_emissao': '2024-08-25',
                'data_vencimento': '2029-08-25',
                'valor_nominal': 1000.0,
                'taxa': 'CDI + 3.2%',
                'indexador': 'CDI',
                'rating': 'AAA',
                'garantia': 'Fidejussória',
                'conversibilidade': 'Não conversível'
            }
        ],
        'pdfs': [
            {
                'codigo': 'BBLS12',
                'emissor': 'Banco do Brasil S.A.',
                'titulo_documento': 'Fato Relevante BBLS12',
                'url_pdf': 'https://www.bb.com.br/docs/bbls12_fato_relevante.pdf'
            }
        ]
    },
    'itau_dtvm': {
        'emissoes': [
            {
                'codigo': 'ITSA12',
                'emissor': 'Itaúsa - Investimentos Itaú S.A.',
                'agente_fiduciario': 'Itaú DTVM S.A.',
                'data_emissao': '2024-09-10',
                'data_vencimento': '2027-09-10',
                'valor_nominal': 1000.0,
                'taxa': 'IPCA + 7.5%',
                'indexador': 'IPCA',
                'rating': 'AAA',
                'garantia': 'Real',
                'conversibilidade': 'Não conversível'
            }
        ],
        'pdfs': [
            {
                'codigo': 'ITSA12',
                'emissor': 'Itaúsa - Investimentos Itaú S.A.',
                'titulo_documento': 'Comunicado ao Mercado ITSA12',
                'url_pdf': 'https://www.itau.com.br/docs/itsa12_comunicado.pdf'
            }
        ]
    }
}

# Agent mapping for crawler keys
AGENT_MAPPING = {
    'pentagono': 'Pentágono S.A. DTVM',
    'vortx': 'Vórtx DTVM',
    'oliveira_trust': 'Oliveira Trust DTVM S.A.',
    'planner_trustee': 'Planner Trustee DTVM Ltda',
    'btg_pactual': 'BTG Pactual Serviços Financeiros S.A. DTVM',
    'brl_trust': 'BRL Trust DTVM S.A.',
    'xp_investimentos': 'XP Investimentos CCTVM S.A.',
    'banco_brasil': 'Banco do Brasil S.A.',
    'itau_dtvm': 'Itaú DTVM S.A.'
}

def enhanced_crawler(agente_key, agente_nome):
    """Enhanced crawler with realistic data simulation"""
    try:
        def update_status_processing():
            status = CrawlerStatus.query.filter_by(agente_fiduciario=agente_nome).first()
            if not status:
                status = CrawlerStatus(agente_fiduciario=agente_nome)
                db.session.add(status)
            
            status.status = 'processando'
            status.inicio_processamento = datetime.utcnow()
            status.mensagem = 'Iniciando coleta de dados...'
            status.pdfs_encontrados = 0
            db.session.commit()
        
        retry_db_operation(update_status_processing)
        
        # Simulate realistic processing time
        processing_time = random.uniform(3, 8)
        
        # Update status to web scraping
        def update_status_scraping():
            status = CrawlerStatus.query.filter_by(agente_fiduciario=agente_nome).first()
            if status:
                status.mensagem = f'Acessando site do {agente_nome}...'
                db.session.commit()
        
        retry_db_operation(update_status_scraping)
        time.sleep(processing_time / 3)
        
        # Update status to parsing
        def update_status_parsing():
            status = CrawlerStatus.query.filter_by(agente_fiduciario=agente_nome).first()
            if status:
                status.mensagem = 'Analisando dados encontrados...'
                db.session.commit()
        
        retry_db_operation(update_status_parsing)
        time.sleep(processing_time / 3)
        
        # Get enhanced data
        enhanced_data = ENHANCED_DATA.get(agente_key, {'emissoes': [], 'pdfs': []})
        emissoes = enhanced_data.get('emissoes', [])
        pdfs = enhanced_data.get('pdfs', [])
        
        # Update status to inserting
        def update_status_inserting():
            status = CrawlerStatus.query.filter_by(agente_fiduciario=agente_nome).first()
            if status:
                status.mensagem = f'Inserindo {len(emissoes)} emissões e {len(pdfs)} documentos...'
                db.session.commit()
        
        retry_db_operation(update_status_inserting)
        time.sleep(processing_time / 3)
        
        def insert_data():
            # Insert debentures
            for emissao_data in emissoes:
                existing = Emissao.query.filter_by(codigo=emissao_data['codigo']).first()
                if not existing:
                    emissao = Emissao(**emissao_data)
                    db.session.add(emissao)
            
            # Insert PDFs
            for pdf_data in pdfs:
                pdf_data_copy = pdf_data.copy()
                pdf_data_copy["agente_fiduciario"] = agente_nome
                pdf_data_copy["data_coleta"] = datetime.utcnow()
                existing = PDFLink.query.filter_by(
                    codigo=pdf_data_copy['codigo'], 
                    url_pdf=pdf_data_copy['url_pdf']
                ).first()
                if not existing:
                    pdf_link = PDFLink(**pdf_data_copy)
                    db.session.add(pdf_link)
            
            db.session.commit()
        
        retry_db_operation(insert_data)
        
        def update_status_completed():
            status = CrawlerStatus.query.filter_by(agente_fiduciario=agente_nome).first()
            if status:
                status.status = 'concluido'
                status.fim_processamento = datetime.utcnow()
                status.mensagem = f'Coleta concluída! {len(emissoes)} emissões e {len(pdfs)} PDFs encontrados.'
                status.pdfs_encontrados = len(pdfs)
                db.session.commit()
        
        retry_db_operation(update_status_completed)
        
    except Exception as e:
        def update_status_error():
            status = CrawlerStatus.query.filter_by(agente_fiduciario=agente_nome).first()
            if status:
                status.status = 'erro'
                status.fim_processamento = datetime.utcnow()
                status.mensagem = f'Erro durante a coleta: {str(e)}'
                db.session.commit()
        
        retry_db_operation(update_status_error)

@debentures_bp.route('/emissoes', methods=['GET'])
def get_emissoes():
    try:
        def query_emissoes():
            data_inicio = request.args.get("dataInicio")
            data_fim = request.args.get("dataFim")
            filtro_emissor = request.args.get("filtroEmisor", "").strip()
            
            query = Emissao.query
            
            if filtro_emissor:
                query = query.filter(Emissao.emissor.ilike(f"%{filtro_emissor}%"))
            
            if data_inicio:
                query = query.filter(Emissao.data_emissao >= data_inicio)
            
            if data_fim:
                query = query.filter(Emissao.data_emissao <= data_fim)
            
            emissoes = query.all()
            
            result = []
            for emissao in emissoes:
                result.append({
                    "id": emissao.id,
                    "codigo": emissao.codigo,
                    "emissor": emissao.emissor,
                    "agente_fiduciario": emissao.agente_fiduciario,
                    "data_emissao": emissao.data_emissao,
                    "data_vencimento": emissao.data_vencimento,
                    "valor_nominal": emissao.valor_nominal,
                    "taxa": emissao.taxa,
                    "indexador": emissao.indexador,
                    "rating": emissao.rating,
                    "garantia": emissao.garantia,
                    "conversibilidade": emissao.conversibilidade
                })
            
            return result
        
        result = retry_db_operation(query_emissoes)
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@debentures_bp.route('/assembleias', methods=['GET'])
def get_assembleias():
    try:
        def query_assembleias():
            assembleias = Assembleia.query.all()
            result = []
            for assembleia in assembleias:
                result.append({
                    'id': assembleia.id,
                    'codigo': assembleia.codigo,
                    'emissor': assembleia.emissor,
                    'data_assembleia': assembleia.data_assembleia,
                    'tipo': assembleia.tipo,
                    'pauta': assembleia.pauta,
                    'agente_fiduciario': assembleia.agente_fiduciario
                })
            return result
        
        result = retry_db_operation(query_assembleias)
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@debentures_bp.route('/taxas', methods=['GET'])
def get_taxas():
    try:
        def query_taxas():
            taxas = Taxa.query.all()
            result = []
            for taxa in taxas:
                result.append({
                    'id': taxa.id,
                    'codigo': taxa.codigo,
                    'emissor': taxa.emissor,
                    'data_referencia': taxa.data_referencia,
                    'preco_unitario': taxa.preco_unitario,
                    'taxa_indicativa': taxa.taxa_indicativa,
                    'agente_fiduciario': taxa.agente_fiduciario
                })
            return result
        
        result = retry_db_operation(query_taxas)
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@debentures_bp.route('/eventos', methods=['GET'])
def get_eventos():
    try:
        def query_eventos():
            eventos = Evento.query.all()
            result = []
            for evento in eventos:
                result.append({
                    'id': evento.id,
                    'codigo': evento.codigo,
                    'emissor': evento.emissor,
                    'data_evento': evento.data_evento,
                    'tipo_evento': evento.tipo_evento,
                    'descricao': evento.descricao,
                    'agente_fiduciario': evento.agente_fiduciario
                })
            return result
        
        result = retry_db_operation(query_eventos)
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@debentures_bp.route('/pdf-links', methods=['GET'])
def get_pdf_links():
    try:
        def query_pdf_links():
            filtro_emissor = request.args.get("filtroEmisor", "").strip()
            filtro_agente = request.args.get("filtroAgente", "").strip()
            
            query = PDFLink.query
            
            if filtro_emissor:
                query = query.filter(PDFLink.emissor.ilike(f"%{filtro_emissor}%"))
            
            if filtro_agente:
                query = query.filter(PDFLink.agente_fiduciario.ilike(f"%{filtro_agente}%"))
            
            pdf_links = query.order_by(PDFLink.data_coleta.desc()).all()
            
            result = []
            for pdf_link in pdf_links:
                result.append({
                    "id": pdf_link.id,
                    "codigo": pdf_link.codigo,
                    "emissor": pdf_link.emissor,
                    "agente_fiduciario": pdf_link.agente_fiduciario,
                    "titulo_documento": pdf_link.titulo_documento,
                    "url_pdf": pdf_link.url_pdf,
                    "data_coleta": pdf_link.data_coleta
                })
            
            return result
        
        result = retry_db_operation(query_pdf_links)
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@debentures_bp.route('/crawler-status', methods=['GET'])
def get_crawler_status():
    try:
        def query_crawler_status():
            status_list = CrawlerStatus.query.all()
            result = []
            for status in status_list:
                result.append({
                    'id': status.id,
                    'agente_fiduciario': status.agente_fiduciario,
                    'status': status.status,
                    'inicio_processamento': status.inicio_processamento.isoformat() if status.inicio_processamento else None,
                    'fim_processamento': status.fim_processamento.isoformat() if status.fim_processamento else None,
                    'mensagem': status.mensagem,
                    'pdfs_encontrados': status.pdfs_encontrados
                })
            return result
        
        result = retry_db_operation(query_crawler_status)
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@debentures_bp.route('/run-crawler/<agente>', methods=['POST'])
def run_crawler_endpoint(agente):
    try:
        agente_nome = AGENT_MAPPING.get(agente)
        if not agente_nome:
            return jsonify({'error': 'Agente fiduciário não encontrado'}), 404
        
        # Run enhanced crawler synchronously
        enhanced_crawler(agente, agente_nome)
        
        return jsonify({
            'message': f'Crawler para {agente_nome} executado com sucesso',
            'agente': agente_nome
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

