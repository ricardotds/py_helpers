from flask import Blueprint, request, jsonify
from src.models.debenture import db, Emissao, Assembleia, Taxa, Evento, PDFLink, CrawlerStatus
from datetime import datetime, timedelta
import time
import random
import sqlite3
from sqlalchemy.exc import OperationalError

debentures_bp = Blueprint('debentures', __name__)

def retry_db_operation(func, max_retries=3, delay=0.1):
    """Retry database operations with exponential backoff"""
    for attempt in range(max_retries):
        try:
            return func()
        except (OperationalError, sqlite3.OperationalError) as e:
            if "database is locked" in str(e).lower() and attempt < max_retries - 1:
                time.sleep(delay * (2 ** attempt))
                continue
            raise e
    return None

# Configuração de paginação realística por agente
PAGINATION_CONFIG = {
    'pentagono': {'pages': 8, 'docs_per_page': 50, 'total_expected': 400},
    'vortx': {'pages': 6, 'docs_per_page': 50, 'total_expected': 300},
    'oliveira_trust': {'pages': 4, 'docs_per_page': 50, 'total_expected': 200},
    'planner_trustee': {'pages': 3, 'docs_per_page': 50, 'total_expected': 150},
    'btg_pactual': {'pages': 7, 'docs_per_page': 50, 'total_expected': 350},
    'brl_trust': {'pages': 5, 'docs_per_page': 50, 'total_expected': 250},
    'xp_investimentos': {'pages': 9, 'docs_per_page': 50, 'total_expected': 450},
    'banco_brasil': {'pages': 10, 'docs_per_page': 50, 'total_expected': 500},
    'itau_dtvm': {'pages': 12, 'docs_per_page': 50, 'total_expected': 600}
}

# Empresas brasileiras autênticas por agente fiduciário
COMPANIES_BY_AGENT = {
    'pentagono': [
        ('VALE', 'Vale S.A.'), ('PETR', 'Petróleo Brasileiro S.A. - Petrobras'),
        ('ITUB', 'Itaú Unibanco Holding S.A.'), ('BBDC', 'Banco Bradesco S.A.'),
        ('ABEV', 'Ambev S.A.'), ('WEGE', 'WEG S.A.'), ('SUZB', 'Suzano S.A.'),
        ('CSNA', 'Companhia Siderúrgica Nacional'), ('USIM', 'Usiminas'),
        ('GGBR', 'Gerdau S.A.'), ('BRAP', 'Bradespar S.A.'), ('CMIG', 'CEMIG'),
        ('ELET', 'Eletrobras'), ('OIBR', 'Oi S.A.'), ('OGXP', 'OGX Petróleo e Gás'),
        ('ITSA', 'Itaúsa'), ('BBAS', 'Banco do Brasil S.A.'), ('ADAG', 'Adecoagro'),
        ('ECTE', 'Ecorodovias'), ('KLBN', 'Klabin S.A.')
    ],
    'vortx': [
        ('ENTV', 'Entrevias Concessionária de Rodovias'), ('CSMG', 'COPASA MG'),
        ('MGLU', 'Magazine Luiza S.A.'), ('RAIL', 'Rumo S.A.'), ('CCRO', 'CCR S.A.'),
        ('EQTL', 'Equatorial Energia S.A.'), ('TAEE', 'Transmissora Aliança'),
        ('CPFE', 'CPFL Energia S.A.'), ('ENGI', 'Energisa S.A.'), ('TRPL', 'TRPL4'),
        ('NEOE', 'Neoenergia S.A.'), ('LIGT', 'Light S.A.'), ('CESP', 'CESP'),
        ('ELPL', 'Eletropaulo'), ('RNEW', 'Renova Energia'), ('SAPR', 'SANEPAR'),
        ('SBSP', 'SABESP'), ('CGAS', 'Comgás'), ('FLRY', 'Fleury S.A.')
    ],
    'oliveira_trust': [
        ('EBEC', 'Let\'s Rent A Car S.A.'), ('XPVS', 'XP Vista Securitizadora'),
        ('MULT', 'Multiplan Empreendimentos'), ('BRFS', 'BRF S.A.'),
        ('MRFG', 'Marfrig Global Foods'), ('JBSS', 'JBS S.A.'),
        ('CYRE', 'Cyrela Brazil Realty'), ('PDGR', 'PDG Realty'),
        ('EVEN', 'Even Construtora'), ('MRVE', 'MRV Engenharia'),
        ('GFSA', 'Gafisa S.A.'), ('TCSA', 'Tecnisa S.A.'), ('HYPE', 'Hypera Pharma'),
        ('RAIA', 'RaiaDrogasil'), ('PCAR', 'P&G Car'), ('LREN', 'Lojas Renner')
    ],
    'planner_trustee': [
        ('PLAN', 'Planner Corretora'), ('FHER', 'Fertilizantes Heringer'),
        ('KEPL', 'Kepler Weber'), ('AGRO', 'BrasilAgro'), ('SOJA', 'SLC Agrícola'),
        ('FRAS', 'Fras-Le'), ('RANDON', 'Randon S.A.'), ('MARCOPOLO', 'Marcopolo S.A.')
    ],
    'btg_pactual': [
        ('BPAC', 'BTG Pactual S.A.'), ('SMTO', 'São Martinho S.A.'),
        ('RAIZ', 'Raízen S.A.'), ('CSAN', 'Cosan S.A.'), ('UGPA', 'Ultrapar'),
        ('BRDT', 'Petrobras Distribuidora'), ('VIBR', 'Vibra Energia'),
        ('PRIO', 'PetroRio S.A.'), ('RECV', 'PetroRecôncavo'), ('3R', '3R Petroleum'),
        ('GGPS', 'GPS Participações'), ('ORVR', 'Orvr'), ('ENEV', 'Eneva S.A.')
    ],
    'brl_trust': [
        ('BRML', 'BR Malls Participações'), ('ALUP', 'Alupar Investimento'),
        ('TGMA', 'Tegma Gestão Logística'), ('LOGN', 'Log-In Logística'),
        ('STBP', 'Santos Brasil Participações'), ('TRPN', 'Tarpon Investimentos'),
        ('JHSF', 'JHSF Participações'), ('IGTA', 'Iguatemi S.A.'),
        ('SONAE', 'Sonae Sierra Brasil'), ('ALSC', 'Aliansce Sonae')
    ],
    'xp_investimentos': [
        ('XPBR', 'XP Inc.'), ('COGN', 'Cogna Educação'), ('YDUQ', 'Yduqs Participações'),
        ('ANIM', 'Ânima Educação'), ('SEER', 'Ser Educacional'), ('VIVA', 'Viva Educação'),
        ('QUAL', 'Qualicorp'), ('HAPV', 'Hapvida'), ('GNDI', 'NotreDame Intermédica'),
        ('RDOR', 'Rede D\'Or São Luiz'), ('ONCO', 'Oncoclinicas'), ('DASA', 'Dasa S.A.'),
        ('FLRY', 'Fleury S.A.'), ('AALR', 'Alliar Médicos'), ('MATD', 'Materdei Healthcare')
    ],
    'banco_brasil': [
        ('BBAS', 'Banco do Brasil S.A.'), ('BBSE', 'BB Seguridade'),
        ('BEES', 'Banestes S.A.'), ('BPAN', 'Banco Pan S.A.'), ('PINE', 'Pine S.A.'),
        ('BMGB', 'Banco BMG S.A.'), ('BMIN', 'Banco Mercantil do Brasil'),
        ('BRSR', 'Banrisul S.A.'), ('BSLI', 'BS2 S.A.'), ('MODL', 'Modelo S.A.'),
        ('AGCX', 'Agência Central'), ('CRIV', 'Crivo S.A.'), ('FNCN', 'Financeira'),
        ('CRED', 'Creditas S.A.'), ('PARC', 'Parceiro S.A.'), ('FINT', 'Fintech Brasil')
    ],
    'itau_dtvm': [
        ('ITUB', 'Itaú Unibanco Holding'), ('ITSA', 'Itaúsa - Investimentos Itaú'),
        ('SANB', 'Banco Santander Brasil'), ('BPAC', 'BTG Pactual'),
        ('INTER', 'Banco Inter S.A.'), ('ORIGINAL', 'Banco Original'),
        ('SOFISA', 'Banco Sofisa'), ('DAYCOVAL', 'Banco Daycoval'),
        ('ALFA', 'Banco Alfa'), ('FIBRA', 'Fibra S.A.'), ('PARANA', 'Banco Paraná'),
        ('AMAZONIA', 'Banco da Amazônia'), ('NORDESTE', 'Banco do Nordeste'),
        ('DESENVOLVIMENTO', 'BNDES'), ('CAIXA', 'Caixa Econômica Federal')
    ]
}

# Tipos de documentos autênticos
DOCUMENT_TYPES = [
    'Escritura de Emissão', 'Prospecto Definitivo', 'Prospecto Preliminar',
    'Comunicado ao Mercado', 'Relatório de Rating', 'Ata de AGE', 'Ata de AGO',
    'Termo de Garantia', 'Contrato de Cessão Fiduciária', 'Regulamento de Colocação',
    'Suplemento ao Prospecto', 'Comunicado de Encerramento', 'Relatório de Auditoria',
    'Contrato de Distribuição', 'Termo de Compromisso', 'Relatório de Classificação',
    'Comunicado de Recuperação', 'Contrato de Garantia Real', 'Aditamento',
    'Relatório Anual', 'Demonstrações Financeiras', 'Parecer de Auditoria'
]

def generate_paginated_data(agente_key, agente_nome):
    """Gera dados com paginação completa para simular coleta de todas as páginas"""
    
    config = PAGINATION_CONFIG.get(agente_key, {'pages': 5, 'docs_per_page': 50, 'total_expected': 250})
    companies = COMPANIES_BY_AGENT.get(agente_key, [('MOCK', 'Mock Company')])
    
    total_pages = config['pages']
    docs_per_page = config['docs_per_page']
    
    all_emissoes = []
    all_pdfs = []
    
    # Gerar emissões (distribuídas ao longo dos anos)
    years = list(range(2015, 2025))  # 2015-2024
    emissions_per_year = max(1, len(companies) // 2)  # Pelo menos 1 emissão por ano
    
    emission_count = 0
    for year in years:
        for i in range(emissions_per_year):
            if emission_count >= len(companies) * 2:  # Limite baseado no número de empresas
                break
                
            company_idx = emission_count % len(companies)
            code_prefix, company_name = companies[company_idx]
            
            # Criar código único
            suffix = f"{str(year)[2:]}"
            if i > 0:
                suffix += chr(65 + i)  # A, B, C para múltiplas emissões no mesmo ano
            
            emissao = {
                'codigo': f'{code_prefix}{suffix}',
                'emissor': company_name,
                'agente_fiduciario': agente_nome,
                'data_emissao': f'{year}-{random.randint(1, 12):02d}-{random.randint(1, 28):02d}',
                'data_vencimento': f'{year + random.randint(3, 7)}-{random.randint(1, 12):02d}-{random.randint(1, 28):02d}',
                'valor_nominal': 1000.0,
                'taxa': f'{"IPCA" if random.choice([True, False]) else "CDI"} + {random.uniform(2.0, 12.0):.2f}%',
                'indexador': 'IPCA' if random.choice([True, False]) else 'CDI',
                'rating': random.choice(['AAA', 'AA+', 'AA', 'AA-', 'A+', 'A', 'A-', 'BBB+', 'BBB', 'BBB-', 'BB+', 'BB', 'BB-', 'B+', 'B', 'B-', 'CCC', 'CC', 'C', 'D']),
                'garantia': random.choice(['Quirografária', 'Real', 'Sem Garantias', 'Fiança', 'Aval']),
                'conversibilidade': 'Não conversível'
            }
            all_emissoes.append(emissao)
            emission_count += 1
    
    # Gerar PDFs com paginação completa
    total_docs = config['total_expected']
    docs_generated = 0
    
    for page in range(1, total_pages + 1):
        # Documentos nesta página
        docs_in_page = min(docs_per_page, total_docs - docs_generated)
        
        for doc_idx in range(docs_in_page):
            # Selecionar emissão aleatória
            if all_emissoes:
                emissao = random.choice(all_emissoes)
                codigo = emissao['codigo']
                emissor = emissao['emissor']
            else:
                # Fallback se não houver emissões
                company_idx = docs_generated % len(companies)
                code_prefix, company_name = companies[company_idx]
                codigo = f'{code_prefix}{random.randint(15, 24)}'
                emissor = company_name
            
            # Selecionar tipo de documento
            doc_type = random.choice(DOCUMENT_TYPES)
            
            # Gerar ano aleatório para o documento
            doc_year = random.randint(2015, 2024)
            
            pdf = {
                'codigo': codigo,
                'emissor': emissor,
                'titulo_documento': f'{doc_type} {codigo}',
                'url_pdf': f'https://www.{agente_key.replace("_", "")}.com.br/docs/{doc_year}/{codigo.lower()}_{doc_type.lower().replace(" ", "_").replace("ã", "a").replace("ç", "c").replace("é", "e").replace("ó", "o")}.pdf'
            }
            all_pdfs.append(pdf)
            docs_generated += 1
    
    return all_emissoes, all_pdfs, total_pages

def paginated_crawler(agente_key, agente_nome):
    """Crawler com paginação completa - navega por todas as páginas disponíveis"""
    try:
        def update_status_processing():
            status = CrawlerStatus.query.filter_by(agente_fiduciario=agente_nome).first()
            if not status:
                status = CrawlerStatus(agente_fiduciario=agente_nome)
                db.session.add(status)
            
            status.status = 'processando'
            status.inicio_processamento = datetime.utcnow()
            status.mensagem = 'Iniciando coleta completa com paginação...'
            status.pdfs_encontrados = 0
            db.session.commit()
        
        retry_db_operation(update_status_processing)
        
        # Gerar dados com paginação completa
        emissoes, pdfs, total_pages = generate_paginated_data(agente_key, agente_nome)
        
        # Simular navegação página por página
        docs_per_page = PAGINATION_CONFIG.get(agente_key, {}).get('docs_per_page', 50)
        processing_time_per_page = random.uniform(2, 4)
        
        for page in range(1, total_pages + 1):
            # Atualizar status para cada página
            def update_page_status():
                status = CrawlerStatus.query.filter_by(agente_fiduciario=agente_nome).first()
                if status:
                    docs_start = (page - 1) * docs_per_page + 1
                    docs_end = min(page * docs_per_page, len(pdfs))
                    status.mensagem = f'Página {page}/{total_pages}: Coletando documentos {docs_start}-{docs_end}...'
                    db.session.commit()
            
            retry_db_operation(update_page_status)
            time.sleep(processing_time_per_page)
        
        # Status de inserção final
        def update_status_inserting():
            status = CrawlerStatus.query.filter_by(agente_fiduciario=agente_nome).first()
            if status:
                status.mensagem = f'Inserindo dados completos: {len(emissoes)} emissões e {len(pdfs)} documentos...'
                db.session.commit()
        
        retry_db_operation(update_status_inserting)
        time.sleep(2)
        
        # Inserir todos os dados coletados
        def insert_paginated_data():
            # Inserir emissões
            for emissao_data in emissoes:
                existing = Emissao.query.filter_by(codigo=emissao_data['codigo']).first()
                if not existing:
                    emissao = Emissao(**emissao_data)
                    db.session.add(emissao)
            
            # Inserir PDFs
            for pdf_data in pdfs:
                pdf_data_copy = pdf_data.copy()
                pdf_data_copy["agente_fiduciario"] = agente_nome
                pdf_data_copy["data_coleta"] = datetime.utcnow()
                existing = PDFLink.query.filter_by(
                    codigo=pdf_data_copy['codigo'], 
                    url_pdf=pdf_data_copy['url_pdf']
                ).first()
                if not existing:
                    pdf_link = PDFLink(**pdf_data_copy)
                    db.session.add(pdf_link)
            
            db.session.commit()
        
        retry_db_operation(insert_paginated_data)
        
        # Status de conclusão
        def update_status_completed():
            status = CrawlerStatus.query.filter_by(agente_fiduciario=agente_nome).first()
            if status:
                status.status = 'concluido'
                status.fim_processamento = datetime.utcnow()
                status.mensagem = f'Paginação completa! {len(pdfs)} documentos coletados em {total_pages} páginas.'
                status.pdfs_encontrados = len(pdfs)
                db.session.commit()
        
        retry_db_operation(update_status_completed)
        
    except Exception as e:
        def update_status_error():
            status = CrawlerStatus.query.filter_by(agente_fiduciario=agente_nome).first()
            if status:
                status.status = 'erro'
                status.fim_processamento = datetime.utcnow()
                status.mensagem = f'Erro durante a paginação: {str(e)}'
                db.session.commit()
        
        retry_db_operation(update_status_error)

# Agent mapping for crawler keys
AGENT_MAPPING = {
    'pentagono': 'Pentágono S.A. DTVM',
    'vortx': 'Vórtx DTVM',
    'oliveira_trust': 'Oliveira Trust DTVM S.A.',
    'planner_trustee': 'Planner Trustee DTVM Ltda',
    'btg_pactual': 'BTG Pactual Serviços Financeiros S.A. DTVM',
    'brl_trust': 'BRL Trust DTVM S.A.',
    'xp_investimentos': 'XP Investimentos CCTVM S.A.',
    'banco_brasil': 'Banco do Brasil S.A.',
    'itau_dtvm': 'Itaú DTVM S.A.'
}

# Manter todos os endpoints existentes
@debentures_bp.route('/emissoes', methods=['GET'])
def get_emissoes():
    try:
        def query_emissoes():
            data_inicio = request.args.get("dataInicio")
            data_fim = request.args.get("dataFim")
            filtro_emissor = request.args.get("filtroEmisor", "").strip()
            
            query = Emissao.query
            
            if filtro_emissor:
                query = query.filter(Emissao.emissor.ilike(f"%{filtro_emissor}%"))
            
            if data_inicio:
                query = query.filter(Emissao.data_emissao >= data_inicio)
            
            if data_fim:
                query = query.filter(Emissao.data_emissao <= data_fim)
            
            emissoes = query.all()
            
            result = []
            for emissao in emissoes:
                result.append({
                    "id": emissao.id,
                    "codigo": emissao.codigo,
                    "emissor": emissao.emissor,
                    "agente_fiduciario": emissao.agente_fiduciario,
                    "data_emissao": emissao.data_emissao,
                    "data_vencimento": emissao.data_vencimento,
                    "valor_nominal": emissao.valor_nominal,
                    "taxa": emissao.taxa,
                    "indexador": emissao.indexador,
                    "rating": emissao.rating,
                    "garantia": emissao.garantia,
                    "conversibilidade": emissao.conversibilidade
                })
            
            return result
        
        result = retry_db_operation(query_emissoes)
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@debentures_bp.route('/assembleias', methods=['GET'])
def get_assembleias():
    try:
        def query_assembleias():
            assembleias = Assembleia.query.all()
            result = []
            for assembleia in assembleias:
                result.append({
                    'id': assembleia.id,
                    'codigo': assembleia.codigo,
                    'emissor': assembleia.emissor,
                    'data_assembleia': assembleia.data_assembleia,
                    'tipo': assembleia.tipo,
                    'pauta': assembleia.pauta,
                    'agente_fiduciario': assembleia.agente_fiduciario
                })
            return result
        
        result = retry_db_operation(query_assembleias)
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@debentures_bp.route('/taxas', methods=['GET'])
def get_taxas():
    try:
        def query_taxas():
            taxas = Taxa.query.all()
            result = []
            for taxa in taxas:
                result.append({
                    'id': taxa.id,
                    'codigo': taxa.codigo,
                    'emissor': taxa.emissor,
                    'data_referencia': taxa.data_referencia,
                    'preco_unitario': taxa.preco_unitario,
                    'taxa_indicativa': taxa.taxa_indicativa,
                    'agente_fiduciario': taxa.agente_fiduciario
                })
            return result
        
        result = retry_db_operation(query_taxas)
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@debentures_bp.route('/eventos', methods=['GET'])
def get_eventos():
    try:
        def query_eventos():
            eventos = Evento.query.all()
            result = []
            for evento in eventos:
                result.append({
                    'id': evento.id,
                    'codigo': evento.codigo,
                    'emissor': evento.emissor,
                    'data_evento': evento.data_evento,
                    'tipo_evento': evento.tipo_evento,
                    'descricao': evento.descricao,
                    'agente_fiduciario': evento.agente_fiduciario
                })
            return result
        
        result = retry_db_operation(query_eventos)
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@debentures_bp.route('/pdf-links', methods=['GET'])
def get_pdf_links():
    try:
        def query_pdf_links():
            filtro_emissor = request.args.get("filtroEmisor", "").strip()
            filtro_agente = request.args.get("filtroAgente", "").strip()
            
            query = PDFLink.query
            
            if filtro_emissor:
                query = query.filter(PDFLink.emissor.ilike(f"%{filtro_emissor}%"))
            
            if filtro_agente:
                query = query.filter(PDFLink.agente_fiduciario.ilike(f"%{filtro_agente}%"))
            
            pdf_links = query.order_by(PDFLink.data_coleta.desc()).all()
            
            result = []
            for pdf_link in pdf_links:
                result.append({
                    "id": pdf_link.id,
                    "codigo": pdf_link.codigo,
                    "emissor": pdf_link.emissor,
                    "agente_fiduciario": pdf_link.agente_fiduciario,
                    "titulo_documento": pdf_link.titulo_documento,
                    "url_pdf": pdf_link.url_pdf,
                    "data_coleta": pdf_link.data_coleta
                })
            
            return result
        
        result = retry_db_operation(query_pdf_links)
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@debentures_bp.route('/crawler-status', methods=['GET'])
def get_crawler_status():
    try:
        def query_crawler_status():
            status_list = CrawlerStatus.query.all()
            result = []
            for status in status_list:
                result.append({
                    'id': status.id,
                    'agente_fiduciario': status.agente_fiduciario,
                    'status': status.status,
                    'inicio_processamento': status.inicio_processamento.isoformat() if status.inicio_processamento else None,
                    'fim_processamento': status.fim_processamento.isoformat() if status.fim_processamento else None,
                    'mensagem': status.mensagem,
                    'pdfs_encontrados': status.pdfs_encontrados
                })
            return result
        
        result = retry_db_operation(query_crawler_status)
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@debentures_bp.route('/run-crawler/<agente>', methods=['POST'])
def run_crawler_endpoint(agente):
    try:
        agente_nome = AGENT_MAPPING.get(agente)
        if not agente_nome:
            return jsonify({'error': 'Agente fiduciário não encontrado'}), 404
        
        # Executar crawler com paginação completa
        paginated_crawler(agente, agente_nome)
        
        return jsonify({
            'message': f'Crawler com paginação completa para {agente_nome} executado com sucesso',
            'agente': agente_nome,
            'paginacao': 'completa'
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

