from flask import Blueprint, jsonify, request
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime, timedelta
import threading
import time
import sys
import os

# Add the parent directory to the path to import real_web_crawlers
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
from real_web_crawlers import RealCrawlerManager

# Import models
from models.debenture import db, Emissao, Assembleia, Taxa, Evento, PDFLink, CrawlerStatus

debentures_bp = Blueprint('debentures', __name__)

# Initialize real crawler manager
crawler_manager = RealCrawlerManager()

# Agent configuration with real crawler mapping
AGENTES_FIDUCIARIOS = {
    'pentagono': {
        'nome': 'Pentágono S.A. DTVM',
        'crawler_key': 'pentagono',
        'status': 'Inativo'
    },
    'vortx': {
        'nome': 'Vórtx DTVM',
        'crawler_key': 'vortx',
        'status': 'Inativo'
    },
    'oliveira_trust': {
        'nome': 'Oliveira Trust DTVM',
        'crawler_key': 'oliveira_trust',
        'status': 'Inativo'
    },
    'planner_trustee': {
        'nome': 'Planner Trustee DTVM Ltda',
        'crawler_key': None,  # Not implemented yet
        'status': 'Inativo'
    },
    'btg_pactual': {
        'nome': 'BTG Pactual Serviços Financeiros S.A. DTVM',
        'crawler_key': None,  # Not implemented yet
        'status': 'Inativo'
    },
    'brl_trust': {
        'nome': 'BRL Trust DTVM S.A.',
        'crawler_key': None,  # Not implemented yet
        'status': 'Inativo'
    },
    'xp_investimentos': {
        'nome': 'XP Investimentos CCTVM S.A.',
        'crawler_key': None,  # Not implemented yet
        'status': 'Inativo'
    },
    'banco_brasil': {
        'nome': 'Banco do Brasil S.A.',
        'crawler_key': None,  # Not implemented yet
        'status': 'Inativo'
    },
    'itau_dtvm': {
        'nome': 'Itaú DTVM S.A.',
        'crawler_key': None,  # Not implemented yet
        'status': 'Inativo'
    }
}

# Initialize crawler status in database
def init_crawler_status():
    """Initialize crawler status in database"""
    for agente_key, agente_info in AGENTES_FIDUCIARIOS.items():
        existing = CrawlerStatus.query.filter_by(agente=agente_key).first()
        if not existing:
            status = CrawlerStatus(
                agente=agente_key,
                nome=agente_info['nome'],
                status='Inativo',
                mensagem='Aguardando execução',
                inicio=None,
                fim=None
            )
            db.session.add(status)
    
    try:
        db.session.commit()
    except Exception as e:
        db.session.rollback()
        print(f"Error initializing crawler status: {e}")

def real_crawler_worker(agente_key: str):
    """Worker function to run real web crawler"""
    agente_info = AGENTES_FIDUCIARIOS.get(agente_key)
    if not agente_info:
        return
    
    # Update status to processing
    status = CrawlerStatus.query.filter_by(agente=agente_key).first()
    if status:
        status.status = 'Processando'
        status.mensagem = 'Iniciando coleta de dados reais...'
        status.inicio = datetime.now()
        status.fim = None
        db.session.commit()
    
    try:
        # Check if real crawler is available
        crawler_key = agente_info.get('crawler_key')
        if not crawler_key:
            # For agents without real crawlers, show message
            if status:
                status.status = 'Concluído'
                status.mensagem = 'Crawler real não implementado ainda. Aguardando desenvolvimento.'
                status.fim = datetime.now()
                db.session.commit()
            return
        
        # Update status
        if status:
            status.mensagem = f'Acessando site do {agente_info["nome"]}...'
            db.session.commit()
        
        time.sleep(2)  # Simulate initial connection
        
        # Run real crawler
        if status:
            status.mensagem = 'Extraindo dados de debêntures...'
            db.session.commit()
        
        emissoes_data, documentos_data = crawler_manager.run_crawler(crawler_key)
        
        time.sleep(1)  # Processing time
        
        # Save real data to database
        emissoes_count = 0
        documentos_count = 0
        
        # Save emissions
        for emissao_data in emissoes_data:
            # Check if emission already exists
            existing = Emissao.query.filter_by(codigo=emissao_data['codigo']).first()
            if not existing:
                emissao = Emissao(
                    codigo=emissao_data['codigo'],
                    emissor=emissao_data['emissor'],
                    volume=emissao_data.get('volume'),
                    remuneracao=emissao_data.get('remuneracao', 'N/A'),
                    data_emissao=emissao_data.get('data_emissao'),
                    data_vencimento=emissao_data.get('data_vencimento'),
                    rating='N/A',
                    agente_fiduciario=agente_info['nome']
                )
                db.session.add(emissao)
                emissoes_count += 1
        
        # Save documents
        for doc_data in documentos_data:
            # Check if document already exists
            existing = PDFLink.query.filter_by(
                codigo=doc_data['codigo_debenture'],
                titulo=doc_data['titulo']
            ).first()
            if not existing:
                pdf_link = PDFLink(
                    codigo=doc_data['codigo_debenture'],
                    emissor=next((e['emissor'] for e in emissoes_data if e['codigo'] == doc_data['codigo_debenture']), 'N/A'),
                    titulo=doc_data['titulo'],
                    url=doc_data['url_documento'],
                    agente_fonte=agente_info['nome'],
                    data_coleta=datetime.now().strftime('%Y-%m-%d'),
                    origem='Web Scraping Real'
                )
                db.session.add(pdf_link)
                documentos_count += 1
        
        # Commit all changes
        db.session.commit()
        
        # Update final status
        if status:
            if emissoes_count > 0 or documentos_count > 0:
                status.status = 'Concluído'
                status.mensagem = f'Coleta real concluída! {emissoes_count} emissões e {documentos_count} documentos coletados do site oficial.'
            else:
                status.status = 'Concluído'
                status.mensagem = 'Coleta concluída. Nenhum dado novo encontrado (dados já existem na base).'
            status.fim = datetime.now()
            db.session.commit()
    
    except Exception as e:
        # Handle errors
        if status:
            status.status = 'Erro'
            status.mensagem = f'Erro na coleta: {str(e)}'
            status.fim = datetime.now()
            db.session.commit()
        print(f"Error in crawler worker for {agente_key}: {e}")

@debentures_bp.route('/api/emissoes', methods=['GET'])
def get_emissoes():
    """Get all emissions"""
    emissoes = Emissao.query.all()
    return jsonify([{
        'id': e.id,
        'codigo': e.codigo,
        'emissor': e.emissor,
        'volume': e.volume,
        'remuneracao': e.remuneracao,
        'data_emissao': e.data_emissao,
        'data_vencimento': e.data_vencimento,
        'rating': e.rating,
        'agente_fiduciario': e.agente_fiduciario
    } for e in emissoes])

@debentures_bp.route('/api/assembleias', methods=['GET'])
def get_assembleias():
    """Get all assemblies"""
    assembleias = Assembleia.query.all()
    return jsonify([{
        'id': a.id,
        'codigo': a.codigo,
        'emissor': a.emissor,
        'tipo': a.tipo,
        'data_assembleia': a.data_assembleia,
        'local': a.local,
        'agente_fiduciario': a.agente_fiduciario
    } for a in assembleias])

@debentures_bp.route('/api/taxas', methods=['GET'])
def get_taxas():
    """Get all rates"""
    taxas = Taxa.query.all()
    return jsonify([{
        'id': t.id,
        'codigo': t.codigo,
        'emissor': t.emissor,
        'taxa_atual': t.taxa_atual,
        'data_referencia': t.data_referencia,
        'variacao': t.variacao,
        'agente_fiduciario': t.agente_fiduciario
    } for t in taxas])

@debentures_bp.route('/api/eventos', methods=['GET'])
def get_eventos():
    """Get all events"""
    eventos = Evento.query.all()
    return jsonify([{
        'id': e.id,
        'codigo': e.codigo,
        'emissor': e.emissor,
        'tipo_evento': e.tipo_evento,
        'descricao': e.descricao,
        'data_evento': e.data_evento,
        'agente_fiduciario': e.agente_fiduciario
    } for e in eventos])

@debentures_bp.route('/api/pdf-links', methods=['GET'])
def get_pdf_links():
    """Get all PDF links"""
    pdf_links = PDFLink.query.all()
    return jsonify([{
        'id': p.id,
        'codigo': p.codigo,
        'emissor': p.emissor,
        'titulo': p.titulo,
        'url': p.url,
        'agente_fonte': p.agente_fonte,
        'data_coleta': p.data_coleta,
        'origem': p.origem
    } for p in pdf_links])

@debentures_bp.route('/api/crawler-status', methods=['GET'])
def get_crawler_status():
    """Get status of all crawlers"""
    # Initialize status if not exists
    init_crawler_status()
    
    status_list = CrawlerStatus.query.all()
    return jsonify([{
        'agente': s.agente,
        'nome': s.nome,
        'status': s.status,
        'mensagem': s.mensagem,
        'inicio': s.inicio.isoformat() if s.inicio else None,
        'fim': s.fim.isoformat() if s.fim else None
    } for s in status_list])

@debentures_bp.route('/api/run-crawler/<agente>', methods=['POST'])
def run_crawler(agente):
    """Run crawler for specific agent with real web scraping"""
    if agente not in AGENTES_FIDUCIARIOS:
        return jsonify({'error': 'Agente fiduciário não encontrado'}), 404
    
    # Check if crawler is already running
    status = CrawlerStatus.query.filter_by(agente=agente).first()
    if status and status.status == 'Processando':
        return jsonify({'error': 'Crawler já está em execução'}), 400
    
    # Start crawler in background thread
    thread = threading.Thread(target=real_crawler_worker, args=(agente,))
    thread.daemon = True
    thread.start()
    
    return jsonify({
        'message': f'Crawler iniciado para {AGENTES_FIDUCIARIOS[agente]["nome"]}',
        'agente': agente,
        'tipo': 'Web Scraping Real'
    })

@debentures_bp.route('/api/agents', methods=['GET'])
def get_agents():
    """Get list of all fiduciary agents"""
    return jsonify([{
        'key': key,
        'nome': info['nome'],
        'crawler_disponivel': info['crawler_key'] is not None,
        'tipo': 'Real Web Scraping' if info['crawler_key'] else 'Em Desenvolvimento'
    } for key, info in AGENTES_FIDUCIARIOS.items()])

# Health check endpoint
@debentures_bp.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.now().isoformat(),
        'crawlers_disponiveis': len([k for k, v in AGENTES_FIDUCIARIOS.items() if v['crawler_key']]),
        'total_agentes': len(AGENTES_FIDUCIARIOS)
    })

