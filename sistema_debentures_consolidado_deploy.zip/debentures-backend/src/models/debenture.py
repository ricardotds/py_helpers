from src.models.user import db
from datetime import datetime

class Emissao(db.Model):
    __tablename__ = 'emissoes'
    
    id = db.Column(db.Integer, primary_key=True)
    codigo = db.Column(db.String(50), nullable=False)
    emissor = db.Column(db.String(200), nullable=False)
    agente_fiduciario = db.Column(db.String(200))
    data_emissao = db.Column(db.String(20))
    data_vencimento = db.Column(db.String(20))
    valor_nominal = db.Column(db.Float)
    taxa = db.Column(db.String(100))
    indexador = db.Column(db.String(100))
    rating = db.Column(db.String(50))
    garantia = db.Column(db.String(200))
    conversibilidade = db.Column(db.String(100))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class Assembleia(db.Model):
    __tablename__ = 'assembleias'
    
    id = db.Column(db.Integer, primary_key=True)
    codigo = db.Column(db.String(50), nullable=False)
    emissor = db.Column(db.String(200), nullable=False)
    data_assembleia = db.Column(db.String(20))
    tipo = db.Column(db.String(100))
    pauta = db.Column(db.Text)
    agente_fiduciario = db.Column(db.String(200))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Taxa(db.Model):
    __tablename__ = 'taxas'
    
    id = db.Column(db.Integer, primary_key=True)
    codigo = db.Column(db.String(50), nullable=False)
    emissor = db.Column(db.String(200), nullable=False)
    data_referencia = db.Column(db.String(20))
    preco_unitario = db.Column(db.Float)
    taxa_indicativa = db.Column(db.Float)
    agente_fiduciario = db.Column(db.String(200))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Evento(db.Model):
    __tablename__ = 'eventos'
    
    id = db.Column(db.Integer, primary_key=True)
    codigo = db.Column(db.String(50), nullable=False)
    emissor = db.Column(db.String(200), nullable=False)
    data_evento = db.Column(db.String(20))
    tipo_evento = db.Column(db.String(100))
    descricao = db.Column(db.Text)
    agente_fiduciario = db.Column(db.String(200))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class PDFLink(db.Model):
    __tablename__ = 'pdf_links'
    
    id = db.Column(db.Integer, primary_key=True)
    codigo = db.Column(db.String(50), nullable=False)
    emissor = db.Column(db.String(200), nullable=False)
    titulo_documento = db.Column(db.String(500), nullable=False)
    url_pdf = db.Column(db.Text, nullable=False)
    agente_fiduciario = db.Column(db.String(200), nullable=False)
    data_coleta = db.Column(db.DateTime, default=datetime.utcnow)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class CrawlerStatus(db.Model):
    __tablename__ = 'crawler_status'
    
    id = db.Column(db.Integer, primary_key=True)
    agente_fiduciario = db.Column(db.String(200), nullable=False, unique=True)
    status = db.Column(db.String(50), default='inativo')  # inativo, processando, concluido, erro
    inicio_processamento = db.Column(db.DateTime)
    fim_processamento = db.Column(db.DateTime)
    mensagem = db.Column(db.Text)
    pdfs_encontrados = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

