#!/usr/bin/env python3
"""
Real Web Crawlers for Brazilian Fiduciary Agents
Extracts actual debenture data from agent websites
"""

import requests
from bs4 import BeautifulSoup
import time
import random
import re
from datetime import datetime, timedelta
from urllib.parse import urljoin, urlparse
import logging
from typing import List, Dict, Optional, Tuple

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class RealWebCrawler:
    """Base class for real web crawling of fiduciary agents"""
    
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'pt-BR,pt;q=0.9,en;q=0.8',
            'Accept-Encoding': 'gzip, deflate, br',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1'
        })
        
    def delay(self, min_seconds=1, max_seconds=3):
        """Random delay to avoid overwhelming servers"""
        time.sleep(random.uniform(min_seconds, max_seconds))
        
    def safe_request(self, url: str, max_retries=3) -> Optional[requests.Response]:
        """Make a safe HTTP request with retries"""
        for attempt in range(max_retries):
            try:
                response = self.session.get(url, timeout=30)
                response.raise_for_status()
                return response
            except requests.RequestException as e:
                logger.warning(f"Request failed (attempt {attempt + 1}): {e}")
                if attempt < max_retries - 1:
                    self.delay(2, 5)
                else:
                    logger.error(f"Failed to fetch {url} after {max_retries} attempts")
                    return None
        return None

class PentagonoCrawler(RealWebCrawler):
    """Real crawler for Pentágono S.A. DTVM"""
    
    BASE_URL = "https://www.pentagonotrustee.com.br"
    DEBENTURES_URL = f"{BASE_URL}/Site/Investidores?tipo=1&emissor=&ativo="
    
    def crawl(self) -> Tuple[List[Dict], List[Dict]]:
        """Crawl Pentágono website for real debenture data"""
        logger.info("Starting Pentágono crawler...")
        
        emissoes = []
        documentos = []
        
        # Get list of debentures
        debenture_codes = self._get_debenture_list()
        logger.info(f"Found {len(debenture_codes)} debentures")
        
        # Process each debenture
        for i, (code, company) in enumerate(debenture_codes[:10]):  # Limit for testing
            logger.info(f"Processing {code} ({i+1}/{min(10, len(debenture_codes))})")
            
            # Get debenture details
            debenture_data = self._get_debenture_details(code, company)
            if debenture_data:
                emissoes.append(debenture_data)
                
                # Get documents
                docs = self._get_debenture_documents(code)
                documentos.extend(docs)
            
            self.delay()
        
        logger.info(f"Collected {len(emissoes)} emissions and {len(documentos)} documents")
        return emissoes, documentos
    
    def _get_debenture_list(self) -> List[Tuple[str, str]]:
        """Extract list of debenture codes and companies"""
        response = self.safe_request(self.DEBENTURES_URL)
        if not response:
            return []
        
        soup = BeautifulSoup(response.content, 'html.parser')
        debentures = []
        
        # Find table rows with debenture data
        rows = soup.find_all('tr')
        for row in rows:
            cells = row.find_all('td')
            if len(cells) >= 3:
                company_cell = cells[0]
                code_cell = cells[2]
                
                company = company_cell.get_text(strip=True)
                code_link = code_cell.find('a')
                
                if code_link and company:
                    code = code_link.get_text(strip=True)
                    if re.match(r'^[A-Z]{4}[0-9]{2}$', code):  # Valid debenture code pattern
                        debentures.append((code, company))
        
        return debentures
    
    def _get_debenture_details(self, code: str, company: str) -> Optional[Dict]:
        """Extract detailed information for a specific debenture"""
        detail_url = f"{self.BASE_URL}/Site/DetalhesEmissor?ativo={code}&tipo=1"
        response = self.safe_request(detail_url)
        if not response:
            return None
        
        soup = BeautifulSoup(response.content, 'html.parser')
        
        # Extract characteristics table
        data = {
            'codigo': code,
            'emissor': company,
            'agente_fiduciario': 'Pentágono S.A. DTVM',
            'data_coleta': datetime.now().isoformat(),
            'url_fonte': detail_url
        }
        
        # Find characteristics table
        tables = soup.find_all('table')
        for table in tables:
            rows = table.find_all('tr')
            for row in rows:
                cells = row.find_all('td')
                if len(cells) >= 2:
                    key = cells[0].get_text(strip=True).lower()
                    value = cells[1].get_text(strip=True)
                    
                    # Map table fields to our data structure
                    if 'remuneração' in key:
                        data['remuneracao'] = value
                    elif 'volume' in key:
                        data['volume'] = self._parse_currency(value)
                    elif 'data de emissão' in key:
                        data['data_emissao'] = self._parse_date(value)
                    elif 'data de vencimento' in key:
                        data['data_vencimento'] = self._parse_date(value)
                    elif 'isin' in key:
                        data['isin'] = value
                    elif 'garantia' in key or 'espécie' in key:
                        data['garantia'] = value
                    elif 'classe' in key:
                        data['classe'] = value
        
        return data
    
    def _get_debenture_documents(self, code: str) -> List[Dict]:
        """Extract documents for a specific debenture"""
        docs_url = f"{self.BASE_URL}/Site/DetalhesEmissor?ativo={code}&aba=tab-2&tipo=1"
        response = self.safe_request(docs_url)
        if not response:
            return []
        
        soup = BeautifulSoup(response.content, 'html.parser')
        documents = []
        
        # Find document links
        doc_links = soup.find_all('a', href=lambda x: x and '.pdf' in x.lower())
        
        for link in doc_links:
            title = link.get_text(strip=True)
            url = link.get('href')
            
            if title and url:
                # Make URL absolute
                if not url.startswith('http'):
                    url = urljoin(self.BASE_URL, url)
                
                doc_data = {
                    'codigo_debenture': code,
                    'titulo': title,
                    'url_documento': url,
                    'tipo_documento': self._classify_document(title),
                    'data_documento': self._extract_date_from_title(title),
                    'agente_fiduciario': 'Pentágono S.A. DTVM',
                    'data_coleta': datetime.now().isoformat()
                }
                documents.append(doc_data)
        
        return documents
    
    def _parse_currency(self, value: str) -> Optional[float]:
        """Parse currency string to float"""
        if not value:
            return None
        
        # Remove currency symbols and convert to float
        clean_value = re.sub(r'[R$\\s.]', '', value)
        clean_value = clean_value.replace(',', '.')
        
        try:
            return float(clean_value)
        except ValueError:
            return None
    
    def _parse_date(self, value: str) -> Optional[str]:
        """Parse date string to ISO format"""
        if not value:
            return None
        
        # Try different date formats
        formats = ['%d/%m/%Y', '%Y-%m-%d', '%d.%m.%Y']
        
        for fmt in formats:
            try:
                date_obj = datetime.strptime(value, fmt)
                return date_obj.strftime('%Y-%m-%d')
            except ValueError:
                continue
        
        return None
    
    def _classify_document(self, title: str) -> str:
        """Classify document type based on title"""
        title_lower = title.lower()
        
        if 'escritura' in title_lower:
            return 'Escritura de Emissão'
        elif 'cessão fiduciária' in title_lower:
            return 'Contrato de Cessão Fiduciária'
        elif 'aditamento' in title_lower:
            return 'Aditamento'
        elif 'prospecto' in title_lower:
            return 'Prospecto'
        elif 'comunicado' in title_lower:
            return 'Comunicado ao Mercado'
        elif 'relatório' in title_lower:
            return 'Relatório'
        else:
            return 'Documento'
    
    def _extract_date_from_title(self, title: str) -> Optional[str]:
        """Extract date from document title"""
        # Look for date patterns in title
        date_patterns = [
            r'(\\d{4})\\.(\\d{2})\\.(\\d{2})',  # YYYY.MM.DD
            r'(\\d{2})\\.(\\d{2})\\.(\\d{4})',  # DD.MM.YYYY
            r'(\\d{4})-(\\d{2})-(\\d{2})',     # YYYY-MM-DD
        ]
        
        for pattern in date_patterns:
            match = re.search(pattern, title)
            if match:
                try:
                    if len(match.group(1)) == 4:  # Year first
                        date_obj = datetime.strptime(f"{match.group(1)}-{match.group(2)}-{match.group(3)}", '%Y-%m-%d')
                    else:  # Day first
                        date_obj = datetime.strptime(f"{match.group(3)}-{match.group(2)}-{match.group(1)}", '%Y-%m-%d')
                    return date_obj.strftime('%Y-%m-%d')
                except ValueError:
                    continue
        
        return None

class VortxCrawler(RealWebCrawler):
    """Real crawler for Vórtx DTVM"""
    
    BASE_URL = "https://www.vortx.com.br"
    
    def crawl(self) -> Tuple[List[Dict], List[Dict]]:
        """Crawl Vórtx website for real debenture data"""
        logger.info("Starting Vórtx crawler...")
        
        # For now, return empty lists as we need to analyze the site structure
        # This will be implemented after analyzing the Vórtx website
        emissoes = []
        documentos = []
        
        logger.info("Vórtx crawler: Site analysis needed")
        return emissoes, documentos

class OliveiraTrustCrawler(RealWebCrawler):
    """Real crawler for Oliveira Trust DTVM"""
    
    BASE_URL = "https://www.oliveiratrust.com.br"
    
    def crawl(self) -> Tuple[List[Dict], List[Dict]]:
        """Crawl Oliveira Trust website for real debenture data"""
        logger.info("Starting Oliveira Trust crawler...")
        
        # For now, return empty lists as we need to analyze the site structure
        # This will be implemented after analyzing the Oliveira Trust website
        emissoes = []
        documentos = []
        
        logger.info("Oliveira Trust crawler: Site analysis needed")
        return emissoes, documentos

class RealCrawlerManager:
    """Manager for all real web crawlers"""
    
    def __init__(self):
        self.crawlers = {
            'pentagono': PentagonoCrawler(),
            'vortx': VortxCrawler(),
            'oliveira_trust': OliveiraTrustCrawler(),
        }
    
    def run_crawler(self, agent_key: str) -> Tuple[List[Dict], List[Dict]]:
        """Run a specific crawler and return real data"""
        if agent_key not in self.crawlers:
            logger.error(f"Unknown crawler: {agent_key}")
            return [], []
        
        crawler = self.crawlers[agent_key]
        
        try:
            emissoes, documentos = crawler.crawl()
            logger.info(f"Crawler {agent_key} completed: {len(emissoes)} emissions, {len(documentos)} documents")
            return emissoes, documentos
        except Exception as e:
            logger.error(f"Crawler {agent_key} failed: {e}")
            return [], []
    
    def get_available_crawlers(self) -> List[str]:
        """Get list of available crawler keys"""
        return list(self.crawlers.keys())

# Test function
def test_pentagono_crawler():
    """Test the Pentágono crawler"""
    crawler = PentagonoCrawler()
    emissoes, documentos = crawler.crawl()
    
    print(f"\\nCollected {len(emissoes)} emissions:")
    for emissao in emissoes[:3]:  # Show first 3
        print(f"- {emissao['codigo']}: {emissao['emissor']}")
    
    print(f"\\nCollected {len(documentos)} documents:")
    for doc in documentos[:5]:  # Show first 5
        print(f"- {doc['codigo_debenture']}: {doc['titulo']}")

if __name__ == "__main__":
    # Test the crawler
    test_pentagono_crawler()

