import React from 'react';
import { Typography, Box, Paper } from '@mui/material';

const NotFoundPage: React.FC = () => {
  return (
    <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '70vh' }}>
      <Paper sx={{ p: 4, maxWidth: 500, textAlign: 'center' }}>
        <Typography variant="h4" component="h1" gutterBottom>
          Página não encontrada
        </Typography>
        <Typography variant="body1" paragraph>
          A página que você está procurando não existe ou foi movida.
        </Typography>
        <Typography variant="body2" color="text.secondary">
          Por favor, utilize o menu de navegação para acessar as páginas disponíveis.
        </Typography>
      </Paper>
    </Box>
  );
};

export default NotFoundPage;
