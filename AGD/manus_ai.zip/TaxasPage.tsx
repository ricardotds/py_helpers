import React, { useState } from 'react';
import { 
  Typography, 
  Paper, 
  Grid, 
  Box,
  TextField,
  Button,
  CircularProgress,
  Alert,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TablePagination
} from '@mui/material';
import { DatePicker } from '@mui/x-date-pickers';
import { format, subDays } from 'date-fns';
import { useApi } from '../contexts/ApiContext';
import { useQuery } from 'react-query';

// Componente para a página de Taxas
const TaxasPage: React.FC = () => {
  // Estados para as datas de filtro
  const [dataInicio, setDataInicio] = useState<Date | null>(subDays(new Date(), 30));
  const [dataFim, setDataFim] = useState<Date | null>(new Date());
  const [codigo, setCodigo] = useState<string>('');
  
  // Estados para paginação
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  
  // Contexto da API
  const api = useApi();
  
  // Formatação de datas para a API
  const formatDateForApi = (date: Date | null) => {
    if (!date) return undefined;
    return format(date, 'yyyy-MM-dd');
  };
  
  // Parâmetros para as consultas
  const queryParams = {
    dataInicio: formatDateForApi(dataInicio),
    dataFim: formatDateForApi(dataFim),
    codigo: codigo || undefined
  };
  
  // Consulta React Query
  const { data, isLoading, isError, refetch } = useQuery(
    ['taxas', queryParams], 
    () => api.fetchTaxas(queryParams.dataInicio, queryParams.dataFim, queryParams.codigo),
    { enabled: !!dataInicio && !!dataFim }
  );
  
  // Manipuladores de paginação
  const handleChangePage = (event: unknown, newPage: number) => {
    setPage(newPage);
  };
  
  const handleChangeRowsPerPage = (event: React.ChangeEvent<HTMLInputElement>) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };
  
  // Formatação de datas para exibição
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return format(date, 'dd/MM/yyyy');
  };
  
  // Função para buscar dados
  const handleSearch = () => {
    refetch();
  };
  
  return (
    <Box>
      <Typography variant="h4" component="h1" gutterBottom>
        Taxas e Preços de Debêntures
      </Typography>
      
      <Paper sx={{ p: 3, mb: 4 }}>
        <Typography variant="h6" gutterBottom>
          Filtros
        </Typography>
        <Grid container spacing={3} alignItems="center">
          <Grid item xs={12} sm={3}>
            <DatePicker
              label="Data Inicial"
              value={dataInicio}
              onChange={setDataInicio}
              slotProps={{ textField: { fullWidth: true } }}
            />
          </Grid>
          <Grid item xs={12} sm={3}>
            <DatePicker
              label="Data Final"
              value={dataFim}
              onChange={setDataFim}
              slotProps={{ textField: { fullWidth: true } }}
            />
          </Grid>
          <Grid item xs={12} sm={3}>
            <TextField
              label="Código da Debênture"
              value={codigo}
              onChange={(e) => setCodigo(e.target.value)}
              fullWidth
            />
          </Grid>
          <Grid item xs={12} sm={3}>
            <Button 
              variant="contained" 
              onClick={handleSearch}
              disabled={isLoading}
              fullWidth
              sx={{ height: '56px' }}
            >
              {isLoading ? <CircularProgress size={24} /> : 'Buscar'}
            </Button>
          </Grid>
        </Grid>
        
        {isError && (
          <Alert severity="error" sx={{ mt: 2 }}>
            Ocorreu um erro ao carregar os dados. Por favor, tente novamente.
          </Alert>
        )}
      </Paper>
      
      <Paper>
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Código</TableCell>
                <TableCell>Data</TableCell>
                <TableCell align="right">PU</TableCell>
                <TableCell align="right">% do PU Par</TableCell>
                <TableCell align="right">Duration</TableCell>
                <TableCell>Fonte</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {isLoading ? (
                <TableRow>
                  <TableCell colSpan={6} align="center" sx={{ py: 3 }}>
                    <CircularProgress />
                  </TableCell>
                </TableRow>
              ) : data?.taxas && data.taxas.length > 0 ? (
                data.taxas
                  .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                  .map((taxa: any, index: number) => (
                    <TableRow key={index} hover>
                      <TableCell>{taxa.codigo}</TableCell>
                      <TableCell>{formatDate(taxa.data)}</TableCell>
                      <TableCell align="right">{taxa.pu.toFixed(6)}</TableCell>
                      <TableCell align="right">{taxa.percentual_pu_par.toFixed(2)}%</TableCell>
                      <TableCell align="right">{taxa.duration || '-'}</TableCell>
                      <TableCell>{taxa.fonte}</TableCell>
                    </TableRow>
                  ))
              ) : (
                <TableRow>
                  <TableCell colSpan={6} align="center">
                    Nenhuma taxa encontrada para os filtros selecionados.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>
        
        {data?.taxas && data.taxas.length > 0 && (
          <TablePagination
            rowsPerPageOptions={[5, 10, 25]}
            component="div"
            count={data.taxas.length}
            rowsPerPage={rowsPerPage}
            page={page}
            onPageChange={handleChangePage}
            onRowsPerPageChange={handleChangeRowsPerPage}
            labelRowsPerPage="Linhas por página:"
            labelDisplayedRows={({ from, to, count }) => `${from}-${to} de ${count}`}
          />
        )}
      </Paper>
    </Box>
  );
};

export default TaxasPage;
