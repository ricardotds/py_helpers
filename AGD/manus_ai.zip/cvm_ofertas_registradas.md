# Dados de Ofertas Registradas - CVM

## Ofertas Registradas - Abril/2025

| Emissora | Data de Registro | Volume |
|----------|------------------|--------|
| OCCAM PORTFOLIO CRÉDITO FUNDO DE INVESTIMENTO EM DIREITOS CREDITÓRIOS DE RESPONSABILIDADE LIMITADA | 17/04/2025 | R$ 350.000.000,00 |

**Total Mensal:** 1 Oferta - R$ 350.000.000,00

## Ofertas Registradas - Fevereiro/2025

| Emissora | Data de Registro | Volume |
|----------|------------------|--------|
| SOLIS PORTFOLIO CRÉDITO CDI+ FIC FIDC RESPONSABILIDADE LIMITADA | 27/02/2025 | R$ 240.000.000,00 |

**Total Mensal:** 1 Oferta - R$ 240.000.000,00

## Total no Ano (2025)
**Total:** 2 Ofertas - R$ 590.000.000,00

*Dados coletados em 26/05/2025 do sistema de Ofertas Registradas da CVM*

## Observações
- Os dados acima referem-se a ofertas registradas de quotas de fundos de investimento em direitos creditórios
- A CVM disponibiliza informações sobre ofertas registradas e dispensadas através de seu sistema online
- É possível consultar dados por ano e por tipo de oferta
- Para debêntures específicas, é necessário utilizar filtros adicionais ou consultar outras seções do sistema
