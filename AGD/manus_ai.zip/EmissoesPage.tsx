import React, { useState } from 'react';
import { 
  Typography, 
  Paper, 
  Grid, 
  Box,
  TextField,
  Button,
  CircularProgress,
  Alert,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TablePagination,
  Chip
} from '@mui/material';
import { DatePicker } from '@mui/x-date-pickers';
import { format, subDays } from 'date-fns';
import { useApi } from '../contexts/ApiContext';
import { useQuery } from 'react-query';

// Componente para a página de Emissões
const EmissoesPage: React.FC = () => {
  // Estados para as datas de filtro
  const [dataInicio, setDataInicio] = useState<Date | null>(subDays(new Date(), 30));
  const [dataFim, setDataFim] = useState<Date | null>(new Date());
  const [emissor, setEmissor] = useState<string>('');
  
  // Estados para paginação
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  
  // Contexto da API
  const api = useApi();
  
  // Formatação de datas para a API
  const formatDateForApi = (date: Date | null) => {
    if (!date) return undefined;
    return format(date, 'yyyy-MM-dd');
  };
  
  // Parâmetros para as consultas
  const queryParams = {
    dataInicio: formatDateForApi(dataInicio),
    dataFim: formatDateForApi(dataFim),
    emissor: emissor || undefined
  };
  
  // Consulta React Query
  const { data, isLoading, isError, refetch } = useQuery(
    ['emissoes', queryParams], 
    () => api.fetchEmissoes(queryParams.dataInicio, queryParams.dataFim, queryParams.emissor),
    { enabled: !!dataInicio && !!dataFim }
  );
  
  // Manipuladores de paginação
  const handleChangePage = (event: unknown, newPage: number) => {
    setPage(newPage);
  };
  
  const handleChangeRowsPerPage = (event: React.ChangeEvent<HTMLInputElement>) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };
  
  // Formatação de valores monetários
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };
  
  // Formatação de datas para exibição
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return format(date, 'dd/MM/yyyy');
  };
  
  // Função para buscar dados
  const handleSearch = () => {
    refetch();
  };
  
  return (
    <Box>
      <Typography variant="h4" component="h1" gutterBottom>
        Emissões de Debêntures
      </Typography>
      
      <Paper sx={{ p: 3, mb: 4 }}>
        <Typography variant="h6" gutterBottom>
          Filtros
        </Typography>
        <Grid container spacing={3} alignItems="center">
          <Grid item xs={12} sm={3}>
            <DatePicker
              label="Data Inicial"
              value={dataInicio}
              onChange={setDataInicio}
              slotProps={{ textField: { fullWidth: true } }}
            />
          </Grid>
          <Grid item xs={12} sm={3}>
            <DatePicker
              label="Data Final"
              value={dataFim}
              onChange={setDataFim}
              slotProps={{ textField: { fullWidth: true } }}
            />
          </Grid>
          <Grid item xs={12} sm={3}>
            <TextField
              label="Emissor"
              value={emissor}
              onChange={(e) => setEmissor(e.target.value)}
              fullWidth
            />
          </Grid>
          <Grid item xs={12} sm={3}>
            <Button 
              variant="contained" 
              onClick={handleSearch}
              disabled={isLoading}
              fullWidth
              sx={{ height: '56px' }}
            >
              {isLoading ? <CircularProgress size={24} /> : 'Buscar'}
            </Button>
          </Grid>
        </Grid>
        
        {isError && (
          <Alert severity="error" sx={{ mt: 2 }}>
            Ocorreu um erro ao carregar os dados. Por favor, tente novamente.
          </Alert>
        )}
      </Paper>
      
      <Paper>
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Emissor</TableCell>
                <TableCell>Código</TableCell>
                <TableCell>Série/Emissão</TableCell>
                <TableCell>Data</TableCell>
                <TableCell align="right">Volume Total</TableCell>
                <TableCell align="center">Status</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {isLoading ? (
                <TableRow>
                  <TableCell colSpan={6} align="center" sx={{ py: 3 }}>
                    <CircularProgress />
                  </TableCell>
                </TableRow>
              ) : data?.emissoes && data.emissoes.length > 0 ? (
                data.emissoes
                  .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                  .map((emissao: any, index: number) => (
                    <TableRow key={index} hover>
                      <TableCell>{emissao.emissor}</TableCell>
                      <TableCell>{emissao.codigo}</TableCell>
                      <TableCell>{emissao.serie} / {emissao.emissao}ª</TableCell>
                      <TableCell>{formatDate(emissao.data_emissao)}</TableCell>
                      <TableCell align="right">{formatCurrency(emissao.volume_total)}</TableCell>
                      <TableCell align="center">
                        <Chip 
                          label={emissao.status} 
                          color={emissao.status === 'Ativa' ? 'success' : 'default'}
                          size="small"
                        />
                      </TableCell>
                    </TableRow>
                  ))
              ) : (
                <TableRow>
                  <TableCell colSpan={6} align="center">
                    Nenhuma emissão encontrada para os filtros selecionados.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>
        
        {data?.emissoes && data.emissoes.length > 0 && (
          <TablePagination
            rowsPerPageOptions={[5, 10, 25]}
            component="div"
            count={data.emissoes.length}
            rowsPerPage={rowsPerPage}
            page={page}
            onPageChange={handleChangePage}
            onRowsPerPageChange={handleChangeRowsPerPage}
            labelRowsPerPage="Linhas por página:"
            labelDisplayedRows={({ from, to, count }) => `${from}-${to} de ${count}`}
          />
        )}
      </Paper>
    </Box>
  );
};

export default EmissoesPage;
