# Documentação do Sistema de Monitoramento de Debêntures

## Visão Geral

Este sistema consiste em uma aplicação completa para monitoramento de debêntures no Brasil, com backend em Python/FastAPI e frontend em React/TypeScript com Material UI. A aplicação permite visualizar e filtrar dados de emissões, assembleias, eventos corporativos e taxas de debêntures.

## Estrutura do Projeto

O projeto está dividido em duas partes principais:

### Backend (FastAPI)

```
debentures_api/
├── app/
│   ├── main.py         # Aplicação principal e endpoints
│   └── config.py       # Configurações e utilitários
└── data/
    ├── assembleias.json # Dados de assembleias
    ├── emissoes.json    # Dados de emissões
    ├── eventos.json     # Dados de eventos corporativos
    └── taxas.json       # Dados de taxas e preços
```

### Frontend (React/TypeScript com Material UI)

```
debentures-frontend/
├── public/
│   └── index.html      # HTML principal
├── src/
│   ├── components/     # Componentes reutilizáveis
│   │   └── Header.tsx  # Cabeçalho da aplicação
│   ├── contexts/
│   │   └── ApiContext.tsx # Contexto para comunicação com a API
│   ├── pages/          # Páginas da aplicação
│   │   ├── Dashboard.tsx
│   │   ├── EmissoesPage.tsx
│   │   ├── AssembleiasPage.tsx
│   │   ├── TaxasPage.tsx
│   │   ├── EventosPage.tsx
│   │   └── NotFoundPage.tsx
│   ├── App.tsx         # Componente principal
│   ├── index.tsx       # Ponto de entrada
│   └── index.css       # Estilos globais
└── package.json        # Dependências e scripts
```

## Requisitos

### Backend
- Python 3.8+
- FastAPI
- Uvicorn (servidor ASGI)
- Pydantic

### Frontend
- Node.js 14+
- React 18
- TypeScript
- Material UI 5
- React Query
- Axios

## Instalação e Execução

### Backend

1. Navegue até o diretório do backend:
   ```bash
   cd debentures_api
   ```

2. Instale as dependências:
   ```bash
   pip install fastapi uvicorn pydantic
   ```

3. Execute o servidor:
   ```bash
   uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
   ```

4. O backend estará disponível em `http://localhost:8000`
   - Documentação interativa: `http://localhost:8000/docs`
   - Documentação alternativa: `http://localhost:8000/redoc`

### Frontend

1. Navegue até o diretório do frontend:
   ```bash
   cd debentures-frontend
   ```

2. Instale as dependências:
   ```bash
   npm install
   ```

3. Execute o servidor de desenvolvimento:
   ```bash
   npm start
   ```

4. O frontend estará disponível em `http://localhost:3000`

## API Endpoints

### Informações Gerais
- `GET /`: Informações básicas sobre a API
- `GET /status`: Status da API e dados disponíveis

### Debêntures
- `GET /emissoes`: Lista de emissões de debêntures
  - Parâmetros: `data_inicio`, `data_fim`, `emissor`
- `GET /assembleias`: Lista de assembleias de debenturistas
  - Parâmetros: `data_inicio`, `data_fim`, `agente_fiduciario`
- `GET /taxas`: Lista de taxas e preços de debêntures
  - Parâmetros: `data_inicio`, `data_fim`, `codigo`
- `GET /eventos`: Lista de eventos corporativos
  - Parâmetros: `data_inicio`, `data_fim`, `tipo_evento`

## Funcionalidades do Frontend

### Dashboard
- Visão geral dos dados de debêntures
- Cards com resumos de emissões, assembleias, eventos e taxas
- Filtros por período de data

### Páginas Específicas
- **Emissões**: Lista detalhada de emissões com filtros
- **Assembleias**: Lista de assembleias de debenturistas com links para documentos
- **Taxas**: Informações sobre taxas e preços unitários
- **Eventos**: Eventos corporativos relacionados a debêntures

### Recursos Comuns
- Filtros por data e parâmetros específicos
- Paginação de resultados
- Indicadores de carregamento
- Tratamento de erros
- Layout responsivo

## Personalização

### Backend
- Modifique os arquivos JSON em `debentures_api/data/` para atualizar os dados
- Adicione novos endpoints em `main.py` conforme necessário
- Ajuste as configurações CORS em `config.py` para produção

### Frontend
- Altere o tema do Material UI em `src/index.tsx`
- Modifique a URL base da API em `src/contexts/ApiContext.tsx`
- Adicione novas páginas em `src/pages/` e atualize as rotas em `App.tsx`

## Considerações para Produção

### Backend
- Configure um servidor ASGI como Uvicorn ou Hypercorn com Gunicorn
- Implemente autenticação e autorização
- Configure logs adequados
- Considere usar um banco de dados real em vez de arquivos JSON

### Frontend
- Execute `npm run build` para gerar a versão de produção
- Sirva os arquivos estáticos com um servidor web como Nginx
- Configure variáveis de ambiente para diferentes ambientes (dev, staging, prod)
