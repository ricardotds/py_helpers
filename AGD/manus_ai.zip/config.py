from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import json
from datetime import datetime
import os

# Arquivo de configuração para o backend FastAPI
# Este arquivo contém configurações adicionais e utilitários para a API

# Configuração de caminhos
DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data")

# Função para carregar dados de um arquivo JSON
def load_json_data(filename):
    """
    Carrega dados de um arquivo JSON no diretório de dados.
    
    Args:
        filename (str): Nome do arquivo JSON (sem o caminho)
        
    Returns:
        dict: Dados carregados do arquivo JSON
        
    Raises:
        HTTPException: Se o arquivo não for encontrado ou não puder ser decodificado
    """
    try:
        file_path = os.path.join(DATA_DIR, filename)
        with open(file_path, 'r', encoding='utf-8') as file:
            return json.load(file)
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail=f"Arquivo {filename} não encontrado")
    except json.JSONDecodeError:
        raise HTTPException(status_code=500, detail=f"Erro ao decodificar o arquivo {filename}")

# Função para salvar dados em um arquivo JSON
def save_json_data(filename, data):
    """
    Salva dados em um arquivo JSON no diretório de dados.
    
    Args:
        filename (str): Nome do arquivo JSON (sem o caminho)
        data (dict): Dados a serem salvos
        
    Raises:
        HTTPException: Se ocorrer um erro ao salvar o arquivo
    """
    try:
        file_path = os.path.join(DATA_DIR, filename)
        with open(file_path, 'w', encoding='utf-8') as file:
            json.dump(data, file, ensure_ascii=False, indent=2)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro ao salvar o arquivo {filename}: {str(e)}")

# Função para atualizar metadados
def update_metadata(metadata):
    """
    Atualiza os metadados com a data e hora atual.
    
    Args:
        metadata (dict): Metadados a serem atualizados
        
    Returns:
        dict: Metadados atualizados
    """
    updated_metadata = metadata.copy() if metadata else {}
    updated_metadata["ultima_atualizacao"] = datetime.now().isoformat()
    return updated_metadata

# Configuração do CORS para a API
def setup_cors(app: FastAPI):
    """
    Configura o middleware CORS para a aplicação FastAPI.
    
    Args:
        app (FastAPI): Instância da aplicação FastAPI
    """
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],  # Em produção, especificar origens permitidas
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

# Função para filtrar dados por intervalo de datas
def filter_by_date_range(items, date_field, start_date=None, end_date=None):
    """
    Filtra uma lista de itens por um intervalo de datas.
    
    Args:
        items (list): Lista de itens a serem filtrados
        date_field (str): Nome do campo de data nos itens
        start_date (str, optional): Data inicial no formato YYYY-MM-DD
        end_date (str, optional): Data final no formato YYYY-MM-DD
        
    Returns:
        list: Itens filtrados pelo intervalo de datas
    """
    filtered_items = items
    
    if start_date:
        filtered_items = [item for item in filtered_items if item[date_field] >= start_date]
    
    if end_date:
        filtered_items = [item for item in filtered_items if item[date_field] <= end_date]
    
    return filtered_items
