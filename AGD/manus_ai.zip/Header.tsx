import React from 'react';
import { AppBar, Toolbar, Typography, Button, Box, Container } from '@mui/material';
import { Link as RouterLink } from 'react-router-dom';

const Header: React.FC = () => {
  return (
    <AppBar position="static">
      <Container maxWidth="lg">
        <Toolbar>
          <Typography
            variant="h6"
            component={RouterLink}
            to="/"
            sx={{
              flexGrow: 1,
              textDecoration: 'none',
              color: 'white',
              fontWeight: 'bold'
            }}
          >
            Monitor de Debêntures
          </Typography>
          <Box sx={{ display: 'flex', gap: 2 }}>
            <Button
              color="inherit"
              component={RouterLink}
              to="/"
            >
              Dashboard
            </Button>
            <Button
              color="inherit"
              component={RouterLink}
              to="/emissoes"
            >
              Emissões
            </Button>
            <Button
              color="inherit"
              component={RouterLink}
              to="/assembleias"
            >
              Assembleias
            </Button>
            <Button
              color="inherit"
              component={RouterLink}
              to="/taxas"
            >
              Taxas
            </Button>
            <Button
              color="inherit"
              component={RouterLink}
              to="/eventos"
            >
              Eventos
            </Button>
          </Box>
        </Toolbar>
      </Container>
    </AppBar>
  );
};

export default Header;
