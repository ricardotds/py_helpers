import React, { useState, useEffect } from 'react';
import { 
  Typography, 
  Paper, 
  Grid, 
  Card, 
  CardContent, 
  CardHeader,
  Box,
  TextField,
  Button,
  CircularProgress,
  Alert,
  Divider
} from '@mui/material';
import { DatePicker } from '@mui/x-date-pickers';
import { format, subDays } from 'date-fns';
import { useApi } from '../contexts/ApiContext';
import { useQuery } from 'react-query';

// Componente para o Dashboard principal
const Dashboard: React.FC = () => {
  // Estados para as datas de filtro
  const [dataInicio, setDataInicio] = useState<Date | null>(subDays(new Date(), 30));
  const [dataFim, setDataFim] = useState<Date | null>(new Date());
  
  // Contexto da API
  const api = useApi();
  
  // Formatação de datas para a API
  const formatDateForApi = (date: Date | null) => {
    if (!date) return undefined;
    return format(date, 'yyyy-MM-dd');
  };
  
  // Parâmetros para as consultas
  const queryParams = {
    dataInicio: formatDateForApi(dataInicio),
    dataFim: formatDateForApi(dataFim)
  };
  
  // Consultas React Query
  const emissoes = useQuery(['emissoes', queryParams], 
    () => api.fetchEmissoes(queryParams.dataInicio, queryParams.dataFim),
    { enabled: !!dataInicio && !!dataFim }
  );
  
  const assembleias = useQuery(['assembleias', queryParams], 
    () => api.fetchAssembleias(queryParams.dataInicio, queryParams.dataFim),
    { enabled: !!dataInicio && !!dataFim }
  );
  
  const taxas = useQuery(['taxas', queryParams], 
    () => api.fetchTaxas(queryParams.dataInicio, queryParams.dataFim),
    { enabled: !!dataInicio && !!dataFim }
  );
  
  const eventos = useQuery(['eventos', queryParams], 
    () => api.fetchEventos(queryParams.dataInicio, queryParams.dataFim),
    { enabled: !!dataInicio && !!dataFim }
  );
  
  // Estado de carregamento geral
  const isLoading = emissoes.isLoading || assembleias.isLoading || taxas.isLoading || eventos.isLoading;
  
  // Estado de erro geral
  const hasError = emissoes.isError || assembleias.isError || taxas.isError || eventos.isError;
  
  // Função para atualizar os dados
  const handleRefresh = () => {
    emissoes.refetch();
    assembleias.refetch();
    taxas.refetch();
    eventos.refetch();
  };
  
  // Formatação de valores monetários
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };
  
  // Formatação de datas para exibição
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return format(date, 'dd/MM/yyyy');
  };
  
  return (
    <Box>
      <Typography variant="h4" component="h1" gutterBottom>
        Dashboard de Debêntures
      </Typography>
      
      <Paper sx={{ p: 3, mb: 4 }}>
        <Typography variant="h6" gutterBottom>
          Filtros
        </Typography>
        <Grid container spacing={3} alignItems="center">
          <Grid item xs={12} sm={4}>
            <DatePicker
              label="Data Inicial"
              value={dataInicio}
              onChange={setDataInicio}
              slotProps={{ textField: { fullWidth: true } }}
            />
          </Grid>
          <Grid item xs={12} sm={4}>
            <DatePicker
              label="Data Final"
              value={dataFim}
              onChange={setDataFim}
              slotProps={{ textField: { fullWidth: true } }}
            />
          </Grid>
          <Grid item xs={12} sm={4}>
            <Button 
              variant="contained" 
              onClick={handleRefresh}
              disabled={isLoading}
              fullWidth
              sx={{ height: '56px' }}
            >
              {isLoading ? <CircularProgress size={24} /> : 'Atualizar Dados'}
            </Button>
          </Grid>
        </Grid>
        
        {hasError && (
          <Alert severity="error" sx={{ mt: 2 }}>
            Ocorreu um erro ao carregar os dados. Por favor, tente novamente.
          </Alert>
        )}
      </Paper>
      
      <Grid container spacing={4}>
        {/* Card de Emissões */}
        <Grid item xs={12} md={6}>
          <Card>
            <CardHeader 
              title="Emissões Recentes" 
              subheader={`Total: ${emissoes.data?.emissoes.length || 0} emissões`}
            />
            <Divider />
            <CardContent sx={{ maxHeight: 300, overflow: 'auto' }}>
              {emissoes.isLoading ? (
                <Box display="flex" justifyContent="center" p={2}>
                  <CircularProgress />
                </Box>
              ) : emissoes.data?.emissoes.length > 0 ? (
                emissoes.data.emissoes.slice(0, 5).map((emissao: any, index: number) => (
                  <Box key={index} mb={2} pb={2} borderBottom={index < 4 ? 1 : 0} borderColor="divider">
                    <Typography variant="subtitle1" fontWeight="bold">
                      {emissao.emissor} - {emissao.codigo}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      Série: {emissao.serie} | Emissão: {emissao.emissao}ª
                    </Typography>
                    <Typography variant="body2">
                      Data: {formatDate(emissao.data_emissao)} | Volume: {formatCurrency(emissao.volume_total)}
                    </Typography>
                  </Box>
                ))
              ) : (
                <Typography variant="body2" color="text.secondary">
                  Nenhuma emissão encontrada no período selecionado.
                </Typography>
              )}
            </CardContent>
          </Card>
        </Grid>
        
        {/* Card de Assembleias */}
        <Grid item xs={12} md={6}>
          <Card>
            <CardHeader 
              title="Assembleias Recentes" 
              subheader={`Total: ${assembleias.data?.assembleias.length || 0} assembleias`}
            />
            <Divider />
            <CardContent sx={{ maxHeight: 300, overflow: 'auto' }}>
              {assembleias.isLoading ? (
                <Box display="flex" justifyContent="center" p={2}>
                  <CircularProgress />
                </Box>
              ) : assembleias.data?.assembleias.length > 0 ? (
                assembleias.data.assembleias.slice(0, 5).map((assembleia: any, index: number) => (
                  <Box key={index} mb={2} pb={2} borderBottom={index < 4 ? 1 : 0} borderColor="divider">
                    <Typography variant="subtitle1" fontWeight="bold">
                      {assembleia.codigo_debenture}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      Data: {formatDate(assembleia.data_assembleia)} | Tipo: {assembleia.tipo}
                    </Typography>
                    <Typography variant="body2">
                      Agente: {assembleia.agente_fiduciario}
                    </Typography>
                  </Box>
                ))
              ) : (
                <Typography variant="body2" color="text.secondary">
                  Nenhuma assembleia encontrada no período selecionado.
                </Typography>
              )}
            </CardContent>
          </Card>
        </Grid>
        
        {/* Card de Eventos */}
        <Grid item xs={12} md={6}>
          <Card>
            <CardHeader 
              title="Eventos Corporativos" 
              subheader={`Total: ${eventos.data?.eventos.length || 0} eventos`}
            />
            <Divider />
            <CardContent sx={{ maxHeight: 300, overflow: 'auto' }}>
              {eventos.isLoading ? (
                <Box display="flex" justifyContent="center" p={2}>
                  <CircularProgress />
                </Box>
              ) : eventos.data?.eventos.length > 0 ? (
                eventos.data.eventos.slice(0, 5).map((evento: any, index: number) => (
                  <Box key={index} mb={2} pb={2} borderBottom={index < 4 ? 1 : 0} borderColor="divider">
                    <Typography variant="subtitle1" fontWeight="bold">
                      {evento.codigo_debenture}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      Data: {formatDate(evento.data_evento)} | Tipo: {evento.tipo_evento}
                    </Typography>
                    <Typography variant="body2">
                      {evento.descricao || 'Sem descrição disponível'}
                    </Typography>
                  </Box>
                ))
              ) : (
                <Typography variant="body2" color="text.secondary">
                  Nenhum evento encontrado no período selecionado.
                </Typography>
              )}
            </CardContent>
          </Card>
        </Grid>
        
        {/* Card de Taxas */}
        <Grid item xs={12} md={6}>
          <Card>
            <CardHeader 
              title="Taxas e Preços Recentes" 
              subheader={`Total: ${taxas.data?.taxas.length || 0} registros`}
            />
            <Divider />
            <CardContent sx={{ maxHeight: 300, overflow: 'auto' }}>
              {taxas.isLoading ? (
                <Box display="flex" justifyContent="center" p={2}>
                  <CircularProgress />
                </Box>
              ) : taxas.data?.taxas.length > 0 ? (
                taxas.data.taxas.slice(0, 5).map((taxa: any, index: number) => (
                  <Box key={index} mb={2} pb={2} borderBottom={index < 4 ? 1 : 0} borderColor="divider">
                    <Typography variant="subtitle1" fontWeight="bold">
                      {taxa.codigo}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      Data: {formatDate(taxa.data)} | PU: {taxa.pu.toFixed(6)}
                    </Typography>
                    <Typography variant="body2">
                      % do PU Par: {taxa.percentual_pu_par.toFixed(2)}% | Fonte: {taxa.fonte}
                    </Typography>
                  </Box>
                ))
              ) : (
                <Typography variant="body2" color="text.secondary">
                  Nenhuma taxa encontrada no período selecionado.
                </Typography>
              )}
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
};

export default Dashboard;
