from fastapi import FastAPI, Query, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from typing import List, Optional
import json
from datetime import datetime
from pydantic import BaseModel
import os
from pathlib import Path

app = FastAPI(
    title="API de Debêntures",
    description="API para consulta de dados de debêntures no Brasil",
    version="1.0.0"
)

# Configuração de CORS para permitir requisições do frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Em produção, especificar origens permitidas
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Caminho para os arquivos de dados
DATA_DIR = Path(__file__).parent.parent / "data"

# Modelos Pydantic
class Emissao(BaseModel):
    emissor: str
    codigo: str
    serie: str
    emissao: str
    data_emissao: str
    volume_total: float
    status: str

class Assembleia(BaseModel):
    codigo_debenture: str
    data_assembleia: str
    tipo: str
    documento_url: Optional[str] = None
    agente_fiduciario: str

class Taxa(BaseModel):
    codigo: str
    data: str
    pu: float
    percentual_pu_par: float
    duration: Optional[float] = None
    fonte: str

class Evento(BaseModel):
    codigo_debenture: str
    data_evento: str
    tipo_evento: str
    descricao: Optional[str] = None
    agente_fiduciario: Optional[str] = None

class MetaDados(BaseModel):
    ultima_atualizacao: str
    fontes: List[str]
    observacoes: Optional[str] = None

class RespostaEmissoes(BaseModel):
    emissoes: List[Emissao]
    meta: MetaDados

class RespostaAssembleias(BaseModel):
    assembleias: List[Assembleia]
    meta: MetaDados

class RespostaTaxas(BaseModel):
    taxas: List[Taxa]
    meta: MetaDados

class RespostaEventos(BaseModel):
    eventos: List[Evento]
    meta: MetaDados

# Funções auxiliares
def carregar_dados(arquivo: str):
    try:
        with open(DATA_DIR / arquivo, 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail=f"Arquivo {arquivo} não encontrado")
    except json.JSONDecodeError:
        raise HTTPException(status_code=500, detail=f"Erro ao decodificar o arquivo {arquivo}")

def filtrar_por_data(items: list, campo_data: str, data_inicio: Optional[str], data_fim: Optional[str]):
    if not data_inicio and not data_fim:
        return items
    
    resultado = items
    if data_inicio:
        resultado = [item for item in resultado if item[campo_data] >= data_inicio]
    if data_fim:
        resultado = [item for item in resultado if item[campo_data] <= data_fim]
    
    return resultado

# Endpoints
@app.get("/", tags=["Informações"])
async def root():
    """
    Retorna informações básicas sobre a API.
    """
    return {
        "nome": "API de Debêntures",
        "versao": "1.0.0",
        "descricao": "API para consulta de dados de debêntures no Brasil",
        "endpoints_disponiveis": [
            "/emissoes",
            "/assembleias",
            "/taxas",
            "/eventos"
        ]
    }

@app.get("/emissoes", response_model=RespostaEmissoes, tags=["Debêntures"])
async def listar_emissoes(
    data_inicio: Optional[str] = Query(None, description="Data inicial (formato YYYY-MM-DD)"),
    data_fim: Optional[str] = Query(None, description="Data final (formato YYYY-MM-DD)"),
    emissor: Optional[str] = Query(None, description="Filtrar por emissor")
):
    """
    Retorna a lista de emissões de debêntures, com opção de filtro por data e emissor.
    """
    dados = carregar_dados("emissoes.json")
    emissoes = dados.get("emissoes", [])
    
    # Filtrar por data
    emissoes = filtrar_por_data(emissoes, "data_emissao", data_inicio, data_fim)
    
    # Filtrar por emissor
    if emissor:
        emissoes = [e for e in emissoes if emissor.lower() in e["emissor"].lower()]
    
    # Atualizar metadados
    meta = dados.get("meta", {})
    meta["ultima_atualizacao"] = datetime.now().isoformat()
    
    return {"emissoes": emissoes, "meta": meta}

@app.get("/assembleias", response_model=RespostaAssembleias, tags=["Debêntures"])
async def listar_assembleias(
    data_inicio: Optional[str] = Query(None, description="Data inicial (formato YYYY-MM-DD)"),
    data_fim: Optional[str] = Query(None, description="Data final (formato YYYY-MM-DD)"),
    agente_fiduciario: Optional[str] = Query(None, description="Filtrar por agente fiduciário")
):
    """
    Retorna a lista de assembleias de debenturistas, com opção de filtro por data e agente fiduciário.
    """
    dados = carregar_dados("assembleias.json")
    assembleias = dados.get("assembleias", [])
    
    # Filtrar por data
    assembleias = filtrar_por_data(assembleias, "data_assembleia", data_inicio, data_fim)
    
    # Filtrar por agente fiduciário
    if agente_fiduciario:
        assembleias = [a for a in assembleias if agente_fiduciario.lower() in a["agente_fiduciario"].lower()]
    
    # Atualizar metadados
    meta = dados.get("meta", {})
    meta["ultima_atualizacao"] = datetime.now().isoformat()
    
    return {"assembleias": assembleias, "meta": meta}

@app.get("/taxas", response_model=RespostaTaxas, tags=["Debêntures"])
async def listar_taxas(
    data_inicio: Optional[str] = Query(None, description="Data inicial (formato YYYY-MM-DD)"),
    data_fim: Optional[str] = Query(None, description="Data final (formato YYYY-MM-DD)"),
    codigo: Optional[str] = Query(None, description="Filtrar por código da debênture")
):
    """
    Retorna a lista de taxas e preços de debêntures, com opção de filtro por data e código.
    """
    dados = carregar_dados("taxas.json")
    taxas = dados.get("taxas", [])
    
    # Filtrar por data
    taxas = filtrar_por_data(taxas, "data", data_inicio, data_fim)
    
    # Filtrar por código
    if codigo:
        taxas = [t for t in taxas if codigo.upper() in t["codigo"].upper()]
    
    # Atualizar metadados
    meta = dados.get("meta", {})
    meta["ultima_atualizacao"] = datetime.now().isoformat()
    
    return {"taxas": taxas, "meta": meta}

@app.get("/eventos", response_model=RespostaEventos, tags=["Debêntures"])
async def listar_eventos(
    data_inicio: Optional[str] = Query(None, description="Data inicial (formato YYYY-MM-DD)"),
    data_fim: Optional[str] = Query(None, description="Data final (formato YYYY-MM-DD)"),
    tipo_evento: Optional[str] = Query(None, description="Filtrar por tipo de evento")
):
    """
    Retorna a lista de eventos corporativos relacionados a debêntures, com opção de filtro por data e tipo.
    """
    dados = carregar_dados("eventos.json")
    eventos = dados.get("eventos", [])
    
    # Filtrar por data
    eventos = filtrar_por_data(eventos, "data_evento", data_inicio, data_fim)
    
    # Filtrar por tipo de evento
    if tipo_evento:
        eventos = [e for e in eventos if tipo_evento.lower() in e["tipo_evento"].lower()]
    
    # Atualizar metadados
    meta = dados.get("meta", {})
    meta["ultima_atualizacao"] = datetime.now().isoformat()
    
    return {"eventos": eventos, "meta": meta}

@app.get("/status", tags=["Informações"])
async def status():
    """
    Retorna o status atual da API e informações sobre os dados disponíveis.
    """
    arquivos = os.listdir(DATA_DIR)
    dados_disponiveis = [arquivo.replace(".json", "") for arquivo in arquivos if arquivo.endswith(".json")]
    
    return {
        "status": "online",
        "timestamp": datetime.now().isoformat(),
        "dados_disponiveis": dados_disponiveis,
        "total_arquivos": len(dados_disponiveis)
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
