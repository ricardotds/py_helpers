# Fontes Oficiais de Informações sobre Debêntures no Brasil

## Agentes Fiduciários

### 1. Pentágono S.A. DTVM
- **URL Principal**: https://www.pentagonotrustee.com.br/
- **Seção de Emissões**: https://www.pentagonotrustee.com.br/Site/#emissoes
- **Método de Acesso**: O site possui um sistema de busca por ativo ou por emissor
- **Informações Disponíveis**: Relatórios anuais, preços unitários, emissões de debêntures
- **Contato**: Tel: (21) 3385-4565 / (11) 4420-5931, Email: faleconosco@pentagonotrustee.com.br

### 2. Vórtx DTVM Ltda.
- **URL Principal**: https://www.vortx.com.br/
- **Portal de Serviços**: https://portal.vortx.com.br/
- **Seção Corporate Trust**: https://www.vortx.com.br/servicos/corporate-trust
- **Método de Acesso**: O site possui seções específicas para investidores e serviços de agente fiduciário
- **Contato**: agentefiduciario@vortx.com.br
- **Informações Disponíveis**: Serviços de agente fiduciário, monitoramento de contratos, informações sobre debêntures, CRI e CRA

### 3. Oliveira Trust DTVM S.A.
- **URL Principal**: https://www.oliveiratrust.com.br/
- **Área de Investidor**: https://www.oliveiratrust.com.br/investidor
- **Seção Agente Fiduciário**: https://www.oliveiratrust.com.br/servicos/agente-fiduciario
- **Método de Acesso**: O site possui áreas específicas para consulta de ativos, incluindo debêntures, CRI e CRA
- **Informações Disponíveis**: Relatórios anuais de agente fiduciário, características de emissões, documentos relacionados a títulos
- **Destaque**: Disponibiliza Relatório anual do Agente Fiduciário 2024

### 4. Planner Trustee DTVM Ltda (Trustee DTVM)
- **URL Principal**: https://fiduciario.com.br/
- **Seção de Debêntures**: https://fiduciario.com.br/debentures/
- **Método de Acesso**: O site possui listagem de emissões de debêntures com filtros por código, emissor, tipo de ativo e emissão
- **Informações Disponíveis**: Detalhes de emissões, assembleias, informativos, PUs diários, relatórios anuais
- **Outros Títulos**: CRI, CRA, CR, Notas Promissórias, Notas Comerciais, Letras Financeiras

### 5. BTG Pactual Serviços Financeiros S.A. DTVM
- **URL Principal**: https://www.btgpactual.com/administracao-fiduciaria
- **Método de Acesso**: O site possui seções para serviços fiduciários, incluindo administração e controladoria de fundos, escrituração e estruturação
- **Informações Disponíveis**: Documentos relacionados a fundos de investimento, assembleias gerais de quotistas, informes aos órgãos reguladores
- **Serviços Relacionados**: Escrituração de valores mobiliários, cálculo de cotas, gestão de riscos
- **Informações Disponíveis**: [A ser pesquisado]

### 6. BRL Trust DTVM S.A.
- **URL Principal**: https://www.apexgroup.com/apex-brazil/
- **Seção de Fundos**: https://www.apexgroup.com/apex-brazil-funds/
- **Método de Acesso**: O site permite filtrar por tipo de negócio (BRL) e tipo de fundo, incluindo debêntures e outros títulos
- **Informações Disponíveis**: Documentos regulatórios, informações sobre fundos de investimento
- **Observação**: A BRL Trust DTVM foi adquirida pelo Apex Group, conforme indicado no site
- **Método de Acesso**: [A ser pesquisado]
- **Informações Disponíveis**: [A ser pesquisado]

### 7. XP Investimentos CCTVM S.A.
- **URL Principal**: https://www.xpi.com.br/
- **Seção de Renda Fixa**: https://www.xpi.com.br/produtos/renda-fixa/
- **Documentos de Ofertas Públicas**: https://ofertaspublicas.xpi.com.br/
- **Método de Acesso**: O site oferece informações sobre debêntures na seção de renda fixa e documentos de ofertas públicas
- **Informações Disponíveis**: Anúncios de início e encerramento de ofertas, prospectos de debêntures, comunicados ao mercado
- **Método de Acesso**: [A ser pesquisado]
- **Informações Disponíveis**: [A ser pesquisado]

### 8. Banco do Brasil S.A.
- **URL Principal**: https://www.bb.com.br/
- **Seção de Crédito Privado**: https://www.bb.com.br/site/investimentos/credito-privado/
- **Portal InvesTalk**: https://investalk.bb.com.br/
- **Método de Acesso**: O site oferece informações sobre debêntures na seção de crédito privado e conteúdos educativos no portal InvesTalk
- **Informações Disponíveis**: Artigos sobre debêntures, análises de mercado, recomendações de investimentos
- **URL**: [A ser pesquisado]
- **Método de Acesso**: [A ser pesquisado]
- **Informações Disponíveis**: [A ser pesquisado]

### 9. Itaú DTVM S.A.
- **URL Principal**: https://www.itau.com.br/investimentos/
- **Seção de Debêntures**: https://www.itau.com.br/investimentos/renda-fixa/debentures
- **Seção Personnalité**: https://www.itau.com.br/personnalite/investimentos/renda-fixa/debentures
- **Método de Acesso**: O site oferece informações educativas sobre debêntures e acesso a produtos de investimento relacionados
- **Informações Disponíveis**: Explicações sobre funcionamento de debêntures, características, riscos e oportunidades de investimento

## Entidades Regulatórias

### 1. ANBIMA (Associação Brasileira das Entidades dos Mercados Financeiro e de Capitais)
- **URL Principal**: https://www.anbima.com.br/
- **Portal de Dados**: https://data.anbima.com.br/
- **Seção de Taxas de Debêntures**: https://www.anbima.com.br/pt_br/informar/taxas-de-debentures.htm
- **Método de Acesso**: O site oferece acesso a dados de mercado, publicações e ferramentas para análise de debêntures
- **Informações Disponíveis**: Taxas médias indicativas, preços unitários, boletins de mercado de capitais, índices de debêntures (IDA), dados sobre emissões

### 2. CVM (Comissão de Valores Mobiliários)
- **URL Principal**: https://www.gov.br/cvm/pt-br
- **Central de Sistemas**: https://sistemas.cvm.gov.br/
- **Método de Acesso**: O site oferece acesso a sistemas de consulta de informações sobre companhias, fundos e ofertas públicas
- **Informações Disponíveis**: Documentos de ofertas públicas, demonstrações financeiras, fatos relevantes, comunicados ao mercado, regulamentação
- **Informações Disponíveis**: [A ser pesquisado]

## Fontes de Debenturistas

### 1. B3 (Brasil, Bolsa, Balcão)
- **URL Principal**: https://www.b3.com.br/
- **Seção de Debêntures**: https://www.b3.com.br/pt_br/produtos-e-servicos/negociacao/renda-fixa/debentures.htm
- **Método de Acesso**: O site oferece informações sobre negociação de debêntures no mercado secundário
- **Informações Disponíveis**: Características das debêntures, preços, volumes negociados, informações sobre emissões

### 2. Vale (Exemplo de Emissor com Debêntures Participativas)
- **URL**: https://vale.com/pt/dividendos-dividas-e-debentures
- **Método de Acesso**: Acesso direto à seção de debêntures no site da empresa
- **Informações Disponíveis**: Informações sobre debêntures participativas, pagamentos de prêmios, documentos relacionados
