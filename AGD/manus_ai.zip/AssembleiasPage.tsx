import React, { useState } from 'react';
import { 
  Typography, 
  Paper, 
  Grid, 
  Box,
  TextField,
  Button,
  CircularProgress,
  Alert,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TablePagination,
  Link
} from '@mui/material';
import { DatePicker } from '@mui/x-date-pickers';
import { format, subDays } from 'date-fns';
import { useApi } from '../contexts/ApiContext';
import { useQuery } from 'react-query';

// Componente para a página de Assembleias
const AssembleiasPage: React.FC = () => {
  // Estados para as datas de filtro
  const [dataInicio, setDataInicio] = useState<Date | null>(subDays(new Date(), 30));
  const [dataFim, setDataFim] = useState<Date | null>(new Date());
  const [agenteFiduciario, setAgenteFiduciario] = useState<string>('');
  
  // Estados para paginação
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  
  // Contexto da API
  const api = useApi();
  
  // Formatação de datas para a API
  const formatDateForApi = (date: Date | null) => {
    if (!date) return undefined;
    return format(date, 'yyyy-MM-dd');
  };
  
  // Parâmetros para as consultas
  const queryParams = {
    dataInicio: formatDateForApi(dataInicio),
    dataFim: formatDateForApi(dataFim),
    agenteFiduciario: agenteFiduciario || undefined
  };
  
  // Consulta React Query
  const { data, isLoading, isError, refetch } = useQuery(
    ['assembleias', queryParams], 
    () => api.fetchAssembleias(queryParams.dataInicio, queryParams.dataFim, queryParams.agenteFiduciario),
    { enabled: !!dataInicio && !!dataFim }
  );
  
  // Manipuladores de paginação
  const handleChangePage = (event: unknown, newPage: number) => {
    setPage(newPage);
  };
  
  const handleChangeRowsPerPage = (event: React.ChangeEvent<HTMLInputElement>) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };
  
  // Formatação de datas para exibição
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return format(date, 'dd/MM/yyyy');
  };
  
  // Função para buscar dados
  const handleSearch = () => {
    refetch();
  };
  
  return (
    <Box>
      <Typography variant="h4" component="h1" gutterBottom>
        Assembleias de Debenturistas
      </Typography>
      
      <Paper sx={{ p: 3, mb: 4 }}>
        <Typography variant="h6" gutterBottom>
          Filtros
        </Typography>
        <Grid container spacing={3} alignItems="center">
          <Grid item xs={12} sm={3}>
            <DatePicker
              label="Data Inicial"
              value={dataInicio}
              onChange={setDataInicio}
              slotProps={{ textField: { fullWidth: true } }}
            />
          </Grid>
          <Grid item xs={12} sm={3}>
            <DatePicker
              label="Data Final"
              value={dataFim}
              onChange={setDataFim}
              slotProps={{ textField: { fullWidth: true } }}
            />
          </Grid>
          <Grid item xs={12} sm={3}>
            <TextField
              label="Agente Fiduciário"
              value={agenteFiduciario}
              onChange={(e) => setAgenteFiduciario(e.target.value)}
              fullWidth
            />
          </Grid>
          <Grid item xs={12} sm={3}>
            <Button 
              variant="contained" 
              onClick={handleSearch}
              disabled={isLoading}
              fullWidth
              sx={{ height: '56px' }}
            >
              {isLoading ? <CircularProgress size={24} /> : 'Buscar'}
            </Button>
          </Grid>
        </Grid>
        
        {isError && (
          <Alert severity="error" sx={{ mt: 2 }}>
            Ocorreu um erro ao carregar os dados. Por favor, tente novamente.
          </Alert>
        )}
      </Paper>
      
      <Paper>
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Debênture</TableCell>
                <TableCell>Data</TableCell>
                <TableCell>Tipo</TableCell>
                <TableCell>Agente Fiduciário</TableCell>
                <TableCell align="center">Documento</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {isLoading ? (
                <TableRow>
                  <TableCell colSpan={5} align="center" sx={{ py: 3 }}>
                    <CircularProgress />
                  </TableCell>
                </TableRow>
              ) : data?.assembleias && data.assembleias.length > 0 ? (
                data.assembleias
                  .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                  .map((assembleia: any, index: number) => (
                    <TableRow key={index} hover>
                      <TableCell>{assembleia.codigo_debenture}</TableCell>
                      <TableCell>{formatDate(assembleia.data_assembleia)}</TableCell>
                      <TableCell>{assembleia.tipo}</TableCell>
                      <TableCell>{assembleia.agente_fiduciario}</TableCell>
                      <TableCell align="center">
                        {assembleia.documento_url ? (
                          <Link 
                            href={assembleia.documento_url} 
                            target="_blank" 
                            rel="noopener noreferrer"
                          >
                            Ver documento
                          </Link>
                        ) : (
                          <Typography variant="body2" color="text.secondary">
                            Não disponível
                          </Typography>
                        )}
                      </TableCell>
                    </TableRow>
                  ))
              ) : (
                <TableRow>
                  <TableCell colSpan={5} align="center">
                    Nenhuma assembleia encontrada para os filtros selecionados.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>
        
        {data?.assembleias && data.assembleias.length > 0 && (
          <TablePagination
            rowsPerPageOptions={[5, 10, 25]}
            component="div"
            count={data.assembleias.length}
            rowsPerPage={rowsPerPage}
            page={page}
            onPageChange={handleChangePage}
            onRowsPerPageChange={handleChangeRowsPerPage}
            labelRowsPerPage="Linhas por página:"
            labelDisplayedRows={({ from, to, count }) => `${from}-${to} de ${count}`}
          />
        )}
      </Paper>
    </Box>
  );
};

export default AssembleiasPage;
