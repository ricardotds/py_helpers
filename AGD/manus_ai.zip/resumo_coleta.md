# Resumo da Coleta de Dados de Debêntures

## Fontes Acessadas com Sucesso

### 1. Oliveira Trust
- **Dados Coletados**: Assembleias de debenturistas recentes
- **Exemplo**: Assembleia de 21/05/2025 da 2ª SÉRIE 2ª EMISSÃO ROTA DAS BANDEIRAS
- **Arquivo Salvo**: `/home/ubuntu/debentures_project/dados/oliveira_trust_assembleias.md`
- **Observações**: Sistema permite filtrar por tipo de ativo (Debêntures) e tipo de documento (Assembleias)

### 2. ANBIMA
- **Dados Coletados**: Taxas médias indicativas e preços unitários do mercado secundário
- **Exemplo**: Dados do ativo VLME11 com PU de 424.192491 e 76,35% do PU Par
- **Arquivo Salvo**: `/home/ubuntu/debentures_project/dados/anbima_taxas_debentures.md`
- **Observações**: Disponibiliza informações para papéis atrelados ao DI, IGP-M e IPCA

### 3. CVM
- **Dados Coletados**: Ofertas registradas de fundos de investimento em direitos creditórios
- **Exemplo**: Oferta de R$ 350.000.000,00 da OCCAM PORTFOLIO CRÉDITO em 17/04/2025
- **Arquivo Salvo**: `/home/ubuntu/debentures_project/dados/cvm_ofertas_registradas.md`
- **Observações**: Sistema permite consulta por ano e tipo de oferta

## Fontes com Restrições de Acesso

### 1. Pentágono S.A. DTVM
- **Status**: Erro de servidor nas páginas de informações aos investidores e emissões
- **Observações**: Tentativas de acesso resultaram em erros de tempo de execução

### 2. Vórtx DTVM
- **Status**: Página de debêntures não encontrada (erro 404)
- **Observações**: Estrutura do site pode ter sido alterada ou página removida

### 3. ANBIMA Data
- **Status**: Acesso bloqueado por proteção anti-robô (reCAPTCHA)
- **Observações**: Portal principal de dados requer verificação humana

### 4. CVM (Seções Adicionais)
- **Status**: Algumas seções requerem login via gov.br
- **Observações**: Acesso completo necessitaria autenticação

## Próximos Passos

1. Estruturar os dados coletados em formato padronizado
2. Validar a consistência e completude das informações
3. Preparar os dados para integração na aplicação web
4. Desenvolver mecanismos para atualização periódica dos dados
