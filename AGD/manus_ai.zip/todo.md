# Projeto de Acompanhamento Diário de Debêntures no Brasil

## Tarefas

### Pesquisa de Fontes
- [ ] Pesquisar sites dos agentes fiduciários:
  - [ ] Pentágono S.A. DTVM
  - [ ] Vórtx DTVM Ltda.
  - [ ] Oliveira Trust DTVM S.A.
  - [ ] Planner Trustee DTVM Ltda
  - [ ] BTG Pactual Serviços Financeiros S.A. DTVM
  - [ ] BRL Trust DTVM S.A.
  - [ ] XP Investimentos CCTVM S.A.
  - [ ] Banco do Brasil S.A.
  - [ ] Itaú DTVM S.A.
- [ ] Pesquisar fontes regulatórias:
  - [ ] ANBIMA
  - [ ] CVM
- [ ] Pesquisar fontes de debenturistas
- [ ] Documentar URLs e métodos de acesso aos dados

### Coleta de Dados
- [ ] Coletar dados sobre emissões de debêntures
- [ ] Coletar dados sobre assembleias de investidores
- [ ] Coletar dados sobre eventos corporativos
- [ ] Coletar datas de eventos

### Estruturação de Dados
- [ ] Definir estrutura de dados para armazenamento
- [ ] Validar dados coletados
- [ ] Organizar dados por categorias

### Desenvolvimento da Aplicação Web
- [ ] Escolher framework adequado
- [ ] Criar estrutura básica da aplicação
- [ ] Desenvolver interface com filtro de datas
- [ ] Implementar visualização de dados

### Integração e Testes
- [ ] Integrar dados na aplicação
- [ ] Implementar funcionalidades de filtro
- [ ] Testar funcionalidades
- [ ] Validar qualidade da aplicação

### Finalização
- [ ] Documentar o projeto
- [ ] Preparar para deploy
- [ ] Disponibilizar link para acesso
