# Dados de Taxas de Debêntures - ANBIMA

## Taxas Médias do Mercado Secundário

| Ativo | PU (mm) | % do PU Par | Duration |
|-------|---------|-------------|----------|
| VLME11 | 424.192491 | 76,35 | 311 |
| VLME11 (Corrigido) | 592.571634 | 81,59 | 227 |

*Dados coletados em 26/05/2025 da página de Taxas de Debêntures da ANBIMA*

## Observações
- A ANBIMA divulga as taxas médias indicativas e os preços unitários (PU) correspondentes do mercado secundário de debêntures
- Estão disponíveis informações para os papéis atrelados ao DI, ao IGP-M e ao IPCA
- Podem ser consultados os valores referentes aos últimos 5 dias úteis
- Conforme aviso, a partir de janeiro de 2025, a divulgação de PU indicativo da série de debêntures da Vale CVRD passou a ser divulgada nas publicações diárias
- Algumas retificações foram realizadas em 15/05/2025 e 28/04/2025 para determinados ativos

## Limitações de Acesso
- O portal principal de dados da ANBIMA (data.anbima.com.br) possui proteção anti-robô que impede o acesso automatizado
- Para acesso completo aos dados, seria necessário autenticação ou uso da API oficial da ANBIMA
