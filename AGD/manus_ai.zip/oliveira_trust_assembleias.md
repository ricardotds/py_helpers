# Dados de Assembleias de Debêntures - Oliveira Trust

## Assembleias Recentes

| Data | Tipo do ativo | Ativo | Tipo de documento | Nome do documento |
|------|---------------|-------|-------------------|-------------------|
| 21/05/2025 | DEBENTURES | 2ª SÉRIE 2ª EMISSÃO ROTA DAS BANDEIRAS - 2ª EMISSÃO | Assembleias | AGT 2025.05.21 |

*Dados coletados em 26/05/2025 do portal da Oliveira Trust*

## Observações
- A Oliveira Trust disponibiliza documentos de assembleias de debenturistas através de seu portal de investidores
- É possível filtrar por tipo de ativo (Debêntures) e tipo de documento (Assembleias)
- Os documentos mais recentes aparecem no topo da lista
- Cada documento contém informações sobre deliberações e eventos corporativos relacionados às debêntures
