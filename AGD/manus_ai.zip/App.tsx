import { useState, useEffect } from 'react';
import './App.css';
import assembleias from './data/assembleias.json';
import taxas from './data/taxas.json';
import emissoes from './data/emissoes.json';
import eventos from './data/eventos.json';

// Tipos de dados
interface Assembleia {
  codigo_debenture: string;
  data_assembleia: string;
  tipo: string;
  documento_url?: string;
  agente_fiduciario: string;
}

interface Taxa {
  codigo: string;
  data: string;
  pu: number;
  percentual_pu_par: number;
  duration?: number;
  fonte: string;
}

interface Emissao {
  emissor: string;
  codigo: string;
  serie: string;
  emissao: string;
  data_emissao: string;
  volume_total: number;
  status: string;
}

interface Evento {
  codigo_debenture: string;
  data_evento: string;
  tipo_evento: string;
  descricao?: string;
  agente_fiduciario?: string;
}

function App() {
  // Estados
  const [dataInicio, setDataInicio] = useState<string>('');
  const [dataFim, setDataFim] = useState<string>('');
  const [tipoFiltro, setTipoFiltro] = useState<string>('todos');
  const [assembleiasFiltradas, setAssembleiasFiltradas] = useState<Assembleia[]>([]);
  const [taxasFiltradas, setTaxasFiltradas] = useState<Taxa[]>([]);
  const [emissoesFiltradas, setEmissoesFiltradas] = useState<Emissao[]>([]);
  const [eventosFiltrados, setEventosFiltrados] = useState<Evento[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [ultimaAtualizacao, setUltimaAtualizacao] = useState<string>('');

  // Definir data inicial como 30 dias atrás e data final como hoje
  useEffect(() => {
    const hoje = new Date();
    const dataFimFormatada = hoje.toISOString().split('T')[0];
    
    const trinta_dias_atras = new Date();
    trinta_dias_atras.setDate(hoje.getDate() - 30);
    const dataInicioFormatada = trinta_dias_atras.toISOString().split('T')[0];
    
    setDataInicio(dataInicioFormatada);
    setDataFim(dataFimFormatada);
    
    // Definir a data e hora da última atualização
    atualizarDataHora();
  }, []);

  // Função para atualizar a data e hora da última atualização
  const atualizarDataHora = () => {
    const agora = new Date();
    const dataHoraFormatada = agora.toLocaleString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
    setUltimaAtualizacao(dataHoraFormatada);
  };

  // Filtrar dados quando as datas ou tipo de filtro mudar
  useEffect(() => {
    if (!dataInicio || !dataFim) return;
    filtrarDados();
  }, [dataInicio, dataFim, tipoFiltro]);

  // Função para filtrar os dados com base nas datas e tipo selecionados
  const filtrarDados = () => {
    // Filtrar assembleias
    if (tipoFiltro === 'todos' || tipoFiltro === 'assembleias') {
      const filtradas = assembleias.assembleias.filter(assembleia => {
        const dataAssembleia = assembleia.data_assembleia;
        return dataAssembleia >= dataInicio && dataAssembleia <= dataFim;
      });
      setAssembleiasFiltradas(filtradas);
    } else {
      setAssembleiasFiltradas([]);
    }

    // Filtrar taxas
    if (tipoFiltro === 'todos' || tipoFiltro === 'taxas') {
      const filtradas = taxas.taxas.filter(taxa => {
        const dataTaxa = taxa.data;
        return dataTaxa >= dataInicio && dataTaxa <= dataFim;
      });
      setTaxasFiltradas(filtradas);
    } else {
      setTaxasFiltradas([]);
    }

    // Filtrar emissões
    if (tipoFiltro === 'todos' || tipoFiltro === 'emissoes') {
      const filtradas = emissoes.emissoes.filter(emissao => {
        const dataEmissao = emissao.data_emissao;
        return dataEmissao >= dataInicio && dataEmissao <= dataFim;
      });
      setEmissoesFiltradas(filtradas);
    } else {
      setEmissoesFiltradas([]);
    }

    // Filtrar eventos
    if (tipoFiltro === 'todos' || tipoFiltro === 'eventos') {
      const filtrados = eventos.eventos.filter(evento => {
        const dataEvento = evento.data_evento;
        return dataEvento >= dataInicio && dataEvento <= dataFim;
      });
      setEventosFiltrados(filtrados);
    } else {
      setEventosFiltrados([]);
    }
  };

  // Função para simular a atualização dos dados
  const atualizarDados = () => {
    setIsLoading(true);
    
    // Simulação de uma chamada de API para atualizar os dados
    setTimeout(() => {
      // Aqui seria feita a chamada real para atualizar os dados
      // Por enquanto, apenas atualizamos os dados existentes
      filtrarDados();
      atualizarDataHora();
      setIsLoading(false);
    }, 1000);
  };

  // Formatar data para exibição
  const formatarData = (data: string) => {
    const [ano, mes, dia] = data.split('-');
    return `${dia}/${mes}/${ano}`;
  };

  // Formatar valor monetário
  const formatarValor = (valor: number) => {
    return valor.toLocaleString('pt-BR', {
      style: 'currency',
      currency: 'BRL',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <header className="mb-8">
        <h1 className="text-3xl font-bold text-center mb-2">Monitor Diário de Debêntures</h1>
        <p className="text-center text-gray-600 mb-6">
          Acompanhamento de emissões, assembleias, eventos e taxas de debêntures no Brasil
        </p>
        
        <div className="bg-gray-100 p-4 rounded-lg">
          <div className="flex flex-wrap gap-4 justify-center items-end mb-4">
            <div>
              <label htmlFor="dataInicio" className="block text-sm font-medium text-gray-700 mb-1">
                Data Inicial
              </label>
              <input
                type="date"
                id="dataInicio"
                value={dataInicio}
                onChange={(e) => setDataInicio(e.target.value)}
                className="border rounded-md px-3 py-2"
              />
            </div>
            
            <div>
              <label htmlFor="dataFim" className="block text-sm font-medium text-gray-700 mb-1">
                Data Final
              </label>
              <input
                type="date"
                id="dataFim"
                value={dataFim}
                onChange={(e) => setDataFim(e.target.value)}
                className="border rounded-md px-3 py-2"
              />
            </div>
            
            <div>
              <label htmlFor="tipoFiltro" className="block text-sm font-medium text-gray-700 mb-1">
                Tipo de Informação
              </label>
              <select
                id="tipoFiltro"
                value={tipoFiltro}
                onChange={(e) => setTipoFiltro(e.target.value)}
                className="border rounded-md px-3 py-2"
              >
                <option value="todos">Todos</option>
                <option value="emissoes">Emissões</option>
                <option value="assembleias">Assembleias</option>
                <option value="eventos">Eventos Corporativos</option>
                <option value="taxas">Taxas e Preços</option>
              </select>
            </div>
          </div>
          
          {/* Botão de atualização */}
          <div className="flex justify-center">
            <button
              onClick={atualizarDados}
              disabled={isLoading}
              className={`flex items-center justify-center px-4 py-2 rounded-md text-white font-medium ${
                isLoading ? 'bg-gray-400 cursor-not-allowed' : 'bg-blue-600 hover:bg-blue-700'
              }`}
            >
              {isLoading ? (
                <>
                  <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Atualizando...
                </>
              ) : (
                <>
                  <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path>
                  </svg>
                  Atualizar Dados
                </>
              )}
            </button>
          </div>
          
          {/* Informação sobre última atualização */}
          {ultimaAtualizacao && (
            <div className="text-center mt-3 text-sm text-gray-500">
              Última atualização: {ultimaAtualizacao}
            </div>
          )}
        </div>
      </header>

      <main>
        {/* Seção de Emissões */}
        {(tipoFiltro === 'todos' || tipoFiltro === 'emissoes') && (
          <section className="mb-8">
            <h2 className="text-2xl font-semibold mb-4">Emissões de Debêntures</h2>
            {emissoesFiltradas.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="min-w-full bg-white border border-gray-200">
                  <thead>
                    <tr className="bg-gray-100">
                      <th className="py-2 px-4 border-b text-left">Emissor</th>
                      <th className="py-2 px-4 border-b text-left">Código</th>
                      <th className="py-2 px-4 border-b text-left">Série/Emissão</th>
                      <th className="py-2 px-4 border-b text-left">Data</th>
                      <th className="py-2 px-4 border-b text-right">Volume Total</th>
                      <th className="py-2 px-4 border-b text-center">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {emissoesFiltradas.map((emissao, index) => (
                      <tr key={index} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                        <td className="py-2 px-4 border-b">{emissao.emissor}</td>
                        <td className="py-2 px-4 border-b">{emissao.codigo}</td>
                        <td className="py-2 px-4 border-b">{emissao.serie} / {emissao.emissao}ª</td>
                        <td className="py-2 px-4 border-b">{formatarData(emissao.data_emissao)}</td>
                        <td className="py-2 px-4 border-b text-right">{formatarValor(emissao.volume_total)}</td>
                        <td className="py-2 px-4 border-b text-center">
                          <span className={`inline-block px-2 py-1 rounded-full text-xs ${
                            emissao.status === 'Ativa' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                          }`}>
                            {emissao.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <p className="text-gray-500 italic">Nenhuma emissão encontrada no período selecionado.</p>
            )}
          </section>
        )}

        {/* Seção de Assembleias */}
        {(tipoFiltro === 'todos' || tipoFiltro === 'assembleias') && (
          <section className="mb-8">
            <h2 className="text-2xl font-semibold mb-4">Assembleias de Debenturistas</h2>
            {assembleiasFiltradas.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="min-w-full bg-white border border-gray-200">
                  <thead>
                    <tr className="bg-gray-100">
                      <th className="py-2 px-4 border-b text-left">Debênture</th>
                      <th className="py-2 px-4 border-b text-left">Data</th>
                      <th className="py-2 px-4 border-b text-left">Tipo</th>
                      <th className="py-2 px-4 border-b text-left">Agente Fiduciário</th>
                      <th className="py-2 px-4 border-b text-center">Documento</th>
                    </tr>
                  </thead>
                  <tbody>
                    {assembleiasFiltradas.map((assembleia, index) => (
                      <tr key={index} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                        <td className="py-2 px-4 border-b">{assembleia.codigo_debenture}</td>
                        <td className="py-2 px-4 border-b">{formatarData(assembleia.data_assembleia)}</td>
                        <td className="py-2 px-4 border-b">{assembleia.tipo}</td>
                        <td className="py-2 px-4 border-b">{assembleia.agente_fiduciario}</td>
                        <td className="py-2 px-4 border-b text-center">
                          {assembleia.documento_url ? (
                            <a 
                              href={assembleia.documento_url} 
                              target="_blank" 
                              rel="noopener noreferrer"
                              className="text-blue-600 hover:underline"
                            >
                              Ver documento
                            </a>
                          ) : (
                            <span className="text-gray-400">Não disponível</span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <p className="text-gray-500 italic">Nenhuma assembleia encontrada no período selecionado.</p>
            )}
          </section>
        )}

        {/* Seção de Eventos */}
        {(tipoFiltro === 'todos' || tipoFiltro === 'eventos') && (
          <section className="mb-8">
            <h2 className="text-2xl font-semibold mb-4">Eventos Corporativos</h2>
            {eventosFiltrados.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="min-w-full bg-white border border-gray-200">
                  <thead>
                    <tr className="bg-gray-100">
                      <th className="py-2 px-4 border-b text-left">Debênture</th>
                      <th className="py-2 px-4 border-b text-left">Data</th>
                      <th className="py-2 px-4 border-b text-left">Tipo de Evento</th>
                      <th className="py-2 px-4 border-b text-left">Descrição</th>
                    </tr>
                  </thead>
                  <tbody>
                    {eventosFiltrados.map((evento, index) => (
                      <tr key={index} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                        <td className="py-2 px-4 border-b">{evento.codigo_debenture}</td>
                        <td className="py-2 px-4 border-b">{formatarData(evento.data_evento)}</td>
                        <td className="py-2 px-4 border-b">{evento.tipo_evento}</td>
                        <td className="py-2 px-4 border-b">{evento.descricao || '-'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <p className="text-gray-500 italic">Nenhum evento encontrado no período selecionado.</p>
            )}
          </section>
        )}

        {/* Seção de Taxas */}
        {(tipoFiltro === 'todos' || tipoFiltro === 'taxas') && (
          <section className="mb-8">
            <h2 className="text-2xl font-semibold mb-4">Taxas e Preços de Debêntures</h2>
            {taxasFiltradas.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="min-w-full bg-white border border-gray-200">
                  <thead>
                  
(Content truncated due to size limit. Use line ranges to read in chunks)