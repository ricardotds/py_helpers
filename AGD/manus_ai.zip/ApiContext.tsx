import React, { createContext, useContext, useState, ReactNode } from 'react';
import axios from 'axios';

// URL base da API
const API_BASE_URL = 'http://localhost:8000';

// Interface para o contexto da API
interface ApiContextType {
  isLoading: boolean;
  error: string | null;
  lastUpdated: Date | null;
  fetchEmissoes: (dataInicio?: string, dataFim?: string, emissor?: string) => Promise<any>;
  fetchAssembleias: (dataInicio?: string, dataFim?: string, agenteFiduciario?: string) => Promise<any>;
  fetchTaxas: (dataInicio?: string, dataFim?: string, codigo?: string) => Promise<any>;
  fetchEventos: (dataInicio?: string, dataFim?: string, tipoEvento?: string) => Promise<any>;
  fetchStatus: () => Promise<any>;
}

// Criação do contexto
const ApiContext = createContext<ApiContextType | undefined>(undefined);

// Hook personalizado para usar o contexto
export const useApi = () => {
  const context = useContext(ApiContext);
  if (context === undefined) {
    throw new Error('useApi deve ser usado dentro de um ApiProvider');
  }
  return context;
};

// Propriedades do provedor
interface ApiProviderProps {
  children: ReactNode;
}

// Componente provedor
export const ApiProvider: React.FC<ApiProviderProps> = ({ children }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);

  // Função genérica para fazer requisições à API
  const apiRequest = async (endpoint: string, params = {}) => {
    setIsLoading(true);
    setError(null);
    
    try {
      const response = await axios.get(`${API_BASE_URL}${endpoint}`, { params });
      setLastUpdated(new Date());
      return response.data;
    } catch (err) {
      if (axios.isAxiosError(err)) {
        setError(err.response?.data?.detail || 'Erro ao comunicar com a API');
      } else {
        setError('Erro desconhecido ao comunicar com a API');
      }
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  // Funções específicas para cada endpoint
  const fetchEmissoes = (dataInicio?: string, dataFim?: string, emissor?: string) => {
    return apiRequest('/emissoes', { data_inicio: dataInicio, data_fim: dataFim, emissor });
  };

  const fetchAssembleias = (dataInicio?: string, dataFim?: string, agenteFiduciario?: string) => {
    return apiRequest('/assembleias', { data_inicio: dataInicio, data_fim: dataFim, agente_fiduciario: agenteFiduciario });
  };

  const fetchTaxas = (dataInicio?: string, dataFim?: string, codigo?: string) => {
    return apiRequest('/taxas', { data_inicio: dataInicio, data_fim: dataFim, codigo });
  };

  const fetchEventos = (dataInicio?: string, dataFim?: string, tipoEvento?: string) => {
    return apiRequest('/eventos', { data_inicio: dataInicio, data_fim: dataFim, tipo_evento: tipoEvento });
  };

  const fetchStatus = () => {
    return apiRequest('/status');
  };

  // Valor do contexto
  const value = {
    isLoading,
    error,
    lastUpdated,
    fetchEmissoes,
    fetchAssembleias,
    fetchTaxas,
    fetchEventos,
    fetchStatus
  };

  return <ApiContext.Provider value={value}>{children}</ApiContext.Provider>;
};
