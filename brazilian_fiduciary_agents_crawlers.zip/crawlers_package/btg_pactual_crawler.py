"""
BTG Pactual Serviços Financeiros S.A. DTVM Crawler
Crawls documents from BTG Pactual investor relations portal
"""

from typing import List, Optional
from datetime import date
import logging
from urllib.parse import urljoin

from app.crawlers.base_crawler import BaseCrawler, DocumentInfo

logger = logging.getLogger(__name__)


class BTGPactualCrawler(BaseCrawler):
    """Crawler for BTG Pactual Serviços Financeiros S.A. DTVM documents"""
    
    def get_agent_name(self) -> str:
        return "BTG Pactual"
    
    def get_base_url(self) -> str:
        return "https://ri.btgpactual.com"
    
    def discover_documents(self, date_from: Optional[date] = None, 
                          date_to: Optional[date] = None) -> List[DocumentInfo]:
        """Discover all available documents from BTG Pactual"""
        documents = []
        
        try:
            logger.info("Fetching documents from BTG Pactual")
            
            # Try investor relations portal
            ir_url = "https://ri.btgpactual.com"
            response = self.make_request(ir_url)
            
            # Parse documents from the page
            documents = self.parse_documents_page(response.text, ir_url)
            
            # Also try CVM documents section
            cvm_url = "https://ri.btgpactual.com/documentos-cvm/"
            try:
                response = self.make_request(cvm_url)
                cvm_docs = self.parse_documents_page(response.text, cvm_url)
                documents.extend(cvm_docs)
            except Exception as e:
                logger.warning(f"Could not access CVM documents: {str(e)}")
            
        except Exception as e:
            error_msg = f"Failed to discover documents from BTG Pactual: {str(e)}"
            self.errors.append(error_msg)
            logger.error(error_msg)
        
        return documents
    
    def parse_documents_page(self, html: str, source_url: str) -> List[DocumentInfo]:
        """Parse documents from a page"""
        soup = self.parse_html(html)
        documents = []
        
        try:
            # Look for PDF links and document links
            links = soup.find_all('a', href=True)
            
            for link in links:
                href = link.get('href', '')
                link_text = link.get_text(strip=True)
                
                # Check if this looks like a document link
                if self.is_valid_pdf_url(href) or any(keyword in link_text.lower() for keyword in 
                    ['debênture', 'debenture', 'prospecto', 'relatório', 'documento', 'pdf', 'cvm']):
                    
                    # Make URL absolute
                    if href.startswith('/'):
                        href = urljoin(source_url, href)
                    elif not href.startswith('http'):
                        continue
                    
                    # Extract document info
                    doc_name = link_text or href.split('/')[-1]
                    
                    # Try to determine document type
                    doc_type = self.classify_document_type(doc_name, link_text)
                    
                    document = DocumentInfo(
                        company_name="BTG Pactual",
                        asset_code=None,
                        emission_number=None,
                        series=None,
                        document_type=doc_type,
                        document_name=doc_name,
                        download_url=href,
                        document_date=None,
                        file_size=None,
                        last_modified=None,
                        source_url=source_url
                    )
                    
                    documents.append(document)
                    
        except Exception as e:
            logger.error(f"Error parsing documents page: {str(e)}")
        
        return documents

