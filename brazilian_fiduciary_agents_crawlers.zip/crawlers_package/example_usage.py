#!/usr/bin/env python3
"""
Brazilian Fiduciary Agents Crawlers - Usage Example
This example demonstrates how to use the crawlers to discover and download documents.
"""

from pathlib import Path
from datetime import date, timedelta
import logging

# Import all available crawlers
from pentagono_crawler import PentagonoCrawler
from vortx_crawler import VortxCrawler
from oliveira_trust_crawler import OliveiraTrustCrawler
from planner_trustee_crawler import PlannerTrusteeCrawler
from btg_pactual_crawler import BTGPactualCrawler
from brl_trust_crawler import BRLTrustCrawler
from banco_do_brasil_crawler import BancoDoBrasilCrawler
from xp_investimentos_crawler import XPInvestimentosCrawler
from itau_dtvm_crawler import ItauDTVMCrawler

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

def main():
    """Main example function"""
    
    # Set up storage path
    storage_path = Path('./downloaded_documents')
    storage_path.mkdir(exist_ok=True)
    
    # Define date range (last 30 days)
    date_to = date.today()
    date_from = date_to - timedelta(days=30)
    
    # Initialize all crawlers
    crawlers = [
        (1, PentagonoCrawler, "Pentágono S.A. DTVM"),
        (2, VortxCrawler, "Vórtx DTVM Ltda."),
        (3, OliveiraTrustCrawler, "Oliveira Trust DTVM S.A."),
        (4, PlannerTrusteeCrawler, "Planner Trustee DTVM Ltda"),
        (5, BTGPactualCrawler, "BTG Pactual DTVM"),
        (6, BRLTrustCrawler, "BRL Trust DTVM S.A."),
        (7, BancoDoBrasilCrawler, "Banco do Brasil S.A."),
        (8, XPInvestimentosCrawler, "XP Investimentos CCTVM S.A."),
        (9, ItauDTVMCrawler, "Itaú DTVM S.A."),
    ]
    
    total_documents = 0
    
    for agent_id, crawler_class, agent_name in crawlers:
        print(f"\n🔍 Processing {agent_name}...")
        
        try:
            # Initialize crawler
            crawler = crawler_class(
                agent_id=agent_id,
                storage_path=storage_path
            )
            
            # Discover documents
            documents = crawler.discover_documents(
                date_from=date_from,
                date_to=date_to
            )
            
            print(f"   📄 Found {len(documents)} documents")
            
            # Download documents (first 5 for demo)
            downloaded = 0
            for doc in documents[:5]:  # Limit to 5 for demo
                try:
                    result = crawler.download_document(doc)
                    if result:
                        downloaded += 1
                        print(f"   ✅ Downloaded: {doc.document_name}")
                except Exception as e:
                    print(f"   ❌ Failed to download {doc.document_name}: {str(e)}")
            
            print(f"   📥 Downloaded {downloaded} documents")
            total_documents += len(documents)
            
        except Exception as e:
            print(f"   ❌ Error processing {agent_name}: {str(e)}")
    
    print(f"\n🎉 Processing complete!")
    print(f"📊 Total documents discovered: {total_documents}")
    print(f"📁 Documents saved to: {storage_path.absolute()}")


def example_single_crawler():
    """Example using a single crawler"""
    
    print("🔍 Single Crawler Example - Pentágono S.A. DTVM")
    
    # Initialize storage
    storage_path = Path('./pentagono_documents')
    storage_path.mkdir(exist_ok=True)
    
    # Create crawler
    crawler = PentagonoCrawler(
        agent_id=1,
        storage_path=storage_path
    )
    
    # Discover documents
    documents = crawler.discover_documents()
    
    print(f"📄 Found {len(documents)} documents")
    
    # Print document details
    for i, doc in enumerate(documents[:3], 1):  # Show first 3
        print(f"\n📋 Document {i}:")
        print(f"   Name: {doc.document_name}")
        print(f"   Type: {doc.document_type}")
        print(f"   Company: {doc.company_name}")
        print(f"   URL: {doc.download_url}")
        print(f"   Source: {doc.source_url}")


def example_document_filtering():
    """Example showing document filtering and classification"""
    
    print("🔍 Document Filtering Example")
    
    storage_path = Path('./filtered_documents')
    storage_path.mkdir(exist_ok=True)
    
    crawler = PentagonoCrawler(agent_id=1, storage_path=storage_path)
    documents = crawler.discover_documents()
    
    # Filter by document type
    debenture_docs = [doc for doc in documents if 'debenture' in doc.document_type.lower()]
    assembly_docs = [doc for doc in documents if 'assembly' in doc.document_type.lower()]
    
    print(f"📊 Document Classification:")
    print(f"   Total documents: {len(documents)}")
    print(f"   Debenture documents: {len(debenture_docs)}")
    print(f"   Assembly documents: {len(assembly_docs)}")
    
    # Show document types distribution
    doc_types = {}
    for doc in documents:
        doc_types[doc.document_type] = doc_types.get(doc.document_type, 0) + 1
    
    print(f"\n📈 Document Types Distribution:")
    for doc_type, count in sorted(doc_types.items()):
        print(f"   {doc_type}: {count}")


if __name__ == "__main__":
    print("🚀 Brazilian Fiduciary Agents Crawlers - Usage Examples")
    print("=" * 60)
    
    # Run examples
    try:
        example_single_crawler()
        print("\n" + "=" * 60)
        
        example_document_filtering()
        print("\n" + "=" * 60)
        
        # Uncomment to run full crawler suite (may take time)
        # main()
        
    except KeyboardInterrupt:
        print("\n⏹️  Execution interrupted by user")
    except Exception as e:
        print(f"\n❌ Error: {str(e)}")
    
    print("\n✅ Examples completed!")

