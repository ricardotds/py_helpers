"""
Planner Trustee DTVM Ltda Crawler
Crawls documents from Planner Trustee DTVM fiduciary portal
"""

from typing import List, Optional
from datetime import date
import logging
from urllib.parse import urljoin

from app.crawlers.base_crawler import BaseCrawler, DocumentInfo

logger = logging.getLogger(__name__)


class PlannerTrusteeCrawler(BaseCrawler):
    """Crawler for Planner Trustee DTVM Ltda documents"""
    
    def get_agent_name(self) -> str:
        return "Planner Trustee"
    
    def get_base_url(self) -> str:
        return "https://www.trusteedtvm.com.br"
    
    def discover_documents(self, date_from: Optional[date] = None, 
                          date_to: Optional[date] = None) -> List[DocumentInfo]:
        """Discover all available documents from Planner Trustee"""
        documents = []
        
        try:
            logger.info("Fetching documents from Planner Trustee")
            
            # Try main website
            main_url = f"{self.get_base_url()}/"
            response = self.make_request(main_url)
            
            # Parse documents from the page
            documents = self.parse_documents_page(response.text, main_url)
            
            # Also try fiduciary portal
            fiduciary_url = "https://fiduciario.com.br/debentures/"
            try:
                response = self.make_request(fiduciary_url)
                fiduciary_docs = self.parse_documents_page(response.text, fiduciary_url)
                documents.extend(fiduciary_docs)
            except Exception as e:
                logger.warning(f"Could not access fiduciary portal: {str(e)}")
            
        except Exception as e:
            error_msg = f"Failed to discover documents from Planner Trustee: {str(e)}"
            self.errors.append(error_msg)
            logger.error(error_msg)
        
        return documents
    
    def parse_documents_page(self, html: str, source_url: str) -> List[DocumentInfo]:
        """Parse documents from a page"""
        soup = self.parse_html(html)
        documents = []
        
        try:
            # Look for PDF links and document links
            links = soup.find_all('a', href=True)
            
            for link in links:
                href = link.get('href', '')
                link_text = link.get_text(strip=True)
                
                # Check if this looks like a document link
                if self.is_valid_pdf_url(href) or any(keyword in link_text.lower() for keyword in 
                    ['debênture', 'debenture', 'prospecto', 'relatório', 'documento', 'pdf']):
                    
                    # Make URL absolute
                    if href.startswith('/'):
                        href = urljoin(self.get_base_url(), href)
                    elif not href.startswith('http'):
                        continue
                    
                    # Extract document info
                    doc_name = link_text or href.split('/')[-1]
                    
                    # Try to determine document type
                    doc_type = self.classify_document_type(doc_name, link_text)
                    
                    document = DocumentInfo(
                        company_name="Planner Trustee",
                        asset_code=None,
                        emission_number=None,
                        series=None,
                        document_type=doc_type,
                        document_name=doc_name,
                        download_url=href,
                        document_date=None,
                        file_size=None,
                        last_modified=None,
                        source_url=source_url
                    )
                    
                    documents.append(document)
                    
        except Exception as e:
            logger.error(f"Error parsing documents page: {str(e)}")
        
        return documents

